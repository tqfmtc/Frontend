# Parcera MVP: 3-Week Ordering Experience

**Timeline**: 3 weeks (15 working days)
**Focus**: Complete ordering experience from menu discovery to order confirmation
**Scope**: Ordering channels only (IVR + Mobile Web), NO fulfillment/kitchen operations
**Target**: 3-5 pilot restaurants for initial launch

---

## Executive Summary

This MVP delivers a complete ordering experience that allows restaurants to accept orders via AI-powered phone (IVR) and mobile web, with menu synchronization from incumbent POS (Toast), AI knowledge base to prevent hallucination, and basic business dashboard for order visibility. The scope respects the incumbent POS for fulfillment operations and focuses exclusively on the ordering layer.

**Key Value Propositions**:
1. **Eliminate duplicate menu entry**: Toast POS menu syncs automatically to Parcera
2. **AI-powered ordering**: Olivia voice assistant handles phone orders naturally
3. **Multi-channel orders**: Phone (IVR) + Mobile web capture all customer preferences
4. **Zero hallucination**: AI Knowledge Base ensures accurate responses to customer questions
5. **Seasonal marketing**: Enable/disable seasonal items automatically (Halloween, holidays)

---

## In-Scope Specifications

### **Core Foundation (Week 1)**

#### **SPEC 001 - Tenant & Restaurant Management** (Minimal Implementation)

**Included**:
- Single restaurant onboarding flow
- Basic business profile: name, address, phone, hours of operation
- Single location setup
- Owner account creation

**Excluded** (Post-MVP):
- Multi-location support
- Franchise hierarchies
- Staff/role management (single owner only)
- Location groups
- Business insights on onboarding dashboard

**Acceptance Criteria**:
- Restaurant owner completes onboarding in <30 minutes
- Business profile persisted and accessible across all ordering channels

**User Stories**: User Story 1 (Single Restaurant Onboarding) - Priority P0

---

#### **SPEC 002 - Menu Management** (Core Features + AI Knowledge Base + Seasonal Items)

**Included**:
- Manual menu creation: categories, items, prices, descriptions
- Item customization: sizes (S/M/L with different prices), modifiers (add-ons with pricing)
- Min/max selection rules for modifiers
- Item availability toggle (available, sold out)
- **User Story 8 - Seasonal Items**: Date-based auto-enable/disable (Halloween specials, holiday items)
- **User Story 9 - AI Knowledge Base**: Capture unanswered questions, owner adds answers, AI uses KB to respond (prevents hallucination)

**Excluded** (Post-MVP):
- OCR menu upload (manual entry only for MVP)
- Location-specific pricing (single location only)
- Time-based availability (breakfast/lunch/dinner menus)
- Ingredient tracking and dietary filters

**Acceptance Criteria**:
- Owner creates 20+ item menu in <45 minutes manually
- Seasonal items auto-enable on start date, auto-disable on end date
- AI Knowledge Base answers 80% of common non-menu questions (hours, delivery, parking)
- AI responds "Let me connect you with staff" when information not in menu or KB (0% hallucination)

**User Stories**:
- User Story 2 (Manual Menu Creation) - Priority P0
- User Story 3 (Item Customization with Sizes & Modifiers) - Priority P1
- User Story 8 (Seasonal Menu Items) - Priority P2
- User Story 9 (AI Knowledge Base & FAQ Harvesting) - Priority P1

**Functional Requirements**: FR-004 to FR-007 (manual menu), FR-009 to FR-010 (modifiers), FR-018 (sold out), FR-029 to FR-039 (seasonal), FR-040 to FR-059 (AI KB)

---

#### **SPEC 028 - POS Menu Synchronization** (Toast Only, One-Way Sync)

**Included**:
- **POS → Parcera sync only** (one direction)
- **Toast POS integration only** (defer Square, Clover, others)
- Polling-based sync (15-minute intervals)
- AI diff detection with confidence scoring
- Auto-apply changes with ≥90% confidence (new items, price changes, availability)
- Manual review queue for ambiguous changes (<90% confidence)
- Side-by-side comparison for flagged changes
- Basic sync history log (last 30 days)

**Excluded** (Post-MVP):
- Reverse sync (Parcera → POS)
- Multi-platform support (Square, Clover, Shopify, Lightspeed, NCR Aloha)
- Real-time webhook sync (polling sufficient for MVP)
- Conflict resolution strategies (default "POS Wins" only)
- Comprehensive sync history dashboard with filters/export
- Rollback capability
- Conservative/Aggressive modes

**Acceptance Criteria**:
- Toast menu syncs to Parcera within 15 minutes of POS change
- AI achieves ≥90% confidence on 80% of detected changes
- 0% data loss (all changes either applied or flagged for review)
- Manual review queue shows <10% of changes (indicates high AI accuracy)
- Sync accuracy ≥99% (no duplicates, mismatches, or corruption)

**User Stories**:
- User Story 1 (POS-to-Parcera Auto Sync with AI Diff Detection) - Priority P0
- User Story 2 (Ambiguous Change Detection with Manual Review) - Priority P0

**Functional Requirements**: FR-001 to FR-015 (inbound sync), FR-044 to FR-045 (basic logging), FR-052 to FR-054 (manual review queue)

---

### **Ordering Channels (Week 2)**

#### **SPEC 003 - IVR Phone Ordering** (Core Conversation Flow)

**Included**:
- Olivia AI voice assistant (conversational AI)
- Restaurant selection (single location for MVP, foundation for multi-location)
- Menu discovery via voice ("What pizzas do you have?")
- Item ordering with modifiers ("Large pepperoni pizza, extra cheese")
- Cart management (add items, review order)
- Payment collection (card-on-file via voice)
- Order confirmation (read back order, total, estimated time)
- AI Knowledge Base integration (answer "What are your hours?", "Do you deliver?")
- Basic error handling (item not available, invalid input)

**Excluded** (Post-MVP):
- Multi-location selection
- Order modification after placement
- Complex dietary filtering ("Show me only vegan items")
- Voice authentication for account access
- Order history retrieval
- Promotional code application
- Advanced conversation features (contextual memory beyond single session)

**Acceptance Criteria**:
- Customer places complete order via phone in <3 minutes (simple order: 1-2 items)
- AI correctly captures 95% of item names and modifiers
- AI uses Knowledge Base to answer 80% of non-menu questions accurately
- AI says "Let me connect you with staff" when information unavailable (no hallucination)
- Payment collection succeeds in 95% of attempts
- Order confirmation read back matches cart contents

**User Stories**:
- User Story 1 (Simple Voice Order Placement) - Priority P0
- User Story 2 (Voice-Driven Menu Discovery) - Priority P1
- User Story 4 (AI Knowledge Base Integration for Common Questions) - Priority P1

**Functional Requirements**: FR-001 to FR-004 (voice recognition), FR-005 to FR-008 (menu discovery), FR-009 to FR-012 (order placement), FR-013 to FR-015 (payment), FR-016 to FR-019 (confirmation), FR-044 to FR-047 (AI KB integration)

---

#### **SPEC 005 - Mobile/Web Ordering** (Responsive Web App, Guest Checkout Only)

**Included**:
- Mobile-responsive web application (works on phones, tablets, desktop)
- Restaurant selection page (single location for MVP)
- Menu browsing with category navigation
- Item detail view with description, price, modifiers
- Item customization: size selection, modifier selection (checkboxes/radio buttons)
- Shopping cart with add/remove/edit
- Guest checkout (no login required)
- Payment via Stripe (card entry)
- Order confirmation screen with order number
- Basic order status display (Received → Preparing → Ready)

**Excluded** (Post-MVP):
- Native mobile apps (iOS, Android)
- User account creation and login
- Saved payment methods (guest checkout only)
- Order history for customers
- Saved addresses
- Loyalty program integration
- Dietary filters (vegan, gluten-free)
- Item search functionality
- Favorites/reorder
- Social sharing

**Acceptance Criteria**:
- Customer completes order on mobile web in <2 minutes (simple order)
- Menu loads in <2 seconds
- Cart persists during session (survives page refresh)
- Checkout flow <30 seconds from cart to confirmation
- Mobile-responsive design works on devices 320px width and up
- Payment success rate ≥95%

**User Stories**:
- User Story 1 (Guest Checkout & First-Time Ordering) - Priority P0
- User Story 2 (Menu Browsing & Item Customization) - Priority P0
- User Story 5 (Mobile-First Responsive Design) - Priority P0

**Functional Requirements**: FR-001 to FR-003 (restaurant selection), FR-004 to FR-009 (menu browsing), FR-010 to FR-017 (item customization), FR-018 to FR-025 (cart management), FR-038 to FR-045 (guest checkout), FR-046 to FR-051 (payment), FR-052 to FR-055 (confirmation)

---

### **Order Processing (Week 2-3)**

#### **SPEC 007 - Order Management & Workflow** (Simplified Flow)

**Included**:
- Order intake from IVR and Mobile channels
- Order number generation (unique per restaurant)
- Basic order status progression: Received → Preparing → Ready
- Order confirmation to customer (SMS)
- Kitchen notification to restaurant staff (email + SMS)
- Order details view for restaurant owner (dashboard)
- Manual status updates by restaurant staff (mark as Preparing, Ready)

**Excluded** (Post-MVP):
- Advanced workflow customization (configurable steps per restaurant)
- Order modification after placement
- Order cancellation (customer-initiated)
- Refund processing
- KDS integration (kitchen display system)
- Automated status transitions
- Estimated ready time calculation
- Customer notification when order ready
- Order assignment to staff

**Acceptance Criteria**:
- Order received by restaurant within 30 seconds of customer confirmation
- SMS notification sent to customer within 10 seconds
- Email + SMS sent to restaurant staff within 30 seconds
- Restaurant owner can view all today's orders in dashboard
- Status updates reflect in customer-facing order tracking within 10 seconds

**User Stories**:
- User Story 1 (Basic Order Intake & Confirmation) - Priority P0
- User Story 2 (Manual Order Status Updates) - Priority P1

**Functional Requirements**: FR-001 to FR-006 (order intake), FR-007 to FR-011 (order confirmation), FR-012 to FR-016 (status management), FR-017 to FR-020 (notifications)

---

#### **SPEC 008 - Payment Processing** (Stripe Only)

**Included**:
- Stripe integration (card payments)
- One-time card payments (guest checkout)
- Card-on-file for IVR (tokenization via voice)
- Payment confirmation
- Payment failure handling (retry, error messages)
- Basic payment security (PCI compliance via Stripe)

**Excluded** (Post-MVP):
- Multiple payment methods (Apple Pay, Google Pay, PayPal, cash)
- Split payments (multiple cards)
- Tip collection
- Refund processing
- Saved payment methods (customer accounts)
- Payment installments
- Gift cards
- Store credit

**Acceptance Criteria**:
- Payment processing completes in <5 seconds
- Payment success rate ≥95%
- Payment failures show clear error messages to customer
- Failed payments do not create orders
- All payment data handled securely via Stripe (no card data stored by Parcera)

**User Stories**:
- User Story 1 (One-Time Card Payment via Stripe) - Priority P0
- User Story 2 (Card-on-File for IVR Voice Ordering) - Priority P1

**Functional Requirements**: FR-001 to FR-005 (Stripe integration), FR-006 to FR-010 (payment processing), FR-011 to FR-014 (error handling), FR-015 to FR-017 (security)

---

### **Business Visibility (Week 3)**

#### **SPEC 016 - Sales Portal & Business Dashboard** (Minimal Implementation)

**Included**:
- Login for restaurant owner
- Today's orders dashboard (list view)
- Order details view (items, modifiers, customer info, payment status, order status)
- Basic sales totals: today's revenue, order count
- Menu management UI (add/edit/delete items, categories, modifiers)
- Item availability toggle (mark sold out)
- POS sync status indicator (last sync time, sync errors)
- Manual review queue for POS sync (approve/reject ambiguous changes)

**Excluded** (Post-MVP):
- Analytics and reporting (revenue trends, popular items, peak hours)
- Multi-location dashboard
- Date range filtering (today only for MVP)
- Staff management interface
- Customer database view
- Promotional campaign management
- Inventory tracking
- Export functionality (CSV, PDF reports)

**Acceptance Criteria**:
- Owner logs in and sees today's orders within 2 seconds
- All orders from IVR and Mobile appear in unified dashboard
- Order details show complete information (items, customer, payment, status)
- Owner can add/edit menu items and changes reflect in ordering channels within 30 seconds
- POS sync errors flagged prominently with actionable resolution steps

**User Stories**:
- User Story 1 (Today's Orders Dashboard) - Priority P0
- User Story 2 (Menu Management UI) - Priority P1
- User Story 6 (POS Sync Status & Manual Review) - Priority P1

**Functional Requirements**: FR-001 to FR-005 (authentication), FR-006 to FR-013 (orders dashboard), FR-014 to FR-021 (menu management UI), FR-034 to FR-037 (POS sync status)

---

### **Infrastructure (Throughout All 3 Weeks)**

#### **SPEC 014 - Multi-Tenant Architecture** (Foundation)

**Included**:
- Tenant isolation (schema-per-tenant OR row-level security with tenant_id)
- Restaurant data isolation (menu, orders, customers scoped to tenant)
- Basic authentication and authorization (owner access only)
- Secure API endpoints (JWT tokens or session-based)

**Excluded** (Post-MVP):
- Advanced tenant management (white-labeling, custom domains)
- Tenant-level feature flags
- Tenant analytics
- Cross-tenant reporting (for platform operators)
- Multi-tenant billing

**Acceptance Criteria**:
- Restaurant A cannot access Restaurant B's data
- All API endpoints enforce tenant isolation
- Menu, orders, and customer data properly scoped to owning restaurant
- No data leakage between tenants (verified via security testing)

**User Stories**:
- User Story 1 (Tenant Isolation for Restaurant Data) - Priority P0

**Functional Requirements**: FR-001 to FR-006 (tenant isolation), FR-007 to FR-010 (data scoping), FR-011 to FR-014 (security)

---

#### **SPEC 019 - Notifications & Alerts** (Basic SMS + Email)

**Included**:
- SMS order confirmations to customers (via Twilio or similar)
- SMS order notifications to restaurant staff (new order received)
- Email order notifications to restaurant staff (detailed order info)
- Basic notification templates (order confirmation, new order alert)

**Excluded** (Post-MVP):
- Complex notification preferences (per-channel opt-in/out)
- In-app notifications
- Push notifications (mobile apps)
- Notification history/log
- Delivery status tracking notifications
- Marketing notifications
- Scheduled notifications

**Acceptance Criteria**:
- SMS confirmation sent to customer within 10 seconds of order placement
- SMS + Email sent to restaurant staff within 30 seconds of new order
- 95% delivery success rate for SMS and email
- Notifications contain accurate order details (items, total, order number)

**User Stories**:
- User Story 1 (Order Confirmation SMS to Customer) - Priority P0
- User Story 2 (New Order Alerts to Restaurant Staff) - Priority P0

**Functional Requirements**: FR-001 to FR-004 (SMS integration), FR-005 to FR-008 (email integration), FR-009 to FR-012 (notification templates)

---

## Out-of-Scope Specifications (Post-MVP)

The following specifications are **explicitly excluded** from the 3-week MVP and will be addressed in subsequent releases:

### **Deferred Ordering Features**

❌ **SPEC 004 - Kiosk Ordering**: Can be added after mobile web is working (similar UI, larger screen)
❌ **SPEC 006 - Customer Accounts & Loyalty**: Guest checkout sufficient for MVP
❌ **SPEC 020 - Advanced Search & Filtering**: Simple menu browsing sufficient

### **Deferred Operations & Fulfillment**

❌ **SPEC 009 - Kitchen Order Routing**: Simple SMS/Email notifications sufficient for MVP
❌ **SPEC 010 - Inventory Management**: Manual stock management for MVP
❌ **SPEC 021 - Order Fulfillment & Kitchen Operations**: Out of scope (incumbent POS handles this)
❌ **SPEC 024 - Kitchen Display System (KDS)**: Out of scope per user instruction
❌ **SPEC 025 - POS Tablet Interface**: Out of scope per user instruction
❌ **SPEC 026 - Table Management & Reservations**: Out of scope per user instruction
❌ **SPEC 027 - Delivery Management & Driver Dispatch**: Out of scope per user instruction

### **Deferred Business Features**

❌ **SPEC 011 - Promotions & Discounts**: No promotions in MVP
❌ **SPEC 012 - Multi-Location Management**: Single location only for MVP
❌ **SPEC 013 - Staff & Roles Management**: Single owner account only
❌ **SPEC 015 - Customer Support Tools**: Manual support for MVP
❌ **SPEC 017 - Analytics & Reporting**: Basic sales totals sufficient
❌ **SPEC 018 - Integrations Hub**: Toast POS only, other integrations deferred

---

## 3-Week Sprint Breakdown

### **Week 1: Foundation & Menu Setup** (Days 1-5)

**Objectives**: Restaurant can onboard, create/sync menu, configure AI Knowledge Base

**Day 1-2: Core Infrastructure**
- Multi-tenant architecture setup (schema-per-tenant or row-level security)
- Restaurant onboarding flow (business profile, location, hours)
- Owner authentication (login/signup)
- Database schema for tenants, restaurants, locations

**Day 3-4: Menu Management**
- Manual menu creation UI (categories, items, prices)
- Item customization: sizes, modifiers with pricing rules
- Seasonal items configuration (start/end dates, badge text)
- Item availability toggle (sold out)

**Day 5: Toast POS Sync Foundation**
- Toast API integration (OAuth, menu endpoint discovery)
- Polling scheduler (every 15 minutes)
- AI diff detection (change categorization: new item, price change, availability)
- Confidence scoring (≥90% auto-apply, <90% flag for review)

**Week 1 Deliverables**:
- ✅ Restaurant owner completes onboarding in <30 minutes
- ✅ Owner creates 20-item menu manually OR syncs from Toast
- ✅ Seasonal items configured (auto-enable/disable on dates)
- ✅ Toast menu changes detected and auto-applied (high confidence) or flagged (low confidence)

---

### **Week 2: Ordering Channels & Payment** (Days 6-10)

**Objectives**: Customers can order via phone (IVR) and mobile web, pay with card

**Day 6-7: IVR Phone Ordering**
- Olivia AI voice assistant integration
- Voice menu browsing ("What pizzas do you have?")
- Item ordering with modifiers via voice
- Cart management (add, review order)
- AI Knowledge Base integration (answer hours, delivery, parking questions)

**Day 8: Mobile Web Ordering**
- Mobile-responsive menu browsing UI
- Category navigation, item detail views
- Item customization UI (size radio buttons, modifier checkboxes)
- Shopping cart (add/edit/remove items)

**Day 9: Payment Processing**
- Stripe integration (card tokenization, payment processing)
- Guest checkout flow (no account required)
- Card-on-file for IVR (voice payment collection)
- Payment confirmation screens

**Day 10: Order Intake & Workflow**
- Order creation from IVR and Mobile channels
- Order number generation
- Basic status progression: Received → Preparing → Ready
- Manual status update by restaurant staff

**Week 2 Deliverables**:
- ✅ Customer orders via phone (IVR) in <3 minutes
- ✅ Customer orders via mobile web in <2 minutes
- ✅ Payment processed successfully via Stripe
- ✅ Order confirmation displayed/spoken to customer
- ✅ AI Knowledge Base answers 80% of non-menu questions

---

### **Week 3: Notifications, Dashboard & Polish** (Days 11-15)

**Objectives**: Restaurant receives orders, owner has visibility, system is polished and tested

**Day 11: Notifications**
- SMS order confirmation to customer (Twilio integration)
- SMS + Email new order alerts to restaurant staff
- Notification templates (order summary, items, total)

**Day 12-13: Sales Portal & Business Dashboard**
- Owner login to business portal
- Today's orders dashboard (list view with filters)
- Order details view (items, customer, payment status)
- Basic sales totals (today's revenue, order count)
- Menu management UI (edit items, mark sold out)

**Day 14: POS Sync Manual Review**
- Manual review queue UI (side-by-side comparison)
- Approve/reject/modify AI-suggested changes
- Sync history log (last 30 days, basic)
- POS sync status indicator on dashboard

**Day 15: Testing, Bug Fixes, Polish**
- End-to-end testing (IVR order flow, Mobile web order flow)
- Payment testing (success, failure scenarios)
- POS sync testing (various change types)
- UI polish (mobile responsiveness, error messages)
- Load testing (10 concurrent orders)

**Week 3 Deliverables**:
- ✅ Order notifications sent to customer and staff within 30 seconds
- ✅ Owner sees all orders in dashboard with accurate totals
- ✅ POS sync manual review queue functional
- ✅ All critical bugs fixed
- ✅ System ready for pilot launch

---

## Success Metrics for MVP Launch

### **Customer Experience Metrics**

| Metric | Target | Measurement |
|--------|--------|-------------|
| IVR order completion time | <3 minutes | Average time from call start to confirmation |
| Mobile web order completion time | <2 minutes | Average time from landing to confirmation |
| AI Knowledge Base accuracy | 80% correct answers | % of non-menu questions answered accurately |
| AI hallucination rate | 0% | % of responses where AI invents information |
| Payment success rate | ≥95% | % of payment attempts that succeed |
| Order confirmation delivery | <10 seconds | Time from order placement to SMS confirmation |

### **Restaurant Owner Experience Metrics**

| Metric | Target | Measurement |
|--------|--------|-------------|
| Onboarding completion time | <30 minutes | Time from signup to first menu ready |
| Menu creation time (manual) | <45 minutes for 20 items | Time to manually create complete menu |
| POS sync accuracy | ≥99% | % of synced changes applied correctly |
| POS sync latency | <15 minutes | Time from Toast change to Parcera update |
| Order notification delivery | <30 seconds | Time from order placement to staff alert |
| Dashboard load time | <2 seconds | Time to load today's orders view |

### **Technical Performance Metrics**

| Metric | Target | Measurement |
|--------|--------|-------------|
| API response time (p95) | <500ms | 95th percentile API latency |
| Menu page load time | <2 seconds | Time to interactive on mobile |
| System uptime | ≥99.5% | % of time system available |
| Data loss rate | 0% | Orders, payments, menu changes |
| Security incidents | 0 | Data breaches, unauthorized access |

### **Business Metrics (Pilot Phase)**

| Metric | Target | Measurement |
|--------|--------|-------------|
| Pilot restaurants onboarded | 3-5 restaurants | Count of active restaurants |
| Orders processed per day | 20+ orders/day (across all pilots) | Daily order volume |
| Channel distribution | 60% mobile, 40% IVR | % of orders by channel |
| Menu sync adoption | 80% use Toast sync | % of restaurants using POS sync vs manual |
| Customer satisfaction | 4.0+ stars | Post-order survey rating |

---

## Key Trade-offs & Rationale

### **1. Single POS Platform (Toast Only)**

**Trade-off**: Support only Toast POS, defer Square, Clover, Shopify, Lightspeed, NCR Aloha

**Rationale**:
- Toast represents ~30-40% of target restaurant market (QSR, fast casual)
- Unified platform allows deeper integration testing
- Multi-platform support adds 2-3 weeks of complexity (API normalization, platform adapters)
- Can expand to Square (#2 market share) in post-MVP Phase 2

**Risk Mitigation**: Architecture designed for multi-platform (POSPlatformAdapter entity, normalization layer), easy to add platforms later

---

### **2. One-Way Sync (POS → Parcera Only)**

**Trade-off**: No reverse sync (Parcera → POS), menu changes in Parcera don't push to Toast

**Rationale**:
- Primary workflow: restaurant manages menu in existing POS (Toast), changes flow to Parcera
- Reverse sync adds bidirectional conflict resolution complexity
- Seasonal items & AI Knowledge Base are Parcera-exclusive features (not synced to POS)
- Reduces risk of corrupting POS data during MVP

**Risk Mitigation**: Manual update notification if owner changes menu in Parcera ("Update Toast manually: Burger $10 → $11")

---

### **3. Polling (15-Min Intervals), No Webhooks**

**Trade-off**: Menu changes appear in Parcera within 15 minutes (polling) instead of real-time (webhooks)

**Rationale**:
- 15-minute sync delay acceptable for menu changes (prices, availability, new items rarely change mid-service)
- Webhook setup adds infrastructure complexity (endpoint security, signature validation, retry logic)
- Polling is simpler to implement and test
- Reduces dependency on POS platform webhook reliability

**Risk Mitigation**: "Sync Now" button for manual immediate sync if owner needs urgent update

---

### **4. Guest Checkout Only (No Customer Accounts)**

**Trade-off**: Customers cannot create accounts, save payment methods, view order history

**Rationale**:
- Guest checkout reduces friction (faster first order, no signup barrier)
- Account management adds 1-2 weeks (authentication, password reset, profile management, saved addresses)
- Order history not critical for MVP (restaurants primarily QSR, fast casual with one-time orders)
- Loyalty program requires accounts but deferred to post-MVP

**Risk Mitigation**: Foundation for accounts exists (can add User entity, authentication in Phase 2)

---

### **5. Manual Menu Creation (No OCR Upload)**

**Trade-off**: Restaurant owner types menu manually instead of uploading menu photo/PDF for OCR extraction

**Rationale**:
- OCR adds 3-5 days (OCR service integration, GenAI post-processing, review UI)
- Toast POS sync covers 80% of use case (menu already exists in POS)
- Manual entry acceptable for pilot phase (3-5 restaurants, owner invests time)
- OCR accuracy <100%, still requires manual review

**Risk Mitigation**: Toast POS sync reduces manual entry need; OCR can be added in Phase 2 for non-POS restaurants

---

### **6. Basic Order Workflow (Received → Preparing → Ready)**

**Trade-off**: Simplified 3-state workflow instead of configurable multi-step workflows per restaurant

**Rationale**:
- Configurable workflows add complexity (workflow builder UI, step validation, conditional logic)
- 3-state workflow covers 90% of QSR/fast casual use cases
- Advanced workflows (Order → Pay → Kitchen → Deliver → Complete) require table management, delivery dispatch (out of scope)
- Restaurant staff manually updates status (no automated transitions in MVP)

**Risk Mitigation**: Workflow engine foundation exists (can add configurable steps in SPEC 023 post-MVP)

---

### **7. Single Location Only**

**Trade-off**: Multi-location chains cannot manage multiple branches in MVP

**Rationale**:
- Multi-location adds complexity (location selector UI, base menu inheritance, location-specific pricing)
- Pilot phase targets single-location restaurants (easier onboarding, simpler testing)
- Single-location architecture foundation supports multi-location expansion (location_id foreign key exists)

**Risk Mitigation**: Data model supports locations (Location entity, menu.location_id), can add UI in Phase 2

---

### **8. SMS/Email Notifications (No Push, In-App)**

**Trade-off**: Notifications via SMS and email only, no push notifications or in-app alerts

**Rationale**:
- Push notifications require native mobile apps (iOS, Android) - out of scope for web-only MVP
- In-app notifications require persistent WebSocket connections (adds infrastructure complexity)
- SMS + Email cover restaurant staff (no app required) and customers (universal channels)

**Risk Mitigation**: Notification service abstraction allows adding push/in-app channels in Phase 2

---

## Dependencies & Risks

### **Critical Dependencies**

| Dependency | Type | Mitigation |
|------------|------|------------|
| **Toast POS API Access** | External | Obtain sandbox credentials early (Week 1, Day 1); fallback to manual menu if API unavailable |
| **Stripe Payment Processing** | External | Setup Stripe test account immediately; minimal API surface (charges, tokens) |
| **Twilio SMS Service** | External | Twilio has 99.95% uptime SLA; fallback to email-only if SMS fails |
| **AI Voice Assistant (Olivia)** | Internal/External | If custom-built, allocate 40% of Week 2; if third-party (Voiceflow, Parloa), integrate early |
| **Semantic Similarity Matching (AI KB)** | External | Use OpenAI Embeddings API or Azure Cognitive Search; fallback to exact text match if unavailable |

### **Technical Risks**

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| **Toast API rate limiting** | Medium | High | Implement exponential backoff, cache menu data locally, poll every 15min (not every 1min) |
| **AI voice recognition accuracy <95%** | Medium | High | Test with real restaurant menus early; provide fallback to "speak to staff" for complex orders |
| **Payment processing failures >5%** | Low | Critical | Use Stripe's production-grade infrastructure; implement retry logic, clear error messages |
| **Multi-tenant data leakage** | Low | Critical | Security audit Week 1, automated tests for tenant isolation, row-level security policies |
| **POS sync creates duplicate menu items** | Medium | Medium | AI similarity matching (>85% = rename, not new); flag ambiguous for manual review |
| **Mobile web performance on slow networks** | Medium | Medium | Optimize bundle size, lazy load images, cache menu data locally (service worker) |

### **Organizational Risks**

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| **Pilot restaurants unavailable for testing** | Medium | High | Recruit 5-7 candidates, ensure 3-5 commit; provide incentive (free service for 3 months) |
| **Scope creep (requests for features outside MVP)** | High | Medium | Lock scope after Week 1 planning; document requests for Phase 2 backlog |
| **Resource constraints (team capacity)** | Medium | High | Ruthlessly prioritize P0 features; cut P2 features (seasonal items, sync history) if timeline slips |
| **Integration delays (Toast API approval)** | Low | High | Apply for API access Week 0 (pre-sprint); use sandbox for development |

---

## Go-Live Checklist

### **Week 3, Day 15: Pre-Launch Validation**

#### **Functional Testing**

- [ ] **IVR Ordering**: Place 10 test orders via phone (simple, complex, with modifiers)
- [ ] **Mobile Web Ordering**: Place 10 test orders on mobile devices (iOS Safari, Android Chrome)
- [ ] **Payment Processing**: Test successful payment, declined card, expired card, network timeout
- [ ] **POS Sync**: Make 20 changes in Toast (new items, price updates, sold out, deletions), verify sync accuracy
- [ ] **AI Knowledge Base**: Ask 20 common questions ("hours?", "delivery?", "parking?"), verify 80% accuracy, 0% hallucination
- [ ] **Notifications**: Verify SMS to customer, Email + SMS to staff, check delivery times <30 seconds
- [ ] **Dashboard**: View orders, verify totals, update menu, mark items sold out, review POS sync queue

#### **Performance Testing**

- [ ] **Load Test**: 10 concurrent orders (5 IVR, 5 mobile web) complete successfully
- [ ] **API Latency**: p95 response time <500ms for menu load, cart operations, checkout
- [ ] **Menu Page Load**: Mobile web menu loads in <2 seconds on 4G network
- [ ] **Dashboard Load**: Today's orders dashboard loads in <2 seconds with 50 orders

#### **Security Testing**

- [ ] **Tenant Isolation**: Restaurant A cannot access Restaurant B's menu, orders, or customer data
- [ ] **Authentication**: Unauthorized access to dashboard blocked, session timeout enforced
- [ ] **Payment Security**: No card data stored by Parcera, all handled via Stripe tokenization
- [ ] **API Security**: JWT tokens validated, rate limiting enforced, SQL injection prevented

#### **User Acceptance Testing (Pilot Restaurants)**

- [ ] **Onboarding**: 3 restaurant owners complete onboarding in <30 minutes, create menu or sync from Toast
- [ ] **Real Orders**: Each pilot restaurant receives 5+ real orders (mix of IVR, mobile web)
- [ ] **Owner Feedback**: Dashboard usability, notification usefulness, POS sync reliability
- [ ] **Customer Feedback**: Order experience, AI voice clarity, mobile web usability

#### **Operational Readiness**

- [ ] **Monitoring**: Application logs, error tracking (Sentry, Datadog), uptime monitoring (Pingdom, UptimeRobot)
- [ ] **Support Runbook**: Documented procedures for common issues (payment failure, POS sync error, notification not sent)
- [ ] **Escalation Plan**: On-call engineer designated, contact info shared with pilot restaurants
- [ ] **Backup Plan**: Manual order fallback (phone call to restaurant) if system down

---

## Post-MVP Phase 2 Roadmap (Weeks 4-8)

Once MVP is live with 3-5 pilot restaurants and validated, prioritize these features based on feedback:

### **High Priority (Weeks 4-5)**

1. **Order Display & Monitoring** (SPEC 029) - **NEW from Transcript**
   - Web-based real-time order display for restaurant staff
   - Shows orders from Parcera channels (IVR, Mobile, Kiosk)
   - Auto-refresh, filtering by status/channel/time
   - Multi-device support (kitchen monitor, expo tablet, front desk)
   - Read-only monitoring (NOT full KDS)
   - Complements email/SMS notifications with centralized view

2. **Customer Accounts & Order History** (SPEC 006)
   - Account creation with email/password
   - Order history for logged-in customers
   - Saved addresses (delivery)
   - Saved payment methods

3. **Kiosk Ordering** (SPEC 004)
   - Reuse mobile web UI on larger screens (tablets, kiosks)
   - Touch-optimized navigation
   - Visual menu with images

4. **Reverse POS Sync** (SPEC 028 - User Story 3)
   - Parcera → Toast menu updates
   - Seasonal items sync to POS (if supported)
   - Conflict resolution (POS Wins, Parcera Wins, Manual)

### **Medium Priority (Weeks 6-7)**

5. **Multi-Platform POS Support** (SPEC 028 - User Story 6)
   - Square POS integration
   - Clover POS integration
   - Unified sync engine for all platforms

6. **Analytics & Reporting** (SPEC 017)
   - Revenue trends (daily, weekly, monthly)
   - Popular items report
   - Peak hours analysis
   - Channel performance (IVR vs Mobile vs Kiosk)

7. **Promotions & Discounts** (SPEC 011)
   - Percentage-off promotions
   - BOGO (Buy One Get One)
   - Promo codes
   - Time-limited offers

### **Low Priority (Week 8+)**

1. **Multi-Location Management** (SPEC 012)
   - Base menu inheritance
   - Location-specific pricing
   - Location selector for customers

2. **Order Modification & Cancellation** (SPEC 007 - deferred features)
   - Edit order after placement (before kitchen starts)
   - Cancel order with refund
   - Order status notifications to customer

3. **Advanced AI Features**
   - Time-based menu availability (breakfast/lunch/dinner menus)
   - Dietary filtering (vegan, gluten-free, nut-free)
   - Contextual conversation memory (IVR)

---

## Appendix: Technical Architecture Summary

### **System Components (MVP)**

```
┌─────────────────────────────────────────────────────────────┐
│                     Customer Channels                        │
├──────────────────────┬──────────────────────────────────────┤
│  IVR Phone Ordering  │  Mobile Web Ordering (Responsive)    │
│  (Olivia AI Voice)   │  (React/Vue/Next.js)                 │
└──────────┬───────────┴──────────────────┬───────────────────┘
           │                              │
           └──────────────┬───────────────┘
                          │
           ┌──────────────▼───────────────┐
           │      API Gateway / BFF        │
           │   (REST APIs, JWT Auth)       │
           └──────────────┬───────────────┘
                          │
       ┌──────────────────┼──────────────────┐
       │                  │                  │
┌──────▼─────┐   ┌───────▼──────┐   ┌──────▼──────┐
│   Order    │   │     Menu     │   │   Payment   │
│  Service   │   │   Service    │   │   Service   │
│            │   │              │   │  (Stripe)   │
└──────┬─────┘   └───────┬──────┘   └──────┬──────┘
       │                 │                  │
       └─────────────────┼──────────────────┘
                         │
              ┌──────────▼──────────┐
              │   Multi-Tenant DB   │
              │  (PostgreSQL/MySQL) │
              │  Schema-per-tenant  │
              └─────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                  Background Services                         │
├────────────────────┬────────────────────┬───────────────────┤
│  POS Sync Worker   │  Notification Svc  │   AI KB Service   │
│  (Toast API Poll)  │  (Twilio, SendGrid)│ (OpenAI Embed)    │
└────────────────────┴────────────────────┴───────────────────┘
```

### **Technology Stack (Recommended)**

**Frontend**:
- Mobile Web: React + Next.js (or Vue + Nuxt)
- State Management: React Context or Zustand
- UI Components: Tailwind CSS, Headless UI
- Forms: React Hook Form + Zod validation

**Backend**:
- API: Node.js + Express (or Python + FastAPI, Ruby on Rails)
- Authentication: JWT tokens or session-based
- Database: PostgreSQL (multi-tenant with schema-per-tenant or row-level security)
- ORM: Prisma (Node.js) or SQLAlchemy (Python)

**External Services**:
- Payment: Stripe
- SMS: Twilio
- Email: SendGrid or AWS SES
- Voice AI: Custom (OpenAI Whisper + GPT) or third-party (Voiceflow, Parloa)
- AI Embeddings: OpenAI Embeddings API or Azure Cognitive Search

**Infrastructure**:
- Hosting: AWS (ECS, Lambda) or Vercel (Next.js) + Railway (Backend)
- Database: AWS RDS PostgreSQL or Supabase
- Monitoring: Sentry (errors), Datadog (APM), LogRocket (session replay)
- CI/CD: GitHub Actions, Vercel auto-deploy

---

## Contact & Feedback

For questions about this roadmap or to provide feedback during pilot phase:

- **Product Lead**: [Name, Email]
- **Engineering Lead**: [Name, Email]
- **Pilot Restaurant Support**: [Support Email, Phone]

**Pilot Feedback Form**: [Link to feedback form]

---

**Document Version**: 1.0
**Last Updated**: 2025-10-31
**Next Review**: Week 3, Day 15 (Pre-Launch)
