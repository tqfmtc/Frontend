# Integration Quickstart: Customer Identity & Wallet

**Target Audience**: Mobile app developers, backend teams, IVR integrators  
**Time to Integrate**: 2-4 hours for passwordless login  
**Prerequisites**: FastAPI backend running, Twilio credentials configured

---

## 1. Quick Start: Mobile App Integration

### 1.1 Install SDK

```bash
pip install requests pyjwt cryptography
```

### 1.2 Initialize Wallet Client

```python
from src.wallet_client import WalletClient

client = WalletClient(
    base_url="https://api.parcera.io/v1",
    api_key=YOUR_API_KEY  # For server-to-server, not needed for mobile app
)
```

### 1.3 Passwordless Login Flow

**Step 1: Request SMS Code**

```python
# User enters phone number: "+12025551234"
response = client.send_sms(phone_number="+12025551234")
# Response: {"verification_id": "uuid", "message": "Code sent..."}
```

**Step 2: Verify Code & Get JWT**

```python
# User enters 6-digit code from SMS
response = client.verify_sms(
    phone_number="+12025551234",
    code="123456"
)

# Response:
# {
#   "access_token": "eyJhbGc...",
#   "refresh_token": "refresh_abc...",
#   "token_type": "Bearer",
#   "expires_in": 2592000,
#   "wallet": {
#     "wallet_id": "550e8400-e29b-41d4-a716-446655440000",
#     "phone_number": "+12025551234",
#     "phone_verified": true,
#     "name": null
#   }
# }

# Store tokens in device keychain/secure storage
KEYCHAIN.save("access_token", response["access_token"])
KEYCHAIN.save("refresh_token", response["refresh_token"])
```

### 1.4 Make Authenticated API Calls

```python
# All subsequent API calls include JWT in Authorization header
headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

# Example: Get order history
response = requests.get(
    "https://api.parcera.io/v1/wallet/orders",
    headers=headers
)

# Response: [
#   {
#     "order_id": "...",
#     "restaurant": "Pizza Palace",
#     "total": 24.99,
#     "items": [...],
#     "status": "completed",
#     "can_reorder": true
#   }
# ]
```

### 1.5 Handle Token Refresh

```python
# When access token expires (30 days)
def refresh_access_token():
    refresh_token = KEYCHAIN.get("refresh_token")
    
    response = client.refresh(refresh_token=refresh_token)
    
    # Update tokens
    KEYCHAIN.save("access_token", response["access_token"])
    KEYCHAIN.save("refresh_token", response["refresh_token"])
    
    return response["access_token"]
```

### 1.6 Logout

```python
def logout():
    response = requests.post(
        "https://api.parcera.io/v1/auth/logout",
        headers={"Authorization": f"Bearer {access_token}"}
    )
    
    # Clear tokens from keychain
    KEYCHAIN.delete("access_token")
    KEYCHAIN.delete("refresh_token")
```

---

## 2. Wallet Management

### 2.1 Get Current Wallet Profile

```python
response = requests.get(
    "https://api.parcera.io/v1/wallet",
    headers={"Authorization": f"Bearer {access_token}"}
)

# Response:
# {
#   "wallet_id": "...",
#   "phone_number": "+12025551234",
#   "email": "customer@example.com",
#   "name": "John Doe",
#   "dietary_preferences": ["vegetarian", "gluten-free"],
#   "marketing_opt_in": false,
#   "notification_preferences": {
#     "order_updates": true,
#     "promotions": false,
#     "new_restaurants": false
#   },
#   "created_at": "2025-11-04T10:00:00Z",
#   "updated_at": "2025-11-04T14:30:00Z"
# }
```

### 2.2 Update Wallet Profile

```python
response = requests.patch(
    "https://api.parcera.io/v1/wallet",
    headers={"Authorization": f"Bearer {access_token}"},
    json={
        "name": "John Doe",
        "email": "john@example.com",
        "dietary_preferences": ["vegetarian"],
        "notification_preferences": {
            "order_updates": true,
            "promotions": true,
            "new_restaurants": false
        }
    }
)
```

### 2.3 Export Wallet Data (GDPR)

```python
response = requests.get(
    "https://api.parcera.io/v1/wallet/export",
    headers={"Authorization": f"Bearer {access_token}"}
)

# Response: JSON file with all wallet data
# {
#   "profile": {...},
#   "payment_methods": [{...}],
#   "addresses": [{...}],
#   "order_history": [{...}],
#   "audit_log": [{...}]
# }
```

### 2.4 Delete Wallet (Right to Erasure)

```python
response = requests.delete(
    "https://api.parcera.io/v1/wallet",
    headers={"Authorization": f"Bearer {access_token}"},
    json={"confirm": true}
)

# Response:
# {
#   "message": "Wallet deletion scheduled",
#   "scheduled_deletion_date": "2025-12-04T10:00:00Z"
# }

# Wallet soft-deleted, will be purged after 90 days
```

---

## 3. Payment Methods

### 3.1 Add Payment Method

```python
response = requests.post(
    "https://api.parcera.io/v1/wallet/payment-methods",
    headers={"Authorization": f"Bearer {access_token}"},
    json={
        "type": "card",
        "card_number": "4242424242424242",  # Only over HTTPS, never log
        "expiry_month": 12,
        "expiry_year": 2026,
        "cvv": "123",  # Transmitted only to payment processor, never stored
        "billing_zip": "20001",
        "set_as_default": true
    }
)

# Response:
# {
#   "payment_method_id": "...",
#   "type": "card",
#   "card_brand": "Visa",
#   "card_last_four": "4242",
#   "expiry_month": 12,
#   "expiry_year": 2026,
#   "is_default": true,
#   "created_at": "2025-11-04T14:30:00Z"
# }
```

### 3.2 List Payment Methods

```python
response = requests.get(
    "https://api.parcera.io/v1/wallet/payment-methods",
    headers={"Authorization": f"Bearer {access_token}"}
)

# Response:
# [
#   {
#     "payment_method_id": "...",
#     "type": "card",
#     "card_brand": "Visa",
#     "card_last_four": "4242",
#     "is_default": true
#   },
#   {
#     "payment_method_id": "...",
#     "type": "card",
#     "card_brand": "Mastercard",
#     "card_last_four": "5555",
#     "is_default": false
#   }
# ]
```

### 3.3 Set Default Payment Method

```python
response = requests.patch(
    f"https://api.parcera.io/v1/wallet/payment-methods/{payment_method_id}",
    headers={"Authorization": f"Bearer {access_token}"},
    json={"is_default": true}
)
```

### 3.4 Delete Payment Method

```python
response = requests.delete(
    f"https://api.parcera.io/v1/wallet/payment-methods/{payment_method_id}",
    headers={"Authorization": f"Bearer {access_token}"}
)
```

---

## 4. Delivery Addresses

### 4.1 Add Address

```python
response = requests.post(
    "https://api.parcera.io/v1/wallet/addresses",
    headers={"Authorization": f"Bearer {access_token}"},
    json={
        "label": "Home",
        "street_address": "123 Main St",
        "apt_suite": "Apt 4B",
        "city": "Washington",
        "state": "DC",
        "zip_code": "20001",
        "delivery_instructions": "Ring doorbell, leave on porch",
        "set_as_default": true
    }
)

# Response:
# {
#   "address_id": "...",
#   "label": "Home",
#   "street_address": "123 Main St",
#   "city": "Washington",
#   "state": "DC",
#   "zip_code": "20001",
#   "latitude": 38.9072,
#   "longitude": -77.0369,
#   "is_default": true,
#   "created_at": "2025-11-04T14:30:00Z"
# }
```

### 4.2 List Addresses

```python
response = requests.get(
    "https://api.parcera.io/v1/wallet/addresses",
    headers={"Authorization": f"Bearer {access_token}"}
)
```

### 4.3 Update Address

```python
response = requests.patch(
    f"https://api.parcera.io/v1/wallet/addresses/{address_id}",
    headers={"Authorization": f"Bearer {access_token}"},
    json={"delivery_instructions": "New instructions"}
)
```

### 4.4 Delete Address

```python
response = requests.delete(
    f"https://api.parcera.io/v1/wallet/addresses/{address_id}",
    headers={"Authorization": f"Bearer {access_token}"}
)
```

---

## 5. Order History & Reorder

### 5.1 Get Order History

```python
response = requests.get(
    "https://api.parcera.io/v1/wallet/orders",
    headers={"Authorization": f"Bearer {access_token}"},
    params={
        "page": 1,
        "per_page": 20,
        "sort": "date_desc"
    }
)

# Response:
# {
#   "orders": [
#     {
#       "order_id": "...",
#       "restaurant_id": "...",
#       "restaurant_name": "Pizza Palace",
#       "order_date": "2025-11-01T19:00:00Z",
#       "status": "completed",
#       "items": [
#         {
#           "name": "Margherita Pizza",
#           "quantity": 1,
#           "price": 12.99,
#           "modifiers": [{"name": "Crust", "value": "Thin"}]
#         }
#       ],
#       "total": 24.99,
#       "can_reorder": true
#     }
#   ],
#   "total_count": 42,
#   "page": 1
# }
```

### 5.2 Get Order Details

```python
response = requests.get(
    f"https://api.parcera.io/v1/wallet/orders/{order_id}",
    headers={"Authorization": f"Bearer {access_token}"}
)
```

### 5.3 Reorder (Add to Cart)

```python
response = requests.post(
    f"https://api.parcera.io/v1/wallet/orders/{order_id}/reorder",
    headers={"Authorization": f"Bearer {access_token}"}
)

# Response:
# {
#   "cart_id": "...",
#   "items": [...],  # Same items from original order
#   "message": "Order added to cart. Review items and proceed to checkout."
# }
```

---

## 6. IVR Integration

### 6.1 Phone Lookup (IVR)

```python
# IVR: "Please enter your phone number"
# Backend receives phone from IVR system
# Look up wallet WITHOUT authentication (IVR has no JWT capability)

response = requests.post(
    "https://api.parcera.io/v1/auth/send-sms",
    json={"phone_number": "+12025551234"}
)

# IVR: "Enter the 6-digit code we just texted you"
# User enters code via phone keypad

response = requests.post(
    "https://api.parcera.io/v1/auth/verify-sms",
    json={
        "phone_number": "+12025551234",
        "code": "123456"
    }
)

# Response includes wallet_id + basic profile
wallet_id = response["wallet"]["wallet_id"]

# IVR retrieves order history by wallet_id
response = requests.get(
    f"https://api.parcera.io/v1/wallet/{wallet_id}/orders",
    headers={"Authorization": f"Bearer {sys_token}"}  # System token, not customer JWT
)
```

---

## 7. Error Handling & Retry Logic

### 7.1 Rate Limiting (HTTP 429)

```python
import time

def send_sms_with_retry(phone_number, max_retries=3):
    for attempt in range(max_retries):
        try:
            response = client.send_sms(phone_number=phone_number)
            return response
        except RateLimitError as e:
            retry_after = int(e.headers.get("Retry-After", 60))
            print(f"Rate limited. Waiting {retry_after} seconds...")
            time.sleep(retry_after)
        except Exception as e:
            print(f"Error: {e}")
            raise
```

### 7.2 Token Expiration

```python
def make_api_call_with_refresh(endpoint, method="GET"):
    try:
        response = requests.request(
            method,
            endpoint,
            headers={"Authorization": f"Bearer {access_token}"}
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 401:
            # Token expired, refresh and retry
            new_token = refresh_access_token()
            response = requests.request(
                method,
                endpoint,
                headers={"Authorization": f"Bearer {new_token}"}
            )
            return response.json()
        else:
            raise
```

---

## 8. Security Best Practices

### 8.1 Token Storage (Mobile App)

```python
# WRONG: Store in SharedPreferences or localStorage
# SharedPreferences.putString("access_token", token)  # INSECURE

# CORRECT: Use secure device storage
import keychain  # iOS Keychain or Android Keystore

keychain.save(
    key="access_token",
    value=token,
    accessible=keychain.ACCESSIBLE_WHEN_UNLOCKED  # Only when device unlocked
)
```

### 8.2 HTTPS Only

```python
# WRONG:
requests.post("http://api.parcera.io/v1/wallet/payment-methods", ...)

# CORRECT:
requests.post("https://api.parcera.io/v1/wallet/payment-methods", ...)

# Enforce HTTPS in mobile app:
# - Certificate pinning for production API
# - Reject self-signed certificates in production
```

### 8.3 Never Log Sensitive Data

```python
# WRONG:
print(f"Login response: {response}")  # Contains tokens!
logger.info(f"Card added: {card_number}")  # Contains PII!

# CORRECT:
print(f"Login successful for wallet {wallet_id}")
logger.info(f"Card added: Visa ****4242")
```

---

## 9. Testing Integration

### 9.1 Unit Test Example

```python
import pytest
from unittest.mock import patch

def test_send_sms():
    """Test sending SMS verification code"""
    with patch('twilio.rest.Client.messages.create') as mock_send:
        mock_send.return_value.sid = "SM123456"
        
        response = client.send_sms(phone_number="+12025551234")
        
        assert response["verification_id"] is not None
        assert "Code sent" in response["message"]

def test_verify_sms():
    """Test verifying SMS code"""
    # Create SMS verification record in test DB
    verification = create_test_sms_verification(
        phone_number="+12025551234",
        code="123456"
    )
    
    response = client.verify_sms(
        phone_number="+12025551234",
        code="123456"
    )
    
    assert "access_token" in response
    assert response["wallet"]["phone_verified"] == True
```

### 9.2 Integration Test Example

```python
def test_passwordless_login_flow_end_to_end():
    """Full passwordless login flow"""
    # Step 1: Send SMS
    sms_response = client.send_sms(phone_number="+12025551234")
    verification_id = sms_response["verification_id"]
    
    # Step 2: Get code from test SMS service
    code = get_sms_code_from_test_provider(verification_id)
    
    # Step 3: Verify code
    auth_response = client.verify_sms(
        phone_number="+12025551234",
        code=code
    )
    
    assert "access_token" in auth_response
    
    # Step 4: Use JWT to access wallet
    wallet_response = requests.get(
        "https://api.parcera.io/v1/wallet",
        headers={"Authorization": f"Bearer {auth_response['access_token']}"}
    )
    
    assert wallet_response.status_code == 200
    assert wallet_response.json()["phone_verified"] == True
```

---

## 10. Troubleshooting

| Issue | Cause | Solution |
|-------|-------|----------|
| SMS not received | Twilio rate limit or network issue | Check Twilio logs, retry after 60s |
| JWT expired | 30-day access token lifetime | Call `/auth/refresh` with refresh token |
| "Invalid code" | Wrong code or >10 min expiry | Request new SMS code |
| "Rate limit exceeded" | 3 codes/phone/hour limit | User must wait before retrying |
| Address geocoding fails | Invalid address format | Show address validation error, allow manual lat/long |

---

**Status**: ✅ Integration guide complete  
**Next**: Review with mobile/web teams, adjust code samples based on feedback

