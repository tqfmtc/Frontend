# Feature Specification: Customer Identity & Privacy-First Wallet

**Feature Branch**: `008-customer-identity`
**Created**: 2025-10-29
**Status**: Draft
**Constitution Alignment**: Principles III (Privacy-First), IV (Omnichannel), V (MVP Discipline)

---

## Overview

Passwordless authentication system using phone verification that creates a unified customer profile (wallet) working across all restaurants on the Parcera platform. Privacy-first data model ensures Parcera owns and controls customer contact information - restaurants never access customer PII directly. Wallet stores payment methods, delivery addresses, dietary preferences, order history, and marketing preferences. Enables cross-restaurant personalization and future loyalty programs while protecting customer privacy.

---

## User Scenarios & Testing

### User Story 1 - Passwordless Wallet Creation (Priority: P0)

**As a** new customer placing my first mobile order
**I want to** create a wallet using just my phone number
**So that** I can order quickly without passwords or lengthy signup forms

**Why this priority**: Frictionless onboarding is critical for mobile app adoption. Passwordless auth reduces abandonment and improves conversion.

**Independent Test**: Can be fully tested by opening mobile app, entering phone number, receiving SMS code, verifying code, and accessing wallet with saved order. Delivers instant authentication without password hassle.

**Acceptance Scenarios**:

1. **Given** Customer opens mobile app for first time, **When** Customer taps "Create Wallet" and enters phone number, **Then** SMS verification code sent within 5 seconds
2. **Given** Customer receives 6-digit code via SMS, **When** Customer enters code in app, **Then** Wallet created and customer logged in without password
3. **Given** Wallet is created, **When** Customer places first order, **Then** Payment method and delivery address captured and saved to wallet for future use
4. **Given** Customer returns to app later, **When** Customer enters phone number, **Then** SMS code sent for passwordless login (no password ever set)

---

### User Story 2 - Cross-Restaurant Order History (Priority: P0)

**As a** customer who orders from multiple restaurants
**I want to** see all my past orders in one place
**So that** I can reorder favorites regardless of which restaurant

**Why this priority**: Unified order history is key wallet value proposition. Differentiates Parcera from single-restaurant apps.

**Independent Test**: Can be fully tested by placing orders at 3 different restaurants, viewing order history in wallet, and verifying all orders appear with restaurant names, dates, and reorder buttons. Delivers cross-restaurant continuity.

**Acceptance Scenarios**:

1. **Given** Customer has ordered from Pizza Place and Burger Joint, **When** Customer views order history in wallet, **Then** Orders from both restaurants appear in chronological order
2. **Given** Customer selects past order from Pizza Place, **When** Order details open, **Then** Full order shown: items, modifiers, total, restaurant, date, order status
3. **Given** Customer taps "Reorder" on past order, **When** Cart loads, **Then** All items from that order added to cart with original modifiers
4. **Given** Restaurant is currently closed, **When** Customer tries to reorder, **Then** App shows "Restaurant closed - opens at [time]" and offers to save for later

---

### User Story 3 - Privacy-First Notifications (Priority: P0)

**As a** customer concerned about privacy
**I want** restaurants to notify me about orders without having my phone number
**So that** I avoid spam and unwanted marketing from restaurants

**Why this priority**: Privacy-first model is constitutional requirement (Principle III). Core differentiat or from competitors who sell customer data.

**Independent Test**: Can be fully tested by placing order, verifying restaurant cannot see customer phone number in their POS, updating order status in POS, and confirming customer receives notification from Parcera (not restaurant). Delivers privacy guarantee.

**Acceptance Scenarios**:

1. **Given** Customer places order via mobile app, **When** Order is submitted to restaurant POS, **Then** Customer phone number is NOT included in POS order data (only Parcera order ID)
2. **Given** Restaurant marks order as ready, **When** Status changes in POS, **Then** Parcera fulfillment engine sends push notification to customer (restaurant has no direct access to customer)
3. **Given** Customer has wallet ID W123, **When** Restaurant wants to send promotional offer, **Then** Restaurant submits offer to Parcera, Parcera sends to customers who opted in, restaurant never sees phone numbers
4. **Given** Customer opts out of marketing, **When** Marketing preference updated in wallet, **Then** No promotional messages sent regardless of restaurant requests

---

### User Story 4 - Payment Method Management (Priority: P0)

**As a** customer ordering frequently
**I want to** save payment methods in my wallet
**So that** I can checkout in seconds without re-entering card details

**Why this priority**: Saved payment reduces checkout friction. Industry standard for food ordering apps.

**Independent Test**: Can be fully tested by adding credit card to wallet, placing order at restaurant, verifying payment method auto-selected, completing checkout without re-entering card, and receiving payment confirmation. Delivers quick checkout.

**Acceptance Scenarios**:

1. **Given** Customer completes first order with credit card, **When** Payment succeeds, **Then** App prompts "Save this card for future orders?" with secure save option
2. **Given** Customer saves payment method, **When** Next order checkout loads, **Then** Saved card pre-selected with last 4 digits and card brand displayed
3. **Given** Customer adds multiple payment methods, **When** Wallet settings opened, **Then** All saved cards listed with ability to set default and remove cards
4. **Given** Saved card expires, **When** Customer attempts to use it, **Then** App prompts to update expiration or add new card before checkout

---

### User Story 5 - Delivery Address Management (Priority: P0)

**As a** customer who orders for delivery
**I want to** save multiple addresses (home, work, etc.)
**So that** I can quickly select delivery location without retyping

**Why this priority**: Saved addresses reduce delivery order friction. Supports common use case of ordering to multiple locations.

**Independent Test**: Can be fully tested by adding "Home" and "Work" addresses to wallet, placing delivery order, selecting "Work" address from saved list, and verifying order delivered to correct address. Delivers address convenience.

**Acceptance Scenarios**:

1. **Given** Customer places first delivery order, **When** Address is entered, **Then** App prompts "Save as Home/Work/Custom?" with option to set as default
2. **Given** Customer saves multiple addresses, **When** Delivery checkout loads, **Then** Saved addresses displayed with labels and distance from restaurant
3. **Given** Customer selects "Work" address, **When** Restaurant delivery radius checked, **Then** Order only proceeds if Work address is within delivery range
4. **Given** Customer moves and updates address, **When** Address changed in wallet, **Then** New address used for all future orders (past orders retain old address for reference)

---

### User Story 6 - Dietary Preferences and Personalization (Priority: P1)

**As a** customer with dietary restrictions
**I want to** set preferences in my wallet (vegetarian, gluten-free, etc.)
**So that** menu items are filtered automatically across all restaurants

**Why this priority**: Personalization improves UX and supports accessibility. Differentiates from competitors. Not blocking MVP but high value-add.

**Independent Test**: Can be fully tested by setting "vegetarian" preference in wallet, browsing menus at 3 restaurants, and verifying vegetarian items highlighted or non-vegetarian items filtered. Delivers personalized experience.

**Acceptance Scenarios**:

1. **Given** Customer sets dietary preference "vegetarian" in wallet, **When** Any restaurant menu loads, **Then** Vegetarian items highlighted or filter applied automatically
2. **Given** Customer has gluten-free preference, **When** Menu item contains gluten, **Then** Item shows warning icon and customer can still order with acknowledgment
3. **Given** Customer preferences saved, **When** AI ordering assistant (Olivia) suggests items, **Then** Suggestions align with dietary preferences
4. **Given** Customer temporarily disables preference, **When** Ordering from specific restaurant, **Then** Full menu shown without filters for that session only

---

## Functional Requirements

### FR-W1: Passwordless Authentication (P0)
- **FR-W1.1**: Phone number as primary identifier (E.164 format, +1XXXXXXXXXX)
- **FR-W1.2**: SMS verification code (6 digits, expires after 10 minutes)
- **FR-W1.3**: Login flow: enter phone → receive SMS → enter code → authenticated
- **FR-W1.4**: Rate limiting: max 3 SMS codes per phone per hour (prevent abuse)
- **FR-W1.5**: Session management: JWT or session token with 30-day expiration, refresh on app use

### FR-W2: Wallet Profile Management (P0)
- **FR-W2.1**: Core profile fields: phone (required), email (optional), name (optional), dietary preferences (optional)
- **FR-W2.2**: Profile update API: change email, name, preferences without re-verification
- **FR-W2.3**: Phone number change requires reverification of new number
- **FR-W2.4**: Wallet deletion: customer can request full data deletion (GDPR/CCPA compliance)
- **FR-W2.5**: Export wallet data: customer can download full profile and order history (GDPR right to data portability)

### FR-W3: Payment Method Storage (P0)
- **FR-W3.1**: Tokenized payment storage via payment gateway (Authorize.Net, Stacks, Adyen)
- **FR-W3.2**: Support credit/debit cards and mobile wallets (Apple Pay, Google Pay)
- **FR-W3.3**: Store: card last 4 digits, brand, expiration, billing ZIP, payment gateway token (encrypted)
- **FR-W3.4**: Set default payment method, allow multiple payment methods per wallet
- **FR-W3.5**: Delete payment method, trigger gateway token deletion

### FR-W4: Address Management (P0)
- **FR-W4.1**: Store multiple addresses with labels (Home, Work, custom)
- **FR-W4.2**: Address fields: street, city, state, ZIP, delivery instructions, lat/long (for radius calc)
- **FR-W4.3**: Validate address format and geocode on entry (Google Maps API or similar)
- **FR-W4.4**: Set default delivery address
- **FR-W4.5**: Delete address (past orders retain address for records)

### FR-W5: Order History (P0)
- **FR-W5.1**: Unified order history across all restaurants (IVR, kiosk, mobile channels)
- **FR-W5.2**: Order list: restaurant name, date, time, total, items, status, reorder button
- **FR-W5.3**: Order detail view: full itemization, modifiers, special instructions, receipt
- **FR-W5.4**: Filter/search orders: by restaurant, date range, order status
- **FR-W5.5**: Reorder functionality: one-tap to add past order items to cart

### FR-W6: Dietary Preferences (P1)
- **FR-W6.1**: Preference options: vegetarian, vegan, gluten-free, dairy-free, nut-free, halal, kosher, custom
- **FR-W6.2**: Multiple preferences can be set simultaneously
- **FR-W6.3**: Preferences sync to all ordering channels (mobile, IVR, kiosk)
- **FR-W6.4**: Menu filtering: apply preferences to highlight/filter items (if menu has dietary tags)
- **FR-W6.5**: Temporary override: disable preferences for single order session

### FR-W7: Marketing Preferences (P0)
- **FR-W7.1**: Opt-in/opt-out for promotional notifications (default: opt-out)
- **FR-W7.2**: Granular controls: order updates (always on), promotions (opt-in), new restaurant alerts (opt-in)
- **FR-W7.3**: Preference applies across all restaurants (no per-restaurant opt-in)
- **FR-W7.4**: Update preference instantly (no delay in notification routing)
- **FR-W7.5**: Compliance: include unsubscribe link in marketing messages (CAN-SPAM, GDPR)

### FR-W8: Privacy Controls (P0)
- **FR-W8.1**: Restaurant order data includes wallet_id (UUID) but NOT phone number or email
- **FR-W8.2**: Notification routing: Parcera sends on behalf of restaurant using wallet_id lookup
- **FR-W8.3**: Customer PII never exposed in restaurant-facing APIs or dashboards
- **FR-W8.4**: Audit log: track all access to customer PII (for security/compliance)
- **FR-W8.5**: Data encryption: PII encrypted at rest and in transit

### FR-W9: Cross-Platform Sync (P0)
- **FR-W9.1**: Wallet data synced across mobile app, web (if applicable), IVR (via phone lookup)
- **FR-W9.2**: Real-time sync: payment method added on mobile immediately available for IVR orders
- **FR-W9.3**: Conflict resolution: last-write-wins for profile updates
- **FR-W9.4**: Offline mode: mobile app caches wallet data, syncs changes when online
- **FR-W9.5**: Multi-device support: customer can log in on multiple devices simultaneously

### FR-W10: Favorites and Quick Reorder (P1)
- **FR-W10.1**: Favorite restaurants: quick access to preferred restaurants
- **FR-W10.2**: Favorite items: save specific menu items with modifiers across restaurants
- **FR-W10.3**: "My Usual" voice command: Olivia recognizes "order my usual from Pizza Place" and retrieves favorited order
- **FR-W10.4**: Edit favorites: update modifiers, remove favorites
- **FR-W10.5**: Favorites sync across channels (set in mobile, use in IVR)

---

## Key Entities

### 1. **CustomerWallet**
- `wallet_id` (UUID, primary key)
- `phone_number` (string, unique, E.164 format, indexed)
- `phone_verified` (boolean, default false until SMS verification)
- `email` (string, nullable, unique if provided)
- `name` (string, nullable)
- `dietary_preferences` (JSON array: ['vegetarian', 'gluten-free'])
- `marketing_opt_in` (boolean, default false)
- `notification_preferences` (JSON: {order_updates: true, promotions: false, new_restaurants: false})
- `default_payment_method_id` (UUID, foreign key, nullable)
- `default_delivery_address_id` (UUID, foreign key, nullable)
- `created_at`, `updated_at`, `last_login_at` (timestamps)

### 2. **PaymentMethod**
- `payment_method_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key)
- `type` (enum: 'card', 'apple_pay', 'google_pay')
- `card_brand` (string: 'Visa', 'Mastercard', etc., nullable)
- `card_last_four` (string, nullable)
- `expiry_month`, `expiry_year` (integers, nullable)
- `billing_zip` (string, nullable)
- `payment_gateway` (enum: 'authorize_net', 'stacks', 'adyen')
- `gateway_token` (string, encrypted, tokenized card reference)
- `is_default` (boolean)
- `created_at`, `updated_at` (timestamps)

### 3. **DeliveryAddress**
- `address_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key)
- `label` (string: 'Home', 'Work', custom)
- `street_address` (string)
- `apt_suite` (string, nullable)
- `city`, `state`, `zip_code` (strings)
- `country` (string, default 'USA')
- `latitude`, `longitude` (floats, for delivery radius calculation)
- `delivery_instructions` (string, nullable, e.g., "Ring doorbell")
- `is_default` (boolean)
- `created_at`, `updated_at` (timestamps)

### 4. **OrderHistory** (References orders from IVR, Kiosk, Mobile)
- `order_id` (UUID, primary key, foreign key to IVROrder/KioskOrder/MobileOrder)
- `wallet_id` (UUID, foreign key)
- `restaurant_id` (UUID, foreign key)
- `channel` (enum: 'ivr', 'kiosk', 'mobile')
- `order_number` (integer, per restaurant per day)
- `order_date` (timestamp)
- `items` (JSON, order items with modifiers)
- `total` (decimal)
- `order_status` (enum: 'pending', 'confirmed', 'preparing', 'ready', 'completed', 'cancelled')
- `can_reorder` (boolean, false if restaurant closed or items unavailable)

### 5. **FavoriteRestaurant**
- `favorite_restaurant_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key)
- `restaurant_id` (UUID, foreign key)
- `order_count` (integer, how many times ordered from this restaurant)
- `last_order_date` (timestamp)
- `created_at` (timestamp)

### 6. **FavoriteItem**
- `favorite_item_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key)
- `restaurant_id` (UUID, foreign key)
- `menu_item_id` (UUID, foreign key to MenuItem)
- `modifiers` (JSON, saved customizations)
- `nickname` (string, nullable, e.g., "My usual burger")
- `created_at` (timestamp)

### 7. **SMSVerification**
- `verification_id` (UUID, primary key)
- `phone_number` (string, E.164 format)
- `code` (string, 6 digits)
- `purpose` (enum: 'wallet_creation', 'login', 'phone_change')
- `sent_at` (timestamp)
- `expires_at` (timestamp, sent_at + 10 minutes)
- `verified_at` (timestamp, nullable)
- `attempts` (integer, tracks failed verification attempts)

---

## Success Criteria

1. **Wallet Creation Time**: ≥90% of customers complete wallet creation in <60 seconds (from phone entry to first order)
2. **SMS Delivery Speed**: ≥95% of verification codes delivered within 5 seconds
3. **Passwordless Login Success Rate**: ≥98% of login attempts succeed on first try (valid code entered)
4. **Cross-Restaurant Usage**: ≥60% of wallet customers order from 2+ restaurants within 30 days
5. **Payment Method Save Rate**: ≥80% of customers save payment method after first order
6. **Reorder Adoption**: ≥40% of repeat customers use reorder feature within first month
7. **Privacy Compliance**: 0 incidents of restaurant accessing customer PII (verified by audit logs)
8. **Data Portability**: 100% of data export requests fulfilled within 24 hours (GDPR compliance)
9. **Marketing Opt-In Rate**: ≥30% of customers opt in to promotional notifications (industry benchmark: 20-25%)
10. **Wallet Retention**: ≥70% of wallet customers place second order within 30 days
11. **Address Validation Accuracy**: ≥99% of entered addresses successfully geocoded for delivery radius calculation
12. **Multi-Device Sync Latency**: <2 seconds for wallet updates to sync across devices

---

## Assumptions

1. **SMS Gateway Available**: Twilio or AWS SNS used for SMS verification code delivery
2. **Payment Gateway Tokenization**: Selected payment gateway (Authorize.Net, Stacks, Adyen) provides tokenization API for secure card storage
3. **Single Phone Number Per Wallet**: MVP assumes one phone number per wallet; multi-number support (family accounts) deferred to P2
4. **US Market Focus**: Phone numbers in E.164 format (+1 prefix), addresses in US format; international expansion is P2
5. **JWT for Session Management**: JSON Web Tokens used for mobile app authentication with 30-day expiration
6. **GDPR/CCPA Compliance**: Wallet data handling complies with GDPR (data portability, right to deletion) and CCPA (data privacy)
7. **No Social Login**: MVP uses phone-only authentication; Google/Apple/Facebook login is P2
8. **Order History Retention**: All orders retained indefinitely for customer access (unless customer requests deletion)
9. **Geocoding API**: Google Maps API or similar used for address validation and lat/long calculation
10. **Privacy by Design**: Customer PII never stored in restaurant-accessible databases or APIs

---

## Open Questions

1. **Social Login Support**: Should MVP include Google/Apple sign-in as alternative to phone verification? (Reduces SMS costs but adds complexity)
2. **Family Accounts**: Should wallets support multiple phone numbers (family sharing)? (Deferred to P2 but affects data model)
3. **Loyalty Points**: Should wallet include loyalty points system for MVP or defer to P2? (Mentioned in constitution as cross-merchant opportunity)
4. **International Phone Numbers**: Does MVP need to support international phone formats beyond +1? (Impacts SMS gateway configuration)
5. **Email as Primary Identifier**: Should email be allowed as alternative to phone for wallet creation? (Some customers prefer email)
6. **Biometric Login**: Should mobile app support fingerprint/Face ID for quick login after initial phone verification? (UX enhancement)
7. **Guest Checkout**: Can customers order without creating wallet (guest mode)? Or is wallet required for all orders? (Impacts conversion)
8. **Wallet Data Backup**: Should customers be able to backup/restore wallet data? (Use case: lost phone, new device)

---

## Dependencies

### Upstream Dependencies
- **SMS Gateway**: Twilio, AWS SNS, or similar for verification codes
- **Payment Gateway**: Authorize.Net, Stacks, or Adyen for tokenized payment storage
- **Geocoding API**: Google Maps API for address validation

### Downstream Dependencies
- **Feature 003 (IVR Ordering)**: Uses wallet for customer lookup by phone
- **Feature 004 (Kiosk Ordering)**: Optional wallet integration for loyalty (P2)
- **Feature 005 (Mobile App Ordering)**: Primary interface for wallet creation and management
- **Feature 006 (Order Fulfillment)**: Uses wallet_id for customer notifications
- **Future Loyalty Program**: Wallet is foundation for cross-restaurant loyalty points

---

## Constitution Alignment

### Principle III: Privacy-First Customer Data ✅
- **Core requirement**: Wallet architecture ensures Parcera owns customer data
- **Privacy guarantee**: Restaurants never access customer PII (phone, email)
- **Notification model**: Parcera sends on behalf of restaurants using wallet_id
- **Data control**: Customers can export, modify, or delete data at any time

### Principle IV: Omnichannel by Default ✅
- **Unified profile**: Single wallet works across IVR, kiosk, and mobile
- **Consistent experience**: Payment methods, addresses, preferences sync across channels
- **Cross-restaurant**: Order history and favorites span all restaurants on platform

### Principle V: Progressive Enhancement & MVP Discipline ✅
- **P0 features**: Phone verification, payment/address storage, order history, privacy controls
- **P1 features**: Dietary preferences, favorites, quick reorder
- **P2 features**: Social login, family accounts, loyalty points, biometric auth

---

## Validation Checklist

- [x] **User Stories**: 6 user stories with acceptance criteria
- [x] **Priorities**: P0 (MVP), P1 (post-MVP)
- [x] **Functional Requirements**: 10 requirement groups
- [x] **Key Entities**: 7 entities defined
- [x] **Success Criteria**: 12 measurable outcomes
- [x] **Assumptions**: 10 assumptions documented
- [x] **Open Questions**: 8 questions for clarification
- [x] **Dependencies**: Upstream and downstream mapped
- [x] **Constitution Alignment**: Principles III, IV, V
- [x] **Privacy-First**: Explicit privacy controls and audit logging
- [x] **GDPR/CCPA Compliance**: Data export, deletion, portability

---

**STATUS**: ✅ SPECIFICATION COMPLETE - Ready for `/speckit.plan`

**Next Steps**:
1. Resolve open questions (social login, guest checkout, loyalty MVP scope)
2. Obtain SMS gateway and payment gateway credentials
3. Create implementation plan with `/speckit.plan`
4. Generate tasks with `/speckit.tasks`
5. Coordinate with features 003, 005, 006 for wallet API integration
