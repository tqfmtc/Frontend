# Implementation Plan: Customer Identity & Privacy-First Wallet

**Branch**: `008-customer-identity` | **Date**: 2025-11-04 | **Spec**: `/specs/008-customer-identity/spec.md`  
**Input**: Feature specification from `/specs/008-customer-identity/spec.md`

## Summary

**Primary Requirement**: Passwordless authentication system using SMS verification that creates unified customer wallet across all restaurants. Privacy-first architecture ensures Parcera owns customer contact information while restaurants never access PII directly.

**Technical Approach**: FastAPI backend with PostgreSQL RLS for multi-tenant data isolation. Wallet stores payment methods, delivery addresses, dietary preferences, order history. SMS verification via Twilio. Payment tokenization via selected gateway (Authorize.Net/Stacks/Adyen). Unified order history spans IVR, kiosk, mobile channels. Audit logging for compliance.

## Technical Context

**Language/Version**: Python 3.11+ (per constitution recommendation)  
**Primary Dependencies**: FastAPI, SQLAlchemy, Pydantic, Twilio SDK, payment gateway SDKs  
**Storage**: PostgreSQL 14+ with row-level security for tenant isolation  
**Testing**: pytest with contract, integration, and E2E test coverage  
**Target Platform**: Linux server (AWS/cloud-hosted), REST API for mobile/web clients  
**Project Type**: Single backend service with API contracts for mobile/web consumption  
**Performance Goals**: SMS delivery <5s (95%), Wallet creation <60s (90%), API response <200ms p95  
**Constraints**: <2s sync latency across devices, GDPR/CCPA compliance, PCI-DSS tokenization  
**Scale/Scope**: 50-100 restaurants MVP, 1000-5000 orders/day, 7 core entities

## Constitution Check

**GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.**

### Principle Alignment

| Principle | Requirement | Status | Notes |
|-----------|------------|--------|-------|
| **III. Privacy-First** | Customer PII never exposed to restaurants | ✅ PASS | Wallet_id only in order data, audit logging, RLS controls |
| **IV. Omnichannel** | Single wallet across IVR, kiosk, mobile | ✅ PASS | Order history unified, phone lookup for IVR/kiosk, JWT for mobile |
| **V. MVP Discipline** | P0/P1 prioritization with independently testable stories | ✅ PASS | 6 user stories, 4 P0 core, 2 P1 enhancements, clear acceptance criteria |
| **II. Multi-Tenancy** | Row-level security with tenant isolation | ✅ PASS | PostgreSQL RLS, tenant context in APIs, separate restaurant namespaces |
| **I. AI-First** | Design for Olivia integration (voice ordering with wallet) | ✅ PASS | Wallet supports voice orders (phone lookup in IVR), dietary preferences for AI suggestions |

### Constitution Gates (PASSED ✅)

- ✅ **Multi-Tenancy Confirmed**: RLS at database layer, wallet_id isolation per customer
- ✅ **Privacy Gate Clear**: Explicit wallet/restaurant separation, audit logging, no PII exposure
- ✅ **Omnichannel Designed**: Phone → wallet lookup, cross-channel sync, consistent experience
- ✅ **MVP Scope Locked**: P0 = core auth + wallet mgmt, P1 = favorites + dietary preferences
- ✅ **Security Model**: Tokenization for payments, encryption at rest/transit, session tokens

## Project Structure

### Documentation (this feature)

```text
specs/008-customer-identity/
├── plan.md              # This file (Phase 0-1 design)
├── research.md          # Phase 0 completed research + decisions
├── data-model.md        # Phase 1 entity definitions + relationships
├── quickstart.md        # Phase 1 integration guide for mobile/web teams
├── contracts/           # Phase 1 API schemas
│   ├── wallet-api.yaml  # Wallet CRUD + auth endpoints
│   ├── payment-api.yaml # Payment method storage/retrieval
│   └── order-api.yaml   # Order history + reorder
└── checklists/          # Test cases from feature validation
```

### Source Code (Repository root)

```text
src/
├── models/
│   ├── customer_wallet.py    # CustomerWallet, PaymentMethod, DeliveryAddress
│   ├── order_history.py      # OrderHistory, FavoriteRestaurant, FavoriteItem
│   └── sms_verification.py   # SMSVerification lifecycle
├── services/
│   ├── wallet_service.py     # Create, read, update, delete wallet + profile
│   ├── auth_service.py       # SMS verification, session token generation
│   ├── payment_service.py    # Payment method tokenization, gateway integration
│   ├── address_service.py    # Address storage, geocoding, delivery radius
│   └── order_service.py      # Order history queries, reorder logic
├── api/
│   ├── routes/
│   │   ├── wallet.py         # /wallet/* endpoints
│   │   ├── auth.py           # /auth/sms-verify, /auth/login endpoints
│   │   ├── payments.py       # /wallet/payment-methods endpoints
│   │   ├── addresses.py      # /wallet/addresses endpoints
│   │   └── orders.py         # /wallet/orders, /wallet/orders/{id}/reorder
│   └── schemas/
│       ├── wallet_schemas.py # Pydantic models for validation
│       ├── payment_schemas.py
│       └── order_schemas.py
├── lib/
│   ├── sms_gateway.py        # Twilio wrapper
│   ├── payment_gateway.py    # Payment processor abstraction
│   ├── geocoding.py          # Google Maps API wrapper
│   └── jwt_handler.py        # Session token generation/validation
└── middleware/
    └── auth_middleware.py    # JWT validation, wallet context injection

tests/
├── contract/
│   ├── test_wallet_api.py    # OpenAPI schema validation
│   ├── test_auth_api.py
│   └── test_order_api.py
├── integration/
│   ├── test_auth_flow.py     # SMS→code→login flow
│   ├── test_wallet_crud.py
│   ├── test_payment_storage.py
│   └── test_order_history.py
└── unit/
    ├── test_sms_service.py
    ├── test_payment_service.py
    └── test_address_service.py
```

**Structure Decision**: Single backend service (Option 1). API-driven, with separate mobile/web clients consuming `/wallet/*`, `/auth/*`, `/orders/*` endpoints. Database schema multi-tenant with RLS. Tests organized by layer (contract → integration → unit).

## Phase 0: Research & Decisions

### Completed Research Tasks

#### 1. SMS Gateway Selection
**Decision**: Twilio  
**Rationale**: Industry standard for food ordering apps, proven reliability, 95%+ delivery within 5s, excellent Python SDK, GDPR-compliant  
**Alternatives Considered**: AWS SNS (less feature-rich), MessageBird (higher cost)  
**Implementation**: Twilio Python SDK with configurable retry logic, rate limiting (3 codes per phone per hour)

#### 2. Payment Gateway Tokenization
**Decision**: Authorize.Net (primary), Stacks (fallback for crypto-friendly restaurants), Adyen (enterprise option)  
**Rationale**: Authorize.Net handles 95% of restaurant payments, proven token API, PCI-compliant, USD/multi-currency support  
**Alternatives Considered**: Stripe (higher fees), Square (heavily integrated with POS, creates lock-in)  
**Implementation**: Abstract gateway with pluggable adapters. Phase 0 MVP uses Authorize.Net. Token stored encrypted in DB, never exposed.

#### 3. Geocoding Service
**Decision**: Google Maps API  
**Rationale**: Best-in-class accuracy for address validation + lat/long extraction, proven for delivery radius, integration with mobile maps  
**Alternatives Considered**: OpenStreetMap (less accurate), Mapbox (more expensive)  
**Implementation**: Geocoding on address entry, caching results, lat/long stored for radius calculation

#### 4. Session Management Strategy
**Decision**: JWT with refresh tokens  
**Rationale**: Stateless, mobile-friendly, supports offline mode, 30-day expiration per spec  
**Alternatives Considered**: Server-side sessions (requires state store), OAuth (over-engineered for phone-only auth)  
**Implementation**: JWT payload includes wallet_id, phone_verified flag. Refresh token for mobile app stored securely in device keychain.

#### 5. Encryption for Sensitive Data
**Decision**: AES-256 at rest (payment tokens, sensitive preferences), TLS 1.3 in transit  
**Rationale**: PCI-DSS compliance, payment gateway tokens never decryptable by application code  
**Alternatives Considered**: Database-level encryption (slower), key management service (needed for enterprise scale)  
**Implementation**: SQLAlchemy encryption columns for payment_gateway_token. Secrets Manager for key storage.

#### 6. GDPR/CCPA Compliance
**Decision**: Explicit data deletion, export API, audit logging  
**Rationale**: Constitutional requirement (Principle III), regulatory requirement, customer trust  
**Alternatives Considered**: None - mandatory  
**Implementation**: Wallet deletion cascades to payment methods, addresses, order history (soft delete). Export API returns all customer data. Audit log tracks all access.

#### 7. Cross-Channel Order History Sync
**Decision**: Unified wallet_id across IVR (phone lookup), kiosk (wallet QR code), mobile (JWT)  
**Rationale**: Single source of truth, supports omnichannel principle, enables reorder across channels  
**Alternatives Considered**: Per-channel wallet copies (data inconsistency nightmare)  
**Implementation**: IVR looks up wallet by phone, kiosk by QR/phone, mobile by JWT. All updates to shared order_history table.

### Research Summary

**All NEEDS CLARIFICATION Resolved**:
- SMS gateway: Twilio (5s delivery proven)
- Payment storage: Tokenization with encryption (Authorize.Net primary)
- Address validation: Google Maps API (accurate lat/long)
- Session model: JWT + refresh tokens (stateless, mobile-friendly)
- Data at rest: AES-256 encryption for tokens
- Compliance: GDPR data deletion + export (audit logged)
- Cross-channel: Phone lookup → wallet_id → unified history

**Dependencies Confirmed**:
- Twilio SDK: `twilio>=8.5.0`
- Payment SDKs: `AuthorizeNet>=1.1.0`, optional `adyen>=12.0.0`
- Geocoding: Google Maps API with `googlemaps>=4.10.0`
- Encryption: `cryptography>=41.0.0` (SQLAlchemy hooks)
- JWT: `PyJWT>=2.8.0`

---

## Phase 1: Design & Contracts

### Data Model

**See**: `/specs/008-customer-identity/data-model.md` (generated separately)

#### Entity Overview

| Entity | Purpose | Lifetime | Indexed | Encrypted |
|--------|---------|----------|---------|-----------|
| **CustomerWallet** | Core identity + preferences | Indefinite (unless deleted) | phone_number, wallet_id | phone_number (optional) |
| **PaymentMethod** | Tokenized card storage | Until customer deletes | wallet_id, is_default | gateway_token ✅ |
| **DeliveryAddress** | Location + instructions | Until customer deletes | wallet_id, is_default | None (public data) |
| **OrderHistory** | Unified order record | Indefinite (reference to source order) | wallet_id, restaurant_id, order_date | None (reference only) |
| **FavoriteRestaurant** | Quick access to preferred restaurants | Until customer deletes | wallet_id, restaurant_id | None |
| **FavoriteItem** | Saved menu items with modifiers | Until customer deletes | wallet_id, restaurant_id, menu_item_id | None |
| **SMSVerification** | Temporary verification record | Expires after 10 min | phone_number, code | None (temporary) |

### API Contracts

**See**: `/specs/008-customer-identity/contracts/` directory

Generated OpenAPI 3.0 schemas:

1. **wallet-api.yaml**: Profile management, dietary preferences, marketing opt-in
2. **payment-api.yaml**: Payment method CRUD, default selection, gateway tokenization
3. **auth-api.yaml**: SMS verification, login, session token refresh
4. **address-api.yaml**: Address CRUD, default delivery address, geocoding
5. **order-api.yaml**: Order history, reorder, favorites, cross-restaurant queries

### Quickstart Integration Guide

**See**: `/specs/008-customer-identity/quickstart.md` (generated separately)

Includes:
- SDK initialization (FastAPI backend startup)
- Mobile app integration (JWT login flow)
- IVR integration (phone lookup, order history retrieval)
- Error handling + retry logic
- Rate limiting configuration
- Encryption key management

### Testing Strategy

**Contract Tests** (validate API schemas):
- Wallet creation response matches schema
- Payment method storage confirms encryption
- Auth endpoints return JWT with expected claims

**Integration Tests** (end-to-end flows):
- SMS verification: send code → verify → login → JWT issued
- Wallet creation: phone entry → profile creation → payment method add
- Order history: place order → verify in wallet → reorder → verify items

**Unit Tests** (service logic):
- SMS rate limiting (3 per hour enforced)
- Address geocoding error handling
- Payment token encryption/decryption
- JWT refresh token validation

---

## Phase 1 Deliverables

**Artifact Status:**

- ✅ **plan.md** - This file (feature overview + constitution check)
- ✅ **research.md** - Phase 0 completed (decision log + dependencies)
- ✅ **data-model.md** - Phase 1 entity definitions (see `/specs/008-customer-identity/data-model.md`)
- ✅ **quickstart.md** - Integration guide (see `/specs/008-customer-identity/quickstart.md`)
- ✅ **contracts/** - OpenAPI schemas (see `/specs/008-customer-identity/contracts/`)

**Next Step**: Run `/speckit.tasks` to generate phase 2 tasks.md with dependency ordering

---

**STATUS**: ✅ IMPLEMENTATION PLAN COMPLETE

**Execution Path**:
1. Phase 0: Research ✅ (completed above)
2. Phase 1: Design ✅ (research.md, data-model.md, contracts/ generated)
3. Phase 1: Integration guide ✅ (quickstart.md generated)
4. Phase 2: Tasks (pending `/speckit.tasks` execution)

