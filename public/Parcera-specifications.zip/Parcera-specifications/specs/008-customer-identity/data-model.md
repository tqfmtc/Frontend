# Data Model: Customer Identity & Privacy-First Wallet

**Date**: 2025-11-04 | **Feature**: SPEC 008  
**Database**: PostgreSQL 14+ with Row-Level Security (RLS)  
**Status**: ✅ Phase 1 Complete

---

## Entity Relationship Diagram (ERD)

```
┌─────────────────────────────────────────────────────────────────┐
│ CustomerWallet (PK: wallet_id)                                  │
├─────────────────────────────────────────────────────────────────┤
│ wallet_id (UUID)                                      [PK]       │
│ phone_number (String, E.164, unique)                 [UK]       │
│ phone_verified (Boolean)                                        │
│ email (String, unique, nullable)                                │
│ name (String, nullable)                                         │
│ dietary_preferences (JSON)                                      │
│ marketing_opt_in (Boolean)                                      │
│ notification_preferences (JSON)                                 │
│ default_payment_method_id (UUID, FK)       [nullable, deferred] │
│ default_delivery_address_id (UUID, FK)     [nullable, deferred] │
│ created_at, updated_at, deleted_at (DateTime)                   │
│ last_login_at (DateTime, nullable)                              │
│ INDEX: phone_number, created_at                                 │
└─────────────┬─────────────────────────────────────┬─────────────┘
              │                                     │
              │ (1:N)                               │ (1:N)
              │                                     │
              ▼                                     ▼
    ┌──────────────────────────────┐   ┌──────────────────────────────┐
    │ PaymentMethod (PK: pmid)     │   │ DeliveryAddress (PK: aid)    │
    ├──────────────────────────────┤   ├──────────────────────────────┤
    │ payment_method_id (UUID)     │   │ address_id (UUID)            │
    │ wallet_id (UUID) [FK]        │   │ wallet_id (UUID) [FK]        │
    │ type (ENUM)                  │   │ label (String)               │
    │ card_brand (String, nullable)│   │ street_address (String)      │
    │ card_last_four (String)      │   │ apt_suite (String, nullable) │
    │ expiry_month (Integer)       │   │ city, state, zip_code        │
    │ expiry_year (Integer)        │   │ country (String)             │
    │ billing_zip (String)         │   │ latitude, longitude (Float)  │
    │ payment_gateway (ENUM)       │   │ delivery_instructions (Text) │
    │ gateway_token [ENCRYPTED]    │   │ is_default (Boolean)         │
    │ is_default (Boolean)         │   │ created_at, updated_at       │
    │ created_at, updated_at       │   │ INDEX: wallet_id, is_default │
    │ deleted_at (DateTime)        │   │ deleted_at (DateTime)        │
    │ INDEX: wallet_id, is_default │   └──────────────────────────────┘
    └──────────────────────────────┘
              │
              │ (0:1) [deferred FK]
              │
              └──────► CustomerWallet.default_payment_method_id

    ┌──────────────────────────────┐
    │ SMSVerification              │
    ├──────────────────────────────┤
    │ verification_id (UUID)       │
    │ phone_number (String, E.164) │
    │ code (String, 6 digits)      │
    │ purpose (ENUM)               │
    │ sent_at (DateTime)           │
    │ expires_at (DateTime)        │
    │ verified_at (DateTime, null) │
    │ attempts (Integer)           │
    │ INDEX: phone_number, code    │
    └──────────────────────────────┘

    ┌──────────────────────────────────────────────────────────────┐
    │ OrderHistory (PK: order_history_id)                          │
    ├──────────────────────────────────────────────────────────────┤
    │ order_history_id (UUID)                                      │
    │ wallet_id (UUID) [FK, nullable for guest orders]             │
    │ restaurant_id (UUID) [FK]                                    │
    │ channel (ENUM: ivr, kiosk, mobile)                           │
    │ order_id (UUID) [reference to source order]                  │
    │ order_number (Integer, per-restaurant per-day)               │
    │ order_date (DateTime)                                        │
    │ items (JSON) [item_id, quantity, modifiers, price]           │
    │ total (Decimal)                                              │
    │ order_status (ENUM)                                          │
    │ can_reorder (Boolean)                                        │
    │ created_at (DateTime)                                        │
    │ INDEX: wallet_id, order_date DESC                            │
    │ INDEX: restaurant_id, order_date DESC                        │
    └──────────────────────────────────────────────────────────────┘
              │
              │ (0:1)
              │
              └──────► CustomerWallet.wallet_id

    ┌──────────────────────────────────────────────────────────────┐
    │ FavoriteRestaurant (PK: favorite_restaurant_id)              │
    ├──────────────────────────────────────────────────────────────┤
    │ favorite_restaurant_id (UUID)                                │
    │ wallet_id (UUID) [FK]                                        │
    │ restaurant_id (UUID) [FK]                                    │
    │ order_count (Integer)                                        │
    │ last_order_date (DateTime, nullable)                         │
    │ created_at (DateTime)                                        │
    │ UNIQUE: (wallet_id, restaurant_id)                           │
    │ INDEX: wallet_id, order_count DESC                           │
    └──────────────────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────────────────┐
    │ FavoriteItem (PK: favorite_item_id)                          │
    ├──────────────────────────────────────────────────────────────┤
    │ favorite_item_id (UUID)                                      │
    │ wallet_id (UUID) [FK]                                        │
    │ restaurant_id (UUID) [FK]                                    │
    │ menu_item_id (UUID) [FK]                                     │
    │ modifiers (JSON) [modifier_id, selected_value]               │
    │ nickname (String, nullable) [e.g., "My usual burger"]        │
    │ created_at (DateTime)                                        │
    │ UNIQUE: (wallet_id, restaurant_id, menu_item_id)             │
    │ INDEX: wallet_id, restaurant_id                              │
    └──────────────────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────────────────┐
    │ AuditLog (PK: audit_id) [Append-only]                        │
    ├──────────────────────────────────────────────────────────────┤
    │ audit_id (UUID)                                              │
    │ wallet_id (UUID) [FK]                                        │
    │ action (String) [login, update_profile, add_payment, etc.]   │
    │ timestamp (DateTime) [UTC]                                   │
    │ ip_address (String, IPv6-compatible)                         │
    │ user_agent (String)                                          │
    │ metadata (JSON) [context-specific data]                      │
    │ INDEX: wallet_id, timestamp DESC                             │
    │ CONSTRAINT: Immutable after creation                         │
    └──────────────────────────────────────────────────────────────┘
```

---

## Entity Definitions

### 1. CustomerWallet

**Primary Purpose**: Core customer identity and preferences across all restaurants

**Fields**:

| Field | Type | Null? | Unique? | Constraints | Notes |
|-------|------|-------|---------|-------------|-------|
| `wallet_id` | UUID | ❌ | ✅ | PK | Auto-generated, immutable |
| `phone_number` | VARCHAR(20) | ❌ | ✅ | E.164 format, indexed | e.g., +12025551234, required for login |
| `phone_verified` | BOOLEAN | ❌ | — | DEFAULT false | Set true after SMS verification |
| `email` | VARCHAR(255) | ✅ | ✅ | If provided, unique | Optional, for order receipts |
| `name` | VARCHAR(255) | ✅ | — | — | Optional, for personalization |
| `dietary_preferences` | JSONB | ❌ | — | DEFAULT '[]' | Array: ["vegetarian", "gluten-free"], P1 feature |
| `marketing_opt_in` | BOOLEAN | ❌ | — | DEFAULT false | Customer must opt-in (privacy-first) |
| `notification_preferences` | JSONB | ❌ | — | See below | Customer control over notification types |
| `default_payment_method_id` | UUID | ✅ | — | FK → PaymentMethod | Nullable until customer adds payment |
| `default_delivery_address_id` | UUID | ✅ | — | FK → DeliveryAddress | Nullable until customer adds address |
| `created_at` | TIMESTAMP | ❌ | — | DEFAULT NOW() | Account creation time, immutable |
| `updated_at` | TIMESTAMP | ❌ | — | DEFAULT NOW(), ON UPDATE NOW() | Profile last modified |
| `deleted_at` | TIMESTAMP | ✅ | — | — | Soft delete, GDPR compliance |
| `last_login_at` | TIMESTAMP | ✅ | — | — | Tracking for inactive customers |

**Notification Preferences JSON Schema**:
```json
{
  "order_updates": true,      // Order status changes (always on for order fulfillment)
  "promotions": false,        // Restaurant offers/discounts (opt-in)
  "new_restaurants": false,   // New restaurant alerts (opt-in)
  "sms": true,                // SMS channel enabled
  "email": false,             // Email channel enabled
  "push": true                // Push notifications enabled
}
```

**Validation Rules**:
- `phone_number`: Must be E.164 format (validated via phonenumbers library)
- `email`: Must be RFC 5322 compliant (validated via pydantic)
- `name`: Max 255 characters, no SQL injection
- `dietary_preferences`: Must be array of known preference types
- Cannot set `default_payment_method_id` unless PaymentMethod exists for this wallet
- Cannot set `default_delivery_address_id` unless DeliveryAddress exists for this wallet

**Indexes**:
- `(phone_number)` - Fast lookup for IVR/kiosk login
- `(wallet_id, created_at DESC)` - Dashboard queries
- `(email)` - If provided, for duplicate detection

**Access Control (Row-Level Security)**:
```sql
-- Customers can only view their own wallet
ALTER TABLE customer_wallet ENABLE ROW LEVEL SECURITY;

CREATE POLICY rls_customer_wallet_self ON customer_wallet
  USING (wallet_id = current_user_id)
  WITH CHECK (wallet_id = current_user_id);
```

**State Lifecycle**:
```
phone_number_entered → SMS_sent → code_verified → account_created (phone_verified=true)
                       → login_later (phone lookup, SMS verification repeats)
                       → customer_requests_deletion → deleted_at=NOW() → 90-day purge
```

---

### 2. PaymentMethod

**Primary Purpose**: Secure storage of tokenized payment methods (cards, wallets)

**Fields**:

| Field | Type | Null? | Unique? | Encrypted? | Notes |
|-------|------|-------|---------|------------|-------|
| `payment_method_id` | UUID | ❌ | ✅ | — | PK, auto-generated |
| `wallet_id` | UUID | ❌ | — | — | FK → CustomerWallet, indexed |
| `type` | ENUM | ❌ | — | — | 'card', 'apple_pay', 'google_pay' |
| `card_brand` | VARCHAR(20) | ✅ | — | — | 'Visa', 'Mastercard', 'Amex', 'Discover' |
| `card_last_four` | VARCHAR(4) | ✅ | — | — | Last 4 digits only (e.g., "4242") |
| `expiry_month` | INTEGER | ✅ | — | — | 1-12, nullable for digital wallets |
| `expiry_year` | INTEGER | ✅ | — | — | YYYY format, nullable for digital wallets |
| `billing_zip` | VARCHAR(10) | ✅ | — | — | For fraud detection, nullable |
| `payment_gateway` | ENUM | ❌ | — | — | 'authorize_net', 'stacks', 'adyen' |
| `gateway_token` | VARCHAR(500) | ❌ | — | ✅ AES-256 | Encrypted reference from payment processor |
| `is_default` | BOOLEAN | ❌ | — | — | DEFAULT false, max 1 per wallet |
| `created_at` | TIMESTAMP | ❌ | — | — | When card was added |
| `updated_at` | TIMESTAMP | ❌ | — | — | Last modified (refresh token after test charge) |
| `deleted_at` | TIMESTAMP | ✅ | — | — | Soft delete, GDPR compliance |

**Validation Rules**:
- `wallet_id`: Must exist in customer_wallet
- `type`: One of defined enum values
- `card_last_four`: Exactly 4 digits if provided
- `expiry_month`: 1-12 if provided
- `expiry_year`: >= current year, < current year + 20
- `billing_zip`: Valid format (US 5 or 9 digits)
- `gateway_token`: Non-empty, never stored in plaintext (AES-256 encrypted)
- Only 1 `is_default=true` per wallet (constraint enforced via trigger)

**Indexes**:
- `(wallet_id, is_default)` - Fast lookup of default payment method
- `(wallet_id, created_at DESC)` - List customer's payment methods

**Access Control (RLS)**:
```sql
-- Customers can only view their own payment methods
CREATE POLICY rls_payment_method_self ON payment_method
  USING (wallet_id = (SELECT wallet_id FROM current_customer_context));
```

**Encryption Strategy**:
- `gateway_token` stored as Base64 Fernet cipher (AES-256 via cryptography library)
- Encryption key stored in AWS Secrets Manager (not in application code)
- Key rotation quarterly (maintain N-1 key for decryption during transition)
- Never log or transmit decrypted token

**State Lifecycle**:
```
card_entered → gateway_tokenization → gateway_token_stored (encrypted)
            → payment_used_in_order → token_reused (no re-transmission)
            → customer_requests_deletion → deleted_at=NOW() → purged after 90 days
```

**PCI Compliance Notes**:
- Level 3: No card data stored locally (tokenization handles Level 1)
- Quarterly security audits
- No card numbers, expiry dates, or CVV in logs/backups
- TLS 1.3 all transmission

---

### 3. DeliveryAddress

**Primary Purpose**: Customer delivery locations with geocoded lat/long for radius calculations

**Fields**:

| Field | Type | Null? | Unique? | Notes |
|-------|------|-------|---------|-------|
| `address_id` | UUID | ❌ | ✅ | PK, auto-generated |
| `wallet_id` | UUID | ❌ | — | FK → CustomerWallet, indexed |
| `label` | VARCHAR(50) | ❌ | — | 'Home', 'Work', custom (e.g., 'Mom's House') |
| `street_address` | VARCHAR(255) | ❌ | — | Street and number (e.g., "123 Main St") |
| `apt_suite` | VARCHAR(100) | ✅ | — | Apartment, suite, unit (e.g., "Apt 4B") |
| `city` | VARCHAR(100) | ❌ | — | City name |
| `state` | VARCHAR(2) | ❌ | — | State code (e.g., "CA", "NY") |
| `zip_code` | VARCHAR(10) | ❌ | — | ZIP code (5 or 9 digits) |
| `country` | VARCHAR(2) | ❌ | — | DEFAULT 'US', ISO 3166-1 alpha-2 |
| `latitude` | FLOAT(8) | ❌ | — | Geocoded lat (from Google Maps API) |
| `longitude` | FLOAT(8) | ❌ | — | Geocoded long (from Google Maps API) |
| `delivery_instructions` | TEXT | ✅ | — | Free-form (e.g., "Ring doorbell, leave on porch") |
| `is_default` | BOOLEAN | ❌ | — | DEFAULT false, max 1 per wallet |
| `created_at` | TIMESTAMP | ❌ | — | When address was added |
| `updated_at` | TIMESTAMP | ❌ | — | Last modified (address correction) |
| `deleted_at` | TIMESTAMP | ✅ | — | Soft delete, past orders retain address |

**Validation Rules**:
- `wallet_id`: Must exist in customer_wallet
- `label`: 1-50 characters, no special characters
- `street_address`: 5-255 characters, required
- `city`, `state`, `zip_code`: Valid US format
- `latitude`, `longitude`: Valid float range (-180 to 180 for lon, -90 to 90 for lat)
- At least 1 address per wallet for delivery orders
- Only 1 `is_default=true` per wallet
- Geocoding API must return valid lat/long on creation

**Indexes**:
- `(wallet_id, is_default)` - Fast lookup of default delivery address
- `(latitude, longitude)` - Spatial queries for nearby restaurants (P2)

**Access Control (RLS)**:
```sql
-- Customers can only view their own addresses
CREATE POLICY rls_delivery_address_self ON delivery_address
  USING (wallet_id = (SELECT wallet_id FROM current_customer_context));
```

**Geocoding Integration**:
- On address creation: Call Google Maps Geocoding API
- Store returned lat/long (sub-meter precision)
- Cache result in Redis (30 days)
- Validate delivery radius: `distance_between(restaurant_lat, restaurant_lon, address_lat, address_lon) <= restaurant_delivery_radius_miles`

**State Lifecycle**:
```
address_entered → geocoding_api_call → lat_long_stored → delivery_validated
              → customer_moves → address_updated → new_lat_long → past_orders_unchanged
              → customer_deletes → deleted_at=NOW() → past_orders_retain_address
```

---

### 4. OrderHistory

**Primary Purpose**: Unified order record across IVR, kiosk, mobile channels. Reference to source order, not copy.

**Fields**:

| Field | Type | Null? | Unique? | Notes |
|-------|------|-------|---------|-------|
| `order_history_id` | UUID | ❌ | ✅ | PK, auto-generated |
| `wallet_id` | UUID | ✅ | — | FK → CustomerWallet, nullable for guest orders |
| `restaurant_id` | UUID | ❌ | — | FK → Restaurant |
| `channel` | ENUM | ❌ | — | 'ivr', 'kiosk', 'mobile' |
| `order_id` | UUID | ❌ | — | Reference to source order (not FK, separate tables per channel) |
| `order_number` | INTEGER | ❌ | — | Per-restaurant per-day order number (e.g., #42 for today) |
| `order_date` | TIMESTAMP | ❌ | — | When order was placed |
| `items` | JSONB | ❌ | — | Order line items (see schema below) |
| `total` | NUMERIC(10,2) | ❌ | — | Order total in USD |
| `order_status` | ENUM | ❌ | — | 'pending', 'confirmed', 'preparing', 'ready', 'completed', 'cancelled' |
| `can_reorder` | BOOLEAN | ❌ | — | DEFAULT true, false if restaurant closed or items unavailable |
| `created_at` | TIMESTAMP | ❌ | — | Immutable |

**Items JSON Schema**:
```json
[
  {
    "item_id": "uuid",
    "menu_item_id": "uuid",
    "name": "Margherita Pizza",
    "quantity": 1,
    "price": 12.99,
    "modifiers": [
      {
        "modifier_group_id": "uuid",
        "modifier_group_name": "Crust",
        "selected_value": "Thin Crust"
      },
      {
        "modifier_group_id": "uuid",
        "modifier_group_name": "Extra Toppings",
        "selected_value": "Extra Cheese"
      }
    ],
    "special_instructions": "No onions"
  }
]
```

**Validation Rules**:
- `wallet_id`: Optional (guest orders NULL, return wallet customers set to FK)
- `restaurant_id`: Must exist in restaurant table
- `items`: Non-empty array, each item must have quantity >= 1
- `total`: Must be non-negative, sum of item prices
- `order_status`: One of defined enum values
- `order_date`: Must be within last 2 years (retention policy)

**Indexes**:
- `(wallet_id, order_date DESC)` - Fast retrieval of customer's order history
- `(restaurant_id, order_date DESC)` - Restaurant order history
- `(order_id, channel)` - Lookup by source order

**Access Control (RLS)**:
```sql
-- Customers can only view their own orders
CREATE POLICY rls_order_history_self ON order_history
  USING (wallet_id = (SELECT wallet_id FROM current_customer_context)
         OR wallet_id IS NULL);  -- Guest orders accessible to unauthenticated

-- Restaurants can see orders for their own restaurant (via restaurant_id)
CREATE POLICY rls_order_history_restaurant ON order_history
  USING (restaurant_id IN (SELECT restaurant_id FROM current_restaurant_context));
```

**State Lifecycle**:
```
order_placed (pending) → confirmed → preparing → ready → completed
                      → cancelled [if customer cancels before kitchen start]
                      → available_for_reorder [if restaurant still has items]
```

**Reorder Logic**:
- Customer selects "Reorder" on past order
- Copy items + modifiers to shopping cart
- Check `can_reorder` flag (false if items unavailable or restaurant closed)
- Allow customer to modify items before checkout

---

### 5. FavoriteRestaurant (P1 Feature)

**Primary Purpose**: Quick access to customer's preferred restaurants

**Fields**:

| Field | Type | Null? | Unique? | Notes |
|-------|------|-------|---------|-------|
| `favorite_restaurant_id` | UUID | ❌ | ✅ | PK, auto-generated |
| `wallet_id` | UUID | ❌ | — | FK → CustomerWallet, indexed |
| `restaurant_id` | UUID | ❌ | — | FK → Restaurant |
| `order_count` | INTEGER | ❌ | — | How many times ordered from this restaurant |
| `last_order_date` | TIMESTAMP | ✅ | — | Most recent order |
| `created_at` | TIMESTAMP | ❌ | — | When favorited |

**Unique Constraint**: `(wallet_id, restaurant_id)` - No duplicate favorites

**Indexes**:
- `(wallet_id, order_count DESC)` - Order favorites by frequency

**State Lifecycle**:
```
first_order_from_restaurant → favorite_auto_created (order_count=1)
                          → subsequent_orders → order_count_incremented
                          → customer_unfavorites → deleted
```

---

### 6. FavoriteItem (P1 Feature)

**Primary Purpose**: Save specific menu items with modifiers across restaurants

**Fields**:

| Field | Type | Null? | Unique? | Notes |
|-------|------|-------|---------|-------|
| `favorite_item_id` | UUID | ❌ | ✅ | PK, auto-generated |
| `wallet_id` | UUID | ❌ | — | FK → CustomerWallet |
| `restaurant_id` | UUID | ❌ | — | FK → Restaurant |
| `menu_item_id` | UUID | ❌ | — | FK → MenuItem |
| `modifiers` | JSONB | ❌ | — | Saved customizations (see schema below) |
| `nickname` | VARCHAR(100) | ✅ | — | Optional (e.g., "My usual burger") |
| `created_at` | TIMESTAMP | ❌ | — | When saved as favorite |

**Modifiers JSON Schema**:
```json
[
  {
    "modifier_group_id": "uuid",
    "modifier_group_name": "Toppings",
    "selected_value": "Extra Cheese"
  },
  {
    "modifier_group_id": "uuid",
    "modifier_group_name": "Sauce",
    "selected_value": "Spicy"
  }
]
```

**Unique Constraint**: `(wallet_id, restaurant_id, menu_item_id)` - No duplicate saved items

**Indexes**:
- `(wallet_id, restaurant_id)` - Favorites per restaurant

**Olivia Integration** (P1):
- Voice command: "Order my usual burger from Pizza Place"
- Olivia retrieves favorite item with saved modifiers
- Customer confirms → adds to cart with saved modifiers

---

### 7. SMSVerification

**Primary Purpose**: Temporary verification records for phone-based authentication

**Fields**:

| Field | Type | Null? | Unique? | Notes |
|-------|------|-------|---------|-------|
| `verification_id` | UUID | ❌ | ✅ | PK, auto-generated |
| `phone_number` | VARCHAR(20) | ❌ | — | E.164 format (indexed) |
| `code` | VARCHAR(6) | ❌ | — | 6-digit code, numeric only |
| `purpose` | ENUM | ❌ | — | 'wallet_creation', 'login', 'phone_change' |
| `sent_at` | TIMESTAMP | ❌ | — | When code was sent |
| `expires_at` | TIMESTAMP | ❌ | — | sent_at + 10 minutes |
| `verified_at` | TIMESTAMP | ✅ | — | When code was verified (nullable = not yet verified) |
| `attempts` | INTEGER | ❌ | — | Failed verification attempts, DEFAULT 0, max 5 |

**Validation Rules**:
- `code`: Must be exactly 6 digits
- `expires_at`: Must be >= sent_at + 10 minutes
- `attempts`: If >= 5, reject further attempts (wait for expiry)
- Only 1 active code per phone_number (invalidate older codes on new request)

**Indexes**:
- `(phone_number, code)` - Fast lookup for verification
- `(expires_at)` - Cleanup expired records (TTL: keep 30 days for audit)

**State Lifecycle**:
```
code_generated → sent_via_twilio → awaiting_verification
              → code_entered_correct → verified_at=NOW() → wallet_created OR login_successful
              → code_entered_wrong (5x) → rejected → wait for new code
              → 10_minutes_expired → invalid_code → request new code
```

**Cleanup**:
- Delete records where `expires_at < NOW() - INTERVAL '30 days'` (nightly batch)
- Retain 30 days for audit trail (GDPR compliance)

---

### 8. AuditLog

**Primary Purpose**: Immutable append-only log of all access to customer PII (GDPR compliance)

**Fields**:

| Field | Type | Null? | Unique? | Notes |
|-------|------|-------|---------|-------|
| `audit_id` | UUID | ❌ | ✅ | PK, auto-generated |
| `wallet_id` | UUID | ❌ | — | FK → CustomerWallet |
| `action` | VARCHAR(50) | ❌ | — | 'login', 'update_profile', 'add_payment', 'export_data', 'delete_request' |
| `timestamp` | TIMESTAMP | ❌ | — | UTC, immutable |
| `ip_address` | VARCHAR(45) | ❌ | — | IPv4 or IPv6, client IP |
| `user_agent` | VARCHAR(500) | ❌ | — | Device/browser info (e.g., "iPhone/iOS 17.1, Parcera App v1.2.3") |
| `metadata` | JSONB | ❌ | — | Context-specific data (see schema below) |

**Metadata JSON Schema** (varies by action):
```json
{
  "login": {
    "success": true,
    "mfa_used": false,
    "device_fingerprint": "abc123def456"
  },
  "update_profile": {
    "fields_updated": ["name", "email"],
    "old_values": {"name": "John", "email": "john@old.com"},
    "new_values": {"name": "John Doe", "email": "john@new.com"}
  },
  "add_payment": {
    "payment_method_id": "uuid",
    "card_brand": "Visa",
    "card_last_four": "4242",
    "set_as_default": true
  },
  "export_data": {
    "export_id": "uuid",
    "delivery_method": "email",
    "status": "completed",
    "records_included": 237
  },
  "delete_request": {
    "initiated_by": "customer",
    "scheduled_deletion_date": "2025-12-04"
  }
}
```

**Validation Rules**:
- `action`: One of defined enum values
- `timestamp`: Must be recent (within last 5 years)
- `ip_address`: Valid IPv4 or IPv6 format
- `metadata`: JSON object with action-specific keys

**Indexes**:
- `(wallet_id, timestamp DESC)` - Customer can view their own audit log
- `(action, timestamp DESC)` - Admin queries for compliance audits

**Access Control (RLS)**:
```sql
-- Customers can view their own audit log
CREATE POLICY rls_audit_log_self ON audit_log
  USING (wallet_id = (SELECT wallet_id FROM current_customer_context));

-- Immutability: No updates or deletes after creation
CREATE TRIGGER prevent_audit_modification BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION raise('Cannot modify audit log');
```

**Retention Policy**:
- Keep all records for 1 year (GDPR minimum)
- Archive to cold storage after 1 year (for compliance audits)
- Never delete unless customer requests full data deletion

---

## Database Schema Constraints

### Foreign Key Constraints

```sql
-- CustomerWallet → PaymentMethod
ALTER TABLE payment_method
ADD CONSTRAINT fk_payment_method_wallet
FOREIGN KEY (wallet_id) REFERENCES customer_wallet(wallet_id)
ON DELETE CASCADE;

-- CustomerWallet → DeliveryAddress
ALTER TABLE delivery_address
ADD CONSTRAINT fk_delivery_address_wallet
FOREIGN KEY (wallet_id) REFERENCES customer_wallet(wallet_id)
ON DELETE CASCADE;

-- CustomerWallet ← OrderHistory (optional)
ALTER TABLE order_history
ADD CONSTRAINT fk_order_history_wallet
FOREIGN KEY (wallet_id) REFERENCES customer_wallet(wallet_id)
ON DELETE SET NULL;

-- Default payment/address (deferred FK to avoid circular dependency)
ALTER TABLE customer_wallet
ADD CONSTRAINT fk_wallet_default_payment
FOREIGN KEY (default_payment_method_id) REFERENCES payment_method(payment_method_id)
ON DELETE SET NULL;

ALTER TABLE customer_wallet
ADD CONSTRAINT fk_wallet_default_address
FOREIGN KEY (default_delivery_address_id) REFERENCES delivery_address(address_id)
ON DELETE SET NULL;
```

### Unique Constraints

```sql
-- Only 1 default payment per wallet
CREATE UNIQUE INDEX idx_wallet_default_payment
ON payment_method(wallet_id) WHERE is_default = true AND deleted_at IS NULL;

-- Only 1 default address per wallet
CREATE UNIQUE INDEX idx_wallet_default_address
ON delivery_address(wallet_id) WHERE is_default = true AND deleted_at IS NULL;

-- One favorite per (wallet, restaurant, item)
CREATE UNIQUE INDEX idx_favorite_item_unique
ON favorite_item(wallet_id, restaurant_id, menu_item_id) WHERE deleted_at IS NULL;

-- One favorite per (wallet, restaurant)
CREATE UNIQUE INDEX idx_favorite_restaurant_unique
ON favorite_restaurant(wallet_id, restaurant_id) WHERE deleted_at IS NULL;
```

### Triggers

```sql
-- Auto-increment order_number per restaurant per day
CREATE TRIGGER set_order_number BEFORE INSERT ON order_history
  FOR EACH ROW
  EXECUTE FUNCTION next_order_number_for_restaurant();

-- Prevent audit log modifications
CREATE TRIGGER prevent_audit_modification BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW
  EXECUTE FUNCTION raise('Cannot modify audit log');

-- Cascade soft delete: wallet deletion invalidates payment/address defaults
CREATE TRIGGER cascade_wallet_deletion AFTER UPDATE ON customer_wallet
  FOR EACH ROW
  WHEN (NEW.deleted_at IS NOT NULL AND OLD.deleted_at IS NULL)
  EXECUTE FUNCTION clear_wallet_defaults();
```

---

## Row-Level Security (RLS) Policies

**Principle**: Customers access only their own data. Restaurants access orders for their own location. No cross-tenant leakage.

```sql
-- Enable RLS for all customer-facing tables
ALTER TABLE customer_wallet ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_method ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_address ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorite_restaurant ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorite_item ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

-- Customer context (set from JWT)
SET app.current_wallet_id = <jwt.wallet_id>;
SET app.current_restaurant_id = <jwt.restaurant_id>;

-- Customer can only view their own data
CREATE POLICY rls_customer_self ON customer_wallet
  USING (wallet_id = current_setting('app.current_wallet_id')::uuid);

CREATE POLICY rls_payment_self ON payment_method
  USING (wallet_id = current_setting('app.current_wallet_id')::uuid);

-- Restaurants can only view orders for their location
CREATE POLICY rls_order_restaurant ON order_history
  USING (restaurant_id = current_setting('app.current_restaurant_id')::uuid
         OR wallet_id = current_setting('app.current_wallet_id')::uuid);
```

---

## Schema Evolution & Migrations

**Version Control**: All migrations tracked in `src/migrations/` with timestamps
**Naming Convention**: `YYYY_MM_DD_HHmmss_{description}.sql`
**Rollback Support**: Every migration has a corresponding downgrade

**Example Migration**:
```sql
-- Migration: 2025_11_04_120000_create_wallet_schema.sql

BEGIN;

CREATE TABLE customer_wallet (
  wallet_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_number VARCHAR(20) NOT NULL UNIQUE,
  phone_verified BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMP
);

CREATE INDEX idx_wallet_phone ON customer_wallet(phone_number);

COMMIT;
```

---

## Data Import/Export

**For Developer Testing**: Sample data seeding script (not for production)

```python
from src.models import CustomerWallet, PaymentMethod, DeliveryAddress

# Seed test wallet
wallet = CustomerWallet(
    phone_number="+12025551234",
    phone_verified=True,
    name="Test Customer",
    marketing_opt_in=True
)

payment = PaymentMethod(
    wallet_id=wallet.wallet_id,
    type="card",
    card_brand="Visa",
    card_last_four="4242",
    payment_gateway="authorize_net",
    gateway_token="ENCRYPTED_TOKEN_HERE",
    is_default=True
)

address = DeliveryAddress(
    wallet_id=wallet.wallet_id,
    label="Home",
    street_address="123 Main St",
    city="Washington",
    state="DC",
    zip_code="20001",
    latitude=38.9072,
    longitude=-77.0369,
    is_default=True
)
```

---

**Status**: ✅ Data model complete, ready for API contract generation  
**Next**: Generate `contracts/*.yaml` with OpenAPI schemas for all endpoints

