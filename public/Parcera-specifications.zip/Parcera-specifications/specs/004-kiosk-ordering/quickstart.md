# Quickstart: Voice-Enabled Kiosk Ordering

**Feature**: 004-kiosk-ordering
**Created**: 2025-11-04
**Audience**: Backend engineers, React Native developers, QA

---

## Overview

This quickstart provides step-by-step instructions for setting up the kiosk ordering system locally and running the MVP user stories (P0 features).

---

## Prerequisites

### System Requirements

```plaintext
Backend (Python/FastAPI):
- Python 3.11+
- PostgreSQL 14+ with admin access
- Redis 6.0+
- Docker & Docker Compose (optional, recommended)

Kiosk UI (React Native):
- Node.js 18+
- npm or yarn
- Xcode 14+ (iOS development, optional for MVP)
- Android SDK (Android development, optional for MVP)

Development Environment:
- Git
- VS Code or PyCharm/WebStorm
- curl or Postman (for API testing)
```

### Environment Variables

Create `.env` file in project root:

```plaintext
# Backend Configuration
DATABASE_URL=postgresql://user:password@localhost:5432/parcera_kiosk_dev
REDIS_URL=redis://localhost:6379
OLIVIA_API_KEY=<from-olivia.io-partner>
AUTHORIZE_NET_API_ID=<payment-gateway-credentials>
AUTHORIZE_NET_TRANSACTION_KEY=<payment-gateway-credentials>

# Kiosk Hardware (Development Mock)
PAYMENT_TERMINAL_MOCK=true
PRINTER_MOCK=true

# Feature Flags
ENABLE_VOICE_INPUT=true
ENABLE_OFFLINE_MODE=true
```

---

## Local Development Setup

### Option 1: Docker Compose (Recommended for MVP)

```bash
# Clone repository
git clone <repo-url>
cd parcera-specs

# Start backend + database + redis
docker-compose -f specs/004-kiosk-ordering/docker-compose.yml up -d

# Check services are running
docker ps
# Should show: postgres, redis, kiosk-backend containers

# Verify database migrations
docker exec kiosk-backend python -m alembic upgrade head

# Backend available at: http://localhost:8000
# API docs: http://localhost:8000/docs (FastAPI Swagger UI)
```

### Option 2: Manual Setup (for detailed debugging)

#### Step 1: Setup Backend

```bash
# Create virtual environment
python3.11 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
cd backend
pip install -r requirements.txt

# Create PostgreSQL database
createdb parcera_kiosk_dev

# Run migrations
python -m alembic upgrade head

# Start FastAPI server
python -m uvicorn src.main:app --reload --port 8000
```

#### Step 2: Setup Kiosk UI

```bash
# Open new terminal
cd kiosk-ui

# Install dependencies
npm install

# For iOS (macOS only)
cd ios && pod install && cd ..

# Start development server (web preview)
npm start

# For Android emulator
npm run android

# For iOS simulator
npm run ios
```

---

## Running P0 User Stories

### User Story 1: Quick Touch-Based Order with Voice Assistance

**Objective**: Complete a 3-item order using touch + optional voice

#### Step 1: Start Session

```bash
# Terminal 1: Backend health check
curl http://localhost:8000/health

# Should return:
# { "status": "ok", "timestamp": "2025-11-04T..." }
```

#### Step 2: Register Kiosk Device (if not already done)

```bash
curl -X POST http://localhost:8000/v1/kiosks/register \
  -H "Content-Type: application/json" \
  -d '{
    "activation_code": "TEST001",
    "device_name": "Kiosk Dev",
    "hardware_model": "Androic Vape 27",
    "payment_terminal_id": "PAX123456789",
    "printer_id": "EPSON001",
    "microphone_model": "Shure SM87A"
  }'

# Response includes:
# { "kiosk_id": 1, "api_key": "kiosk_sk_...", ... }
```

#### Step 3: Create Session

```bash
curl -X POST http://localhost:8000/v1/sessions \
  -H "Content-Type: application/json" \
  -d '{
    "kiosk_id": 1,
    "language": "en",
    "accessibility_mode": false
  }'

# Response:
# { "session_id": "uuid...", "status": "active", "expires_at": "..." }
```

#### Step 4: Create Order (Draft)

```bash
SESSION_ID="<from-previous-response>"

curl -X POST http://localhost:8000/v1/orders \
  -H "Content-Type: application/json" \
  -d "{\"session_id\": \"$SESSION_ID\"}"

# Response:
# { "order_id": "uuid...", "items": [], "total": 0.00 }
```

#### Step 5: Add Items to Cart

```bash
ORDER_ID="<from-previous-response>"

# Add Burger
curl -X POST http://localhost:8000/v1/orders/$ORDER_ID/items \
  -H "Content-Type: application/json" \
  -d '{
    "menu_item_id": "550e8400-e29b-41d4-a716-446655440001",
    "quantity": 1,
    "modifiers": { "size": "Large" }
  }'

# Add Fries
curl -X POST http://localhost:8000/v1/orders/$ORDER_ID/items \
  -H "Content-Type: application/json" \
  -d '{
    "menu_item_id": "550e8400-e29b-41d4-a716-446655440002",
    "quantity": 1
  }'

# Add Drink
curl -X POST http://localhost:8000/v1/orders/$ORDER_ID/items \
  -H "Content-Type: application/json" \
  -d '{
    "menu_item_id": "550e8400-e29b-41d4-a716-446655440003",
    "quantity": 1,
    "modifiers": { "size": "Medium" }
  }'

# Verify order
curl http://localhost:8000/v1/orders/$ORDER_ID
# Should show 3 items with calculated total
```

#### Step 6: Checkout

```bash
curl -X POST http://localhost:8000/v1/orders/$ORDER_ID/checkout
# Response includes subtotal, tax, total
```

#### Step 7: Payment (Mock)

```bash
# In development, payment is mocked (PAYMENT_TERMINAL_MOCK=true)
# In production, payment terminal handles card processing

# Simulate payment approval
curl -X POST http://localhost:8000/v1/payments \
  -H "Content-Type: application/json" \
  -d "{
    \"order_id\": \"$ORDER_ID\",
    \"amount\": 25.99,
    \"payment_method\": \"nfc\",
    \"gateway\": \"Authorize.Net\"
  }"

# Response: { "transaction_id": "uuid...", "status": "approved" }
```

#### Step 8: Submit to POS

```bash
TRANSACTION_ID="<from-previous-response>"

curl -X POST http://localhost:8000/v1/orders/$ORDER_ID/submit \
  -H "Content-Type: application/json" \
  -d "{\"payment_transaction_id\": \"$TRANSACTION_ID\"}"

# Response:
# {
#   "order_id": "uuid...",
#   "order_number": "20251104-0001",
#   "status": "submitted",
#   "pos_system": "Toast"
# }
```

#### Step 9: Print Ticket

```bash
# Ticket is printed automatically by backend (in dev, logged to console)
# Check logs: docker logs kiosk-backend | grep "TICKET PRINTED"
```

---

### User Story 2: Accessible Ordering (Voice-Only)

**Objective**: Complete entire order using only voice commands

#### Step 1-3: Setup (same as User Story 1)

```bash
# Register kiosk, create session
# (see User Story 1, steps 1-3)
```

#### Step 4: Create Session with Accessibility Mode

```bash
curl -X POST http://localhost:8000/v1/sessions \
  -H "Content-Type: application/json" \
  -d '{
    "kiosk_id": 1,
    "language": "en",
    "accessibility_mode": true
  }'

# Response indicates accessibility mode is active
```

#### Step 5: Voice Command - Add Items

Simulate voice input via API (in production, Olivia.io WebSocket):

```bash
curl -X POST http://localhost:8000/v1/voice/command \
  -H "Content-Type: application/json" \
  -d "{
    \"session_id\": \"$SESSION_ID\",
    \"transcript\": \"Add a large burger and a medium fries\",
    \"confidence\": 0.92
  }"

# Backend parses command, adds items to order
# Returns TTS response: "Added large burger and medium fries to your cart"
```

#### Step 6: Voice Command - Checkout

```bash
curl -X POST http://localhost:8000/v1/voice/command \
  -H "Content-Type: application/json" \
  -d "{
    \"session_id\": \"$SESSION_ID\",
    \"transcript\": \"Checkout\",
    \"confidence\": 0.95
  }"

# TTS: "Your total is $25.99. Please tap your card on the reader"
```

---

### User Story 3: Payment & Order Ticket

**Objective**: Process payment and print order ticket

(Covered in User Story 1, Steps 7-9)

---

## Running Tests

### Backend Tests

```bash
# Unit tests
cd backend
pytest tests/unit -v

# Integration tests (requires database)
pytest tests/integration -v

# Contract tests (verify OpenAPI schemas)
pytest tests/contract -v

# All tests with coverage
pytest --cov=src tests/
```

### Frontend Tests

```bash
cd kiosk-ui

# Unit tests
npm test -- --watch

# Integration tests
npm run test:integration

# Test coverage
npm test -- --coverage
```

---

## Common Development Tasks

### Add New Menu Item

```bash
# Menu items are managed by Feature 002 (Menu Management)
# For testing, seed sample items:

curl -X POST http://localhost:8000/v1/menu/items \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Classic Burger",
    "description": "1/4 lb beef patty with lettuce, tomato",
    "price": 12.99,
    "category": "burgers",
    "modifiers": [
      { "name": "Size", "options": ["Small", "Medium", "Large"] },
      { "name": "Toppings", "options": ["Cheese", "Bacon", "Pickles"] }
    ]
  }'
```

### Mock Payment Terminal

```bash
# In PAYMENT_TERMINAL_MOCK=true mode, all payment commands return success
# To test declined card:

curl -X POST http://localhost:8000/v1/payments \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": "...",
    "amount": 25.99,
    "payment_method": "nfc",
    "test_card": "DECLINED"
  }'

# Returns: { "status": "declined", "reason": "Insufficient funds" }
```

### Trigger Offline Mode

```bash
# Stop Redis to simulate backend unavailability
docker stop kiosk-redis

# Kiosk will queue orders locally
# When Redis comes back: docker start kiosk-redis
# Orders sync automatically
```

### Monitor Database

```bash
# Connect to PostgreSQL
psql postgresql://user:password@localhost:5432/parcera_kiosk_dev

# View recent orders
SELECT order_id, order_status, total FROM kiosk_orders ORDER BY created_at DESC LIMIT 5;

# View sessions
SELECT session_id, status, last_activity_at FROM kiosk_sessions WHERE status = 'active';

# View payment transactions
SELECT transaction_id, status, amount FROM payment_transactions ORDER BY created_at DESC;
```

---

## Troubleshooting

### Database Connection Refused

```bash
# Check PostgreSQL is running
docker ps | grep postgres

# If not running:
docker-compose up -d postgres

# Verify connection:
psql postgresql://user:password@localhost:5432/parcera_kiosk_dev -c "SELECT 1"
```

### Redis Connection Error

```bash
# Check Redis is running
docker ps | grep redis

# If not, restart:
docker-compose up -d redis

# Verify:
redis-cli ping  # Should return: PONG
```

### Voice Commands Not Working

```bash
# Check Olivia.io API key is set
grep OLIVIA_API_KEY .env

# Mock voice in development
# Set OLIVIA_MOCK=true in .env to use hardcoded responses

# Check WebSocket connection
curl -i -N -H "Connection: Upgrade" \
  -H "Upgrade: websocket" \
  wss://voice.olivia.io/channel/kiosk?api_key=<YOUR_KEY>
```

### Payment Terminal Integration Failing

```bash
# In development, use mock payment:
# Set PAYMENT_TERMINAL_MOCK=true

# Check PAX terminal connection (production):
# Kiosk should detect terminal on POST request to /v1/payments

# View payment terminal logs:
docker logs kiosk-backend | grep "payment_terminal"
```

---

## Performance Testing

### Load Test (10 concurrent orders)

```bash
# Install locust
pip install locust

# Create locustfile.py with kiosk order scenarios
cd backend && locust -f ../tests/load/locustfile.py \
  -u 10 -r 2 -t 5m \
  http://localhost:8000
```

### Voice Latency Test

```bash
# Measure end-to-end voice command latency
time curl -X POST http://localhost:8000/v1/voice/command \
  -d '{"transcript": "Add burger"}'

# Target: <1500ms for Olivia.io + backend processing
```

---

## Next Steps

1. **Implement Contract Tests**: Create pytest fixtures for OpenAPI validation
2. **Setup CI/CD**: GitHub Actions workflow for testing on each commit
3. **Deploy to Staging**: Docker image build + push to container registry
4. **Hardware Testing**: Test with actual Androic kiosk + PAX terminal
5. **POS Integration**: Configure Toast/Square/Clover API credentials, test order submission

---

**STATUS**: ✅ QUICKSTART COMPLETE - Ready for development sprint
