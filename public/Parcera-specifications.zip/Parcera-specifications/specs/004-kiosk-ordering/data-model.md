# Data Model: Voice-Enabled Kiosk Ordering

**Feature**: 004-kiosk-ordering
**Created**: 2025-11-04
**Status**: Technical Specification
**PostgreSQL Version**: 14+

---

## Overview

This document defines the complete data model for the Voice-Enabled Kiosk Ordering feature, including PostgreSQL schema definitions, entity relationships, row-level security policies, indexes, validation rules, and state transitions.

**Architecture Pattern**: Shared multi-tenant (RLS) for SMB, with tenant_id on all kiosk tables for isolation.

---

## Entity Relationship Diagram

```plaintext
┌─────────────────────┐
│   Restaurants       │ (from feature 001)
│ ─────────────────── │
│ id (UUID, PK)       │
│ tenant_id (UUID, FK)│
└──────────┬──────────┘
           │
           │ 1:N
           │
┌──────────▼──────────────────┐         ┌──────────────────────┐
│   Locations                 │◄────────┤  KioskDevices        │
│ ─────────────────────────── │  N:1    │ ────────────────────│
│ id (UUID, PK)               │         │ kiosk_id (SERIAL, PK)│
│ restaurant_id (UUID, FK)    │         │ location_id (FK)     │
│ tenant_id (UUID, FK)        │         │ status               │
│ address, timezone           │         └──────────┬───────────┘
└──────────────────────────────┘                   │
                                                   │ 1:N
                                                   │
                        ┌──────────────────────────┴──────┐
                        │                                 │
          ┌─────────────▼─────────────┐      ┌───────────▼──────────┐
          │   KioskSessions           │      │  KioskInteractions   │
          │ ─────────────────────────│      │ ──────────────────── │
          │ session_id (UUID, PK)    │      │ interaction_id (UUID)│
          │ kiosk_id (FK)            │      │ session_id (FK)      │
          │ restaurant_id (UUID, FK) │      │ type (voice/touch)   │
          │ tenant_id (UUID, FK)     │      │ timestamp            │
          │ status, language         │      │ voice_confidence     │
          │ started_at, ended_at     │      └──────────────────────┘
          └──────────────┬────────────┘
                        │
                        │ 1:N
                        │
          ┌─────────────▼──────────────────┐
          │      KioskOrders               │
          │ ───────────────────────────── │
          │ order_id (UUID, PK)           │
          │ session_id (UUID, FK)         │
          │ restaurant_id (UUID, FK)      │
          │ tenant_id (UUID, FK)          │
          │ order_number (INT)            │
          │ items (JSONB)                 │
          │ subtotal, tax, total          │
          │ payment_status, order_status  │
          │ created_at, updated_at        │
          └──────────┬─────────────────────┘
                    │
          ┌─────────┴──────────────────┐
          │                            │
┌─────────▼─────────────────┐ ┌──────▼──────────────────┐
│  PaymentTransactions      │ │     OrderTickets       │
│ ───────────────────────── │ │ ──────────────────────│
│ transaction_id (UUID, PK) │ │ ticket_id (UUID, PK)  │
│ order_id (UUID, FK)       │ │ order_id (UUID, FK)   │
│ amount (DECIMAL)          │ │ ticket_number (INT)   │
│ payment_method, status    │ │ qr_code_data          │
│ gateway_transaction_id    │ │ printed_at            │
│ retry_count               │ │ print_status          │
└──────────────────────────┘ └───────────────────────┘
```

---

## Schema Definitions

### 1. KioskDevices Table

**Purpose**: Registry of physical kiosk hardware units

```sql
CREATE TABLE public.kiosk_devices (
    kiosk_id SERIAL PRIMARY KEY,
    location_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    
    -- Device identification
    device_name VARCHAR(100) NOT NULL,  -- "Kiosk 1", "Kiosk Front"
    hardware_model VARCHAR(100),         -- "Androic Vape 27"
    
    -- Hardware components
    payment_terminal_id VARCHAR(50),     -- PAX A920 serial number
    printer_id VARCHAR(50),              -- Thermal printer ID
    microphone_model VARCHAR(100),       -- Hardware microphone for noise cancellation
    screen_size VARCHAR(20),             -- "27 inch" or similar
    
    -- Accessibility hardware
    accessibility_hardware JSONB,        -- { external_switch: true, etc }
    
    -- Device status & monitoring
    status VARCHAR(20) NOT NULL DEFAULT 'online'
        CHECK (status IN ('online', 'offline', 'maintenance')),
    last_heartbeat TIMESTAMPTZ,
    installed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    
    -- Constraints
    FOREIGN KEY (location_id, tenant_id) REFERENCES locations(id, tenant_id),
    CONSTRAINT device_name_unique_per_location UNIQUE (location_id, device_name),
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX idx_kiosk_devices_location_id ON public.kiosk_devices(location_id);
CREATE INDEX idx_kiosk_devices_tenant_id ON public.kiosk_devices(tenant_id);
CREATE INDEX idx_kiosk_devices_status ON public.kiosk_devices(status);

-- Row-Level Security
ALTER TABLE public.kiosk_devices ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_kiosk_devices_access ON public.kiosk_devices
    FOR ALL
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);
```

### 2. KioskSessions Table

**Purpose**: Track individual user sessions at kiosk (60-second timeout)

```sql
CREATE TABLE public.kiosk_sessions (
    session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kiosk_id SERIAL NOT NULL,
    restaurant_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    
    -- Session context
    language VARCHAR(5) NOT NULL DEFAULT 'en' CHECK (language IN ('en', 'es')),
    accessibility_mode BOOLEAN DEFAULT FALSE,
    voice_enabled BOOLEAN DEFAULT TRUE,
    
    -- Ambient environment
    ambient_noise_level NUMERIC(5, 2),  -- dB measurement
    
    -- Session lifecycle
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'timed_out', 'completed', 'abandoned')),
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    ended_at TIMESTAMPTZ,
    last_activity_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    
    -- Constraints
    FOREIGN KEY (kiosk_id) REFERENCES public.kiosk_devices(kiosk_id),
    FOREIGN KEY (restaurant_id, tenant_id) REFERENCES restaurants(id, tenant_id),
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX idx_kiosk_sessions_kiosk_id ON public.kiosk_sessions(kiosk_id);
CREATE INDEX idx_kiosk_sessions_tenant_id ON public.kiosk_sessions(tenant_id);
CREATE INDEX idx_kiosk_sessions_status ON public.kiosk_sessions(status);
CREATE INDEX idx_kiosk_sessions_started_at ON public.kiosk_sessions(started_at);

-- Row-Level Security
ALTER TABLE public.kiosk_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_kiosk_sessions_access ON public.kiosk_sessions
    FOR ALL
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);
```

### 3. KioskOrders Table

**Purpose**: Order records created at kiosk with full lifecycle tracking

```sql
CREATE TABLE public.kiosk_orders (
    order_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL,
    restaurant_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    
    -- Order identification
    order_number BIGINT NOT NULL,  -- Unique per restaurant per day, sequential
    
    -- Order contents
    items JSONB NOT NULL,  -- Array: [{menu_item_id, quantity, modifiers, special_instructions}]
    
    -- Pricing
    subtotal DECIMAL(10, 2) NOT NULL,
    tax DECIMAL(10, 2) NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    
    -- Payment tracking
    payment_status VARCHAR(20) NOT NULL DEFAULT 'pending'
        CHECK (payment_status IN ('pending', 'approved', 'declined', 'refunded')),
    payment_method VARCHAR(20),  -- 'card_swipe', 'chip', 'nfc', 'mobile_wallet'
    payment_transaction_id UUID,
    
    -- POS integration
    pos_order_id VARCHAR(255),     -- Toast/Square/Clover order ID
    order_status VARCHAR(20) NOT NULL DEFAULT 'draft'
        CHECK (order_status IN ('draft', 'submitted', 'in_progress', 'ready', 'completed', 'failed')),
    
    -- Constraints
    FOREIGN KEY (session_id) REFERENCES public.kiosk_sessions(session_id),
    FOREIGN KEY (restaurant_id, tenant_id) REFERENCES restaurants(id, tenant_id),
    FOREIGN KEY (payment_transaction_id) REFERENCES public.payment_transactions(transaction_id),
    CONSTRAINT unique_order_number_per_restaurant_day 
        UNIQUE (restaurant_id, order_number, DATE(created_at)),
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX idx_kiosk_orders_session_id ON public.kiosk_orders(session_id);
CREATE INDEX idx_kiosk_orders_restaurant_id ON public.kiosk_orders(restaurant_id);
CREATE INDEX idx_kiosk_orders_tenant_id ON public.kiosk_orders(tenant_id);
CREATE INDEX idx_kiosk_orders_payment_status ON public.kiosk_orders(payment_status);
CREATE INDEX idx_kiosk_orders_order_status ON public.kiosk_orders(order_status);
CREATE INDEX idx_kiosk_orders_created_at ON public.kiosk_orders(created_at);

-- Row-Level Security
ALTER TABLE public.kiosk_orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_kiosk_orders_access ON public.kiosk_orders
    FOR ALL
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);
```

### 4. KioskInteractions Table

**Purpose**: Log all user interactions (voice/touch) for analytics and debugging

```sql
CREATE TABLE public.kiosk_interactions (
    interaction_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    
    -- Interaction metadata
    interaction_type VARCHAR(30) NOT NULL
        CHECK (interaction_type IN ('touch', 'voice', 'voice_fallback', 'timeout_warning', 'error')),
    timestamp TIMESTAMPTZ NOT NULL DEFAULT now(),
    
    -- Voice-specific fields
    voice_transcript TEXT,
    voice_confidence NUMERIC(3, 2),  -- 0.00 to 1.00
    
    -- Action taken
    action_taken VARCHAR(50),  -- 'add_item', 'remove_item', 'modify_cart', 'checkout'
    
    -- Additional context
    context_data JSONB,  -- { menu_item_id, quantity, modifiers, etc }
    
    -- Constraints
    FOREIGN KEY (session_id) REFERENCES public.kiosk_sessions(session_id),
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX idx_kiosk_interactions_session_id ON public.kiosk_interactions(session_id);
CREATE INDEX idx_kiosk_interactions_tenant_id ON public.kiosk_interactions(tenant_id);
CREATE INDEX idx_kiosk_interactions_timestamp ON public.kiosk_interactions(timestamp);
CREATE INDEX idx_kiosk_interactions_interaction_type ON public.kiosk_interactions(interaction_type);

-- Row-Level Security
ALTER TABLE public.kiosk_interactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_kiosk_interactions_access ON public.kiosk_interactions
    FOR ALL
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);
```

### 5. PaymentTransactions Table

**Purpose**: Record all payment processing events

```sql
CREATE TABLE public.payment_transactions (
    transaction_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    
    -- Payment details
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'USD',
    payment_method VARCHAR(20) NOT NULL,  -- 'card_swipe', 'chip', 'nfc', 'mobile_wallet'
    card_last_four VARCHAR(4),
    card_type VARCHAR(20),  -- 'visa', 'mastercard', 'amex'
    
    -- Gateway integration
    payment_gateway VARCHAR(50) NOT NULL,  -- 'Authorize.Net', 'Stacks', 'Adyen'
    gateway_transaction_id VARCHAR(255),
    gateway_response JSONB,  -- Full response from payment gateway
    
    -- Status tracking
    status VARCHAR(20) NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'approved', 'declined', 'refunded', 'error')),
    
    -- Retry logic
    retry_count INTEGER DEFAULT 0,
    processed_at TIMESTAMPTZ,
    
    -- Constraints
    FOREIGN KEY (order_id) REFERENCES public.kiosk_orders(order_id),
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX idx_payment_transactions_order_id ON public.payment_transactions(order_id);
CREATE INDEX idx_payment_transactions_tenant_id ON public.payment_transactions(tenant_id);
CREATE INDEX idx_payment_transactions_status ON public.payment_transactions(status);
CREATE INDEX idx_payment_transactions_gateway_transaction_id ON public.payment_transactions(gateway_transaction_id);

-- Row-Level Security
ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_payment_transactions_access ON public.payment_transactions
    FOR ALL
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);
```

### 6. OrderTickets Table

**Purpose**: Track printed order tickets with QR codes

```sql
CREATE TABLE public.order_tickets (
    ticket_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    
    -- Ticket identification
    ticket_number BIGINT NOT NULL,  -- Unique per restaurant per day
    
    -- QR code data
    qr_code_data TEXT NOT NULL,  -- URL or order lookup code
    
    -- Printer tracking
    printer_id VARCHAR(50),
    print_status VARCHAR(20) NOT NULL DEFAULT 'success'
        CHECK (print_status IN ('success', 'failed', 'retrying')),
    printed_at TIMESTAMPTZ,
    
    -- Content (for reprinting)
    ticket_content TEXT NOT NULL,
    
    -- Constraints
    FOREIGN KEY (order_id) REFERENCES public.kiosk_orders(order_id),
    CONSTRAINT unique_ticket_number_per_restaurant_day 
        UNIQUE (tenant_id, ticket_number, DATE(created_at)),
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX idx_order_tickets_order_id ON public.order_tickets(order_id);
CREATE INDEX idx_order_tickets_tenant_id ON public.order_tickets(tenant_id);
CREATE INDEX idx_order_tickets_print_status ON public.order_tickets(print_status);

-- Row-Level Security
ALTER TABLE public.order_tickets ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_order_tickets_access ON public.order_tickets
    FOR ALL
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);
```

---

## Key Design Decisions

### 1. Order Number Generation
- **Approach**: Sequence per restaurant per day (resets at midnight)
- **Format**: YYYYMMDD-{sequential} e.g., 20251104-0001
- **Why**: Customer-friendly, used on printed ticket, resets daily for management

### 2. Order Items Storage
- **Format**: JSONB array to support arbitrary modifiers without schema bloat
- **Schema** (each item):
  ```plaintext
  {
    menu_item_id: UUID,
    quantity: INT,
    modifiers: {
      size: "Large",
      toppings: ["pepperoni", "mushrooms"],
      special_instructions: "extra hot"
    },
    unit_price: DECIMAL,
    total_price: DECIMAL
  }
  ```
- **Why**: Flexible for future modifier types without migrations

### 3. Payment Processing Isolation
- **PaymentTransaction** is separate from KioskOrder
- Payment can be approved but POS submission failed (handled by offline queue)
- Enables retry logic without re-charging customer

### 4. Tenant Isolation
- ALL tables have `tenant_id` column
- Row-Level Security enforced at database layer
- `current_setting('app.current_tenant_id')` passed by middleware
- No data leakage possible even with buggy SQL queries

### 5. Session Timeout
- **Mechanism**: Background job queries `last_activity_at > 60s`
- **Action**: Set status='timed_out', end_at=now()
- **Cart Preservation**: Abandoned carts discarded (not stored)

---

## Constraints & Validations

| Field | Constraint | Purpose |
|-------|-----------|---------|
| `total`, `subtotal`, `tax` | ≥0, ≤999999.99 | Prevent negative/overflow amounts |
| `order_number` | Unique per (restaurant_id, date) | Prevent duplicate printed numbers |
| `voice_confidence` | 0.00-1.00 | Confidence score range |
| `ambient_noise_level` | 0-150 dB | Realistic noise range |
| `language` | 'en', 'es' | Supported languages (MVP) |
| `accessibility_mode` | BOOLEAN | Feature flag per session |
| `payment_status` | Enum (pending/approved/declined/refunded) | State machine |
| `order_status` | Enum (draft/submitted/in_progress/ready/completed/failed) | State machine |

---

## Indexes for Performance

**Query Patterns**:

```sql
-- Session queries (highest frequency)
SELECT * FROM kiosk_sessions WHERE kiosk_id = ? AND status = 'active' ORDER BY started_at DESC;
-- Index: (kiosk_id, status, started_at)

-- Order submission history
SELECT * FROM kiosk_orders WHERE restaurant_id = ? AND created_at > now() - INTERVAL '24 hours';
-- Index: (restaurant_id, created_at)

-- Payment retry queue
SELECT * FROM payment_transactions WHERE status = 'pending' AND retry_count < 3;
-- Index: (status, retry_count)

-- Voice analytics
SELECT COUNT(*), AVG(voice_confidence) FROM kiosk_interactions 
    WHERE session_id = ? AND interaction_type = 'voice';
-- Index: (session_id, interaction_type)
```

---

## Migration Strategy

**Phase 1 (MVP)**:
1. Create all tables with RLS policies
2. Load test data (5-10 sample kiosks per restaurant)
3. Verify tenant isolation (test data leakage attempts)

**Phase 2 (Post-MVP)**:
1. Add TimescaleDB hypertable for kiosk_interactions (high-volume analytics)
2. Archive old kiosk_sessions (>30 days) to cold storage

---

**STATUS**: ✅ DATA MODEL COMPLETE - Ready for Phase 1 Contracts & Quickstart
