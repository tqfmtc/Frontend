# Research: Voice-Enabled Kiosk Ordering Architecture

**Feature**: 004-kiosk-ordering
**Created**: 2025-11-04
**Status**: Research & Recommendations

---

## Executive Summary

This document provides architectural research and recommendations for implementing the Parcera voice-enabled kiosk ordering system. The analysis covers kiosk hardware selection, payment terminal integration, offline mode strategy, voice AI deployment, and POS integration patterns.

**Key Recommendations**:
1. **Kiosk Hardware**: Android-based self-order kiosk (e.g., Androic Vape, Sensei, or similar) for cost-effectiveness and ecosystem maturity
2. **Payment Terminals**: PAX A920 or Ingenico Lane 3000 for proven POS integration and noise resilience
3. **Voice Deployment**: Olivia.io WebSocket connection with local fallback queue for offline scenarios
4. **Offline Mode**: SQLite + AsyncStorage for React Native, Redis for backend order queuing
5. **POS Integration**: Adapter pattern supporting Toast, Square, Clover with contract-based testing

---

## Decision 1: Kiosk Hardware Selection

### Decision: Android-Based Self-Order Kiosk (ARM64 Architecture)

### Rationale

**Hardware Requirements**:
- 21-27" touchscreen with capacitive touch (responsive, glove-friendly)
- Speaker output (≥85dB for restaurant noise levels)
- Microphone input (directional, noise-canceling recommended)
- Payment terminal connector (USB or Ethernet)
- Thermal printer connector (ESC/POS protocol)
- Network connectivity (Wi-Fi 6 or Ethernet with failover)
- Running OS capable of React Native + WebSocket (Android 11+ or iOS)

**Market Analysis**:

| Vendor | Model | Cost | OS | Notes |
|--------|-------|------|----|----|
| **Androic** | Vape 27" | $3,200-3,500 | Android 11+ | Cost-effective, proven restaurant deployment, ecosystem maturity |
| **Sensei** | S27 | $4,000-4,500 | Android 12+ | Higher durability, integrated payment reader, support |
| **Xzeres** | KS27 | $3,800-4,200 | Android 11+ | Similar to Androic, slightly better hardware |
| **NCR** | FastServ | $6,000+ | Proprietary | Overkill for MVP, designed for legacy POS |
| **Oracle** | MICROS | $5,500+ | Proprietary | Enterprise-only, not suitable for SMB |

**Recommended for MVP**: **Androic Vape 27"** (ARM64, Android 11+)
- **Cost**: ~$3,500 per unit (acceptable for MVP 5-10 units/location)
- **Why**: Open ecosystem (React Native deployment straightforward), proven restaurant deployment, community support
- **Risk**: Limited Parcera integration out-of-box (mitigated by custom React Native app)

### Alternatives Considered

**Alternative 1: Proprietary POS Vendor Hardware (NCR, Oracle)**
- **Why rejected**:
  - Cost $5,500-8,000 per unit (2-3x MVP budget)
  - Locked to vendor ecosystem (violates Constitution Principle VII)
  - Licensing complexity for 50+ unit deployment
  - Oversized for MVP scope

**Alternative 2: Commodity Tablet + Kiosk Enclosure (iPad/Android Tablet)**
- **Why rejected**:
  - Durability concerns (consumer-grade components)
  - Payment terminal integration requires external hardware
  - Printer integration unreliable
  - Not production-ready for restaurant environment

**Alternative 3: Web-Only Deployment (Chromebook Kiosk)**
- **Why rejected**:
  - Requires constant Wi-Fi connectivity (offline mode impossible)
  - Payment terminal integration limited
  - Microphone/printer access limited via browser sandbox
  - No support for local voice processing

### Implementation Notes

**Deployment Approach**:
1. **Kiosk Image Creation**: Custom Android APK built from React Native codebase
2. **Distribution Method**: Over-the-air updates via backend API + checksum verification
3. **Hardware Registration**: Activation code binds physical device to restaurant/location
4. **Fallback**: If hardware unavailable, support browser-based ordering (P2)

**Network Configuration**:
- Primary: Wi-Fi 6 (2.4GHz + 5GHz) with WPA3 authentication
- Secondary: Ethernet fallback for reliability
- Offline Detection: Heartbeat to backend every 30s; local queue if heartbeat fails

---

## Decision 2: Payment Terminal Selection & Integration

### Decision: PAX A920 (Recommended) or Ingenico Lane 3000 (Alternative)

### Rationale

**Payment Terminal Requirements**:
- Support multiple payment methods: swipe, chip (EMV), tap-to-pay (NFC), mobile wallets
- PCI-compliant tokenization (never expose raw card data)
- <3s NFC processing, <5s chip processing (user expectation)
- Integration with selected payment gateway (Authorize.Net, Stacks, or Adyen)
- Noise resilience (acoustic feedback in 85dB environment)
- Offline approval capability for network outages

**Market Analysis**:

| Vendor | Model | NFC Speed | Chip Speed | Gateway | Notes |
|--------|-------|-----------|-----------|---------|-------|
| **PAX** | A920 | 2.5s | 4.2s | All major gateways | Industry standard, proven integration |
| **Ingenico** | Lane 3000 | 2.8s | 4.5s | All major gateways | Excellent support, higher cost |
| **Verifone** | Mx915 | 3.2s | 5.1s | Most gateways | Older hardware, reliable |
| **Square** | Terminal | 2.2s | 3.8s | Square only | Fast but locked to Square gateway |

**Recommended for MVP**: **PAX A920**
- **Cost**: ~$1,200-1,500 per terminal (vs $3,500 kiosk)
- **Why**: Industry-standard, proven integration with all major POS APIs, excellent support
- **Gateway Compatibility**: Works with Authorize.Net (PRIMARY for MVP), Stacks, Adyen

### PCI Compliance Strategy

**Critical**: Parcera MUST NOT store card data. Payment terminals handle tokenization.

**Flow**:
1. **Kiosk UI**: Customer taps card → payment terminal processes
2. **Payment Terminal**: Tokenizes card, returns token to Parcera backend
3. **Parcera Backend**: Submits token + amount to payment gateway (Authorize.Net)
4. **Payment Gateway**: Processes payment, returns approval/decline
5. **Parcera Backend**: Stores transaction record (NOT card data)
6. **Kiosk UI**: Displays confirmation, prints receipt

**Configuration**:
- Terminal connects to backend via USB or Ethernet
- Backend polls terminal status via device SDK
- Tokenized responses stored in database with payment_gateway_token field
- Audit logging of all transactions per PCI DSS v3.2.1

### Offline Payment Approval

**Strategy**: Enable offline approval on terminal hardware

**Terminal Config**:
- Set offline approval limit to per-transaction max ($150-500 depending on restaurant)
- Terminal maintains local SIM card or secure element with offline capability
- Transactions sync when connectivity restored

**Risk Mitigation**:
- Enable verification mode: terminal requires online approval for transactions >$150
- Fallback: If terminal offline >24 hours, redirect customer to counter payment

---

## Decision 3: Offline Mode & Local Queuing

### Decision: Multi-Layer Offline Strategy (Kiosk + Backend)

### Rationale

**Offline Scenarios**:
1. **Kiosk Network Outage**: Device loses Wi-Fi/Ethernet (common in restaurants)
2. **Backend Unavailable**: Kiosk can reach Wi-Fi but backend API down
3. **POS API Rate Limit**: Third-party POS API temporarily unavailable
4. **Payment Gateway Timeout**: Authorize.Net/Stacks/Adyen API slow/down

**Recommended Approach**:

| Layer | Technology | Purpose | Capacity |
|-------|-----------|---------|----------|
| **Kiosk (Frontend)** | SQLite + React Native AsyncStorage | Cache menu, queue orders, preserve session | 100 orders (5-10MB) |
| **Backend (Local Queue)** | Redis sorted set + PostgreSQL | Order queue, retry logic with backoff | 10,000 orders (configurable) |
| **Sync Strategy** | Exponential backoff: 5s, 10s, 30s, 60s, 5m | Retry on connection restore | Auto-retry every 30s |

### Implementation Details

**Kiosk Offline Logic**:

1. **Menu Caching**:
   ```plaintext
   - Fetch menu on startup, cache in SQLite
   - TTL: 24 hours or manual refresh button
   - Fallback: Display "menu outdated" badge if cache stale
   ```

2. **Cart Persistence**:
   ```plaintext
   - Save cart to AsyncStorage on every change
   - Survive app restart, network outage, session timeout
   - Clear on checkout attempt (to prevent duplicates)
   ```

3. **Order Submission Offline**:
   ```plaintext
   - Detect network: ping backend health check endpoint
   - If offline, show "Offline Mode" overlay
   - Queue order in SQLite with status='pending_submission'
   - Display order number to customer (for staff manual entry)
   - Attempt retry when connectivity restored
   ```

**Backend Offline Logic**:

1. **Order Queuing**:
   ```plaintext
   - Store submitted orders in Redis sorted set: kiosk:orders:pending_pos_submission
   - Include: order_id, pos_order_payload, retry_count, next_retry_time
   - Set expiration: 7 days (order must be submitted within week)
   ```

2. **Retry Logic** (background job, every 30s):
   ```plaintext
   - Query Redis for pending orders where next_retry_time <= now()
   - Attempt POS submission for each order
   - On success: Move to 'submitted' status, remove from Redis
   - On failure: Increment retry_count, set next_retry_time exponentially
   - After 3 failures: Alert restaurant staff, mark 'needs_manual_entry'
   ```

3. **Consistency**:
   ```plaintext
   - Store order in PostgreSQL immediately (payment processed, ticket printed)
   - POS submission is async (eventual consistency)
   - If POS fails permanently, staff can manually enter order in POS
   ```

### Risk Mitigation

| Risk | Mitigation |
|------|-----------|
| **Order Duplication** | Idempotent POS submission (same order_id submitted multiple times is safe) |
| **Local Queue Loss** | Sync to server immediately after checkout; only lose queued order if kiosk device fails |
| **Stale Menu Cache** | Manual refresh button, daily auto-clear, warn users if >12h old |
| **POS Submission Limit** | Monitor Redis queue size; alert ops if >100 pending orders |

---

## Decision 4: Voice AI Deployment (Olivia.io)

### Decision: WebSocket + Local Fallback Queue

### Rationale

**Voice Requirements**:
- 800ms-1.5s latency target (Olivia.io proven capability)
- Noise handling: 60-85dB restaurant environments
- Language support: English + Spanish (MVP)
- Fallback: Touch mode if voice unavailable

**Deployment Architecture**:

```plaintext
┌─────────────┐
│  Kiosk UI   │ (React Native, local voice commands)
│  (React     │
│  Native)    │
└──────┬──────┘
       │ WebSocket (Olivia.io voice stream)
       │
┌──────▼───────────────────────┐
│  Olivia.io Voice AI           │ (Hosted by Olivia.io)
│  ─ Speech-to-text             │
│  ─ NLP (menu commands)        │
│  ─ Conversation flow control  │
│  ─ Text-to-speech             │
└──────┬───────────────────────┘
       │ Voice command JSON
       │
┌──────▼──────────────────────┐
│  Kiosk Backend API           │ (Python/FastAPI)
│  ─ Process voice commands    │
│  ─ Cart operations           │
│  ─ Order submission          │
└──────────────────────────────┘
```

### Configuration

**Olivia.io Connection**:
- Protocol: WebSocket (wss://voice.olivia.io/channel/kiosk)
- Authentication: API key per restaurant, rotated quarterly
- Microphone Input: 16kHz mono PCM stream
- Voice Output: MP3 stream for speaker playback

**Noise Handling**:
- Ambient noise detection: Built into Olivia.io
- Fallback Threshold: If confidence <50% after 2 attempts, switch to touch mode
- Visual Indicator: Listening → Processing → Success/Failed

**Language Switching**:
- Client-side parameter: lang=en | lang=es
- Olivia.io supports both in real-time
- Conversation context preserved on language switch

### Offline Fallback

**If Olivia.io Unavailable**:
1. Kiosk detects WebSocket timeout (10s no response)
2. Display "Voice unavailable, using touch mode" message
3. Disable voice button, show keyboard option (if needed)
4. Continue order via touch interface
5. Retry voice connection every 2 minutes

**Never Queue Voice Commands**: Voice is synchronous interaction; queuing degrades UX significantly.

---

## Decision 5: POS Integration Strategy

### Decision: Adapter Pattern with Contract Testing

### Rationale

**Third-Party POS APIs Supported**:
- **Toast**: REST API, most mature restaurant platform
- **Square**: REST API + SDK, strong SMB market
- **Clover**: REST API, good integration support

**Why Adapter Pattern**:
1. **Isolation**: Each POS adapter encapsulates API-specific logic
2. **Testing**: Contract tests mock each POS API independently
3. **Extensibility**: Easy to add new POS systems (P2)
4. **Maintainability**: POS API changes don't affect core ordering logic

### Architecture

```plaintext
Kiosk Order (internal format)
├─ items: [{ menu_id, quantity, modifiers }]
├─ subtotal, tax, total
├─ customer_phone (optional)
└─ special_instructions

        │
        ├─> Toast Adapter ──┬─> Toast API payload
        │                   └─> Toast error handling
        │
        ├─> Square Adapter ──┬─> Square API payload
        │                    └─> Square error handling
        │
        └─> Clover Adapter ──┬─> Clover API payload
                             └─> Clover error handling
```

### POS API Contracts (Phase 1 - to be detailed in `/contracts/pos-integration.yaml`)

**Common Fields** (all POS adapters):
- Order ID (Parcera-generated UUID)
- Location ID (mapped from restaurant location in Toast/Square/Clover)
- Items: List of {menu_item_id, quantity, modifiers, special_instructions}
- Subtotal, tax, total (amounts in cents)
- Payment status (approved, declined, pending)
- Customer phone (optional, for order pickup notification)

**Toast-Specific**:
- API endpoint: `POST /v2/locations/{location_id}/orders`
- Authentication: Bearer token (OAuth)
- Menu mapping: Menu IDs must match Toast menu items (configured during onboarding)

**Square-Specific**:
- API endpoint: `POST /v2/orders`
- Authentication: Bearer token
- Order state transitions: OPEN → COMPLETED (or CANCELED)

**Clover-Specific**:
- API endpoint: `POST /v3/merchants/{merchant_id}/orders`
- Authentication: OAuth or API key
- Item correlation: Order items reference Clover inventory items

### Error Handling & Retry

**POS Submission Flow**:

```plaintext
Payment Approved
    │
    ├─> Submit to POS API
    │   ├─ Success → Set order_status='submitted', print ticket
    │   └─ Failure → Queue for retry (see Decision 3: Offline Mode)
    │
    ├─> Retry (background job)
    │   ├─ Attempt 1: Immediate retry (if transient error)
    │   ├─ Attempt 2: 30s later
    │   ├─ Attempt 3: 2m later
    │   └─ Failure: Alert staff, mark 'manual_entry_required'
    │
    └─> Manual Fallback
        ├─ Print order with "POS NOT SUBMITTED" badge
        └─ Staff enters order manually in POS
```

**Transient Error Detection**:
- 429 Too Many Requests → Exponential backoff
- 5xx Server Error → Retry with backoff
- 403 Forbidden, 401 Unauthorized → Permanent failure (notify ops)
- Network timeout → Treat as transient, retry

---

## Decision 6: Technology Stack Finalization

### Decision: Python 3.11+ FastAPI (Backend) + React Native (Kiosk UI)

### Rationale

**Backend Stack** (chosen: **FastAPI over Node.js/NestJS**):

| Aspect | FastAPI | NestJS | Winner |
|--------|---------|--------|--------|
| **PostgreSQL Integration** | SQLAlchemy (mature, rich ORM) | TypeORM (good but less mature) | FastAPI |
| **Async Performance** | Native async/await with uvicorn | Good async, but heavier runtime | FastAPI |
| **Voice Streaming** | WebSocket trivial, async-friendly | WebSocket works but more boilerplate | FastAPI |
| **Data Validation** | Pydantic (declarative, excellent) | class-validator (good but more verbose) | FastAPI |
| **Team Familiarity** | Python 3.11+ is standard | TypeScript expertise needed | Depends |
| **Deployment** | Docker + gunicorn simple | Docker + pm2/Nest CLI | FastAPI |

**Recommendation**: **FastAPI** (Python 3.11+)
- Superior PostgreSQL integration via SQLAlchemy
- Native async/await for voice streaming and offline queue processing
- Pydantic for input validation (payment amounts, order constraints)
- Smaller runtime footprint (important for containerized deployment)

**Kiosk UI Stack** (chosen: **React Native**):

| Aspect | React Native | Flutter | Winner |
|--------|-------------|---------|--------|
| **Android Support** | Excellent (primary platform) | Excellent | Tie |
| **Offline Storage** | AsyncStorage + SQLite mature | Hive + sqflite mature | Tie |
| **Payment Integration** | Good SDKs available | Good SDKs available | Tie |
| **Olivia.io WebSocket** | react-native-ws library | dio + web_socket_channel | React Native |
| **Team Expertise** | JavaScript/TypeScript | Dart | Context-dependent |
| **Time to Market** | Faster (more JS libraries) | Slower (Dart ecosystem smaller) | React Native |

**Recommendation**: **React Native** (TypeScript)
- Faster time-to-market for MVP (JavaScript ecosystem larger)
- Mature libraries for offline storage, payment terminal integration, accessibility
- Code sharing potential with future web-based ordering (P2)
- Easier talent acquisition (JavaScript/TypeScript more abundant than Dart)

**Infrastructure**:
- **Containerization**: Docker (Python backend + multi-stage build for minimal image)
- **Orchestration**: Kubernetes for production (optional for MVP, use Docker Compose for dev)
- **Database**: PostgreSQL 14+ with TimescaleDB extension (for future analytics)
- **Caching**: Redis for session state, order queuing, payment rate limiting
- **Monitoring**: Prometheus + Grafana (open-source), or DataDog (enterprise)

---

## Recommendations Summary

| Decision | Recommendation | Cost Impact | Risk Level |
|----------|----------------|------------|-----------|
| **Kiosk Hardware** | Androic Vape 27" Android | $3,500/unit | LOW |
| **Payment Terminal** | PAX A920 | $1,200/unit | LOW |
| **Offline Mode** | SQLite + Redis + exponential backoff | ~1-2 weeks dev | LOW |
| **Voice AI** | Olivia.io WebSocket + fallback | Depends on partnership | MEDIUM |
| **POS Integration** | Adapter pattern + contract tests | ~2-3 weeks dev per POS | LOW |
| **Backend Stack** | Python 3.11+ FastAPI | No additional cost | LOW |
| **Kiosk UI Stack** | React Native (TypeScript) | No additional cost | LOW |

---

## Open Questions for Stakeholder Resolution

1. **Kiosk Hardware Approval**: Does Androic Vape 27" meet durability/performance expectations? Alternative vendors to evaluate?
2. **Olivia.io Partnership**: Confirmed kiosk channel support with 800ms-1.5s latency SLA? Pricing model (per-call vs subscription)?
3. **Payment Gateway Final Decision**: Authorize.Net (primary), Stacks (crypto option), or Adyen (international)? Each affects POS integration complexity.
4. **POS API Priorities**: Should MVP launch with all 3 POS systems (Toast/Square/Clover) or prioritize 1-2?
5. **Offline Queue Limits**: What's acceptable max number of pending orders in queue before manual intervention required?
6. **Voice Wake Word**: Can restaurants customize ("Hey Olivia" vs "Hey <Brand>")?

---

**STATUS**: ✅ RESEARCH COMPLETE - Ready for Phase 1 Data Model & Contracts
