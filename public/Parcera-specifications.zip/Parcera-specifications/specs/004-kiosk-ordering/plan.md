# Implementation Plan: Voice-Enabled Kiosk Ordering

**Branch**: `004-kiosk-ordering` | **Date**: 2025-11-04 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `/specs/004-kiosk-ordering/spec.md`

**Note**: This template is filled in by the `/speckit.plan` command. See `.specify/templates/commands/plan.md` for the execution workflow.

## Summary

Voice-enabled kiosk interface for in-restaurant self-service ordering with touch screen menu browsing, voice input capability (Olivia.io integration), payment terminal processing, order ticket printing, and accessibility features. Supports multi-language (English/Spanish), integration with third-party POS systems (Toast, Square, Clover), and adaptive noise handling for realistic restaurant environments (60-85dB). Independent channel that works with existing POS systems without requiring Parcera hardware.

## Technical Context

**Language/Version**: Python 3.11+ (FastAPI backend) or Node.js 18+ (pending decision); React Native for kiosk UI
**Primary Dependencies**: FastAPI/Express backend, React Native (kiosk touchscreen UI), Olivia.io voice AI, payment terminal SDK (Ingenico/Verifone/PAX), thermal printer driver
**Storage**: PostgreSQL 14+ with RLS for kiosk session/order data, Redis for real-time session state and payment transaction queuing
**Testing**: pytest (backend) + Jest (React Native), contract tests via OpenAPI schema validation, integration tests for payment terminals and POS APIs
**Target Platform**: Linux server (backend API + offline queue), React Native (cross-platform kiosk touchscreen hardware), payment terminal hardware (Ingenico, Verifone, or PAX)
**Project Type**: Mobile + API (kiosk touchscreen UI + backend ordering service)
**Performance Goals**: <200ms touch response time (95th percentile), <3s NFC payment processing, <1.5s voice command response (Olivia.io), ≥70% voice accuracy at 65dB, ≥50% at 85dB
**Constraints**: <3 minutes for typical 3-item order (start to payment), ≥85% order completion rate, ≥99% POS submission success rate, 60-second session timeout, offline mode with local queue capability
**Scale/Scope**: MVP: 5-10 kiosks per location, 50-100 orders/day per kiosk, 3-year target: multi-location deployment with order number coordination

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

### Principle I: AI-First Architecture ✅ CRITICAL

**Requirements from Constitution:**
- MUST integrate Olivia.io voice AI for omnichannel ordering with 800ms-1.5s latency target
- MUST implement goal-oriented conversation engine with block-based, context-aware orchestration
- MUST support AI-driven conversation mining and semantic analytics

**Alignment with Spec:**
- ✅ FR-K2: Olivia.io voice AI integration with same conversation engine as IVR channel
- ✅ FR-K2.4: Natural language processing for menu item names and modifiers
- ✅ FR-K3: Adaptive noise cancellation and automatic fallback (AI-driven)
- ✅ User Story 1: Voice-assisted ordering as core feature
- ✅ User Story 2: Voice-only accessibility mode with TTS

**Gate Status:** ✅ PASS - Core feature dependency on Olivia.io partnership established

**Critical Dependency:** Olivia.io kiosk channel support must be verified before development start

---

### Principle IV: Omnichannel by Default ✅

**Requirements from Constitution:**
- MUST provide all ordering channels independently of POS
- MUST integrate with third-party POS systems (Toast, Square, Clover)
- MUST maintain order state and customer context across all channels seamlessly

**Alignment with Spec:**
- ✅ FR-K9: Kiosk submits orders to third-party POS APIs (Toast, Square, Clover)
- ✅ FR-K4: Menu display via Menu Management API (shared across channels)
- ✅ FR-K12: Session management with timeout and state preservation
- ✅ User Story 3: Payment and order submission (independent of POS)
- ✅ Offline Mode (Edge Case 12): Local queuing during network outage

**Gate Status:** ✅ PASS - Kiosk designed as independent channel with POS integration

---

### Principle V: Progressive Enhancement & MVP Discipline ✅

**Requirements from Constitution:**
- MUST define P0/P1/P2/P3 priorities for all features
- MUST ship P0 features within 3-month MVP timeline
- MUST design features as independently testable user stories
- MUST NOT implement P2/P3 features without explicit stakeholder approval

**Alignment with Spec:**
- ✅ User Story 1 (P0): Touch + voice basic ordering - independently testable
- ✅ User Story 2 (P0): Accessibility features - WCAG 2.1 AA compliance required
- ✅ User Story 3 (P0): Payment + ticket printing - essential for order completion
- ✅ User Story 4 (P1): Modifiers and special requests (enhancement)
- ✅ User Story 5 (P1): Noise handling fallback (robustness)
- ✅ FR-K13 (P2): Analytics deferred to post-MVP
- ✅ Open Questions flag payment gateway decision (P0 blocking)

**Gate Status:** ✅ PASS - Clear P0/P1/P2 prioritization with MVP discipline

**Blocking Decision:** Payment gateway selection (Authorize.Net, Stacks, Adyen) required before Phase 0 research

---

### Principle III: Privacy-First Customer Data ⚠️ PARTIAL

**Requirements from Constitution:**
- MUST store all customer data in Parcera-controlled tables
- MUST use order ID-based notification routing
- MUST NOT expose customer contact information to merchants

**Alignment with Spec:**
- ⚠️ Spec allows anonymous kiosk orders (no login required)
- ⚠️ Customer wallet integration deferred to P2
- ⚠️ Order submission includes modifiers/instructions but NOT customer PII
- ✅ Order ticket includes QR code linking to order status (not customer data)

**Gate Status:** ⚠️ CONDITIONAL PASS - P0 kiosk orders are anonymous; customer data privacy applies to P2 loyalty integration. Ensure POS submission contracts do NOT leak customer contact info.

**Action Item:** Document which order fields are transmitted to third-party POS (Phase 1 - contracts/)

---

### Principle VII: Integration-Friendly Architecture ✅

**Requirements from Constitution:**
- MUST provide RESTful APIs with clear contracts for all core services
- MUST integrate with payment gateways (Authorize.Net, Stacks, Adyen)
- MUST support third-party POS API integration (Toast, Square, Clover)
- SHOULD follow OpenAPI/Swagger standards for API documentation

**Alignment with Spec:**
- ✅ FR-K9: Explicit support for Toast, Square, Clover APIs
- ✅ FR-K7: Payment terminal integration with multiple gateway options
- ✅ FR-K4: Menu Management API consumption (shared interface)
- ✅ Contracts will be defined in Phase 1 (/speckit.plan)

**Gate Status:** ✅ PASS - API contracts will be generated in Phase 1

---

### Overall Gate Assessment

**STATUS: ✅ PROCEED TO PHASE 0**

**Critical Decisions Needed (BLOCKING MVP - Resolve Before Phase 0):**
1. **Payment Gateway Selection**: Authorize.Net vs Stacks vs Adyen (affects payment terminal integration, PCI compliance, settlement model)
2. **Olivia.io Kiosk Channel Support**: Confirm voice AI supports kiosk deployment with 800ms-1.5s latency, noise handling, language variants
3. **Payment Terminal Hardware Vendor**: Recommended model(s) for MVP (Ingenico, Verifone, PAX) with pricing

**Recommendations from Phase 0 Research (to be completed):**
4. Microphone selection for noise cancellation (directional vs omnidirectional)
5. Offline queue storage limits and sync strategy
6. Voice wake word customization approach
7. POS API rate limits and order number coordination strategy

## Project Structure

### Documentation (this feature)

```text
specs/004-kiosk-ordering/
├── plan.md              # This file (/speckit.plan command output)
├── research.md          # Phase 0 output (/speckit.plan command)
├── data-model.md        # Phase 1 output (/speckit.plan command)
├── quickstart.md        # Phase 1 output (/speckit.plan command)
├── contracts/           # Phase 1 output (/speckit.plan command)
│   ├── kiosk-registration.yaml    # Hardware registration and status API
│   ├── order-submission.yaml      # Order creation and payment flow
│   └── pos-integration.yaml       # Third-party POS order submission
├── checklists/
│   └── requirements.md   # User story acceptance criteria
└── tasks.md             # Phase 2 output (/speckit.tasks command - NOT created by /speckit.plan)
```

### Source Code (repository root)

```text
# Kiosk Backend API + Kiosk UI (React Native)

backend/
├── src/
│   ├── models/
│   │   ├── kiosk_device.py              # KioskDevice entity
│   │   ├── kiosk_session.py             # KioskSession entity
│   │   ├── kiosk_order.py               # KioskOrder entity
│   │   ├── kiosk_interaction.py         # KioskInteraction (voice/touch logs)
│   │   ├── payment_transaction.py       # PaymentTransaction entity
│   │   └── order_ticket.py              # OrderTicket entity
│   ├── services/
│   │   ├── kiosk_service.py             # Kiosk device management
│   │   ├── session_service.py           # Session lifecycle (60s timeout, etc)
│   │   ├── cart_service.py              # Cart management and persistence
│   │   ├── payment_service.py           # Payment terminal integration, tokenization
│   │   ├── printer_service.py           # Thermal printer integration
│   │   ├── pos_integration_service.py   # Toast/Square/Clover order submission + retry
│   │   ├── voice_service.py             # Olivia.io orchestration
│   │   ├── menu_service.py              # Menu API consumption, cache
│   │   ├── offline_queue_service.py     # Local order queuing during outages
│   │   └── analytics_service.py         # Kiosk usage metrics (P2)
│   ├── api/
│   │   ├── v1/
│   │   │   ├── kiosks.py                # Device registration, heartbeat, status
│   │   │   ├── sessions.py              # Session create, end, timeout
│   │   │   ├── orders.py                # Order create, add item, remove item, checkout
│   │   │   ├── payments.py              # Payment status, decline handling
│   │   │   ├── voice.py                 # Olivia.io webhook for voice transcripts
│   │   │   └── admin.py                 # Kiosk deployment and monitoring
│   │   └── middleware/
│   │       ├── kiosk_auth.py            # Device token validation
│   │       ├── tenant_context.py        # Inject restaurant/tenant ID
│   │       └── error_handler.py         # Standardized error responses
│   └── db/
│       ├── migrations/
│       └── rls_policies.sql
└── tests/
    ├── contract/
    │   ├── kiosk_registration_test.py
    │   ├── order_submission_test.py
    │   └── pos_integration_test.py
    ├── integration/
    │   ├── test_payment_flow.py          # NFC, chip, swipe payment flows
    │   ├── test_pos_submission.py        # Toast/Square/Clover integration
    │   ├── test_offline_queue.py
    │   └── test_voice_order.py           # Olivia.io conversation flow
    └── unit/
        ├── test_session_service.py
        ├── test_cart_service.py
        ├── test_payment_service.py
        └── test_pos_integration_service.py

kiosk-ui/                               # React Native application
├── src/
│   ├── components/
│   │   ├── MenuBrowser/                 # Category nav, item cards, search
│   │   ├── CartDisplay/                 # Sidebar/tray cart, running total
│   │   ├── ModifierScreen/              # Size, toppings, special instructions
│   │   ├── PaymentFlow/                 # NFC reader UI, status, decline handling
│   │   ├── VoiceButton/                 # Push-to-talk, visual feedback
│   │   ├── AccessibilityMode/           # TTS, high contrast, voice-only nav
│   │   ├── SessionTimer/                # 60s timeout warning, continue button
│   │   └── OrderTicketDisplay/          # Order number, QR code, wait time
│   ├── pages/
│   │   ├── StartScreen.tsx              # Welcome, language selection
│   │   ├── MenuScreen.tsx               # Main ordering interface
│   │   ├── CartReview.tsx               # Cart summary, item removal
│   │   ├── CheckoutScreen.tsx           # Order summary, payment entry
│   │   ├── ConfirmationScreen.tsx       # Order submitted, ticket printing, timer
│   │   └── ErrorScreen.tsx              # Error states, retry options
│   ├── services/
│   │   ├── kioskApi.ts                  # API client for backend
│   │   ├── voiceService.ts              # Olivia.io integration
│   │   ├── paymentTerminal.ts           # Hardware integration layer
│   │   ├── printerService.ts            # Thermal printer commands
│   │   ├── sessionManager.ts            # Local session state + timeout
│   │   └── offlineQueue.ts              # Local AsyncStorage persistence
│   ├── utils/
│   │   ├── i18n.ts                      # English/Spanish translations
│   │   ├── validation.ts                # Order validation, constraints
│   │   ├── tts.ts                       # Text-to-speech (accessibility)
│   │   └── noise-detection.ts           # Ambient noise level measurement
│   └── App.tsx                          # Root component, session lifecycle
└── tests/
    ├── integration/
    │   ├── voice_order_flow.test.ts
    │   ├── payment_flow.test.ts
    │   └── offline_mode.test.ts
    └── unit/
        ├── cart_service.test.ts
        ├── session_manager.test.ts
        └── voice_service.test.ts
```

**Structure Decision**: Mobile + API (Option 3) - Backend API handles kiosk device management, session coordination, payment processing, and POS integration. React Native UI runs on kiosk touchscreen hardware (Andersen, Sensei, or similar ARM-based kiosk device). Voice is handled via Olivia.io webhook integration. Payment terminal integration via device SDK.

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

No constitution violations detected. All gates passed.

**Technical Debt/Accepted Complexity**:

| Item | Justification | Acceptable Risk |
|------|---------------|-----------------|
| Hybrid Payment/POS Integration | Support 3 payment gateways + 3 POS systems (matrix = 9 combinations). Mitigated by contract-based testing and adapter pattern. | LOW - Payment gateway + POS are separate concerns; adapters isolate changes |
| Voice Integration Dependency | Reliance on Olivia.io for voice AI. Risk: API changes, latency degradation. Mitigation: fallback to touch, contract tests with mock Olivia responses. | MEDIUM - Must confirm Olivia.io terms include kiosk support |
| Real-Time Synchronization | Cart state + session timeout + POS submission must coordinate across network outages. Mitigated by offline queue + robust retry logic. | LOW - Proven pattern in other POS systems |

---

**STATUS**: ✅ SPECIFICATION COMPLETE - Ready for `/speckit.plan` Phase 0 (Research)
