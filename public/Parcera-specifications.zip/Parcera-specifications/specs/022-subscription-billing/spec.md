# Feature Specification: Subscription & Billing Management

**Feature Branch**: `022-subscription-billing`
**Created**: 2025-10-30
**Status**: Draft
**Input**: User description: "Subscription & Billing Management - Manages restaurant subscription plans (Basic, Pro, Enterprise) with tiered pricing, billing cycle management (monthly/annual), automated payment processing via Stripe, plan upgrade/downgrade flows with prorated charges, payment failure handling with retry logic and grace periods (auto-suspend after 7 days), invoice generation and delivery, usage-based billing for per-transaction fees, dunning management, billing dispute resolution, subscription analytics (MRR, ARR, churn rate), and multi-location billing consolidation. Key features: 3 subscription tiers (Basic $99/mo, Pro $249/mo, Enterprise custom), automatic billing on monthly/annual cycle, seamless plan changes with immediate feature access and prorated billing adjustments, 3 automatic payment retry attempts over 7 days before suspension, grace period warnings sent at day 3 and day 6, downloadable PDF invoices emailed monthly, usage-based transaction fees (2.9% + $0.30 per transaction for Basic, 2.5% + $0.30 for Pro, custom for Enterprise), failed payment recovery workflows with email/SMS notifications, subscription pause/resume capability, billing history and audit trail. Scope: ONLY subscription management and billing operations, NOT individual payment processing for orders (handled by SPEC 021 Payment Processing). Example flows: restaurant upgrades from Basic to Pro mid-cycle (prorated charge of ~$75 applied immediately, Pro features enabled instantly) vs payment failure triggers retry on day 1, day 3, day 5, grace period warning sent on day 3 and day 6, account suspended on day 7 if all retries fail. Required capabilities: subscription CRUD, billing cycle automation, prorated billing calculations, payment retry logic, invoice generation, usage tracking, subscription analytics dashboard."

## Overview

This specification defines the subscription and billing management system for the Parcera multi-tenant restaurant platform. Restaurant owners subscribe to tiered plans (Basic, Pro, Enterprise) and are automatically billed monthly or annually. The system handles plan upgrades/downgrades with prorated charges, failed payment recovery with automatic retries and grace periods, invoice generation and delivery, usage-based transaction fees, and comprehensive billing analytics. This enables predictable SaaS revenue operations and ensures restaurants maintain uninterrupted service through automated billing workflows.

**Scope**: This specification covers ONLY subscription lifecycle management and recurring billing operations. Individual payment processing for customer orders is handled by SPEC 021 (Payment Processing). Extension billing integration is defined in SPEC 020 (Extension Marketplace).

## User Scenarios & Testing

### User Story 1 - Subscribe to Initial Plan (Priority: P1)

Restaurant owner selects and subscribes to an initial subscription plan during onboarding or from the Business Dashboard. Owner provides payment method, selects plan tier (Basic/Pro/Enterprise) and billing cycle (monthly/annual), reviews pricing, and activates subscription. System processes initial payment, provisions platform features based on plan tier, and confirms subscription activation.

**Why this priority**: Core revenue-generating flow - no restaurant can use the platform without an active subscription. This is the entry point for all billing operations.

**Independent Test**: Can be fully tested by completing onboarding wizard, selecting Basic plan with monthly billing, entering test card, and verifying subscription activation with immediate feature access.

**Acceptance Scenarios**:

1. **Given** new restaurant owner completing onboarding wizard, **When** owner selects "Basic - $99/month" plan and enters valid payment method, **Then** system charges $99, activates Basic plan features immediately, sends confirmation email with invoice, and displays "Subscription Active" status in dashboard
2. **Given** restaurant owner on Business Dashboard, **When** owner selects "Pro - $249/month" plan and confirms payment, **Then** system processes payment, upgrades feature access to Pro tier instantly, generates first invoice, and sends welcome email with Pro feature details
3. **Given** enterprise customer on Enterprise signup flow, **When** custom pricing agreement finalized ($custom/month), **Then** system creates Enterprise subscription with custom pricing, activates all premium features, and assigns dedicated account manager

---

### User Story 2 - Upgrade/Downgrade Subscription Plan (Priority: P1)

Restaurant owner changes subscription plan mid-cycle to access more features (upgrade) or reduce costs (downgrade). Owner selects new plan tier, reviews prorated charge/credit calculation, and confirms change. System immediately adjusts feature access, calculates prorated billing adjustment, processes payment difference (upgrade) or issues credit (downgrade), and updates subscription for next billing cycle.

**Why this priority**: Critical for revenue growth (upsells) and customer retention (downgrades prevent cancellations). Prorated billing ensures fair charges and builds customer trust.

**Independent Test**: Can be fully tested by subscribing to Basic plan, waiting 15 days, upgrading to Pro plan, verifying prorated charge of ~$75 (half of $249 - $99 difference), and confirming instant Pro feature access.

**Acceptance Scenarios**:

1. **Given** restaurant on Basic plan ($99/mo) 15 days into billing cycle, **When** owner upgrades to Pro plan ($249/mo), **Then** system calculates prorated charge: ($249 - $99) × (15 days remaining / 30 days) = ~$75, charges payment method immediately, enables Pro features instantly, and adjusts next billing cycle to Pro rate
2. **Given** restaurant on Pro plan ($249/mo) 10 days into billing cycle, **When** owner downgrades to Basic plan ($99/mo), **Then** system calculates prorated credit: ($249 - $99) × (20 days remaining / 30 days) = ~$100, applies credit to account, maintains Pro features until end of current cycle, downgrades to Basic features on next billing date
3. **Given** restaurant on annual Pro plan ($2,490/year) 6 months into cycle, **When** owner upgrades to annual Enterprise plan ($5,000/year), **Then** system calculates prorated charge: ($5,000 - $2,490) × (6 months remaining / 12 months) = ~$1,255, processes payment, enables Enterprise features immediately, and sets next renewal to Enterprise annual rate

---

### User Story 3 - Handle Payment Failure with Automatic Recovery (Priority: P1)

Restaurant's subscription payment fails due to expired card, insufficient funds, or bank decline. System automatically retries payment 3 times over 7 days (day 1, day 3, day 5), sends grace period warnings on day 3 and day 6, and suspends account on day 7 if all retries fail. Owner can update payment method anytime during grace period to recover subscription. Upon successful payment, system reactivates account immediately.

**Why this priority**: Critical for revenue protection (recovers failed payments) and customer retention (grace period prevents involuntary churn). Prevents service disruption for legitimate customers with temporary payment issues.

**Independent Test**: Can be fully tested by simulating failed payment on renewal date, observing 3 automatic retry attempts over 7 days, verifying warning emails sent on day 3 and day 6, confirming account suspension on day 7, then updating payment method and verifying immediate reactivation.

**Acceptance Scenarios**:

1. **Given** restaurant subscription renewal date arrives with expired payment method, **When** initial payment fails, **Then** system logs failure, schedules retry for day 3, sends email "Payment Failed - Will Retry in 2 Days", maintains full feature access during grace period
2. **Given** payment failed on day 1 and day 3, **When** day 3 arrives, **Then** system sends warning email "Payment Failed - Account will suspend in 4 days if not resolved. Please update payment method", displays warning banner in dashboard, retries payment (attempt 2), and schedules final retry for day 5 if failed
3. **Given** all 3 payment retries failed (day 1, day 3, day 5), **When** day 7 arrives, **Then** system sends final notification "Account Suspended - Payment Failed", suspends account access (blocks orders, disables features), displays "Suspended" status with payment update prompt, and marks subscription for cancellation in 30 days if unresolved
4. **Given** account suspended due to payment failure, **When** owner updates payment method and clicks "Retry Payment", **Then** system immediately processes payment with new method, reactivates subscription if successful, restores full feature access within 60 seconds, sends "Account Reactivated" confirmation email

---

### User Story 4 - View and Download Invoices (Priority: P2)

Restaurant owner views billing history and downloads invoices for accounting and tax purposes. Owner accesses "Billing History" section in Business Dashboard, views list of all past invoices with date/amount/status, filters by date range or status, and downloads PDF invoices. System generates itemized invoices showing subscription charges, usage-based fees, extension charges, prorated adjustments, taxes, and payment method.

**Why this priority**: Important for customer self-service (reduces support burden) and compliance (restaurants need invoices for bookkeeping). Not blocking for core subscription functionality.

**Independent Test**: Can be fully tested by subscribing to plan, waiting for first billing cycle to complete, navigating to Billing History, viewing invoice list, downloading PDF invoice, and verifying all line items (subscription base, extensions, usage fees, taxes).

**Acceptance Scenarios**:

1. **Given** restaurant owner on Business Dashboard, **When** owner clicks "Billing → Billing History", **Then** displays table of all invoices: Invoice #, Date, Amount, Status (Paid/Failed/Pending), Download button - sorted by date descending
2. **Given** restaurant owner viewing billing history for multi-location business, **When** owner filters by "Last 3 Months" and "Paid", **Then** displays only paid invoices from last 3 months with total amount summary
3. **Given** restaurant owner viewing specific invoice, **When** owner clicks "Download PDF", **Then** generates PDF invoice with: business name, billing address, invoice #, date, line items (Basic Plan $99, KDS Extension $49, Transaction Fees $47.50, Subtotal $195.50, Sales Tax $19.55, Total $215.05), payment method (Visa ****1234), status (Paid)

---

### User Story 5 - Monitor Subscription Analytics (Priority: P2)

Platform admin views subscription analytics to monitor SaaS business health: Monthly Recurring Revenue (MRR), Annual Recurring Revenue (ARR), churn rate, average revenue per user (ARPU), plan distribution, failed payment recovery rate, and subscription growth trends. Admin accesses "Platform Admin Dashboard → Subscription Analytics" and views real-time metrics with historical trends.

**Why this priority**: Important for SaaS business operations and growth planning but not blocking for restaurant subscription functionality. Primarily used by platform owner, not restaurant users.

**Independent Test**: Can be fully tested by having 10+ test restaurants with various subscription plans active, accessing Platform Admin Dashboard, navigating to Subscription Analytics, and verifying MRR calculation (sum of all active monthly subscriptions), ARR projection (MRR × 12), churn rate (cancelled subscriptions / total subscriptions over 30 days).

**Acceptance Scenarios**:

1. **Given** platform admin on Subscription Analytics dashboard with 100 active subscriptions (60 Basic @ $99, 35 Pro @ $249, 5 Enterprise @ $500 average), **When** dashboard loads, **Then** displays: MRR = $23,155 (60×$99 + 35×$249 + 5×$500), ARR = $277,860 (MRR × 12), ARPU = $231.55 (MRR / 100), Active Subscriptions = 100
2. **Given** platform admin viewing 90-day churn report with 5 cancellations out of 100 active subscriptions, **When** report generates, **Then** displays: Churn Rate = 5% (5 cancelled / 100 active), Reason Breakdown (3 "Too Expensive", 1 "Missing Features", 1 "Business Closed"), MRR Lost = $495
3. **Given** platform admin viewing payment failure recovery metrics for last 30 days with 20 failed payments and 15 successful recoveries, **When** report loads, **Then** displays: Recovery Rate = 75% (15 recovered / 20 failed), Revenue Recovered = $1,485, Average Recovery Time = 4.2 days, Still in Grace Period = 3 accounts, Suspended = 2 accounts

---

### User Story 6 - Pause and Resume Subscription (Priority: P3)

Restaurant owner temporarily pauses subscription during seasonal closure or business hiatus without losing account data. Owner selects "Pause Subscription" from Business Dashboard, confirms pause duration (max 90 days), and system immediately suspends billing and feature access while retaining all configuration, menu data, customer data, and order history. Owner can resume subscription anytime during pause period, and system reactivates features and resumes billing immediately.

**Why this priority**: Nice-to-have for customer retention (prevents cancellations during temporary closures) but not essential for MVP. Lower priority because most restaurants operate year-round.

**Independent Test**: Can be fully tested by subscribing to Basic plan, selecting "Pause Subscription" for 30 days, verifying billing suspension and feature access blocked, waiting or manually advancing time, clicking "Resume Subscription", and confirming immediate feature reactivation and billing resumption.

**Acceptance Scenarios**:

1. **Given** restaurant owner on Basic plan with active subscription, **When** owner clicks "Pause Subscription" and selects "30 days" pause, **Then** system confirms pause date range (today through +30 days), immediately suspends billing (no charges during pause), blocks feature access (orders disabled, dashboard read-only), retains all data (menu, customers, order history), sends "Subscription Paused" email with resume instructions
2. **Given** restaurant subscription paused for 15 days of 30-day pause period, **When** owner clicks "Resume Subscription" early, **Then** system immediately reactivates feature access, resumes billing from today (pro-rates next invoice for 15-day pause period), sends "Subscription Resumed" confirmation email
3. **Given** restaurant subscription paused for full 90 days (maximum pause duration), **When** 90-day pause period ends, **Then** system sends "Pause Period Ending in 3 Days" warning email, auto-resumes subscription on day 91 if no action taken, resumes billing from resume date, reactivates all features

---

### User Story 7 - Manage Usage-Based Transaction Fees (Priority: P2)

System automatically tracks and bills restaurants for per-transaction fees based on subscription plan tier. Each completed order incurs transaction fee: Basic plan (2.9% + $0.30), Pro plan (2.5% + $0.30), Enterprise plan (custom rate). System aggregates transaction fees throughout billing cycle and includes total in monthly invoice as separate line item. Owner views transaction fee breakdown in Billing History.

**Why this priority**: Important revenue stream for platform (transaction fees) but secondary to base subscription revenue. Not blocking for basic subscription functionality.

**Independent Test**: Can be fully tested by processing 10 test orders totaling $500 on Basic plan, calculating expected transaction fees ($500 × 2.9% + 10 × $0.30 = $17.50), waiting for billing cycle end, viewing invoice, and verifying "Transaction Fees: $17.50" line item with breakdown.

**Acceptance Scenarios**:

1. **Given** restaurant on Basic plan ($99/mo) processes 100 orders totaling $5,000 in revenue during billing cycle, **When** billing cycle ends, **Then** invoice includes: Base Subscription $99.00, Transaction Fees $148.00 ($5,000 × 2.9% + 100 × $0.30), Total $247.00
2. **Given** restaurant on Pro plan ($249/mo) processes 250 orders totaling $12,000 in revenue, **When** billing cycle ends, **Then** invoice includes: Base Subscription $249.00, Transaction Fees $375.00 ($12,000 × 2.5% + 250 × $0.30), Total $624.00
3. **Given** restaurant owner viewing invoice transaction fee line item, **When** owner clicks "View Breakdown", **Then** displays: Total Orders = 100, Total Order Value = $5,000.00, Percentage Fee = $145.00 (2.9% × $5,000), Per-Transaction Fee = $30.00 (100 × $0.30), Total Transaction Fees = $175.00

---

### Edge Cases

- **What happens when payment fails during plan upgrade?** System does not apply upgrade, keeps restaurant on current plan, displays error message "Payment failed - please update payment method to upgrade", and allows retry
- **How does system handle partial month when restaurant cancels mid-cycle?** System continues service until end of current billing period (no prorated refund for cancellations per standard SaaS policy), then deactivates subscription at period end
- **What happens when card expires during active subscription?** System sends "Card Expiring Soon" email 30 days before expiration, displays dashboard warning 14 days before, and triggers payment failure flow on renewal if not updated
- **How does system handle billing for multi-location restaurants?** System consolidates all locations under single subscription and invoice, calculates transaction fees across all locations combined, allows per-location usage breakdown in invoice details
- **What happens when restaurant disputes charge?** Owner contacts support, support admin issues refund if dispute valid, system maintains subscription active during dispute investigation period (max 30 days), suspends only if dispute resolved against restaurant
- **How does system handle annual subscription mid-year cancellation?** System continues service until end of annual term (no refund for unused months per standard SaaS policy), sends "Subscription Ending" reminder 30 days before term end
- **What happens when payment succeeds after grace period but before suspension?** System immediately cancels scheduled suspension, resets failure counter to 0, sends "Payment Successful - Account Recovered" email, maintains uninterrupted service

---

## Requirements

### Functional Requirements

#### Subscription Management

- **FR-001**: System MUST support 3 subscription plan tiers: Basic ($99/month), Pro ($249/month), Enterprise (custom pricing)
- **FR-002**: System MUST allow restaurants to subscribe to initial plan during onboarding or from Business Dashboard
- **FR-003**: System MUST support both monthly and annual billing cycles for Basic and Pro plans
- **FR-004**: System MUST provide 15% discount for annual billing (Basic $1,009/year, Pro $2,539/year vs $1,188/$2,988 monthly equivalent)
- **FR-005**: System MUST allow restaurant owners to upgrade subscription plan at any time with immediate feature access
- **FR-006**: System MUST allow restaurant owners to downgrade subscription plan at any time with changes effective at next billing cycle
- **FR-007**: System MUST calculate prorated charges for mid-cycle upgrades based on remaining days in current billing period
- **FR-008**: System MUST apply prorated credits to account balance for mid-cycle downgrades
- **FR-009**: System MUST process prorated upgrade charges immediately upon plan change confirmation
- **FR-010**: System MUST maintain current plan features until end of billing cycle for downgrades
- **FR-011**: System MUST allow subscription pause for up to 90 days with all data retention
- **FR-012**: System MUST suspend billing during subscription pause period (no charges)
- **FR-013**: System MUST block feature access during subscription pause while maintaining data access
- **FR-014**: System MUST allow subscription resume at any time during pause period with immediate reactivation
- **FR-015**: System MUST auto-resume subscription after maximum 90-day pause period expires
- **FR-016**: System MUST allow restaurant owners to cancel subscription with service continuing until end of current billing period
- **FR-017**: System MUST send cancellation confirmation email with final service date when subscription cancelled
- **FR-018**: System MUST display subscription status in Business Dashboard: Active, Paused, Grace Period, Suspended, Cancelled
- **FR-019**: System MUST show next billing date, current plan tier, and billing cycle in subscription dashboard
- **FR-020**: System MUST allow payment method update at any time without interrupting active subscription

#### Billing Cycle & Payment Processing

- **FR-021**: System MUST automatically charge payment method on file on each billing cycle date (monthly or annual)
- **FR-022**: System MUST process initial subscription payment immediately upon plan selection and confirmation
- **FR-023**: System MUST send billing reminder email 7 days before next billing cycle date
- **FR-024**: System MUST send payment receipt email immediately after successful payment processing
- **FR-025**: System MUST generate unique invoice number for each billing transaction (format: INV-YYYY-MM-######)
- **FR-026**: System MUST itemize invoices with line items: base subscription, extension charges, usage-based fees, prorated adjustments, taxes
- **FR-027**: System MUST calculate and collect applicable sales tax based on restaurant billing address jurisdiction
- **FR-028**: System MUST support credit card payments via Stripe (Visa, Mastercard, Amex, Discover)
- **FR-029**: System MUST support ACH bank transfer payments for Enterprise plans
- **FR-030**: System MUST tokenize and securely store payment methods (PCI-compliant via Stripe)
- **FR-031**: System MUST never store raw credit card numbers (use Stripe tokens only)
- **FR-032**: System MUST validate payment method before processing subscription activation or plan change
- **FR-033**: System MUST update billing cycle date when subscription resumes after pause (advance by pause duration)

#### Payment Failure & Recovery

- **FR-034**: System MUST automatically retry failed payment 3 times: day 1 (initial failure), day 3, and day 5
- **FR-035**: System MUST send "Payment Failed - Will Retry" email immediately after initial payment failure
- **FR-036**: System MUST send "Grace Period Warning" email on day 3 after initial failure with payment update instructions
- **FR-037**: System MUST send "Final Warning - Account Suspends in 2 Days" email on day 6 after initial failure
- **FR-038**: System MUST display payment failure warning banner in Business Dashboard during grace period
- **FR-039**: System MUST maintain full feature access during 7-day grace period
- **FR-040**: System MUST suspend account on day 7 if all 3 payment retry attempts fail
- **FR-041**: System MUST block order processing and feature access when account suspended due to payment failure
- **FR-042**: System MUST allow payment method update during grace period or after suspension
- **FR-043**: System MUST provide "Retry Payment Now" button in dashboard after payment method update
- **FR-044**: System MUST immediately reactivate subscription within 60 seconds if manual payment retry succeeds
- **FR-045**: System MUST send "Account Reactivated" confirmation email after successful payment recovery
- **FR-046**: System MUST log all payment retry attempts with timestamp, amount, failure reason, and retry count
- **FR-047**: System MUST mark subscription for cancellation if account remains suspended for 30 days
- **FR-048**: System MUST send "Card Expiring Soon" email 30 days before payment method expiration date
- **FR-049**: System MUST display payment method expiration warning 14 days before expiration in dashboard

#### Usage-Based Transaction Fees

- **FR-050**: System MUST track transaction fees for all completed orders: Basic plan (2.9% + $0.30/order), Pro plan (2.5% + $0.30/order), Enterprise (custom rate)
- **FR-051**: System MUST calculate transaction fee per order: (order total × percentage) + fixed fee
- **FR-052**: System MUST aggregate transaction fees throughout billing cycle and include total in monthly invoice as separate line item
- **FR-053**: System MUST display transaction fee breakdown in invoice: total orders, total order value, percentage fee, per-transaction fee, total transaction fees
- **FR-054**: System MUST allow restaurant owner to view transaction fee details for current billing cycle in dashboard
- **FR-055**: System MUST apply transaction fee rate based on subscription plan tier active at time of order completion
- **FR-056**: System MUST calculate transaction fees on order subtotal before taxes and tips
- **FR-057**: System MUST consolidate transaction fees across all locations for multi-location restaurants in single invoice

#### Invoice Generation & Delivery

- **FR-058**: System MUST generate PDF invoices for all billing transactions within 24 hours of payment processing
- **FR-059**: System MUST email PDF invoice to restaurant owner's billing email address within 24 hours of payment
- **FR-060**: System MUST display all invoices in "Billing History" section of Business Dashboard
- **FR-061**: System MUST allow restaurant owners to download PDF invoices at any time
- **FR-062**: System MUST include in invoice: business name, billing address, invoice number, invoice date, due date (date of charge), line items with descriptions and amounts, subtotal, taxes, total, payment method (last 4 digits), payment status
- **FR-063**: System MUST mark invoice status as: Paid, Failed, Pending, Refunded, Disputed
- **FR-064**: System MUST allow filtering billing history by date range (last 30 days, last 90 days, last year, custom range)
- **FR-065**: System MUST allow filtering billing history by status (Paid, Failed, Pending)
- **FR-066**: System MUST display billing history in reverse chronological order (newest first)
- **FR-067**: System MUST generate year-end billing summary PDF for tax purposes (total paid, total transaction fees, monthly breakdown)

#### Subscription Analytics (Platform Admin)

- **FR-068**: System MUST calculate and display Monthly Recurring Revenue (MRR): sum of all active monthly subscription base fees
- **FR-069**: System MUST calculate and display Annual Recurring Revenue (ARR): MRR × 12
- **FR-070**: System MUST calculate and display Average Revenue Per User (ARPU): MRR / active subscription count
- **FR-071**: System MUST calculate and display churn rate: (cancelled subscriptions / total active subscriptions at start of period) over last 30 days
- **FR-072**: System MUST display subscription plan distribution: count and percentage of Basic, Pro, Enterprise subscriptions
- **FR-073**: System MUST calculate and display payment failure recovery rate: (recovered payments / total failed payments) over last 30 days
- **FR-074**: System MUST display MRR trend chart: MRR over last 12 months
- **FR-075**: System MUST display churn reason breakdown: count of cancellations by reason category
- **FR-076**: System MUST display grace period accounts: count of subscriptions currently in payment failure grace period
- **FR-077**: System MUST display suspended accounts: count of subscriptions suspended due to payment failure
- **FR-078**: System MUST allow platform admin to export subscription analytics report as CSV

#### Multi-Location Billing

- **FR-079**: System MUST consolidate billing for multi-location restaurants under single subscription
- **FR-080**: System MUST allow viewing per-location transaction fee breakdown in invoice details
- **FR-081**: System MUST apply single subscription base fee regardless of location count
- **FR-082**: System MUST aggregate transaction fees across all locations in consolidated invoice

#### Dispute & Refund Management

- **FR-083**: System MUST allow platform admin to issue full or partial refunds for billing disputes
- **FR-084**: System MUST mark invoice as "Refunded" with refund amount and reason when refund issued
- **FR-085**: System MUST send refund confirmation email to restaurant owner with refund amount and processing timeline (5-7 business days)
- **FR-086**: System MUST maintain subscription active during dispute investigation period (max 30 days)
- **FR-087**: System MUST log all refund transactions with timestamp, admin user, amount, reason, and associated invoice

### Key Entities

- **Subscription**: Represents restaurant's active subscription - includes plan tier (Basic/Pro/Enterprise), billing cycle (monthly/annual), status (Active/Paused/Grace Period/Suspended/Cancelled), next billing date, payment method reference, creation date, pause dates, cancellation date, current period start/end dates
- **Subscription Plan**: Defines available tiers - includes plan name, base price, billing cycle, feature set access, transaction fee rate (percentage + fixed), discount for annual billing, Enterprise custom pricing flag
- **Invoice**: Represents billing transaction - includes invoice number, restaurant reference, invoice date, due date, billing period start/end, line items (base subscription, extensions, usage fees, adjustments, taxes), subtotal, tax amount, total amount, payment status, payment method, failure reason, refund details
- **Invoice Line Item**: Individual charge on invoice - includes description (e.g., "Basic Plan - Monthly", "Transaction Fees", "KDS Extension"), quantity, unit price, amount, item type (subscription/extension/usage/tax/adjustment)
- **Payment Retry**: Tracks automatic payment recovery attempts - includes invoice reference, attempt number (1-3), retry date, status (Pending/Success/Failed), failure reason, next retry date
- **Transaction Fee Record**: Tracks usage-based fees per order - includes order reference, order date, order total, fee rate (percentage + fixed), calculated fee amount, subscription plan at time of order
- **Billing Analytics Snapshot**: Daily snapshot of subscription metrics - includes date, MRR, ARR, ARPU, active subscription count, new subscriptions, cancelled subscriptions, churn rate, plan distribution, grace period count, suspended count
- **Payment Method**: Tokenized payment info (via Stripe) - includes type (card/ACH), card brand, last 4 digits, expiration date, billing address, Stripe token ID, default flag, creation date

---

## Success Criteria

### Measurable Outcomes

- **SC-001**: Restaurant owners can subscribe to initial plan and complete payment in under 3 minutes from plan selection to confirmation
- **SC-002**: Plan upgrade processes in under 60 seconds from confirmation to full feature access
- **SC-003**: Prorated billing calculations are accurate to 2 decimal places for all plan changes
- **SC-004**: Automatic payment processing succeeds for 95%+ of active subscriptions on billing cycle date
- **SC-005**: Payment failure recovery rate achieves 60%+ within 7-day grace period through automatic retries
- **SC-006**: Invoice generation and email delivery completes within 24 hours of payment processing for 99%+ of transactions
- **SC-007**: Subscription analytics dashboard displays MRR, ARR, and churn rate with data refreshed within 15 minutes of subscription changes
- **SC-008**: Platform supports 1,000+ active subscriptions with real-time billing operations
- **SC-009**: Transaction fee calculations are accurate to 2 decimal places for 100% of orders
- **SC-010**: Failed payment account suspension executes automatically on day 7 for 100% of unrecovered failures

### Qualitative Measures

- Restaurant owners understand subscription pricing, billing cycles, and plan differences before subscribing
- Plan upgrade/downgrade flows feel seamless with immediate feature access changes and transparent prorated billing
- Payment failure recovery workflows reduce involuntary churn through clear communication and grace period warnings
- Billing history and invoice downloads provide restaurant owners with complete financial transparency for accounting
- Platform admin has comprehensive subscription analytics for business health monitoring and growth planning
- Multi-location billing consolidation simplifies accounting for restaurant chains with single invoice

---

## Dependencies

### Related Specifications

- **SPEC 001 - Restaurant & Multi-Tenant Management**: Subscription is created during restaurant tenant provisioning
- **SPEC 009 - Business Dashboard**: Subscription management UI, billing history, and plan changes accessed from Business Dashboard
- **SPEC 019 - Platform Admin Dashboard**: Platform admin accesses subscription analytics and refund management
- **SPEC 020 - Extension Marketplace**: Extension charges are added as line items to subscription invoices
- **SPEC 021 - Payment Processing**: Subscription billing uses same payment gateway integration (Stripe) for payment method tokenization

### External Services

- **Stripe API**: Payment processing, payment method tokenization, automatic billing, refund processing, webhook notifications for payment events
- **Email Delivery Service**: Invoice delivery, payment failure notifications, grace period warnings, subscription confirmation emails
- **SMS Service**: Optional SMS notifications for payment failures during grace period

---

## Assumptions

1. **Stripe as Payment Processor**: Subscription billing uses Stripe for payment method storage (tokenization), automatic recurring billing, payment retries, and webhook event notifications
2. **Standard SaaS Cancellation Policy**: No prorated refunds for mid-cycle cancellations - service continues until end of current billing period then deactivates
3. **Grace Period Duration**: 7-day grace period with 3 automatic retry attempts (day 1, 3, 5) balances revenue recovery and customer experience
4. **Tax Calculation**: Sales tax calculated based on restaurant billing address jurisdiction using standard tax rate table (not real-time tax API)
5. **Invoice Generation Timing**: PDF invoices generated within 24 hours (not real-time) to allow for any immediate adjustments or refunds
6. **Transaction Fee Scope**: Transaction fees apply only to completed customer orders (not refunded or cancelled orders)
7. **Multi-Location Billing**: Single subscription covers all locations under restaurant chain with consolidated billing (not per-location subscriptions)
8. **Enterprise Pricing**: Enterprise plans use custom pricing negotiated per customer with flexible transaction fee rates

---

## Out of Scope

The following features are explicitly excluded from this specification:

1. **Individual Order Payment Processing**: Processing customer payments for individual orders is handled by SPEC 021 (Payment Processing) - this spec covers only subscription billing
2. **Extension Billing Logic**: Logic for calculating extension charges and free trials is defined in SPEC 020 (Extension Marketplace) - this spec handles only invoice line item inclusion
3. **Payment Gateway Integration Details**: Technical integration with Stripe API is implementation detail - this spec defines required payment capabilities only
4. **Tax Compliance & Reporting**: Detailed tax calculation rules, nexus determination, and tax filing/remittance are out of scope (uses simple jurisdiction-based tax rates)
5. **Dunning Campaign Configuration**: Advanced dunning workflows with custom email sequences, timing rules, and A/B testing are deferred to future iteration
6. **Revenue Recognition Accounting**: Financial accounting rules for revenue recognition (GAAP/IFRS compliance) are out of scope
7. **Subscription Promotions & Discounts**: Coupon codes, promotional discounts, referral credits, and limited-time offers are deferred to future iteration
