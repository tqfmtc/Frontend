# Feature Specification: POS Tablet Interface

**Feature Branch**: `025-pos-tablet`
**Created**: 2025-10-30
**Status**: Draft - Archived for Future Implementation
**Input**: User description: "POS Tablet Interface - Touch-optimized order entry interface for waitstaff and cashiers to create and manage customer orders at the point of sale. Category-based menu navigation with visual item cards (photo, name, price). Touch-friendly modifier selection with checkboxes for add-ons, radio buttons for required choices (size, doneness, temperature). Order splitting for separate checks (split by seat, by item, custom split). Table management: assign order to table number, track table status (available, occupied, needs clearing), transfer orders between tables. Employee PIN authentication for shift start. Order cart management: add items, remove items, adjust quantities, apply discounts/comps (requires manager PIN). Customer identification via phone number lookup for loyalty and order history. Payment tender selection: cash, card (routed to payment processing), gift card, split payment. Order firing to kitchen: send entire order or fire by course (appetizers now, entrees in 15min). Order modification after firing (mark items as 'rush' or 'hold'). Visual order status indicators showing kitchen prep progress. Server-specific order views (waitstaff sees only their assigned tables/orders). Interface layout: left sidebar for categories (Appetizers, Entrees, Drinks, Desserts), center grid for items within selected category, right panel for current order cart with subtotal/tax/total. Manager functions: void items (requires PIN), apply discounts (requires PIN), comp entire order (requires PIN), override prices, reprint receipts. Key features: touch-optimized UI with large tap targets, category-based menu navigation, visual item cards with photos, modifier selection UI (checkboxes/radio buttons), order cart with add/remove/quantity controls, table assignment and tracking, employee PIN authentication, customer phone lookup, payment tender selection, order firing controls (fire now, fire by course, mark rush/hold), manager functions with PIN protection. Scope: ONLY order entry and basic POS functions, NOT payment processing (handled by SPEC 021), NOT kitchen display (handled by SPEC 024 KDS), NOT inventory management. Example flows: Waitstaff logs in with PIN → navigates to 'Entrees' category → selects 'Burger' item → chooses modifiers: Size=Medium, Doneness=Medium Rare, Add Cheese (+$1) → adds to cart → assigns to Table 5 → fires order to kitchen vs Cashier at counter: customer orders 'Large Coffee + Bagel' → adds items to cart → customer pays with card → processes payment → prints receipt → order fires to kitchen. Required capabilities: touch-optimized menu navigation, modifier selection, cart management, table assignment, employee auth, payment tender selection, order firing, manager overrides with PIN."

## Overview

This specification defines the POS Tablet Interface, a touch-optimized order entry system for waitstaff and cashiers to create, manage, and process customer orders at the point of sale. The interface features category-based menu navigation (Appetizers, Entrees, Drinks, Desserts) with visual item cards showing photos and prices. Staff selects items, customizes with modifiers (checkboxes for add-ons, radio buttons for required choices like size/doneness), builds order cart, assigns to table, and fires to kitchen. Supports order splitting (separate checks by seat/item/custom), table management (track availability, transfer orders), employee PIN authentication, customer phone lookup for loyalty, manager functions (void items, discounts, comps with PIN protection), and flexible payment tender selection (cash, card, gift card, split payment). Orders can fire entirely or by course (appetizers now, entrees in 15min). Layout: left sidebar (categories), center grid (items), right panel (order cart with subtotal/tax/total).

**Scope**: This specification covers ONLY order entry and basic POS functions. Payment processing is handled by SPEC 021. Kitchen display is handled by SPEC 024 (KDS). Inventory management is out of scope.

**Note**: This specification is archived for future implementation - not required for short-term ordering focus.

## User Scenarios & Testing

### User Story 1 - Create Simple Order with Modifiers (Priority: P1)

Waitstaff logs in with PIN, navigates category sidebar to select 'Entrees', taps 'Burger' item card, customizes with modifiers (Size: Medium radio button, Doneness: Medium Rare radio button, Add Cheese checkbox +$1), adds to cart, assigns to Table 5, fires entire order to kitchen. Order displays in right panel cart with subtotal, tax, and total. Kitchen receives order on KDS.

**Why this priority**: Core POS functionality - staff must create and fire orders to kitchen. Without this, no orders can be entered.

**Independent Test**: Can be fully tested by logging in with PIN "1234", selecting Entrees category, tapping Burger item, choosing modifiers (Medium size, Medium Rare doneness, Add Cheese +$1), verifying cart shows "1x Medium Burger, Medium Rare, Add Cheese $9.99 + $1.00 = $10.99", assigning to Table 5, firing to kitchen.

**Acceptance Scenarios**:

1. **Given** waitstaff on POS login screen, **When** staff enters PIN "1234" and taps "Login", **Then** POS displays main interface: left sidebar with categories (Appetizers, Entrees, Drinks, Desserts), center empty (no category selected), right panel empty cart (Subtotal: $0.00, Tax: $0.00, Total: $0.00)
2. **Given** POS main interface displayed, **When** staff taps "Entrees" category in left sidebar, **Then** center grid displays entree items: Burger (photo, $8.99), Pasta ($12.99), Steak ($24.99), Salmon ($18.99) - 4-column grid with large touch targets
3. **Given** Entrees category displayed, **When** staff taps "Burger" item card, **Then** modifier selection modal appears: Size (radio buttons: Small $7.99, Medium $8.99 selected, Large $10.99), Doneness (radio buttons: Rare, Medium Rare, Medium, Well Done), Add-ons (checkboxes: Add Cheese +$1, Add Bacon +$2, Add Avocado +$1.50), "Add to Cart" button at bottom
4. **Given** modifier modal for Burger, **When** staff selects Medium size (radio), Medium Rare doneness (radio), Add Cheese checkbox, taps "Add to Cart", **Then** modal closes, order cart in right panel updates: "1x Medium Burger, Medium Rare, Add Cheese $8.99 + $1.00 = $9.99", Subtotal: $9.99, Tax: $0.80 (8%), Total: $10.79
5. **Given** order cart with Burger, **When** staff taps "Assign Table" button, selects "Table 5" from table list, taps "Fire Order", **Then** order submits to kitchen, POS displays confirmation "Order sent to kitchen for Table 5", cart clears for next order

---

### User Story 2 - Split Order for Separate Checks (Priority: P1)

Table of 4 guests requests separate checks. Waitstaff creates order with 4 items (2 Burgers, 1 Salad, 1 Pasta), assigns to Table 8, then splits order by seat: Seat 1 (Burger), Seat 2 (Burger), Seat 3 (Salad), Seat 4 (Pasta). System creates 4 separate checks. Each guest pays individually. Waitstaff processes 4 separate payment transactions.

**Why this priority**: Critical for full-service restaurants - separate checks for groups is standard expectation. Without this, staff manually splits bills causing errors and delays.

**Independent Test**: Can be fully tested by creating order with 4 items (2 Burgers @ $8.99, 1 Salad @ $6.99, 1 Pasta @ $12.99), assigning to Table 8, tapping "Split Check", selecting "Split by Seat", assigning items: Seat 1 (Burger), Seat 2 (Burger), Seat 3 (Salad), Seat 4 (Pasta), verifying 4 separate checks created with correct totals.

**Acceptance Scenarios**:

1. **Given** order cart with 4 items: 2x Burger ($8.99 each), 1x Salad ($6.99), 1x Pasta ($12.99), Total: $37.96, assigned to Table 8, **When** staff taps "Split Check" button, **Then** split options modal displays: "Split by Seat", "Split by Item", "Custom Split", "Equal Split"
2. **Given** split options modal, **When** staff selects "Split by Seat", **Then** seat assignment interface displays: Order items list on left, 4 seat buttons on right (Seat 1, Seat 2, Seat 3, Seat 4), staff drags/taps items to assign: Burger → Seat 1, Burger → Seat 2, Salad → Seat 3, Pasta → Seat 4
3. **Given** items assigned to seats, **When** staff taps "Create Split Checks", **Then** system generates 4 separate checks: Check 1 (Table 8-Seat 1): Burger $8.99 + Tax $0.72 = $9.71, Check 2 (Table 8-Seat 2): Burger $8.99 + Tax $0.72 = $9.71, Check 3 (Table 8-Seat 3): Salad $6.99 + Tax $0.56 = $7.55, Check 4 (Table 8-Seat 4): Pasta $12.99 + Tax $1.04 = $14.03
4. **Given** 4 separate checks created for Table 8, **When** staff selects Check 1 (Seat 1), processes payment (card), **Then** Check 1 marks as Paid, remaining 3 checks still Open, staff repeats for Check 2, 3, 4 individually until all paid, Table 8 status updates to "Available" after all checks closed

---

### User Story 3 - Apply Manager Discount and Comp Items (Priority: P2)

Customer complains about food quality. Manager authorizes 20% discount on entire check. Waitstaff applies discount but requires manager PIN for approval. Manager enters PIN "9999", discount applies, new total calculated. For severe complaint, manager comps entire entree (voids item with manager PIN).

**Why this priority**: Important for customer service recovery but not blocking for basic order entry. Lower priority because discounts/comps are exception cases, not standard workflow.

**Independent Test**: Can be fully tested by creating order with Burger ($8.99) + Salad ($6.99) = $15.98 total, tapping "Apply Discount", entering 20% discount, system prompting for manager PIN, entering manager PIN "9999", verifying discount applied: Subtotal $15.98, Discount -$3.20 (20%), Tax $1.02 (8% of discounted amount), Total $13.80.

**Acceptance Scenarios**:

1. **Given** order cart with Burger ($8.99) + Salad ($6.99), Subtotal $15.98, Tax $1.28, Total $17.26, **When** staff taps "Apply Discount" button, **Then** discount modal displays: Discount Type (Percentage / Fixed Amount), Amount field, "Apply" button
2. **Given** discount modal, **When** staff enters "20" for Percentage discount, taps "Apply", **Then** system prompts "Manager PIN Required", displays PIN pad, waits for manager authorization
3. **Given** manager PIN prompt, **When** manager enters PIN "9999", taps "Confirm", **Then** discount applies: Subtotal $15.98, Discount (20%) -$3.20, New Subtotal $12.78, Tax $1.02 (8% of discounted amount), Total $13.80, discount reason logged: "Manager Override - PIN 9999"
4. **Given** order cart with Burger ($8.99) + Salad ($6.99) + Pasta ($12.99), **When** manager decides to comp Burger due to customer complaint, staff selects Burger line item, taps "Void Item", **Then** system prompts "Manager PIN Required", manager enters PIN "9999", Burger removes from cart with $0 charge, void logged: "Manager Comp - Burger - PIN 9999", new Subtotal: $19.98 (Salad + Pasta only)

---

### User Story 4 - Fire Order by Course (Priority: P2)

Table orders appetizers and entrees simultaneously. Waitstaff wants appetizers prepared immediately, entrees delayed 15 minutes. Staff creates full order (Appetizer: Wings, Entree: Burger), marks Appetizer "Fire Now", marks Entree "Fire in 15min". Kitchen receives Wings immediately, Burger arrives 15 minutes later.

**Why this priority**: Important for full-service dining experience (course timing) but not essential for fast-casual/QSR. Lower priority because simpler restaurants fire all items immediately.

**Independent Test**: Can be fully tested by creating order with Wings (Appetizer) + Burger (Entree), assigning to Table 3, tapping "Fire by Course", selecting Wings "Fire Now" and Burger "Fire in 15min", verifying Wings appears on KDS immediately, Burger appears 15 minutes later.

**Acceptance Scenarios**:

1. **Given** order cart with Wings ($7.99, category: Appetizer) + Burger ($8.99, category: Entree), **When** staff taps "Fire by Course" button, **Then** course timing interface displays: order items with Fire Time dropdown per item (Fire Now / Fire in 10min / Fire in 15min / Fire in 20min / Hold)
2. **Given** course timing interface, **When** staff selects Wings "Fire Now", Burger "Fire in 15min", taps "Fire Order", **Then** Wings immediately sends to kitchen KDS (displays on KDS as New order), Burger schedules for 15min delay (system holds Burger, countdown timer starts)
3. **Given** Burger scheduled to fire in 15min, **When** 15 minutes elapse, **Then** Burger automatically fires to kitchen KDS (displays as New order), waitstaff receives notification "Table 3 - Burger fired to kitchen", no manual action required

---

### User Story 5 - Lookup Customer for Loyalty and Order History (Priority: P2)

Regular customer arrives, provides phone number for loyalty points. Waitstaff enters phone "555-0123" in customer lookup, system retrieves customer profile: "John Doe, 450 loyalty points, Last order: Large Burger + Fries 2 weeks ago". Staff views order history, offers to reorder previous favorite. Customer confirms, previous order adds to cart automatically.

**Why this priority**: Important for customer experience and loyalty program engagement but not blocking for basic order processing. Lower priority because first-time customers don't require lookup.

**Independent Test**: Can be fully tested by tapping "Customer Lookup" button, entering phone "555-0123", verifying customer profile displays: "John Doe, 450 points, Last order: Burger + Fries", tapping "Reorder Last", verifying Burger + Fries adds to cart automatically.

**Acceptance Scenarios**:

1. **Given** POS main interface with empty cart, **When** staff taps "Customer Lookup" button in top toolbar, **Then** customer lookup modal displays: Phone Number field, "Search" button, "New Customer" button
2. **Given** customer lookup modal, **When** staff enters phone "555-0123", taps "Search", **Then** system retrieves customer profile: displays "John Doe, 450 loyalty points, Member since: Jan 2024, Last order: 2 weeks ago (Large Burger + Fries - $12.99)", "View Order History" button, "Reorder Last" button, "Apply Customer" button
3. **Given** customer profile displayed with "Last order: Burger + Fries", **When** staff taps "Reorder Last" button, **Then** Burger + Fries automatically adds to current order cart: 1x Large Burger ($8.99), 1x Fries ($3.99), Subtotal $12.98, customer name "John Doe" attaches to order for loyalty tracking
4. **Given** customer profile applied to order, **When** order completes and payment processes, **Then** loyalty points automatically calculate and credit to customer account: $12.98 order = 13 points earned (1 point per dollar), new balance 463 points, customer receives SMS "You earned 13 points! New balance: 463 points"

---

### Edge Cases

- **What happens when staff enters wrong PIN repeatedly?** System locks out employee account after 3 failed PIN attempts, displays "Account locked - contact manager", manager must unlock account from Business Dashboard employee management
- **How does system handle order cart if staff logs out without firing order?** System saves draft order to employee session, prompts "You have unsaved order for Table 5 - Resume or Discard?", staff can resume draft when logging back in
- **What happens when item selected but modifiers required?** System prevents "Add to Cart" until all required modifiers selected (size, temperature, doneness), displays validation error "Please select required options: Size"
- **How does system handle table transfer mid-order?** Staff selects active order, taps "Transfer Table", selects new table number, all order items and status transfer to new table, old table status updates to Available, kitchen sees updated table number
- **What happens when order already fired but customer requests addition?** Staff adds new item to existing order, taps "Fire Addition", system sends only new item to kitchen with notation "Addition to Order #1234 - Table 5", kitchen sees separate order card marked "ADDITION"
- **How does system handle split check if items shared (appetizer for table)?** Staff selects "Custom Split" option, manually assigns portion of shared item to each seat (e.g., Wings $7.99 / 2 people = $4.00 each), system calculates split amounts
- **What happens when payment fails after order fired to kitchen?** Order remains in "Pending Payment" status, kitchen continues preparing food, staff can retry payment or manager can comp/discount to resolve, order doesn't fire again

---

## Requirements

### Functional Requirements

#### Employee Authentication & Session Management

- **FR-001**: System MUST provide employee login screen with PIN pad (4-digit PIN entry)
- **FR-002**: System MUST authenticate employee PIN against employee database
- **FR-003**: System MUST lock employee account after 3 consecutive failed PIN attempts
- **FR-004**: System MUST track employee session: logged-in employee name, login timestamp, role (Server/Cashier/Manager)
- **FR-005**: System MUST allow employee logout with session termination
- **FR-006**: System MUST save draft orders to employee session if logging out with unsaved order in cart
- **FR-007**: System MUST prompt employee to resume or discard draft order upon re-login
- **FR-008**: System MUST display logged-in employee name in top toolbar

#### Menu Navigation & Item Selection

- **FR-009**: System MUST display menu category sidebar on left: configurable categories (Appetizers, Entrees, Drinks, Desserts, etc.)
- **FR-010**: System MUST load category items in center grid when category selected (4-6 column responsive grid)
- **FR-011**: System MUST display item cards with: item photo (thumbnail), item name, base price, "Add" button
- **FR-012**: System MUST support large touch targets (minimum 100px x 100px) for touch-optimized interaction
- **FR-013**: System MUST open modifier selection modal when item with modifiers tapped
- **FR-014**: System MUST display items without modifiers directly added to cart when tapped (e.g., "Coffee" with no customization)

#### Modifier Selection

- **FR-015**: System MUST display modifier groups in modal: group name, modifier options, selection type (radio/checkbox)
- **FR-016**: System MUST render required modifier groups as radio buttons (exactly one selection required: Size, Doneness, Temperature)
- **FR-017**: System MUST render optional modifier groups as checkboxes (zero or multiple selections allowed: Toppings, Add-ons, Extras)
- **FR-018**: System MUST display modifier price adjustments next to options: "+$1.00", "+$2.50", "No charge"
- **FR-019**: System MUST validate required modifiers selected before allowing "Add to Cart"
- **FR-020**: System MUST display validation error if required modifiers missing: "Please select required options: Size, Doneness"
- **FR-021**: System MUST update item price in real-time as modifiers selected (base price + modifier upcharges)
- **FR-022**: System MUST support special instructions text field in modifier modal (free-text, 200 character limit)

#### Order Cart Management

- **FR-023**: System MUST display order cart in right panel showing: line items with quantities, modifiers per item, special instructions, line item subtotals, order subtotal, tax amount, total amount
- **FR-024**: System MUST allow staff to increase/decrease item quantity with +/- buttons
- **FR-025**: System MUST allow staff to remove item from cart with "X" delete button
- **FR-026**: System MUST allow staff to tap line item to edit modifiers (reopen modifier modal with current selections)
- **FR-027**: System MUST calculate tax based on restaurant tax rate configuration (default 8%, configurable in settings)
- **FR-028**: System MUST update subtotal/tax/total in real-time as items added/removed/modified
- **FR-029**: System MUST support "Clear Cart" function to remove all items with confirmation prompt

#### Table Assignment & Management

- **FR-030**: System MUST display "Assign Table" button in cart panel
- **FR-031**: System MUST display table selection interface: table list showing table number, party size, status (Available/Occupied/Needs Clearing)
- **FR-032**: System MUST allow staff to assign order to table number
- **FR-033**: System MUST update table status to "Occupied" when order assigned and fired
- **FR-034**: System MUST display assigned table number on order cart header: "Table 5"
- **FR-035**: System MUST support table transfer: move existing order from one table to another
- **FR-036**: System MUST filter server view to show only tables assigned to logged-in server (server-specific order view)
- **FR-037**: System MUST allow managers to view all tables regardless of server assignment

#### Order Firing & Kitchen Integration

- **FR-038**: System MUST provide "Fire Order" button to submit entire order to kitchen
- **FR-039**: System MUST send order to kitchen system (KDS) with: order items, modifiers, special instructions, table number, server name, order timestamp
- **FR-040**: System MUST support "Fire by Course" option allowing staff to schedule delayed firing per item category
- **FR-041**: System MUST allow staff to mark items: "Fire Now", "Fire in 10min", "Fire in 15min", "Fire in 20min", "Hold"
- **FR-042**: System MUST automatically fire delayed items when scheduled time reached (countdown timer)
- **FR-043**: System MUST allow staff to fire additions to existing orders (new items added after initial firing)
- **FR-044**: System MUST mark additions clearly for kitchen: "ADDITION to Order #1234"
- **FR-045**: System MUST support order modification after firing: mark items "Rush" or "Hold"
- **FR-046**: System MUST display visual order status indicators showing kitchen prep progress: New, In Progress, Completed

#### Order Splitting

- **FR-047**: System MUST provide "Split Check" button for orders with 2+ items
- **FR-048**: System MUST support split options: Split by Seat, Split by Item, Equal Split, Custom Split
- **FR-049**: System MUST display seat assignment interface for "Split by Seat": drag/tap items to assign to seats
- **FR-050**: System MUST generate separate checks per seat with independent subtotal/tax/total calculations
- **FR-051**: System MUST support "Split by Item" creating individual check per line item
- **FR-052**: System MUST support "Equal Split" dividing total amount equally by number of people (e.g., $40 total / 4 people = $10 each)
- **FR-053**: System MUST support "Custom Split" allowing manual percentage/amount assignment per check
- **FR-054**: System MUST maintain association between split checks and original order/table
- **FR-055**: System MUST track payment status per split check independently

#### Payment Tender Selection

- **FR-056**: System MUST provide "Payment" button to initiate checkout after order fired
- **FR-057**: System MUST display payment tender selection: Cash, Card (Credit/Debit), Gift Card, Split Payment
- **FR-058**: System MUST route card payments to SPEC 021 (Payment Processing) for payment gateway integration
- **FR-059**: System MUST accept cash payment with change calculation: amount tendered - order total = change due
- **FR-060**: System MUST display change due prominently: "Change Due: $5.25"
- **FR-061**: System MUST support gift card payment with balance check and partial payment if insufficient balance
- **FR-062**: System MUST support split payment: customer pays portion with card, remainder with cash
- **FR-063**: System MUST print receipt after successful payment with: order items, amounts, payment method, change (if cash), order timestamp, table number, server name

#### Customer Identification & Loyalty

- **FR-064**: System MUST provide "Customer Lookup" button in top toolbar
- **FR-065**: System MUST allow customer search by phone number (format: 555-0123)
- **FR-066**: System MUST retrieve customer profile from SPEC 008 (Customer Identity & Wallet): customer name, loyalty points balance, membership date, order history (last 5 orders)
- **FR-067**: System MUST display customer order history with dates, items, and amounts
- **FR-068**: System MUST allow "Reorder Last" function automatically adding previous order items to cart
- **FR-069**: System MUST attach customer profile to order for loyalty point tracking
- **FR-070**: System MUST calculate and credit loyalty points after successful payment (1 point per dollar spent default, configurable)

#### Manager Functions & Overrides

- **FR-071**: System MUST require manager PIN for sensitive operations: void items, apply discounts, comp orders, price overrides
- **FR-072**: System MUST display manager PIN prompt modal when manager function triggered
- **FR-073**: System MUST log all manager overrides with: manager PIN/name, action taken, timestamp, order reference, reason (optional text field)
- **FR-074**: System MUST support "Void Item" function removing item from cart with $0 charge (requires manager PIN)
- **FR-075**: System MUST support "Apply Discount" function: percentage discount or fixed amount discount (requires manager PIN)
- **FR-076**: System MUST recalculate tax after discount applied (tax applies to discounted subtotal, not original)
- **FR-077**: System MUST support "Comp Entire Order" function marking order as $0 total (requires manager PIN)
- **FR-078**: System MUST support "Override Price" function allowing manager to manually set item price (requires manager PIN)
- **FR-079**: System MUST support "Reprint Receipt" function reprinting last transaction receipt for table
- **FR-080**: System MUST display manager override audit log accessible from manager PIN entry (last 20 overrides: action, time, manager name)

### Key Entities

- **POS Session**: Active employee session - includes employee ID, employee name, role (Server/Cashier/Manager), login timestamp, assigned tables (servers only), draft orders (unsaved carts)
- **Order Cart**: Current order being built - includes line items list, assigned table number, customer reference (if looked up), subtotal, tax amount, total amount, order status (Draft/Fired/Pending Payment/Completed), split check references (if split)
- **Line Item**: Individual item in cart - includes menu item reference, quantity, selected modifiers (list of modifier options with prices), special instructions (free text), line item subtotal (base price + modifier upcharges × quantity)
- **Table**: Restaurant table - includes table number, party size (guest count), table status (Available/Occupied/Needs Clearing), assigned server ID (servers only see their tables), active order reference (if order in progress)
- **Split Check**: Separate check from split order - includes parent order reference, seat number or split method, assigned line items (subset of parent order items), check subtotal, tax, total, payment status (Open/Paid), payment tender (if paid)
- **Manager Override Log**: Audit record of sensitive operations - includes override action (Void/Discount/Comp/Price Override), manager PIN/name, order reference, table number, timestamp, amount affected, reason (optional)
- **Customer Profile Reference**: Lookup result from customer identity system - includes customer name, phone number, loyalty points balance, last order date, order history (last 5 orders with items and amounts)

---

## Success Criteria

### Measurable Outcomes

- **SC-001**: Staff can log in with PIN and start taking orders within 5 seconds
- **SC-002**: Menu categories and items load within 1 second of category selection
- **SC-003**: Item with modifiers can be added to cart within 10 seconds (item tap → modifier selection → add to cart)
- **SC-004**: Order cart updates subtotal/tax/total within 500ms of item added/removed/modified
- **SC-005**: Table assignment completes within 3 taps (Assign Table → Select Table → Confirm)
- **SC-006**: Order fires to kitchen within 2 seconds of "Fire Order" button tap
- **SC-007**: Split check by seat generates separate checks within 3 seconds for table of 4
- **SC-008**: Manager PIN validation completes within 1 second of PIN entry
- **SC-009**: Customer lookup by phone retrieves profile within 2 seconds
- **SC-010**: Payment processing (card) completes within 10 seconds from tender selection to receipt print

### Qualitative Measures

- Staff can navigate menu categories and select items intuitively without training
- Touch interface feels responsive with large tap targets and minimal mis-taps
- Modifier selection UI clearly distinguishes required (radio) vs optional (checkbox) choices
- Order cart provides clear visibility of all items, modifiers, and pricing
- Split check workflow feels natural and accurate for separate payments
- Manager override PINs provide security without slowing legitimate operations
- Customer lookup enhances personalization without disrupting order flow

---

## Dependencies

### Related Specifications

- **SPEC 002 - Menu Management**: POS displays menu items, categories, modifiers, and prices from menu catalog
- **SPEC 006 - Order Fulfillment & Status Tracking**: Orders created in POS flow to fulfillment system for kitchen routing
- **SPEC 008 - Customer Identity & Privacy-First Wallet**: Customer phone lookup retrieves profiles and loyalty data
- **SPEC 021 - Payment Processing**: Card payments from POS route to payment gateway for processing
- **SPEC 024 - Kitchen Display System (KDS)**: Orders fired from POS display on kitchen KDS screens

### External Services

- **Receipt Printer**: Physical receipt printer connected to POS device for printing customer receipts

---

## Assumptions

1. **Touch Screen Hardware**: POS runs on touch-enabled tablet devices (iPad, Android tablet, Windows tablet) supporting tap gestures
2. **Employee PIN Security**: 4-digit PINs provide adequate security for employee authentication in controlled restaurant environment
3. **Manager Override Model**: Manager PINs separate from employee PINs, stored securely with audit logging
4. **Tax Calculation**: Single tax rate per restaurant location (default 8%, configurable), applied to subtotal after discounts
5. **Loyalty Points Calculation**: Default 1 point per dollar spent, configurable per restaurant policy
6. **Table Count**: Typical restaurant has 10-50 tables, table list displays all tables with scrolling
7. **Network Connectivity**: POS tablets have reliable network connection for order submission and payment processing
8. **Session Timeout**: Employee session expires after 30 minutes of inactivity for security

---

## Out of Scope

The following features are explicitly excluded from this specification:

1. **Payment Processing**: Processing card payments, refunds, and payment gateway integration is handled by SPEC 021 (Payment Processing)
2. **Kitchen Display**: Displaying orders to kitchen staff is handled by SPEC 024 (KDS)
3. **Inventory Management**: Tracking ingredient quantities and depletion is out of scope for POS interface
4. **Employee Time Clock**: Clock-in/out and time tracking functionality is out of scope
5. **Reservations**: Table reservation and booking is handled by SPEC 026 (Table Management & Reservations)
6. **Reporting & Analytics**: Sales reports, employee performance analytics deferred to future iteration
7. **Cash Drawer Management**: Cash drawer reconciliation, cash counting, till management deferred to future iteration
8. **Gift Card Balance Management**: Loading gift card balances, gift card sales is out of scope (only payment tender selection)
9. **Delivery Orders**: Delivery order management and driver dispatch is handled by SPEC 027 (Delivery Management)
10. **Multi-Location Support**: POS interface designed for single location, multi-location features deferred

---

**Note**: This specification is archived for future implementation and not required for short-term ordering focus. Implementation can be prioritized based on customer demand for in-restaurant POS order entry capabilities.
