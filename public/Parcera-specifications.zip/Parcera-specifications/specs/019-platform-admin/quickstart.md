# Quickstart: 019-platform-admin

**Date**: 2025-11-04
**API Version**: 1.0.0

## Overview

This quickstart guide demonstrates the core usage patterns for the 019-platform-admin API and integration scenarios.

## Prerequisites

- Python 3.11+ or Node.js 18+
- PostgreSQL 14+ (for development)
- Redis (for caching/sessions)
- API credentials (JWT token)

## Installation

### Local Development Setup

```bash
# Clone repository
git clone https://github.com/parcera/platform.git
cd platform

# Create virtual environment (Python)
python3.11 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Set up environment
cp .env.example .env
# Edit .env with your configuration

# Run database migrations
alembic upgrade head

# Start development server
uvicorn main:app --reload --port 8000
```

## Authentication

All API requests require JWT token in Authorization header:

```bash
curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  https://api.parcera.local/api/v1/health
```

Response example (for test endpoints):
```json
{
  "status": "healthy",
  "timestamp": "2025-11-04T12:00:00Z"
}
```

## Core API Endpoints

### Health Check

```bash
curl https://api.parcera.local/api/v1/health
```

## Integration Scenarios

### Scenario 1: Multi-Tenant Data Access

All requests automatically scope to tenant from JWT claims.

### Scenario 2: Row-Level Security

Database-level security ensures tenant isolation.

### Scenario 3: Webhook Events

Subscribe to platform events for real-time updates.

## Error Handling

All errors follow standard format with proper HTTP status codes.

## Testing

### Unit Tests

```bash
pytest tests/unit/ -v --cov=src
```

### Integration Tests

```bash
pytest tests/integration/ -v
```

### Contract Tests

```bash
pytest tests/contract/ -v
```

## Deployment

### Docker

```bash
docker build -t parcera/api:latest .
docker run -p 8000:8000 parcera/api:latest
```

### Kubernetes

```bash
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
```

## Next Steps

1. Review API documentation: See `contracts/` directory for OpenAPI spec
2. Implement integration: Follow patterns in `/src` for your integration
3. Write tests: Use test templates in `tests/` directory
4. Deploy: Use Docker/Kubernetes configurations

## Support

- API Documentation: https://api.parcera.io/docs
- GitHub Issues: https://github.com/parcera/platform/issues
- Slack Community: #parcera-platform
