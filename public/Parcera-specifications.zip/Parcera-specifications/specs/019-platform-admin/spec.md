# Feature Specification: Platform Admin Dashboard & Tenant Management

**Feature Branch**: `019-platform-admin`
**Created**: 2025-10-30
**Status**: Draft
**Constitution Alignment**: Principles II (Multi-Tenancy), V (MVP Discipline)

---

## Overview

SaaS platform administration dashboard for platform owners to manage the entire multi-tenant system. Provides comprehensive tenant lifecycle management including CRUD operations, automated provisioning with schema isolation, self-service onboarding wizard, platform-wide analytics (MRR, ARR, churn), billing management, and tenant health monitoring. Enables platform owners to onboard restaurants in minutes, monitor platform growth, manage subscriptions, handle payment failures, and ensure system health across all tenants.

**Distinction**: This is the platform owner's administrative interface (managing multiple restaurant tenants). This is separate from Spec 009 (Admin Dashboard) which is for individual restaurant owners managing their own business.

**Core Value**: Enables SaaS scalability by eliminating manual tenant management, providing visibility into platform health, and automating operational workflows.

---

## User Scenarios & Testing

### User Story 1 - Create and Provision New Tenant (Priority: P0)

**As a** platform owner
**I want to** create a new restaurant tenant through an automated onboarding wizard
**So that** new customers can be provisioned in minutes without manual database work

**Why this priority**: Core SaaS operational capability. Without automated provisioning, platform cannot scale beyond handful of customers requiring manual setup.

**Independent Test**: Can be fully tested by: (1) platform owner logs into admin dashboard, (2) clicks "Add New Restaurant", (3) completes onboarding wizard (business name, contact, plan selection), (4) system auto-creates isolated schema, generates activation code, sends onboarding email, (5) new tenant appears in tenant list with "active" status. Delivers standalone value by enabling self-service tenant creation.

**Acceptance Scenarios**:

1. **Given** platform owner is logged into admin dashboard, **When** they click "Add New Restaurant" button, **Then** onboarding wizard opens showing Step 1: Business Information (name, address, contact email, phone)
2. **Given** wizard Step 1 completed, **When** owner proceeds to Step 2, **Then** plan selection screen shows available plans (Basic, Pro, Enterprise) with pricing and features listed
3. **Given** plan selected, **When** owner clicks "Create Tenant", **Then** system automatically: creates isolated database schema with RLS policies, generates unique activation code (48-hour expiry), sets up default menu structure, configures initial settings, creates tenant record with "active" status
4. **Given** tenant provisioning completes, **When** system finishes, **Then** dashboard displays success message with activation code, sends onboarding email to restaurant contact with activation instructions and login link
5. **Given** provisioning fails mid-process, **When** error occurs, **Then** system rolls back all changes (atomic operation), displays specific error message, logs failure for debugging

---

### User Story 2 - View Platform-Wide Analytics (Priority: P0)

**As a** platform owner
**I want to** view platform-wide growth and revenue metrics
**So that** I can monitor business health and make data-driven decisions

**Why this priority**: Critical for business operations. Without analytics visibility, platform owner cannot track growth, identify issues, or report to stakeholders.

**Independent Test**: Can be fully tested by: (1) platform owner accesses analytics dashboard, (2) views MRR/ARR metrics, tenant count, churn rate, (3) changes date range to view historical trends, (4) exports report. Delivers standalone business intelligence value.

**Acceptance Scenarios**:

1. **Given** platform owner accesses analytics dashboard, **When** page loads, **Then** dashboard displays: current MRR (Monthly Recurring Revenue), ARR (Annual Recurring Revenue), total active tenants, new tenants this month, churn rate, average revenue per tenant
2. **Given** analytics dashboard is displayed, **When** owner views revenue chart, **Then** chart shows MRR trend over last 12 months with month-over-month growth percentage
3. **Given** owner wants detailed breakdown, **When** they click "View Details" on MRR, **Then** system shows revenue breakdown by plan type (Basic, Pro, Enterprise) and tenant status (trial, active, suspended)
4. **Given** owner wants to export data, **When** they click "Export Report", **Then** system generates CSV/PDF report with all metrics and downloads to owner's device
5. **Given** real-time data updates, **When** new tenant subscribes or existing tenant upgrades, **Then** analytics dashboard updates within 5 minutes reflecting new revenue

---

### User Story 3 - Search and Filter Tenants (Priority: P1)

**As a** platform owner
**I want to** search for specific tenants and filter by various criteria
**So that** I can quickly find tenants needing attention or matching specific conditions

**Why this priority**: Operational efficiency. With hundreds or thousands of tenants, ability to quickly locate specific tenant or identify problem tenants is essential.

**Independent Test**: Can be fully tested by: (1) owner enters search term in tenant search bar, (2) results filter to matching tenants, (3) owner applies filters (plan type, status, location), (4) tenant list updates to show only matching records. Delivers value through rapid tenant location.

**Acceptance Scenarios**:

1. **Given** owner is on tenant list page, **When** they type restaurant name in search bar, **Then** tenant list filters in real-time showing only tenants matching search term
2. **Given** owner wants to filter by plan, **When** they select "Enterprise" from plan type dropdown, **Then** tenant list shows only Enterprise plan subscribers
3. **Given** owner wants to find problem tenants, **When** they select "Suspended" status filter, **Then** list shows only suspended tenants with suspension reason displayed
4. **Given** multiple filters applied, **When** owner clicks "Clear Filters", **Then** all filters reset and full tenant list displays
5. **Given** owner applies filters, **When** they export tenant list, **Then** CSV export includes only filtered tenants, not entire database

---

### User Story 4 - Suspend and Reactivate Tenants (Priority: P0)

**As a** platform owner
**I want to** suspend tenants for non-payment or policy violations and later reactivate them
**So that** I can enforce payment policies while allowing recovery for legitimate customers

**Why this priority**: Revenue protection. Without ability to suspend non-paying tenants, platform loses revenue and has no enforcement mechanism.

**Independent Test**: Can be fully tested by: (1) owner views tenant with payment failure, (2) clicks "Suspend Account", (3) enters suspension reason, (4) confirms suspension, (5) tenant status changes to "suspended" and services are disabled, (6) later owner clicks "Reactivate" and tenant services restore. Delivers value through account lifecycle management.

**Acceptance Scenarios**:

1. **Given** owner viewing tenant details with failed payment, **When** they click "Suspend Account" button, **Then** suspension dialog opens requesting reason (payment failure, policy violation, fraud, other) and optional notes
2. **Given** suspension reason entered, **When** owner confirms suspension, **Then** system immediately: changes tenant status to "suspended", disables all API access for tenant, stops processing orders, sends suspension notification email to restaurant contact
3. **Given** tenant is suspended, **When** restaurant tries to access system, **Then** they see "Account Suspended" message with platform contact information and suspension reason (if appropriate to share)
4. **Given** suspended tenant makes payment, **When** owner clicks "Reactivate Account", **Then** system confirms reactivation, restores full access, changes status to "active", sends reactivation confirmation email
5. **Given** tenant suspended for 90+ days, **When** owner views tenant details, **Then** system displays "Consider Termination" warning and "Permanently Delete" option with confirmation requirements

---

### User Story 5 - Manage Tenant Billing and Subscriptions (Priority: P1)

**As a** platform owner
**I want to** view and manage tenant subscriptions, handle payment failures, and process refunds
**So that** I can maintain billing accuracy and resolve customer payment issues

**Why this priority**: Revenue operations essential but not immediately blocking (can handle manually initially for small tenant base).

**Independent Test**: Can be fully tested by: (1) owner views tenant billing details, (2) sees subscription plan, next renewal date, payment history, (3) processes plan change, (4) issues refund for incorrect charge. Delivers value through billing operations management.

**Acceptance Scenarios**:

1. **Given** owner viewing tenant details, **When** they access Billing tab, **Then** system displays: current plan (Basic/Pro/Enterprise), monthly/annual billing, next renewal date, payment method (last 4 digits), billing history (last 12 months)
2. **Given** payment failure indicated, **When** owner views failure details, **Then** system shows: failure date, failure reason (card declined, insufficient funds, expired card), retry attempts made, next retry scheduled
3. **Given** owner needs to change tenant's plan, **When** they click "Change Plan" and select new plan, **Then** system calculates prorated amount, displays confirmation with new billing amount, applies change immediately upon confirmation
4. **Given** tenant requests refund, **When** owner clicks "Issue Refund" on specific transaction, **Then** refund dialog shows transaction details, owner enters refund amount and reason, system processes refund and updates billing history
5. **Given** tenant on annual plan wants to cancel, **When** owner processes cancellation, **Then** system calculates remaining value, offers partial refund option, schedules account for suspension at end of billing period (not immediate)

---

### User Story 6 - Monitor Tenant Health and Usage (Priority: P1)

**As a** platform owner
**I want to** monitor tenant usage statistics, error rates, and system health
**So that** I can proactively identify and resolve issues before they cause customer churn

**Why this priority**: Operational excellence and churn prevention. Health monitoring enables proactive support but platform can function without it initially.

**Independent Test**: Can be fully tested by: (1) owner views tenant health dashboard, (2) sees usage metrics (API calls, orders processed, error rates), (3) identifies tenant with high error rate, (4) drills into error details, (5) contacts tenant for support. Delivers value through proactive issue detection.

**Acceptance Scenarios**:

1. **Given** owner viewing tenant details, **When** they access Health tab, **Then** system displays: daily order volume (last 30 days), API call count and rate, error rate percentage, last 24-hour uptime, storage usage, active users count
2. **Given** tenant has elevated error rate, **When** owner views error details, **Then** system shows: error type breakdown, most frequent errors, timestamps of recent errors, affected endpoints, suggested resolutions
3. **Given** owner wants to compare tenants, **When** they view health overview across all tenants, **Then** dashboard shows tenants sorted by error rate (highest first), highlighting those exceeding 5% error threshold
4. **Given** tenant approaching storage limit, **When** usage reaches 80% of plan allocation, **Then** system displays warning on tenant details page and in health overview
5. **Given** tenant has been inactive 14+ days, **When** owner views tenant list, **Then** inactive tenants are flagged with "No Recent Activity" badge for potential churn risk follow-up

---

### Edge Cases

- What happens when tenant provisioning fails due to database connection issue?
  - System rolls back all partial changes, logs detailed error, displays user-friendly message to platform owner, allows retry with different configuration

- How does system handle when owner tries to suspend tenant that has active orders in progress?
  - System warns "X active orders in progress. Suspend anyway or wait for completion?" Allows owner to choose immediate suspension (cancels orders) or scheduled suspension after completion

- What happens when owner tries to delete tenant that has historical data?
  - System prevents deletion, requires "Archive" instead. Archived tenants retain data for compliance but cannot access system. Permanent deletion requires explicit confirmation and compliance review period (90 days)

- How does system handle simultaneous admin actions on same tenant from multiple browser sessions?
  - Optimistic locking prevents conflicts. Second action receives error "Tenant was modified by another user. Please refresh and try again."

- What happens when automated onboarding email fails to send?
  - System logs email failure, displays activation code to platform owner with "Email failed - share code manually" warning, queues retry for email delivery

- How does system handle when tenant reaches plan limits (order volume, users, locations)?
  - Tenant health monitoring flags limit approaching (80%) and exceeded (100%). Platform owner receives alert to contact tenant for plan upgrade. System continues functioning but displays upgrade prompts to restaurant owner.

- What happens to tenant data when subscription expires and isn't renewed?
  - System suspends tenant on expiration date. Data retained for 30 days in grace period. After 30 days, tenant moved to "archived" status. After 90 days of archived status, eligible for permanent deletion per retention policy.

---

## Requirements

### Functional Requirements

**Platform Authentication & Access**

- **FR-001**: System MUST authenticate platform owners using separate admin credentials (distinct from tenant authentication)
- **FR-002**: System MUST restrict admin dashboard access to verified platform owner accounts only
- **FR-003**: System MUST provide role-based access within platform admin (super admin, billing admin, support admin)
- **FR-004**: System MUST log all admin actions (tenant creation, suspension, billing changes) with timestamp and admin user ID for audit trail

**Tenant CRUD Operations**

- **FR-005**: System MUST provide "Create Tenant" functionality accessible via prominent button on tenant list page
- **FR-006**: System MUST require minimum tenant information: business name, contact email, contact phone, plan selection
- **FR-007**: System MUST validate tenant information before provisioning (email format, phone format, unique business name within system)
- **FR-008**: System MUST display list of all tenants with: tenant name, plan type, status, signup date, last activity date
- **FR-009**: System MUST allow platform owner to view detailed tenant information including: business details, billing history, usage statistics, health metrics
- **FR-010**: System MUST allow platform owner to update tenant information (business name, contact details, plan) with change logging
- **FR-011**: System MUST provide tenant suspension capability with reason tracking (payment failure, policy violation, fraud, other)
- **FR-012**: System MUST provide tenant reactivation capability restoring full access and services
- **FR-013**: System MUST prevent immediate permanent deletion, requiring "Archive" status first with 90-day retention before delete eligibility

**Automated Provisioning**

- **FR-014**: System MUST create isolated database schema for each new tenant with unique schema name derived from tenant identifier
- **FR-015**: System MUST apply row-level security (RLS) policies to tenant schema ensuring complete data isolation
- **FR-016**: System MUST generate unique activation code (8-12 alphanumeric characters) with 48-hour expiry for restaurant onboarding
- **FR-017**: System MUST set up default menu structure template based on business type (restaurant, cafe, food truck)
- **FR-018**: System MUST configure initial tenant settings (timezone, currency, business hours template)
- **FR-019**: System MUST execute provisioning as atomic transaction (all-or-nothing, rollback on any failure)
- **FR-020**: System MUST complete tenant provisioning in under 60 seconds for 95% of requests
- **FR-021**: System MUST send onboarding email to restaurant contact containing: activation code, login link, getting started guide, support contact

**Self-Service Onboarding Wizard**

- **FR-022**: System MUST provide multi-step wizard interface for tenant creation (Business Info → Plan Selection → Review & Create)
- **FR-023**: System MUST validate each wizard step before allowing progression to next step
- **FR-024**: System MUST display plan comparison showing features and pricing for Basic, Pro, Enterprise tiers
- **FR-025**: System MUST show real-time provisioning progress indicator during tenant creation
- **FR-026**: System MUST display activation code prominently after successful provisioning with copy-to-clipboard functionality
- **FR-027**: System MUST handle wizard abandonment by saving partial progress for 24 hours with "Resume Onboarding" option

**Platform-Wide Analytics**

- **FR-028**: System MUST calculate and display Monthly Recurring Revenue (MRR) as sum of all active subscriptions normalized to monthly
- **FR-029**: System MUST calculate and display Annual Recurring Revenue (ARR) as MRR × 12
- **FR-030**: System MUST track and display total active tenant count (excluding trials, suspended, archived)
- **FR-031**: System MUST calculate and display churn rate as (canceled tenants / total tenants at period start) × 100
- **FR-032**: System MUST track and display new tenant signups by month with growth rate percentage
- **FR-033**: System MUST calculate and display average revenue per tenant (ARPT) as MRR / active tenant count
- **FR-034**: System MUST provide revenue breakdown by plan type (Basic, Pro, Enterprise) showing count and total revenue per tier
- **FR-035**: System MUST display MRR trend chart showing last 12 months with month-over-month growth indicators
- **FR-036**: System MUST allow analytics date range selection (last 7 days, 30 days, 90 days, 12 months, custom range)
- **FR-037**: System MUST provide analytics export functionality generating CSV or PDF reports with all metrics

**Tenant Search and Filtering**

- **FR-038**: System MUST provide real-time search filtering tenant list as owner types (search by name, email, phone)
- **FR-039**: System MUST allow filtering tenants by plan type (Basic, Pro, Enterprise, Trial)
- **FR-040**: System MUST allow filtering tenants by status (active, trial, suspended, archived)
- **FR-041**: System MUST allow filtering tenants by signup date range
- **FR-042**: System MUST allow filtering tenants by location/region for geographic analysis
- **FR-043**: System MUST support combining multiple filters simultaneously with AND logic
- **FR-044**: System MUST display active filter pills with individual removal option and "Clear All Filters" button
- **FR-045**: System MUST maintain filter state when navigating between tenant detail pages and returning to list

**Billing Management**

- **FR-046**: System MUST display tenant billing details including: current plan, billing cycle (monthly/annual), next renewal date, payment method (masked), billing history
- **FR-047**: System MUST track and display payment failures with: failure date, reason, retry attempts, next retry schedule
- **FR-048**: System MUST allow platform owner to manually retry failed payment with confirmation
- **FR-049**: System MUST provide plan change functionality with prorated billing calculation shown before confirmation
- **FR-050**: System MUST allow platform owner to issue full or partial refunds with reason tracking
- **FR-051**: System MUST handle subscription cancellations by scheduling suspension at end of current billing period (not immediate)
- **FR-052**: System MUST display billing history showing last 12 months of transactions with: date, amount, status (success/failed/refunded), invoice link

**Tenant Health Monitoring**

- **FR-053**: System MUST track and display tenant usage metrics: daily order volume, API call count, active user count
- **FR-054**: System MUST calculate and display tenant error rate as (failed requests / total requests) × 100
- **FR-055**: System MUST track and display system uptime percentage for each tenant (last 24 hours, 7 days, 30 days)
- **FR-056**: System MUST display storage usage percentage with visual indicator (green <70%, yellow 70-90%, red >90%)
- **FR-057**: System MUST show most frequent errors for tenant with error type, count, and last occurrence timestamp
- **FR-058**: System MUST flag tenants with error rate >5% as "Health Issue" requiring attention
- **FR-059**: System MUST flag tenants with no activity for 14+ days as "Inactive - Churn Risk"
- **FR-060**: System MUST provide health overview across all tenants sorted by issue severity

**Notifications and Alerts**

- **FR-061**: System MUST notify platform owner when new tenant signs up (email + dashboard notification)
- **FR-062**: System MUST alert platform owner when tenant payment fails and retries exhaust (email notification)
- **FR-063**: System MUST notify platform owner when tenant reaches 80% of plan limits (order volume, users, storage)
- **FR-064**: System MUST alert platform owner when tenant error rate exceeds 5% threshold
- **FR-065**: System MUST display notification center in admin dashboard showing recent alerts with unread count

---

### Key Entities

- **Platform Owner**: Administrator of entire SaaS platform with credentials separate from tenant users. Has permissions to create tenants, view analytics, manage billing, suspend accounts. Relationships: creates and manages multiple tenants, receives platform-wide alerts.

- **Tenant**: Restaurant business entity in multi-tenant system. Contains tenant_id (unique), business_name, contact_email, contact_phone, plan_type (Basic/Pro/Enterprise), status (active/trial/suspended/archived), signup_date, last_activity, schema_name (isolated database), activation_code. Relationships: belongs to platform, has one billing subscription, has usage metrics, has health status.

- **Provisioning Request**: Record of tenant creation process. Contains request_id, tenant_id, status (pending/in_progress/completed/failed), created_at, completed_at, activation_code, onboarding_email_status. Tracks automated provisioning workflow.

- **Platform Analytics**: Aggregated metrics across all tenants. Contains MRR (Monthly Recurring Revenue), ARR (Annual Recurring Revenue), total_active_tenants, churn_rate, new_tenants_count, ARPT (average revenue per tenant), calculated_at (timestamp). Updated real-time or near-real-time.

- **Billing Subscription**: Tenant's payment and plan details. Contains subscription_id, tenant_id, plan_type, billing_cycle (monthly/annual), amount, next_renewal_date, payment_method (tokenized), status (active/past_due/canceled). Relationships: belongs to tenant, has payment history.

- **Payment Transaction**: Individual billing event. Contains transaction_id, tenant_id, amount, transaction_type (charge/refund), status (success/failed), failure_reason, processed_at, invoice_url. Immutable audit trail.

- **Tenant Health Metrics**: Usage and performance data per tenant. Contains tenant_id, date, order_count, api_call_count, error_count, error_rate, uptime_percentage, storage_used_gb, active_users. Updated daily with real-time error tracking.

- **Admin Action Log**: Audit trail of platform owner actions. Contains log_id, admin_user_id, action_type (create_tenant/suspend/reactivate/billing_change), tenant_id, details (JSON), timestamp. Immutable for compliance.

- **Notification Alert**: Platform-level alert for owner attention. Contains alert_id, alert_type (payment_failed/high_errors/new_signup), tenant_id, severity (info/warning/critical), message, created_at, read_status. Displayed in notification center.

---

## Success Criteria

### Measurable Outcomes

- Platform owner can provision new tenant in under 3 minutes from start to activation code delivery
- Tenant provisioning success rate of 99.5% (failures due to system errors, not user input errors)
- Platform analytics dashboard loads within 2 seconds showing real-time metrics
- Platform owner can locate specific tenant via search in under 10 seconds
- Suspended tenant loses all system access within 5 seconds of suspension confirmation
- Platform owner receives payment failure alert within 1 hour of failure occurrence
- Tenant health metrics update within 5 minutes of data collection
- Platform supports managing 1000+ tenants without performance degradation
- Billing operations (plan changes, refunds) complete within 30 seconds
- Admin action audit logs are 100% complete with no missing entries

### Qualitative Measures

- Platform owner reports confidence in tenant data accuracy and isolation
- Onboarding time per new customer reduced by 90% compared to manual provisioning
- Payment issue resolution time reduced through centralized billing management
- Churn prevention improved through proactive health monitoring and early intervention
- Platform owner can make strategic decisions based on analytics insights
- Support team efficiency improved by quick tenant lookup and health diagnostics

---

## Dependencies and Assumptions

### Dependencies

- Spec 001 (Restaurant Management) provides base tenant data model that this spec extends with platform-level operations
- Spec 002 (Menu Management) provides default menu templates used during tenant provisioning
- Platform must have multi-tenant database architecture with schema isolation capability
- Payment processing system (Stripe or similar) must provide webhooks for payment event notifications
- Email delivery service must be available for onboarding and notification emails

### Assumptions

- Platform owner has technical proficiency to manage SaaS operations (not requiring extensive training)
- Tenant count will grow gradually allowing iterative scaling (not 1000 tenants overnight)
- Database supports creating schemas programmatically with Row-Level Security (RLS) policies
- Payment provider supports plan changes, prorated billing, and refund operations via API
- Most tenants successfully activate within 48-hour activation code expiry window
- Platform owner monitors dashboard regularly (daily) for alerts and health issues
- Tenant suspensions are rare operational events, not daily occurrences
- Analytics calculations can tolerate 5-minute data lag (not requiring real-time to the second)

### Out of Scope

- Multi-admin collaboration features (multiple platform owners working simultaneously) - single admin in MVP
- Automated billing dunning workflows (automated email sequences for payment failures) - manual follow-up in MVP
- Tenant self-service plan upgrades from restaurant dashboard - platform owner manages billing in MVP
- Advanced analytics (cohort analysis, customer lifetime value, forecasting) - basic metrics only in MVP
- White-label customization per tenant (custom branding, domains) - deferred to future release
- Tenant data migration tools (importing data from other systems) - manual migration only in MVP
- Automated tenant tier recommendations based on usage - manual plan changes only in MVP

---

**Status**: ✅ Ready for validation and `/speckit.plan` command
