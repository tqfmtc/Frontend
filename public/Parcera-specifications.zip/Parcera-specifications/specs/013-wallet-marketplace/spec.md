# Feature Specification: Enhanced Mobile Wallet & Marketplace

**Feature Branch**: `013-wallet-marketplace`
**Created**: 2025-10-29
**Status**: Draft
**Input**: User description: "Enhanced Mobile Wallet & Marketplace - Mobile app serves as unified wallet across all partner restaurants with marketplace for discovery (search by cuisine, location, rating), PWA home screen shortcuts creating restaurant-specific launch icons, comprehensive preference management (allergies, dietary restrictions, favorite modifications stored once and applied everywhere), cross-restaurant order history with one-tap reorder, personalized restaurant recommendations based on order history and preferences. One app, many restaurants - network effects drive customer value."

## User Scenarios & Testing

### User Story 1 - Restaurant Marketplace Discovery (Priority: P1)

Customer opens app and browses marketplace to discover partner restaurants by searching cuisine types, filtering by location/distance, viewing ratings and reviews, and saving favorites for quick access.

**Why this priority**: Primary discovery mechanism for new customers. Without marketplace, customers can't find restaurants to order from. Core value proposition of "one app, many restaurants."

**Independent Test**: Install app, browse marketplace without logging in, search for "pizza", filter by distance, view restaurant details, create account to save favorites.

**Acceptance Scenarios**:
1. **Given** customer opens app for first time, **When** they view marketplace home, **Then** they see list of nearby restaurants with photos, ratings, cuisine tags, and distance
2. **Given** customer searches "sushi", **When** search completes, **Then** results show all sushi restaurants sorted by distance with filter options (price, rating, delivery availability)
3. **Given** customer views restaurant details, **When** they tap "Add to Favorites", **Then** restaurant is saved and appears in "My Restaurants" section
4. **Given** customer has location permissions disabled, **When** they browse marketplace, **Then** app prompts for location access with explanation and fallback to manual ZIP code entry

---

### User Story 2 - PWA Home Screen Shortcuts (Priority: P1)

Customer adds restaurant-specific shortcut to phone home screen that launches app directly to that restaurant's menu, creating single-tap ordering experience.

**Why this priority**: Reduces friction for repeat customers. Single tap from home screen to familiar restaurant menu drives frequency. Differentiated from traditional food delivery apps.

**Independent Test**: Browse marketplace, select restaurant, tap "Add to Home Screen", verify shortcut created, tap shortcut from home screen, confirm app launches directly to restaurant menu.

**Acceptance Scenarios**:
1. **Given** customer views restaurant details in app, **When** they tap "Add to Home Screen", **Then** system displays PWA install prompt with restaurant name and logo
2. **Given** customer approves home screen shortcut, **When** shortcut is created, **Then** icon shows restaurant branding (logo, name) and tapping launches app to restaurant-specific landing page
3. **Given** customer has multiple restaurant shortcuts, **When** they tap different shortcuts, **Then** each launches to correct restaurant menu with customer preferences pre-loaded
4. **Given** customer on iOS Safari, **When** they tap "Add to Home Screen", **Then** app provides guided instructions for Safari PWA installation with visual steps

---

### User Story 3 - Comprehensive Preference Management (Priority: P1)

Customer sets allergies, dietary restrictions, and favorite modifications once in wallet settings, and preferences automatically apply across all restaurant orders with visual indicators and smart filtering.

**Why this priority**: Core safety and convenience feature. Prevents allergy incidents, reduces order friction, demonstrates cross-restaurant value. Stored once, used everywhere.

**Independent Test**: Go to wallet settings, add peanut allergy and vegan dietary restriction, browse multiple restaurant menus, verify allergen warnings appear and non-vegan items are flagged.

**Acceptance Scenarios**:
1. **Given** customer adds "peanut allergy" in wallet preferences, **When** they browse any restaurant menu, **Then** items containing peanuts display "Contains allergen" warning badge in red
2. **Given** customer adds "vegan" dietary restriction, **When** they view menu items, **Then** non-vegan items show dimmed with "Not vegan" label and vegan filter toggle appears
3. **Given** customer adds favorite modification "extra sauce", **When** they add eligible item to cart, **Then** modification is pre-selected with confirmation prompt "Add extra sauce as usual?"
4. **Given** customer has conflicting preferences (e.g., "dairy allergy" + "extra cheese" favorite), **When** conflict detected, **Then** app displays warning "This favorite contains dairy - modify?" with suggested alternatives

---

### User Story 4 - Cross-Restaurant Order History & Reorder (Priority: P1)

Customer views unified order history showing all orders across every partner restaurant with one-tap reorder functionality that adapts to restaurant availability.

**Why this priority**: Drives repeat orders and customer retention. Unified history demonstrates platform value vs individual restaurant apps. Reorder removes all friction.

**Independent Test**: Place orders at 3 different restaurants, view order history showing all 3, tap "Reorder" on past order, verify cart populated with adjustments for current availability.

**Acceptance Scenarios**:
1. **Given** customer views order history, **When** history loads, **Then** all orders from all restaurants appear in chronological order with restaurant name, date, items, total, and "Reorder" button
2. **Given** customer taps "Reorder" on past order, **When** all items still available, **Then** cart populates with exact items, modifications, and quantities with confirmation "Reordering [Restaurant Name] from [Date]"
3. **Given** customer reorders but some items discontinued, **When** cart populates, **Then** unavailable items flagged with "No longer available - Remove or Replace?" prompt showing similar alternatives
4. **Given** customer views order detail, **When** they expand past order, **Then** full receipt displayed with itemized list, modifications, totals, payment method used, and delivery/pickup details

---

### User Story 5 - Personalized Restaurant Recommendations (Priority: P2)

Customer receives personalized restaurant suggestions based on order history, saved preferences, and behavioral patterns to drive discovery of new partner restaurants.

**Why this priority**: Drives network effects and platform value. Helps customers discover new restaurants aligned with preferences. Secondary to core ordering features but key for engagement.

**Independent Test**: Place 5+ orders at Italian restaurants with vegetarian preferences, view recommendations section, verify Italian and vegetarian restaurant suggestions appear.

**Acceptance Scenarios**:
1. **Given** customer has order history, **When** they open app home, **Then** "Recommended for You" section displays 3-5 restaurants matching cuisine preferences with explanation "Based on your love of [cuisine]"
2. **Given** customer frequently orders vegetarian, **When** recommendations load, **Then** vegetarian-friendly restaurants prioritized with "Great vegetarian options" badge
3. **Given** customer orders from new cuisine type, **When** they complete order, **Then** recommendations refresh within 24 hours to include similar restaurants
4. **Given** customer has no order history (new user), **When** recommendations load, **Then** popular local restaurants displayed with "Popular near you" instead of personalized messaging

---

### Edge Cases

- What if customer has 10+ allergies and dietary restrictions? Show scrollable list in preferences with ability to prioritize critical allergies. Limit visual indicators to top 3 most severe to avoid cluttered UI.
- How does reorder handle different restaurant hours or delivery zones? Check restaurant availability before populating cart. If closed or out of delivery range, show "Not available now - Schedule for later?" prompt.
- What if PWA shortcut points to restaurant that closed permanently? App detects closed restaurant on launch and displays "This restaurant is no longer available" with marketplace redirect and option to remove shortcut.
- How to handle preference conflicts between customer settings and restaurant capabilities? Display clear warnings: "This restaurant doesn't support [preference] - Would you like to browse anyway?" with option to filter marketplace by preference compatibility.
- What if customer changes allergies after placing order? Display alert: "Allergy preferences updated - Review in-progress orders for safety" with list of orders containing new allergen.
- How does marketplace handle restaurants with no ratings yet? Display "New to Parcera" badge instead of star rating with option to "Be the first to review."

## Requirements

### Functional Requirements

#### Restaurant Marketplace Discovery
- **FR-001**: App MUST display marketplace home screen showing all partner restaurants with photo, name, cuisine tags, average rating (1-5 stars), and distance from customer location
- **FR-002**: App MUST provide search functionality accepting cuisine type, restaurant name, or food item keywords with real-time results as customer types
- **FR-003**: App MUST offer filters for price range ($ to $$$$), rating (1-5 stars), distance (1, 3, 5, 10+ miles), dietary options (vegan, vegetarian, gluten-free), and delivery availability
- **FR-004**: Customers MUST be able to save favorite restaurants with "Add to Favorites" button that persists across devices
- **FR-005**: App MUST display restaurant detail view including full menu preview, hours of operation, delivery/pickup options, photos, reviews, and contact information
- **FR-006**: Marketplace MUST support location-based sorting showing nearest restaurants first with fallback to manual ZIP code entry if location services disabled

#### PWA Home Screen Shortcuts
- **FR-007**: App MUST generate PWA manifest with restaurant-specific name, icon, and start URL for each restaurant shortcut
- **FR-008**: App MUST provide "Add to Home Screen" button in restaurant detail view that triggers native browser PWA install prompt
- **FR-009**: PWA shortcuts MUST launch app directly to restaurant-specific landing page with customer wallet preferences pre-loaded
- **FR-010**: System MUST serve unique manifest files per restaurant using dynamic routing (e.g., /restaurants/[restaurant-id]/manifest.json)
- **FR-011**: App MUST provide fallback instructions for iOS Safari PWA installation with visual guide showing "Share > Add to Home Screen" steps
- **FR-012**: PWA shortcuts MUST include restaurant logo as icon (512x512 minimum) and branded theme color matching restaurant identity

#### Preference Management
- **FR-013**: Wallet settings MUST provide allergy management with ability to add/remove allergens from comprehensive list (peanuts, tree nuts, dairy, eggs, soy, wheat/gluten, fish, shellfish, sesame)
- **FR-014**: Wallet settings MUST support dietary restrictions (vegan, vegetarian, pescatarian, halal, kosher, gluten-free, dairy-free, low-carb)
- **FR-015**: Wallet settings MUST allow customers to save favorite modifications (e.g., "no onions", "extra sauce", "well done") with optional notes
- **FR-016**: App MUST display allergen warnings on menu items containing customer's stored allergens with red "Contains [allergen]" badge
- **FR-017**: App MUST apply dietary restriction filters to menu items with visual dimming of non-compliant items and toggle to "Show All Items"
- **FR-018**: App MUST pre-select favorite modifications when customer adds eligible items to cart with confirmation prompt "Apply [modification] as usual?"
- **FR-019**: System MUST sync preferences across all devices within 5 seconds of update using wallet_id
- **FR-020**: App MUST detect conflicting preferences (e.g., dairy allergy + extra cheese favorite) and display warning before order submission

#### Cross-Restaurant Order History
- **FR-021**: App MUST display unified order history showing all orders from all restaurants in reverse chronological order
- **FR-022**: Order history entries MUST include restaurant name, order date/time, items list, total amount, order status, and "Reorder" button
- **FR-023**: Customers MUST be able to tap "Reorder" to populate cart with all items and modifications from past order
- **FR-024**: System MUST validate item availability before reordering and flag discontinued items with "No longer available" warning and suggested replacements
- **FR-025**: App MUST allow filtering order history by restaurant, date range, or order status (completed, cancelled)
- **FR-026**: Order detail view MUST display full itemized receipt including modifications, taxes, tips, payment method used, and delivery/pickup address
- **FR-027**: System MUST retain order history for minimum 2 years for reorder functionality and customer reference

#### Personalized Recommendations
- **FR-028**: App MUST display "Recommended for You" section on marketplace home with 3-5 restaurant suggestions
- **FR-029**: Recommendation engine MUST analyze order history for cuisine preferences, dietary patterns, and frequency to generate suggestions
- **FR-030**: Recommendations MUST include explanation text (e.g., "Based on your love of Italian food" or "Great vegetarian options")
- **FR-031**: System MUST refresh recommendations within 24 hours after customer places order from new cuisine type or restaurant
- **FR-032**: For new users without order history, app MUST display "Popular near you" recommendations based on location and aggregate platform ratings
- **FR-033**: Recommendations MUST prioritize restaurants matching customer dietary restrictions and avoid restaurants with known allergen conflicts

### Key Entities

- **RestaurantProfile**: Partner restaurant with restaurant_id, name, brand_logo, cuisine_tags, average_rating, total_reviews, location (lat/long), delivery_radius, pickup_available, hours_of_operation, photos, description
- **CustomerFavorites**: Restaurant bookmark with favorite_id, wallet_id, restaurant_id, added_date, notification_preferences (new menu items, promotions)
- **PreferenceProfile**: Customer preferences with profile_id, wallet_id, allergies (array), dietary_restrictions (array), favorite_modifications (array with item_category mapping), last_updated
- **OrderHistoryEntry**: Unified order record with order_id, wallet_id, restaurant_id, order_date, items (array with modifications), total_amount, payment_method_used, delivery_address, order_status, receipt_url
- **PWAManifest**: Restaurant-specific manifest with manifest_id, restaurant_id, name, short_name, description, start_url, icons (array), theme_color, background_color, display_mode
- **RecommendationScore**: Personalized restaurant ranking with score_id, wallet_id, restaurant_id, score (0-100), reasoning (cuisine_match, dietary_match, popularity), last_calculated

## Success Criteria

- **SC-001**: 60% of active customers use marketplace to discover at least one new restaurant within first 30 days
- **SC-002**: 30% of customers create at least one PWA home screen shortcut for frequently ordered restaurant
- **SC-003**: Customers with stored preferences (allergies/dietary restrictions) complete orders 40% faster than those without
- **SC-004**: Allergy warning system prevents 100% of orders containing customer allergens without explicit override confirmation
- **SC-005**: One-tap reorder drives 25% of repeat orders within 90 days of feature launch
- **SC-006**: Cross-restaurant order history shows average of 3+ different restaurants per active customer (demonstrating platform value)
- **SC-007**: 70% of recommended restaurants result in customer viewing menu (click-through rate)
- **SC-008**: 20% of recommendations lead to completed order within 7 days (conversion rate)
- **SC-009**: 85% customer satisfaction rating for preference auto-application accuracy in post-order surveys
- **SC-010**: PWA shortcuts reduce time-to-order by 50% compared to app launch and navigation (measured from home screen tap to cart)

## Assumptions

1. **Restaurant Data Availability**: All partner restaurants provide complete profile data including cuisine tags, photos, hours, and menu item allergen information. Assumption: Restaurants complete onboarding checklist before marketplace visibility.
2. **PWA Browser Support**: Target browsers (Chrome/Edge on Android, Safari on iOS) support PWA manifest and home screen installation. Fallback: Manual instructions for browsers without native PWA support.
3. **Allergen Data Accuracy**: Restaurants maintain accurate allergen information in menu item metadata. Assumption: Restaurant admin dashboard (spec 009) requires allergen declaration for all items.
4. **Cross-Device Sync**: Customers use same wallet_id across devices enabling preference and history sync. Assumption: Passwordless authentication (spec 008) ensures consistent identity.
5. **Recommendation Algorithm**: Order history of 5+ orders provides sufficient data for personalized recommendations. Assumption: New users see location-based popular restaurants until enough data collected.
6. **Reorder Item Availability**: Menu items remain relatively stable with <20% discontinuation rate per year. Assumption: System handles unavailable items gracefully with suggestions.
7. **Location Permissions**: Majority of customers grant location access for distance-based sorting. Fallback: Manual ZIP code entry for privacy-conscious users.
8. **Storage Limits**: Customer preference data (allergies, favorites) fits within 50KB per wallet. Assumption: Reasonable limits on preference count (10 allergies max, 20 favorite modifications max).
9. **Network Effects Timeline**: Platform value increases with 10+ partner restaurants in customer's delivery area. Assumption: Marketplace launches in markets with critical mass of restaurants.
10. **Rating System Integrity**: Restaurant ratings are based on verified orders with fraud prevention. Assumption: Only customers who completed orders can leave reviews (prevents spam).

## Constitution Alignment

### Principle III: Privacy-First Customer Data
- Customer preference data (allergies, dietary restrictions) stored in wallet, accessible only to customer
- Restaurants see only applied preferences during order (e.g., "no peanuts" modifier) without full allergy profile
- Order history includes wallet_id, not customer PII (name, phone, email)

### Principle IV: Omnichannel by Default
- Preferences apply consistently across mobile app, kiosk (spec 004), and IVR (spec 003) ordering
- Order history unified regardless of ordering channel (phone, kiosk, app all appear together)
- PWA shortcuts work seamlessly with voice ordering and kiosk biometric authentication

### Principle V: Progressive Enhancement & MVP Discipline
- **P1**: Marketplace discovery, PWA shortcuts, preference management, order history, reorder (FR-001 to FR-027)
- **P2**: Personalized recommendations (FR-028 to FR-033)
- **Future**: Social features (share favorites with friends), group ordering, scheduled recurring orders

### Principle VI: Network Effects & Platform Thinking
- "One app, many restaurants" model drives customer acquisition via cross-restaurant discovery
- More restaurants → more customer value → more customers → more restaurants (flywheel)
- Loyalty points earned at one restaurant usable at all partners (spec 011 integration)
- Preferences stored once, applied everywhere (reduces friction exponentially with restaurant count)

## Dependencies

### Internal Dependencies
- **Mobile App (spec 005)**: Provides React Native UI for marketplace, preferences, history
- **Customer Wallet (spec 008)**: Stores preferences, favorites, order history with wallet_id
- **Restaurant Management (spec 001)**: Sources restaurant profile data (name, logo, hours, location)
- **Menu Management (spec 002)**: Provides menu items with allergen metadata for filtering
- **Loyalty & Rewards (spec 011)**: Integrates points earned across restaurants into recommendation algorithm
- **Order Fulfillment (spec 006)**: Populates order history with completed orders from all channels

### External Dependencies
- **PWA Manifest Standard**: Relies on W3C Web App Manifest specification for home screen shortcuts
- **Geolocation API**: Browser/device location services for distance-based marketplace sorting
- **Restaurant Allergen Data**: Third-party allergen databases or restaurant-provided metadata
- **Recommendation Engine**: Machine learning library (e.g., collaborative filtering) for personalized suggestions

## Future Considerations

- **Social Sharing**: Share favorite restaurants or orders with friends via link, earn referral bonus
- **Group Ordering**: Multiple customers add items to shared cart for single delivery (office lunch)
- **Scheduled Recurring Orders**: Set up weekly "Taco Tuesday" orders that auto-submit with one-tap approval
- **Restaurant Collections**: Curated lists like "Best Burgers" or "Healthy Options" with editorial content
- **Deals & Promotions**: Marketplace filter for restaurants offering active discounts or loyalty bonuses
- **Advanced Filters**: Delivery time estimate, minimum order amount, accepts loyalty points, family-friendly
- **Wallet Integration with Health Apps**: Import dietary restrictions from Apple Health or Google Fit
- **Voice-Activated Reorder**: "Hey Parcera, reorder my last pizza" triggers reorder via voice command
- **Cross-Restaurant Bundles**: Order appetizer from Restaurant A, entree from B, dessert from C in single transaction

---

**Validation Checklist**: See [checklists/requirements.md](checklists/requirements.md)
