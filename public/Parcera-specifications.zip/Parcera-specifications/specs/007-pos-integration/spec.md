# Feature Specification: Third-Party POS Integration Gateway

**Feature Branch**: `007-pos-integration`
**Created**: 2025-10-29
**Status**: Draft
**Constitution Alignment**: Principles IV (Omnichannel), VII (Integration-Friendly)

---

## Overview

API adapter layer providing unified interface to multiple third-party POS systems (Toast, Square, Clover). Handles order submission, status polling, menu synchronization, authentication management, error handling, and POS-specific payload transformation. Abstracts POS vendor differences to provide consistent integration contract for order fulfillment engine and menu management systems.

---

## User Scenarios & Testing

### User Story 1 - Order Submission to Toast POS (Priority: P0)

**As a** fulfillment engine
**I want** to submit orders to Toast POS via unified API
**So that** orders are created in the restaurant's Toast system regardless of originating channel

**Why this priority**: Toast is major POS vendor. Core integration capability required for MVP restaurant onboarding.

**Independent Test**: Can be fully tested by submitting order payload to POS gateway with restaurant configured for Toast, verifying Toast-specific API call is made with correct authentication and payload format, and confirming Toast order ID is returned. Delivers end-to-end Toast integration.

**Acceptance Scenarios**:

1. **Given** Restaurant configured with Toast POS credentials, **When** Fulfillment engine submits order via unified API, **Then** Gateway transforms payload to Toast format and submits to Toast API within 500ms
2. **Given** Toast API returns success with order ID, **When** Gateway receives response, **Then** Gateway returns standardized response with POS order ID to fulfillment engine
3. **Given** Toast API returns authentication error, **When** Gateway detects 401 response, **Then** Gateway attempts token refresh and retries request
4. **Given** Order includes special instructions, **When** Payload is transformed, **Then** Toast-specific notes field is populated correctly

---

### User Story 2 - Multi-POS Support (Square, Clover) (Priority: P0)

**As a** platform administrator
**I want** restaurants using Square or Clover to integrate seamlessly
**So that** Parcera supports major POS vendors without vendor lock-in

**Why this priority**: Multi-POS support is constitutional requirement (Principle VII). MVP must support Toast, Square, and Clover.

**Independent Test**: Can be fully tested by configuring three test restaurants with Toast, Square, and Clover respectively, submitting identical orders to each, and verifying all three receive orders in their native format. Delivers POS vendor flexibility.

**Acceptance Scenarios**:

1. **Given** Restaurant configured with Square POS, **When** Order submitted, **Then** Gateway uses Square adapter, authenticates via Square OAuth, and submits order using Square order format
2. **Given** Restaurant configured with Clover POS, **When** Order submitted, **Then** Gateway uses Clover adapter, authenticates via Clover API token, and submits order using Clover JSON format
3. **Given** Three restaurants with different POS systems, **When** Orders submitted simultaneously, **Then** Each order routed to correct POS adapter without cross-contamination
4. **Given** New POS vendor needs to be added, **When** Adapter is implemented, **Then** Existing POS integrations continue to function without modification (extensibility)

---

### User Story 3 - Order Status Polling (Priority: P0)

**As a** fulfillment engine
**I want** to poll POS systems for order status updates
**So that** customers receive accurate order status notifications

**Why this priority**: Status tracking is core customer experience requirement. Without status updates, customers don't know when orders are ready.

**Independent Test**: Can be fully tested by creating order in POS, updating status in POS UI (confirmed → preparing → ready), polling via gateway API, and verifying status changes are detected and returned in standardized format. Delivers status synchronization.

**Acceptance Scenarios**:

1. **Given** Order exists in Toast POS, **When** Gateway polls for status every 30 seconds, **Then** Toast API is called with order ID and current status returned
2. **Given** Restaurant staff marks order as "ready" in Square POS, **When** Gateway polls next, **Then** Status change is detected and returned to fulfillment engine in standardized format (map Square's "ready" to Parcera's "ready")
3. **Given** POS returns unfamiliar status code, **When** Gateway receives unknown status, **Then** Gateway logs warning and maps to closest standard status based on POS documentation
4. **Given** POS API is temporarily unavailable, **When** Poll fails with network error, **Then** Gateway returns error to fulfillment engine without crashing and allows retry

---

### User Story 4 - Menu Synchronization from POS (Priority: P1)

**As a** menu management system
**I want** to import menu data from restaurant's existing POS
**So that** restaurants can onboard quickly without manual menu entry

**Why this priority**: Accelerates restaurant onboarding. Complements OCR menu extraction (feature 002). Not blocking for MVP if OCR is primary method.

**Independent Test**: Can be fully tested by configuring restaurant with menu in Toast POS, triggering menu sync via gateway API, and verifying menu items, categories, modifiers, and prices are imported correctly. Delivers automated menu migration.

**Acceptance Scenarios**:

1. **Given** Restaurant has 50 menu items in Toast POS, **When** Menu sync is triggered, **Then** Gateway fetches menu via Toast API, transforms to Parcera format, and returns menu data
2. **Given** Menu includes nested modifiers (size → toppings), **When** Data is transformed, **Then** Modifier hierarchy is preserved in Parcera format
3. **Given** POS menu includes out-of-stock items, **When** Sync occurs, **Then** Items are imported with availability flag set correctly
4. **Given** Menu has changed since last sync, **When** Incremental sync is requested, **Then** Only changed items are fetched (if POS supports delta queries)

---

### User Story 5 - Authentication and Credential Management (Priority: P0)

**As a** restaurant administrator
**I want** POS credentials securely managed and auto-refreshed
**So that** integration remains active without manual intervention

**Why this priority**: OAuth tokens expire. Auto-refresh prevents integration downtime and reduces support burden.

**Independent Test**: Can be fully tested by configuring Toast OAuth with short-lived token, waiting for expiration, submitting order, and verifying gateway auto-refreshes token before submission. Delivers authentication resilience.

**Acceptance Scenarios**:

1. **Given** Toast restaurant configured with OAuth refresh token, **When** Access token expires, **Then** Gateway detects 401 error, uses refresh token to obtain new access token, and retries original request
2. **Given** Square restaurant uses long-lived API token, **When** Token is stored, **Then** Gateway encrypts token at rest and uses securely for API calls
3. **Given** Clover OAuth refresh fails (refresh token expired), **When** Gateway cannot refresh, **Then** Restaurant is marked as "authentication failed" and admin alerted to re-authorize
4. **Given** Multiple requests occur during token refresh, **When** Refresh is in progress, **Then** Subsequent requests wait for refresh to complete (no duplicate refresh attempts)

---

### User Story 6 - Error Handling and Rate Limiting (Priority: P1)

**As a** platform operator
**I want** gateway to handle POS API errors and rate limits gracefully
**So that** temporary POS issues don't cause order failures

**Why this priority**: POS APIs have rate limits and occasional downtime. Graceful handling improves reliability and reduces manual intervention.

**Independent Test**: Can be fully tested by simulating POS rate limit (429 response), network timeout, and server error (500), verifying gateway returns appropriate error codes to fulfillment engine, and confirming retry logic respects backoff timing. Delivers error resilience.

**Acceptance Scenarios**:

1. **Given** Toast API returns 429 rate limit error, **When** Gateway receives response, **Then** Gateway returns "rate_limited" error to fulfillment engine with retry-after timestamp from Toast headers
2. **Given** Square API call times out after 10 seconds, **When** Timeout occurs, **Then** Gateway returns "timeout" error and allows fulfillment engine to decide retry strategy
3. **Given** Clover returns 500 server error, **When** Error is received, **Then** Gateway logs error with full context (request/response) and returns "pos_error" to fulfillment engine
4. **Given** POS-specific error (e.g., "item not found"), **When** Error is detected, **Then** Gateway translates to standard error code and includes POS-specific message for debugging

---

## Functional Requirements

### FR-P1: Unified Order Submission API (P0)
- **FR-P1.1**: Accept order submission requests in standardized Parcera format (restaurant_id, items, modifiers, order_type, customer_info, special_instructions)
- **FR-P1.2**: Route order to appropriate POS adapter based on restaurant's configured POS type
- **FR-P1.3**: Transform Parcera order format to POS-specific format (Toast, Square, Clover)
- **FR-P1.4**: Submit order to POS API with appropriate authentication
- **FR-P1.5**: Return standardized response: success with POS order ID, or error with code and message

### FR-P2: Toast POS Adapter (P0)
- **FR-P2.1**: Authenticate using Toast OAuth 2.0 (client credentials or authorization code flow)
- **FR-P2.2**: Submit orders to Toast Orders API with required fields: restaurant GUID, items, modifiers, dining option (pickup/delivery)
- **FR-P2.3**: Map Parcera order statuses to Toast statuses (pending → new, confirmed → sent, preparing → in_progress, ready → ready, completed → completed)
- **FR-P2.4**: Poll Toast Orders API for status updates using order GUID
- **FR-P2.5**: Fetch menu data from Toast Menus API (items, categories, modifiers, prices)

### FR-P3: Square POS Adapter (P0)
- **FR-P3.1**: Authenticate using Square OAuth 2.0 or long-lived access tokens
- **FR-P3.2**: Submit orders to Square Orders API with required fields: location ID, line items, fulfillment (pickup/delivery)
- **FR-P3.3**: Map Parcera order statuses to Square statuses (pending → PROPOSED, confirmed → OPEN, ready → COMPLETED)
- **FR-P3.4**: Poll Square Orders API for status updates using order ID
- **FR-P3.5**: Fetch catalog data from Square Catalog API (items, categories, variations, modifiers)

### FR-P4: Clover POS Adapter (P0)
- **FR-P4.1**: Authenticate using Clover OAuth 2.0 or API tokens
- **FR-P4.2**: Submit orders to Clover Orders API with required fields: merchant ID, line items, order type
- **FR-P4.3**: Map Parcera order statuses to Clover statuses (pending → "", confirmed → pending, preparing → locked, ready → fulfilled)
- **FR-P4.4**: Poll Clover Orders API for status updates using order ID
- **FR-P4.5**: Fetch menu data from Clover Inventory API (items, categories, modifiers)

### FR-P5: Authentication Management (P0)
- **FR-P5.1**: Store POS credentials encrypted at rest (OAuth tokens, API keys, refresh tokens)
- **FR-P5.2**: Detect authentication failures (401, 403) and attempt token refresh for OAuth-based POS
- **FR-P5.3**: Auto-refresh OAuth tokens before expiration (if expiry time available)
- **FR-P5.4**: Lock token refresh to prevent concurrent refresh attempts for same restaurant
- **FR-P5.5**: Mark restaurant as "authentication failed" after 3 consecutive auth errors, alert admin

### FR-P6: Status Polling API (P0)
- **FR-P6.1**: Accept status polling requests with POS order ID
- **FR-P6.2**: Call appropriate POS adapter to fetch current order status
- **FR-P6.3**: Transform POS-specific status to standardized Parcera status
- **FR-P6.4**: Return standardized status response with last_updated timestamp
- **FR-P6.5**: Cache status for 15 seconds to reduce POS API calls for frequent polling

### FR-P7: Menu Synchronization API (P1)
- **FR-P7.1**: Accept menu sync request with restaurant ID
- **FR-P7.2**: Fetch full menu data from POS API (items, categories, modifiers, prices)
- **FR-P7.3**: Transform POS menu format to Parcera Menu Management format
- **FR-P7.4**: Return menu data or error if POS doesn't support menu API
- **FR-P7.5**: Support incremental sync (fetch only changes) if POS provides delta query capability

### FR-P8: Error Handling and Retry Logic (P1)
- **FR-P8.1**: Standardize error codes: "auth_error", "rate_limited", "timeout", "pos_error", "invalid_request", "item_not_found"
- **FR-P8.2**: Include POS-specific error message in response for debugging
- **FR-P8.3**: Implement exponential backoff for retries: 2s, 4s, 8s (max 3 attempts)
- **FR-P8.4**: Respect POS rate limit headers (Retry-After, X-Rate-Limit-Reset)
- **FR-P8.5**: Log all errors with full context: restaurant, POS type, request/response, timestamps

### FR-P9: Configuration and Testing (P1)
- **FR-P9.1**: Provide POS credential configuration API for admin dashboard
- **FR-P9.2**: Test connection endpoint: verify credentials work and return sample menu item
- **FR-P9.3**: Support sandbox/test environments for Toast, Square, Clover
- **FR-P9.4**: Per-restaurant configuration: POS type, credentials, API base URL, webhook URL (if applicable)
- **FR-P9.5**: Configuration validation: ensure required fields present for each POS type

### FR-P10: Monitoring and Health Checks (P2)
- **FR-P10.1**: Expose health check endpoint reporting status of each POS adapter
- **FR-P10.2**: Track success/failure rates per POS and per restaurant
- **FR-P10.3**: Monitor API response times (P95, P99) for each POS vendor
- **FR-P10.4**: Alert when POS integration health degrades (>5% error rate, >2s latency)
- **FR-P10.5**: Dashboard showing POS integration status per restaurant

---

## Key Entities

### 1. **POSAdapter** (Interface)
- `submit_order(order)` → POSOrderResponse
- `poll_status(pos_order_id)` → POSStatusResponse
- `fetch_menu()` → POSMenuResponse
- `refresh_auth()` → bool
- `test_connection()` → bool

### 2. **RestaurantPOSConfig**
- `config_id` (UUID, primary key)
- `restaurant_id` (UUID, foreign key, unique)
- `pos_type` (enum: 'toast', 'square', 'clover')
- `credentials` (JSON, encrypted: api_key, oauth_token, refresh_token, merchant_id, location_id)
- `api_base_url` (string, for sandbox vs production)
- `webhook_url` (string, nullable)
- `connection_status` (enum: 'active', 'auth_failed', 'disabled')
- `last_successful_call` (timestamp)
- `created_at`, `updated_at` (timestamps)

### 3. **POSAPILog**
- `log_id` (UUID, primary key)
- `restaurant_id` (UUID, foreign key)
- `pos_type` (enum)
- `operation` (enum: 'submit_order', 'poll_status', 'fetch_menu', 'refresh_auth')
- `request_payload` (JSON)
- `response_status` (integer, HTTP status code)
- `response_body` (JSON)
- `latency_ms` (integer)
- `success` (boolean)
- `error_code` (string, nullable)
- `timestamp` (timestamp)

---

## Success Criteria

1. **Order Submission Success Rate**: ≥99% of order submissions succeed on first or retry attempt
2. **Order Submission Latency**: ≥95% of submissions complete within 1 second (P95)
3. **Status Polling Reliability**: ≥99.5% of status polls return valid data without errors
4. **Authentication Auto-Refresh Success**: ≥99% of expired tokens successfully refreshed without manual intervention
5. **Multi-POS Parity**: Toast, Square, and Clover integrations have equivalent success rates (within 2% of each other)
6. **Error Handling Coverage**: 100% of POS API errors mapped to standardized error codes
7. **POS Adapter Extensibility**: New POS adapter can be added in <5 days without modifying core gateway logic
8. **Menu Sync Accuracy**: ≥95% of menu items correctly imported from POS (when POS supports menu API)
9. **Rate Limit Compliance**: Zero violations of POS API rate limits (respect Retry-After headers)
10. **Integration Uptime**: ≥99.9% gateway availability for order submission and status polling

---

## Assumptions

1. **POS API Documentation Available**: Toast, Square, and Clover provide complete, up-to-date API documentation
2. **OAuth 2.0 Standard**: All POS systems using OAuth follow standard OAuth 2.0 flows
3. **Order Statuses Mappable**: Different POS status vocabularies can be reasonably mapped to Parcera standard statuses
4. **No Webhook Support for MVP**: MVP uses polling; webhook support for real-time updates added post-MVP
5. **Single Location Per Restaurant**: MVP assumes each restaurant has one POS location; multi-location support is P2
6. **JSON Payloads**: All POS APIs accept/return JSON (no XML, SOAP, or proprietary formats)
7. **Internet Connectivity**: Gateway has reliable internet to reach POS APIs (cloud-hosted)
8. **POS Sandbox Environments**: Toast, Square, Clover provide sandbox/test environments for development
9. **No POS Webhooks Require Static IP**: If webhooks used post-MVP, no POS requires static IP allowlisting
10. **Menu Sync is Optional**: Not all POS systems provide menu API; manual/OCR entry is acceptable fallback

---

## Open Questions

1. **Toast API Version**: Which Toast API version (v1, v2) should be used? (Impacts payload format)
2. **Square Catalog Sync Frequency**: How often should menu be synced from Square? (Hourly, daily, on-demand only?)
3. **Clover Webhook Requirements**: Does Clover require webhook signature verification? (Security consideration)
4. **POS API Rate Limits**: What are exact rate limits for Toast, Square, Clover? (Per minute? Per restaurant? Global?)
5. **Order Modification Support**: Do any POS APIs support modifying submitted orders? (Impacts customer "edit order" feature feasibility)
6. **POS Downtime SLAs**: What are Toast, Square, Clover uptime SLAs? (Informs our error handling strategy)
7. **Multi-Currency Support**: Do Square/Clover international deployments require multi-currency? (MVP scope question)
8. **POS Partnership Agreements**: Are formal partnership agreements required with Toast, Square, Clover? (Legal/business consideration)

---

## Dependencies

### Upstream Dependencies
- **Feature 001 (Restaurant Management)**: Restaurant records with POS configuration
- **POS Vendor APIs**: Toast, Square, Clover API access and credentials

### Downstream Dependencies
- **Feature 002 (Menu Management)**: Consumes menu sync data from gateway
- **Feature 006 (Order Fulfillment)**: Uses gateway for order submission and status polling

### Infrastructure Dependencies
- Secrets management system (AWS Secrets Manager, HashiCorp Vault) for encrypted credential storage
- HTTP client library with timeout/retry support
- Background job system for token refresh

---

## Constitution Alignment

### Principle IV: Omnichannel by Default ✅
- Gateway enables orders from any channel (IVR, kiosk, mobile) to reach any POS system
- Consistent integration regardless of ordering channel

### Principle VII: Integration-Friendly Architecture ✅
- Supports multiple third-party POS vendors (no vendor lock-in)
- Adapter pattern enables easy addition of new POS systems
- Standard API contract isolates POS differences from rest of platform

---

## Validation Checklist

- [x] **User Stories**: 6 user stories with acceptance criteria
- [x] **Priorities**: P0 (MVP), P1 (post-MVP), P2 (future)
- [x] **Functional Requirements**: 10 requirement groups
- [x] **Key Entities**: 3 entities (POSAdapter interface, config, logs)
- [x] **Success Criteria**: 10 measurable outcomes
- [x] **Assumptions**: 10 assumptions documented
- [x] **Open Questions**: 8 questions for clarification
- [x] **Dependencies**: Upstream and downstream mapped
- [x] **Constitution Alignment**: Principles IV, VII

---

**STATUS**: ✅ SPECIFICATION COMPLETE - Ready for `/speckit.plan`

**Next Steps**:
1. Obtain Toast, Square, Clover sandbox API credentials
2. Create implementation plan with `/speckit.plan`
3. Generate tasks with `/speckit.tasks`
4. Coordinate with feature 006 for order submission/polling API contract
