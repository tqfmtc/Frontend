# Research: POS Integration Gateway

**Phase**: 0 (Research)  
**Date**: 2025-11-04  
**Spec Reference**: spec.md

---

## Executive Summary

POS (Point-of-Sale) integration is a critical architectural component enabling Parcera to submit orders to restaurant POS systems (Toast, Square, Clover) via a unified adapter pattern. This research documents API capabilities, authentication models, status mapping conventions, and integration patterns for MVP implementation.

---

## Vendor Comparison Matrix

| Aspect | Toast | Square | Clover |
|--------|-------|--------|--------|
| **Primary Use** | Full restaurant management | Omnichannel commerce | Merchant tools |
| **Order API** | Orders API v2 | Orders API v1 | Orders API (REST) |
| **Auth Method** | OAuth 2.0 (Authorization Code) | OAuth 2.0 (Long-lived tokens) | OAuth 2.0 (API tokens) |
| **Typical Rate Limit** | 100 req/min per restaurant | 600 req/min | 1000 req/min |
| **Menu API** | Menu Management API v2 | Catalog API | Inventory API |
| **Status Webhooks** | Supported (post-MVP) | Supported (post-MVP) | Supported (post-MVP) |
| **Sandbox Support** | Yes (staging environment) | Yes (sandbox.squareup.com) | Yes (sandbox.clover.com) |
| **Status Vocabulary** | new, sent, in_progress, ready, completed | PROPOSED, OPEN, READY, COMPLETED, CANCELED | pending, locked, fulfilled |

---

## Toast API Overview

### Authentication
- **Flow**: Authorization Code (OAuth 2.0)
- **Endpoints**:
  - Token: `https://api.toasttab.com/oauth/token`
  - Authorization: `https://api.toasttab.com/oauth/authorize`
- **Token Expiry**: 3600 seconds (1 hour)
- **Required Scopes**: `orders_read`, `orders_write`, `menu_read`

### Order Submission
- **Endpoint**: `POST /restaurants/{restaurantGuid}/orders`
- **Required Fields**:
  ```json
  {
    "items": [{"name": "item_name", "guid": "item_guid", "quantity": 1}],
    "diningOption": "DINE_IN|TAKEOUT|DELIVERY",
    "notes": "special instructions"
  }
  ```
- **Response**: Returns `guid` (Toast order ID), `externalId` (our order ID), `status`
- **Latency**: Typically 200-400ms

### Status Polling
- **Endpoint**: `GET /restaurants/{restaurantGuid}/orders/{orderGuid}`
- **Response**: `status` field with values: new, sent, in_progress, ready, completed, canceled
- **Cache Strategy**: 15s recommended (lightweight endpoint)

### Menu Fetch
- **Endpoint**: `GET /restaurants/{restaurantGuid}/menus`
- **Returns**: Categories, items, modifiers with prices and availability

---

## Square API Overview

### Authentication
- **Flow**: OAuth 2.0 or Long-lived Personal Access Tokens
- **Endpoints**:
  - Token: `https://connect.squareup.com/oauth2/token`
  - Authorization: `https://connect.squareup.com/oauth2/authorize`
- **Token Expiry**: Long-lived (no refresh needed with PAT)
- **Required Scopes**: `orders:read`, `orders:write`, `merchant:read`

### Order Submission
- **Endpoint**: `POST /v2/orders`
- **Required Fields**:
  ```json
  {
    "location_id": "location_guid",
    "line_items": [{"name": "item_name", "quantity": 1, "base_price_money": {...}}],
    "fulfillments": [{"type": "PICKUP"|"DELIVERY"}]
  }
  ```
- **Response**: Returns `id` (Square order ID), `state`
- **Latency**: Typically 300-500ms

### Status Polling
- **Endpoint**: `GET /v2/orders/{order_id}`
- **Response**: `state` field with values: OPEN, COMPLETED, CANCELED, DRAFT
- **Cache Strategy**: 15s recommended

### Catalog (Menu)
- **Endpoint**: `GET /v2/catalog/list`
- **Returns**: Items, categories, variations (modifiers), prices

---

## Clover API Overview

### Authentication
- **Flow**: OAuth 2.0 or Merchant API Tokens
- **Endpoints**:
  - Token: `https://www.clover.com/oauth/token`
  - Authorization: `https://www.clover.com/oauth2/authorize`
- **Token Expiry**: 3600 seconds (1 hour, some tokens longer)
- **Required Scopes**: `orders:rw`, `inventory:r`

### Order Submission
- **Endpoint**: `POST /v3/merchants/{merchant_id}/orders`
- **Required Fields**:
  ```json
  {
    "lineItems": [{"item": {"id": "item_id"}, "quantity": 1}],
    "note": "special instructions"
  }
  ```
- **Response**: Returns `id` (Clover order ID), `status`
- **Latency**: Typically 250-400ms

### Status Polling
- **Endpoint**: `GET /v3/merchants/{merchant_id}/orders/{order_id}`
- **Response**: `status` field with values: pending, locked, fulfilled, open, closed
- **Cache Strategy**: 15s recommended

### Inventory (Menu)
- **Endpoint**: `GET /v3/merchants/{merchant_id}/items`
- **Returns**: Items, categories, modifiers with prices and availability

---

## Status Mapping Convention

### Parcera Standard Status Vocabulary
- **pending**: Order received, awaiting confirmation
- **confirmed**: Order confirmed by restaurant
- **preparing**: Order being prepared
- **ready**: Order ready for pickup/delivery
- **completed**: Order fulfilled/delivered
- **canceled**: Order canceled

### Vendor → Parcera Mapping

```yaml
Toast:
  new: pending
  sent: confirmed
  in_progress: preparing
  ready: ready
  completed: completed
  canceled: canceled

Square:
  PROPOSED: pending
  OPEN: confirmed
  READY: ready
  COMPLETED: completed
  CANCELED: canceled

Clover:
  open: pending
  pending: confirmed
  locked: preparing
  fulfilled: ready
  closed: completed
```

---

## Error Handling Standards

### Standard Error Codes
- `auth_error`: Authentication/authorization failure (401, 403)
- `rate_limited`: API rate limit exceeded (429)
- `timeout`: Request timeout (>10s)
- `pos_error`: Generic POS error (5xx, network)
- `invalid_request`: Malformed request (4xx)
- `item_not_found`: Item not found in POS
- `restaurant_not_found`: Restaurant not configured

### HTTP Status Mapping
```
POS Response → Standard Code
401, 403 → auth_error
429 → rate_limited
408, 504 → timeout
500-599 → pos_error
400, 422 → invalid_request
404 → item_not_found
```

---

## Authentication Management Strategy

### Token Refresh Patterns

**Toast & Clover (Short-lived OAuth)**:
1. Detect 401 response → trigger refresh
2. Use stored refresh token → fetch new access token
3. Retry original request
4. Lock refresh to prevent concurrent attempts

**Square (Long-lived tokens)**:
1. No automatic refresh needed
2. Store token securely (encrypted at rest)
3. Monitor for explicit token revocation (periodic validation)

### Credential Storage
- Encrypt at rest using AES-256-GCM
- Store in secure vault (AWS Secrets Manager, HashiCorp Vault, or database with encryption)
- Never log credentials in plaintext
- Rotate keys annually

---

## Rate Limiting & Backoff

### Retry Strategy
```
Attempt 1: immediate
Attempt 2: wait 2s (exponential backoff)
Attempt 3: wait 4s
Attempt 4: wait 8s (max)
Max attempts: 3
```

### Rate Limit Detection
- Monitor `X-Rate-Limit-*` headers (Toast, Square, Clover all provide these)
- Respect `Retry-After` header if present
- Implement per-restaurant rate limit tracking
- Alert admin if consistent rate limiting

---

## Architecture Decisions

### Adapter Pattern
- **Why**: Abstracts vendor-specific API details
- **Implementation**: Interface-based design with concrete adapters per vendor
- **Extension**: New POS vendor = new adapter class, no core changes

### Polling vs Webhooks
- **MVP**: Polling only (simpler, no firewall/IP allowlisting)
- **Post-MVP**: Webhook support for real-time updates
- **Polling Frequency**: 30s baseline, configurable per restaurant

### Credential Management
- **Encryption**: AES-256-GCM at rest
- **In-Transit**: HTTPS/TLS 1.3 minimum
- **Rotation**: Manual rotation trigger, auto-refresh for OAuth

### Caching
- Status cache: 15s (reduces POS API calls, acceptable for order tracking)
- Menu cache: 1 hour (less frequent changes)
- Adapter config: 5m (refresh on errors)

---

## Technical Risks & Mitigations

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|-----------|
| POS API breaking changes | Medium | High | Version pinning, changelog monitoring, contract tests |
| Token refresh failures | Medium | High | Graceful degradation, admin alert, manual re-auth flow |
| Rate limit exhaustion | Low | Medium | Per-restaurant rate tracking, request deduplication |
| Network latency variance | High | Low | Timeout handling, retry with backoff, async polling |
| Credential exposure | Low | Critical | Encryption, RBAC, audit logging, secrets scanning |

---

## MVP Scope & Constraints

### Included (P0)
- Toast, Square, Clover adapters
- Order submission & status polling
- OAuth token management + auto-refresh
- Standard error codes & logging
- Configuration API (admin dashboard)

### Post-MVP (P1/P2)
- Menu sync from POS
- Webhook-based real-time updates
- Multi-location support
- Advanced retry strategies (idempotency keys)
- POS health dashboard

### Not in Scope
- Custom POS integrations (VendHQ, Toast ancillary systems)
- Payment processing (POS handles payments)
- Kitchen display system (KDS) integration

---

## Deliverables from Research

1. **Status Mapping Table** ✓ (documented above)
2. **Error Handling Spec** ✓ (documented above)
3. **Authentication Patterns** ✓ (documented above)
4. **Rate Limiting Strategy** ✓ (documented above)
5. **Adapter Interface Sketch** (→ data-model.md)
6. **API Contracts** (→ contracts/*.yaml)

---

## Next Steps

1. ✓ Complete research (this document)
2. Create data-model.md with entity definitions
3. Define API contracts in contracts/*.yaml
4. Create quickstart.md with integration examples
5. Update agent context with update-agent-context.sh
6. Commit to git

