#!/bin/bash
# update-agent-context.sh
# Update Claude agent memory with SPEC 007 design artifacts
# Run from spec root directory

set -e

SPEC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SPEC_DIR/../.." && pwd)"
MEMORY_FILE="$PROJECT_ROOT/Claude_memory.md"

echo "Updating agent context for SPEC 007 - POS Integration Gateway..."

# Extract key information from generated artifacts
RESEARCH_URL="specs/007-pos-integration/research.md"
DATA_MODEL_URL="specs/007-pos-integration/data-model.md"
CONTRACTS_URL="specs/007-pos-integration/contracts/"
QUICKSTART_URL="specs/007-pos-integration/quickstart.md"

# Append to memory file
cat >> "$MEMORY_FILE" << 'MEMORY_UPDATE'

## SPEC 007: POS Integration Gateway - Phase 1 Complete

### Overview
Third-party POS integration gateway (Toast, Square, Clover) with unified order submission, status polling, menu sync, and auth management.

### Phase 1 Artifacts (Design Complete)
- **research.md**: Vendor API comparison, status mapping, authentication patterns, error handling
- **data-model.md**: Entity definitions (POSAdapter interface, RestaurantPOSConfig, POSAPILog), database schema
- **contracts/**:
  - gateway-api.yaml: Main REST API (OpenAPI 3.0)
  - toast-api.yaml: Toast-specific contract
  - square-api.yaml: Square-specific contract
  - clover-api.yaml: Clover-specific contract
- **quickstart.md**: Python/FastAPI implementation examples, multi-POS integration pattern

### Architecture Summary
- **Pattern**: Adapter pattern (abstract POSAdapter interface, 3 concrete implementations)
- **Tech**: Python 3.11, FastAPI, async httpx, SQLAlchemy, Redis, PostgreSQL
- **API Contract**: /pos/submit_order, /pos/status/{order_id}, /pos/menu, /pos/config, /pos/test_connection
- **Database**: restaurant_pos_configs (encrypted credentials), pos_api_logs (audit trail)
- **Caching**: Redis, 15s status TTL
- **Error Handling**: 7 standard codes (auth_error, rate_limited, timeout, pos_error, invalid_request, item_not_found, network_error)
- **Retry Strategy**: Exponential backoff (2s, 4s, 8s), max 3 attempts

### Key Design Decisions
1. **Adapter Pattern**: Abstracts vendor differences, enables easy POS additions
2. **Async Throughout**: Scales to 1000+ req/min, non-blocking I/O
3. **Encrypted Credentials**: AES-256-GCM at rest
4. **Status Cache**: 15s TTL, reduces POS API calls, respects rate limits
5. **Per-Restaurant Config**: 1:1 with restaurants, supports multi-vendor deployment
6. **Exponential Backoff**: Standard API resilience pattern

### Success Criteria (10)
1. Order submission success ≥99% (first or retry)
2. P95 latency ≤1s
3. Status polling reliability ≥99.5%
4. Token auto-refresh ≥99%
5. Multi-POS parity (±2%)
6. Error mapping 100%
7. Extensibility: new adapter in <5 days
8. Menu accuracy ≥95%
9. Zero rate limit violations
10. Uptime ≥99.9%

### Phase 2 Tasks (Next)
- Core infrastructure (DB schema, encryption, retry logic)
- Adapter implementations (Toast, Square, Clover)
- Services (gateway, auth manager, status poller)
- API routes + middleware
- Contract tests, integration tests, end-to-end tests
- Staging + production deployment

### Dependencies
- Upstream: Restaurant Management (001), POS sandbox credentials
- Downstream: Order Fulfillment (006), Menu Management (002), Admin Dashboard

MEMORY_UPDATE

echo "✓ Agent context updated in $MEMORY_FILE"
echo ""
echo "Workflow Complete:"
echo "  ✓ research.md (Phase 0)"
echo "  ✓ data-model.md (Phase 1)"
echo "  ✓ contracts/ (Phase 1)"
echo "  ✓ quickstart.md (Phase 1)"
echo "  ✓ plan.md (Phase 1)"
echo "  ✓ Agent context updated"
echo ""
echo "Next: Run '/speckit.tasks' to generate Phase 2 task breakdown"
