# Quickstart: POS Integration Gateway

**Phase**: 1 (Design)  
**Date**: 2025-11-04  
**Audience**: Backend engineers implementing POS adapters

---

## Overview

This quickstart shows how to integrate Parcera's fulfillment engine with restaurant POS systems via the POS Gateway. Examples cover order submission, status polling, and error handling.

---

## Architecture (30 seconds)

```
Fulfillment Engine
    ↓
POS Gateway API (/pos/submit_order, /pos/status, etc)
    ↓
POSAdapter (Interface)
    ↓
Concrete Adapters: ToastAdapter | SquareAdapter | CloverAdapter
    ↓
POS APIs (Toast, Square, Clover)
```

---

## Setup

### 1. Install Dependencies (Python/FastAPI)

```bash
pip install fastapi httpx pydantic aioredis
```

### 2. Create Adapter Interface

```python
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class Order:
    """Standardized Parcera order format"""
    restaurant_id: str
    items: List[Dict[str, Any]]  # [{"name": "Burger", "quantity": 1, "modifiers": [...]}]
    order_type: str  # "pickup", "delivery", "dine_in"
    customer_info: Dict[str, str]  # {"name": "John", "phone": "+1-555-0100"}
    special_instructions: str

@dataclass
class POSOrderResponse:
    """Standardized response from POS"""
    success: bool
    pos_order_id: str
    status: str  # "pending", "confirmed", "preparing", "ready"
    timestamp: datetime
    error_code: Optional[str] = None
    error_message: Optional[str] = None

class POSAdapter(ABC):
    """All POS adapters inherit from this interface"""
    
    @abstractmethod
    async def submit_order(self, order: Order, config: dict) -> POSOrderResponse:
        """Submit order to POS"""
        pass
    
    @abstractmethod
    async def poll_status(self, pos_order_id: str, config: dict) -> dict:
        """Get order status from POS"""
        pass
    
    @abstractmethod
    async def refresh_auth(self, config: dict) -> dict:
        """Refresh OAuth tokens if needed"""
        pass
```

---

## Example 1: Toast Order Submission

### Scenario
Submit burger order to restaurant using Toast POS.

### Code

```python
class ToastAdapter(POSAdapter):
    """Toast POS adapter implementation"""
    
    def __init__(self):
        self.base_url = "https://api.toasttab.com"
    
    async def submit_order(self, order: Order, config: dict) -> POSOrderResponse:
        """
        Transform Parcera order to Toast format and submit
        """
        try:
            # Load Toast credentials
            restaurant_guid = config['credentials']['restaurant_guid']
            access_token = config['credentials']['access_token']
            
            # Transform Parcera order → Toast format
            toast_payload = {
                "items": [
                    {
                        "guid": item.get("toast_item_id"),
                        "name": item["name"],
                        "quantity": item["quantity"]
                    }
                    for item in order.items
                ],
                "diningOption": self._map_order_type(order.order_type),
                "notes": order.special_instructions,
                "externalId": order.order_id
            }
            
            # Submit to Toast API
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.base_url}/restaurants/{restaurant_guid}/orders",
                    json=toast_payload,
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "Content-Type": "application/json"
                    },
                    timeout=10.0
                )
            
            # Parse response
            if response.status_code == 200:
                data = response.json()
                return POSOrderResponse(
                    success=True,
                    pos_order_id=data['guid'],
                    status=self._map_status('Toast', data['status']),
                    timestamp=datetime.now(timezone.utc)
                )
            
            elif response.status_code == 401:
                # Token expired, attempt refresh
                await self.refresh_auth(config)
                return await self.submit_order(order, config)  # Retry
            
            else:
                return POSOrderResponse(
                    success=False,
                    pos_order_id=None,
                    status=None,
                    error_code=self._map_error(response.status_code),
                    error_message=response.text
                )
        
        except httpx.TimeoutException:
            return POSOrderResponse(
                success=False,
                pos_order_id=None,
                status=None,
                error_code="timeout",
                error_message="Toast API timeout"
            )
    
    def _map_order_type(self, order_type: str) -> str:
        """Parcera → Toast order type"""
        mapping = {
            "pickup": "TAKEOUT",
            "delivery": "DELIVERY",
            "dine_in": "DINE_IN"
        }
        return mapping.get(order_type, "TAKEOUT")
    
    def _map_status(self, vendor: str, vendor_status: str) -> str:
        """POS-specific status → Parcera standard"""
        if vendor == 'Toast':
            mapping = {
                "new": "pending",
                "sent": "confirmed",
                "in_progress": "preparing",
                "ready": "ready",
                "completed": "completed"
            }
        return mapping.get(vendor_status, "pending")
    
    async def refresh_auth(self, config: dict) -> dict:
        """Refresh Toast OAuth token"""
        client_id = config['credentials']['client_id']
        client_secret = config['credentials']['client_secret']
        refresh_token = config['credentials']['refresh_token']
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/oauth/token",
                json={
                    "grant_type": "refresh_token",
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "refresh_token": refresh_token
                }
            )
        
        if response.status_code == 200:
            data = response.json()
            config['credentials']['access_token'] = data['access_token']
            config['credentials']['refresh_token'] = data.get('refresh_token', refresh_token)
            # Save to database (encrypted)
            return config
        else:
            raise AuthError("Token refresh failed")
```

### Usage

```python
# In fulfillment engine
order = Order(
    restaurant_id="rest-123",
    order_id="ord-456",
    items=[{"name": "Burger", "quantity": 1, "modifiers": ["no-onions"]}],
    order_type="pickup",
    customer_info={"name": "John", "phone": "+1-555-0100"},
    special_instructions="No onions"
)

# Load restaurant POS config
config = db.get_pos_config(restaurant_id="rest-123")

# Create adapter and submit
adapter = ToastAdapter()
response = await adapter.submit_order(order, config)

if response.success:
    print(f"Order submitted to Toast: {response.pos_order_id}")
    # Store pos_order_id for future status polling
    db.update_order(order.order_id, pos_order_id=response.pos_order_id)
else:
    print(f"Error: {response.error_code} - {response.error_message}")
```

---

## Example 2: Status Polling

### Scenario
Poll Toast for order status every 30 seconds.

### Code

```python
class StatusPoller:
    """Background job for polling POS status"""
    
    def __init__(self):
        self.cache = {}  # Simple in-memory cache (use Redis in production)
        self.adapters = {
            'toast': ToastAdapter(),
            'square': SquareAdapter(),
            'clover': CloverAdapter()
        }
    
    async def poll_order(self, restaurant_id: str, pos_order_id: str, pos_type: str) -> dict:
        """
        Poll POS for order status with 15-second cache
        """
        cache_key = f"{restaurant_id}:{pos_order_id}"
        
        # Check cache
        if cache_key in self.cache:
            cached_time, cached_status = self.cache[cache_key]
            if datetime.now() - cached_time < timedelta(seconds=15):
                return cached_status
        
        # Fetch from POS
        config = db.get_pos_config(restaurant_id)
        adapter = self.adapters[pos_type]
        
        try:
            status = await adapter.poll_status(pos_order_id, config)
            
            # Cache result
            self.cache[cache_key] = (datetime.now(), status)
            
            return status
        
        except Exception as e:
            return {
                "success": False,
                "error_code": "pos_error",
                "error_message": str(e)
            }

# FastAPI endpoint
@app.get("/pos/status/{pos_order_id}")
async def get_order_status(pos_order_id: str, restaurant_id: str):
    """
    GET /pos/status/toast-order-123?restaurant_id=rest-456
    Response: { "success": true, "status": "preparing", "last_updated": "..." }
    """
    config = db.get_pos_config(restaurant_id)
    poller = StatusPoller()
    
    result = await poller.poll_order(
        restaurant_id=restaurant_id,
        pos_order_id=pos_order_id,
        pos_type=config['pos_type']
    )
    
    return result
```

---

## Example 3: Error Handling & Retry

### Scenario
Submit order; if rate-limited, retry with exponential backoff.

### Code

```python
from tenacity import retry, stop_after_attempt, wait_exponential

class ResilientPOSGateway:
    """POS Gateway with retry logic"""
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=2, min=1, max=10)
    )
    async def submit_order_with_retry(self, order: Order, config: dict) -> POSOrderResponse:
        """
        Submit order with automatic retry on transient errors
        """
        pos_type = config['pos_type']
        adapter = self._get_adapter(pos_type)
        
        response = await adapter.submit_order(order, config)
        
        # Log to database
        db.log_pos_api_call(
            restaurant_id=order.restaurant_id,
            pos_type=pos_type,
            operation="submit_order",
            success=response.success,
            error_code=response.error_code,
            latency_ms=0  # Would be measured
        )
        
        if not response.success:
            if response.error_code == "rate_limited":
                # Raise to trigger retry
                raise RateLimitError(response.error_message)
            elif response.error_code in ["timeout", "pos_error"]:
                # Transient, retry
                raise TransientError(response.error_message)
            else:
                # Permanent error, don't retry
                return response
        
        return response
    
    def _get_adapter(self, pos_type: str):
        """Factory: get adapter for POS type"""
        adapters = {
            'toast': ToastAdapter(),
            'square': SquareAdapter(),
            'clover': CloverAdapter()
        }
        return adapters.get(pos_type)

# Usage
gateway = ResilientPOSGateway()
response = await gateway.submit_order_with_retry(order, config)

if response.success:
    print(f"Success: {response.pos_order_id}")
else:
    print(f"Failed after retries: {response.error_code}")
```

---

## Example 4: Multi-POS Support

### Scenario
Three restaurants using Toast, Square, and Clover respectively. Submit same order to each.

### Code

```python
@app.post("/pos/submit_order")
async def submit_order_multi_pos(request: OrderSubmissionRequest):
    """
    Universal endpoint: routes to correct POS based on restaurant config
    """
    # Load restaurant config
    config = db.get_pos_config(request.restaurant_id)
    
    if not config:
        return {
            "success": False,
            "error": {
                "code": "restaurant_not_found",
                "message": "No POS configured for restaurant"
            }
        }
    
    # Create standardized order
    order = Order(
        restaurant_id=request.restaurant_id,
        order_id=request.order_id,
        items=request.items,
        order_type=request.order_type,
        customer_info=request.customer_info,
        special_instructions=request.special_instructions
    )
    
    # Route to correct adapter
    gateway = ResilientPOSGateway()
    response = await gateway.submit_order_with_retry(order, config)
    
    return {
        "success": response.success,
        "pos_order_id": response.pos_order_id,
        "status": response.status,
        "error": {
            "code": response.error_code,
            "message": response.error_message
        } if not response.success else None
    }

# Test: Submit order to three restaurants
restaurants = [
    {"id": "rest-toast-123", "pos": "toast"},
    {"id": "rest-square-456", "pos": "square"},
    {"id": "rest-clover-789", "pos": "clover"}
]

for rest in restaurants:
    response = await client.post(
        "/pos/submit_order",
        json={
            "restaurant_id": rest["id"],
            "order_id": "ord-unified-001",
            "items": [{"name": "Burger", "quantity": 1}],
            "order_type": "pickup",
            "customer_info": {"name": "John"},
            "special_instructions": ""
        }
    )
    print(f"{rest['pos']}: {response['success']}")
    # Output:
    # toast: True
    # square: True
    # clover: True
```

---

## Testing Strategy

### Unit Tests
- Each adapter tested independently
- Mock HTTP responses
- Status mapping validation

### Integration Tests
- Three test restaurants (Toast, Square, Clover sandboxes)
- Perform full order submission → status polling cycle
- Error scenarios (401, 429, 500)

### Contract Tests
- Validate responses match schemas in `contracts/*.yaml`
- Use OpenAPI spec validation

---

## Deployment Checklist

- [ ] Implement all three adapters (Toast, Square, Clover)
- [ ] Add database tables: `restaurant_pos_configs`, `pos_api_logs`
- [ ] Implement token encryption (AES-256-GCM)
- [ ] Add rate limiting per restaurant
- [ ] Implement status cache (Redis, 15s TTL)
- [ ] Add comprehensive logging and monitoring
- [ ] Sandbox testing with each POS vendor
- [ ] Admin dashboard for POS configuration
- [ ] Health check endpoint `/pos/health`
- [ ] Runbook for credential rotation

---

## Next Steps

1. ✓ Review spec.md, research.md, data-model.md
2. ✓ Review API contract (gateway-api.yaml, toast-api.yaml, etc)
3. ✓ Review this quickstart
4. Implement adapters and FastAPI endpoints
5. Write integration tests
6. Deploy to staging, test with sandbox credentials
7. Coordinate with fulfillment engine for API integration

---

## Resources

- [Spec](./spec.md): Feature specification and requirements
- [Research](./research.md): Vendor comparison, status mapping, error handling
- [Data Model](./data-model.md): Entity definitions, database schema
- [API Contracts](./contracts/): OpenAPI specs for gateway + vendor-specific contracts
- [Toast API Docs](https://dev.toasttab.com/docs)
- [Square API Docs](https://developer.squareup.com/docs)
- [Clover API Docs](https://docs.clover.com)

