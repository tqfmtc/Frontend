# Data Model: POS Integration Gateway

**Phase**: 1 (Design)  
**Date**: 2025-11-04  
**Input**: spec.md, research.md

---

## Domain Model

```
┌─────────────────────────────────────────────────────────────────┐
│                     POS Integration Gateway                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ POSAdapter (Interface) - Abstracts vendor differences    │   │
│  ├──────────────────────────────────────────────────────────┤   │
│  │ • submit_order(order: Order) → POSOrderResponse         │   │
│  │ • poll_status(pos_order_id: str) → POSStatusResponse    │   │
│  │ • fetch_menu() → POSMenuResponse                        │   │
│  │ • refresh_auth() → AuthToken                            │   │
│  │ • test_connection() → bool                              │   │
│  └──────────────────────────────────────────────────────────┘   │
│           ▲                ▲                   ▲                  │
│           │                │                   │                  │
│     ┌─────┴──┐      ┌──────┴───┐      ┌───────┴────┐            │
│     │  Toast  │      │ Square   │      │   Clover   │            │
│     │ Adapter │      │ Adapter  │      │  Adapter   │            │
│     └─────────┘      └──────────┘      └────────────┘            │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ RestaurantPOSConfig - POS credential & config per       │   │
│  │                      restaurant                          │   │
│  ├──────────────────────────────────────────────────────────┤   │
│  │ • config_id: UUID (PK)                                  │   │
│  │ • restaurant_id: UUID (FK, unique)                      │   │
│  │ • pos_type: 'toast' | 'square' | 'clover'              │   │
│  │ • credentials: JSON (encrypted)                         │   │
│  │ • api_base_url: str (sandbox vs prod)                   │   │
│  │ • webhook_url: str (optional)                           │   │
│  │ • connection_status: 'active' | 'auth_failed' | ...     │   │
│  │ • last_successful_call: datetime                        │   │
│  │ • created_at, updated_at: datetime                      │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ POSAPILog - Audit trail of all API interactions         │   │
│  ├──────────────────────────────────────────────────────────┤   │
│  │ • log_id: UUID (PK)                                     │   │
│  │ • restaurant_id: UUID (FK)                              │   │
│  │ • pos_type: 'toast' | 'square' | 'clover'              │   │
│  │ • operation: str (submit_order, poll_status, etc)       │   │
│  │ • request_payload: JSON                                 │   │
│  │ • response_status: int (HTTP)                           │   │
│  │ • response_body: JSON                                   │   │
│  │ • latency_ms: int                                       │   │
│  │ • success: bool                                         │   │
│  │ • error_code: str (nullable)                            │   │
│  │ • timestamp: datetime                                   │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Entity Definitions

### 1. POSAdapter (Interface)

**Purpose**: Abstract interface defining all POS adapter contracts.

**Methods**:

```python
class POSAdapter(ABC):
    """
    Abstract base adapter for all POS systems.
    Concrete implementations: ToastAdapter, SquareAdapter, CloverAdapter
    """
    
    @abstractmethod
    async def submit_order(
        self,
        order: Order,
        config: RestaurantPOSConfig
    ) -> POSOrderResponse:
        """
        Submit order to POS system.
        
        Args:
            order: Standardized Parcera order (items, modifiers, customer, etc)
            config: Restaurant's POS credentials and configuration
            
        Returns:
            POSOrderResponse(
                success: bool,
                pos_order_id: str,
                status: 'pending' | 'confirmed' | 'preparing',
                timestamp: datetime,
                raw_response: dict (for debugging)
            )
        
        Raises:
            AuthError: 401/403 response
            RateLimitError: 429 response
            TimeoutError: Network timeout
            POSError: Generic POS error (5xx, network)
        """
        pass
    
    @abstractmethod
    async def poll_status(
        self,
        pos_order_id: str,
        config: RestaurantPOSConfig
    ) -> POSStatusResponse:
        """
        Poll POS for current order status.
        
        Returns:
            POSStatusResponse(
                success: bool,
                status: 'pending' | 'confirmed' | 'preparing' | 'ready' | 'completed',
                last_updated: datetime,
                raw_status: str (POS-specific),
                notes: str (optional, e.g., "ready for pickup")
            )
        """
        pass
    
    @abstractmethod
    async def fetch_menu(
        self,
        config: RestaurantPOSConfig
    ) -> POSMenuResponse:
        """
        Fetch menu from POS system.
        
        Returns:
            POSMenuResponse(
                success: bool,
                items: List[MenuItem],
                categories: List[str],
                modifiers: List[Modifier],
                timestamp: datetime
            )
        """
        pass
    
    @abstractmethod
    async def refresh_auth(
        self,
        config: RestaurantPOSConfig
    ) -> AuthToken:
        """
        Refresh authentication credentials if using OAuth.
        
        Returns:
            AuthToken(
                access_token: str,
                expires_in: int,
                refresh_token: str (optional),
                token_type: 'Bearer'
            )
        
        Raises:
            AuthError: Refresh token invalid or expired
        """
        pass
    
    @abstractmethod
    async def test_connection(
        self,
        config: RestaurantPOSConfig
    ) -> bool:
        """
        Test if credentials and connection are valid.
        Used during restaurant onboarding.
        
        Returns: True if connection successful
        Raises: AuthError if credentials invalid
        """
        pass
```

---

### 2. RestaurantPOSConfig

**Purpose**: Store POS credentials and configuration per restaurant.

**Schema**:

```yaml
RestaurantPOSConfig:
  type: object
  
  properties:
    config_id:
      type: string (UUID)
      description: Primary key, generated on creation
      example: "550e8400-e29b-41d4-a716-446655440000"
    
    restaurant_id:
      type: string (UUID)
      description: Foreign key to Restaurant. UNIQUE constraint.
      example: "550e8400-e29b-41d4-a716-446655440001"
    
    pos_type:
      type: string (enum)
      enum: ["toast", "square", "clover"]
      description: POS vendor type
      example: "toast"
    
    credentials:
      type: object (encrypted JSON)
      description: |
        Vendor-specific credentials. Encrypted at rest (AES-256-GCM).
        
        Toast:
        {
          "client_id": "...",
          "client_secret": "...",
          "access_token": "...",
          "refresh_token": "...",
          "restaurant_guid": "..."
        }
        
        Square:
        {
          "access_token": "...",
          "location_id": "...",
          "merchant_id": "..."
        }
        
        Clover:
        {
          "api_token": "...",
          "oauth_token": "..." (if using OAuth),
          "refresh_token": "...",
          "merchant_id": "..."
        }
    
    api_base_url:
      type: string
      description: |
        POS API base URL.
        - Toast: https://api.toasttab.com (prod) or staging
        - Square: https://connect.squareup.com (prod) or sandbox.squareup.com
        - Clover: https://api.clover.com (prod) or sandbox.clover.com
      example: "https://api.toasttab.com"
    
    webhook_url:
      type: string (nullable)
      description: |
        URL for POS webhooks (status updates, menu changes).
        Optional for MVP (polling only).
      example: "https://parcera.api/webhooks/toast/550e8400..."
    
    connection_status:
      type: string (enum)
      enum: ["active", "auth_failed", "disabled", "pending_auth"]
      description: |
        Current connection status.
        - active: credentials valid, recent successful API call
        - auth_failed: credentials invalid or token refresh failed
        - disabled: manually disabled by admin
        - pending_auth: awaiting OAuth completion
      example: "active"
    
    last_successful_call:
      type: datetime (ISO 8601)
      nullable: true
      description: Timestamp of last successful API call to POS
      example: "2025-11-04T15:30:45Z"
    
    auth_failures_count:
      type: integer
      default: 0
      description: |
        Consecutive authentication failures.
        If >= 3, connection_status → "auth_failed", admin alerted.
      example: 0
    
    created_at:
      type: datetime (ISO 8601)
      description: When configuration was created
      example: "2025-11-01T10:00:00Z"
    
    updated_at:
      type: datetime (ISO 8601)
      description: When configuration was last updated
      example: "2025-11-04T15:30:45Z"
  
  required: [config_id, restaurant_id, pos_type, credentials, api_base_url]
```

---

### 3. POSAPILog

**Purpose**: Audit trail of all POS API interactions for debugging and monitoring.

**Schema**:

```yaml
POSAPILog:
  type: object
  
  properties:
    log_id:
      type: string (UUID)
      description: Primary key
      example: "550e8400-e29b-41d4-a716-446655440010"
    
    restaurant_id:
      type: string (UUID)
      description: Foreign key to Restaurant
      example: "550e8400-e29b-41d4-a716-446655440001"
    
    pos_type:
      type: string (enum)
      enum: ["toast", "square", "clover"]
      description: Which POS vendor
      example: "toast"
    
    operation:
      type: string (enum)
      enum: ["submit_order", "poll_status", "fetch_menu", "refresh_auth", "test_connection"]
      description: What operation was performed
      example: "submit_order"
    
    request_payload:
      type: object (JSON)
      description: |
        Full request sent to POS API (scrubbed of secrets).
        Example (Toast):
        {
          "items": [{"name": "Burger", "quantity": 1}],
          "diningOption": "TAKEOUT",
          "notes": "No onions"
        }
    
    response_status:
      type: integer
      description: HTTP status code from POS API
      example: 200
    
    response_body:
      type: object (JSON)
      description: |
        Full response from POS API.
        Example (Toast success):
        {
          "guid": "abc123...",
          "status": "new",
          "createdAt": "2025-11-04T15:30:45Z"
        }
        
        Example (error):
        {
          "error": "Invalid item GUID",
          "code": "INVALID_REQUEST"
        }
    
    latency_ms:
      type: integer
      description: Round-trip latency in milliseconds
      example: 245
    
    success:
      type: boolean
      description: Whether operation succeeded (2xx HTTP status)
      example: true
    
    error_code:
      type: string (nullable)
      enum: [
        "auth_error",
        "rate_limited",
        "timeout",
        "pos_error",
        "invalid_request",
        "item_not_found",
        "network_error"
      ]
      description: Standardized error code if operation failed
      example: null
    
    timestamp:
      type: datetime (ISO 8601)
      description: When the API call was made
      example: "2025-11-04T15:30:45Z"
  
  required: [log_id, restaurant_id, pos_type, operation, response_status, success, timestamp]
  
  indexes:
    - [restaurant_id, timestamp]  # Query logs by restaurant
    - [pos_type, success]          # Query success rates by vendor
    - [error_code, timestamp]      # Query error patterns
```

---

## Data Flow Diagrams

### Order Submission Flow

```
Fulfillment Engine
        │
        │ POST /pos/submit_order
        │ { items, modifiers, restaurant_id, ... }
        ▼
┌─────────────────────────────────────┐
│ POS Gateway Controller              │
│ • Validate request                  │
│ • Load RestaurantPOSConfig          │
│ • Select adapter (toast|square|...) │
└────────────┬────────────────────────┘
             │
             │ order + config
             ▼
┌─────────────────────────────────────┐
│ POSAdapter (concrete impl)          │
│ • Transform Parcera → POS format    │
│ • Detect missing credentials        │
│ • Check token expiry                │
└────────────┬────────────────────────┘
             │
             │ if token expired
             ▼
┌─────────────────────────────────────┐
│ AuthManager.refresh_token()         │
│ • Use refresh_token → new access    │
│ • Update RestaurantPOSConfig        │
│ • Lock (prevent concurrent refresh) │
└────────────┬────────────────────────┘
             │
             │ fresh credentials
             ▼
┌─────────────────────────────────────┐
│ HTTP POST to POS API                │
│ • Serialize POS payload             │
│ • Add authentication headers        │
│ • Timeout: 10s                      │
│ • Retry on 429/5xx (exponential bkf)│
└────────────┬────────────────────────┘
             │
             │ response (200/4xx/5xx)
             ▼
┌─────────────────────────────────────┐
│ Response Handler                    │
│ • Log to POSAPILog                  │
│ • Parse response                    │
│ • Extract POS order ID              │
│ • Update RestaurantPOSConfig.       │
│   last_successful_call              │
└────────────┬────────────────────────┘
             │
             │ POSOrderResponse
             ▼
Fulfillment Engine
(success/error + POS order ID)
```

### Status Polling Flow

```
Status Check (from fulfillment engine, webhook, or periodic job)
        │
        │ GET /pos/status/{pos_order_id}?restaurant_id=...
        ▼
┌──────────────────────────────────────┐
│ Status Cache Check                   │
│ • Key: {restaurant_id}_{pos_order_id}│
│ • TTL: 15 seconds                    │
└──┬─────────────────────────┬─────────┘
   │ MISS                    │ HIT
   ▼                         ▼
POS API Call         Return Cached Status
   │
   └─→ Load RestaurantPOSConfig
       Select adapter
       Call adapter.poll_status(pos_order_id)
       │
       ▼
    HTTP GET to POS
    │
    ▼
   Parse response
   Map POS status → Parcera status
   │
   ├─→ Update cache (15s)
   └─→ Return POSStatusResponse
           (status, last_updated)
```

---

## Database Tables (SQL Schema)

```sql
CREATE TABLE restaurant_pos_configs (
    config_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL UNIQUE REFERENCES restaurants(id),
    pos_type VARCHAR(20) NOT NULL CHECK (pos_type IN ('toast', 'square', 'clover')),
    credentials BYTEA NOT NULL,  -- Encrypted JSON
    api_base_url VARCHAR(255) NOT NULL,
    webhook_url VARCHAR(255),
    connection_status VARCHAR(20) NOT NULL DEFAULT 'pending_auth',
    auth_failures_count INTEGER NOT NULL DEFAULT 0,
    last_successful_call TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    
    INDEX idx_restaurant (restaurant_id),
    INDEX idx_pos_type (pos_type),
    INDEX idx_connection_status (connection_status)
);

CREATE TABLE pos_api_logs (
    log_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id),
    pos_type VARCHAR(20) NOT NULL,
    operation VARCHAR(50) NOT NULL,
    request_payload JSONB,
    response_status INTEGER NOT NULL,
    response_body JSONB,
    latency_ms INTEGER NOT NULL,
    success BOOLEAN NOT NULL,
    error_code VARCHAR(50),
    timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
    
    INDEX idx_restaurant_timestamp (restaurant_id, timestamp),
    INDEX idx_error_code_timestamp (error_code, timestamp),
    INDEX idx_pos_type_success (pos_type, success)
);
```

---

## Next Steps

1. ✓ Complete research.md
2. ✓ Complete data-model.md (this document)
3. Create contracts/*.yaml with OpenAPI specs
4. Create quickstart.md with integration examples
5. Update agent context
6. Commit to git

