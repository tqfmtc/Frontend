# Feature Specification: Table Management & Reservation System

**Feature Branch**: `026-table-management`
**Created**: 2025-10-30
**Status**: Draft - Archived for Future Implementation
**Input**: User description: "Table Management & Reservation System - Manages restaurant table layout, availability tracking, and reservation booking. Visual floor plan configuration with drag-and-drop table placement (2-top, 4-top, 6-top, 8-top, booths, bar seating). Real-time table status tracking: Available (green), Occupied (red), Reserved (yellow), Needs Clearing (orange). Reservation system for customers to book tables: phone reservations, online booking widget, walk-in waitlist. Reservation details: customer name, phone, party size, date/time, special requests (high chair, wheelchair accessible, window seat, quiet area). Table assignment algorithm matches reservations to available tables based on party size and preferences. Waitlist management for walk-ins: add to queue, estimated wait time, SMS notifications when table ready. Hostess interface shows floor plan with table statuses, upcoming reservations timeline, current waitlist. Table turnover tracking: average time per table, estimated clear time. Scope: ONLY table configuration and reservation booking, NOT order management (handled by POS), NOT seating charts for staff assignments. Archived for future - not required for short-term ordering focus."

## Overview

This specification defines the Table Management & Reservation System for managing restaurant floor plans, table availability tracking, reservation booking, and walk-in waitlists. Restaurant managers configure visual floor plans with drag-and-drop table placement (2-top, 4-top, 6-top, 8-top, booths, bar seating). System tracks real-time table status with color coding: Available (green), Occupied (red), Reserved (yellow), Needs Clearing (orange). Customers book reservations via phone, online widget, or walk-in, providing party size, date/time, and special requests (high chair, wheelchair accessible, window seat). Table assignment algorithm matches reservations to available tables based on party size and preferences. Waitlist management for walk-ins with estimated wait times and SMS notifications when table ready. Hostess interface displays floor plan with statuses, upcoming reservations timeline, and current waitlist queue. Tracks table turnover metrics: average occupancy time, estimated clear time.

**Scope**: ONLY table configuration and reservation booking. Order management is handled by SPEC 025 (POS Tablet). Seating charts for staff assignments are out of scope.

**Note**: This specification is archived for future implementation - not required for short-term ordering focus (primarily relevant for dine-in, not delivery/takeout).

## User Scenarios & Testing

### User Story 1 - Configure Restaurant Floor Plan (Priority: P1)

Restaurant manager accesses Business Dashboard, opens Floor Plan Editor, drags table shapes onto canvas (2-top, 4-top, 6-top, 8-top, booth, bar seat), positions tables to match actual restaurant layout, labels tables (Table 1-20, Booth A-D, Bar 1-10), saves floor plan. System validates no overlapping tables. Floor plan becomes active for hostess interface and reservation system.

**Why this priority**: Core functionality - floor plan must exist before any table management or reservations can function.

**Independent Test**: Can be fully tested by accessing Floor Plan Editor, dragging 10 4-top tables onto canvas, positioning in 2 rows of 5, labeling Table 1-10, saving, verifying floor plan displays in hostess interface with all 10 tables shown as Available (green).

**Acceptance Scenarios**:

1. **Given** restaurant manager on Business Dashboard, **When** manager opens Floor Plan Editor, **Then** displays blank canvas with table shape palette on left (2-Top Circle, 4-Top Square, 6-Top Rectangle, 8-Top Long Rectangle, Booth, Bar Seat), drag-and-drop interface, Save/Cancel buttons
2. **Given** Floor Plan Editor open, **When** manager drags 4-Top Square table onto canvas, positions at coordinates (100, 150), enters label "Table 1", **Then** table displays on canvas: 4-Top shape, "Table 1" label, default status Available (green outline)
3. **Given** floor plan with 10 tables configured, **When** manager clicks Save, **Then** system validates no overlapping tables, saves floor plan to restaurant configuration, displays confirmation "Floor plan saved successfully", floor plan activates for hostess interface immediately

---

### User Story 2 - Book Reservation via Online Widget (Priority: P1)

Customer visits restaurant website, clicks "Make a Reservation", selects party size (4 people), date (Saturday), time (7:00pm), enters name, phone, special request ("Window seat preferred"). System checks table availability, displays available time slots, customer confirms reservation. Customer receives confirmation email and SMS with reservation details.

**Why this priority**: Critical for customer self-service reservations reducing phone call volume and no-shows through automated reminders.

**Independent Test**: Can be fully tested by accessing reservation widget, selecting 4 people, Saturday 7:00pm, entering name "John Doe", phone "555-0123", special request "Window seat", confirming reservation, verifying confirmation email sent with reservation #R-1234.

**Acceptance Scenarios**:

1. **Given** customer on restaurant website reservation widget, **When** customer selects Party Size: 4, Date: 2025-11-02 (Saturday), **Then** system displays available time slots based on table capacity: 5:00pm, 5:30pm, 6:00pm, 6:30pm, 7:00pm, 7:30pm, 8:00pm (30-minute intervals), greys out fully booked times
2. **Given** available time slots displayed, **When** customer selects 7:00pm, enters Name: "John Doe", Phone: "555-0123", Special Request: "Window seat preferred", clicks "Reserve", **Then** system creates reservation #R-1234, assigns to available 4-top table (or larger if 4-top unavailable), marks table status Reserved (yellow) for 7:00pm slot
3. **Given** reservation #R-1234 created, **When** confirmation processes, **Then** customer receives confirmation email: "Reservation confirmed for 4 people on Saturday Nov 2, 7:00pm at [Restaurant Name]. Reservation #R-1234", SMS sent: "Your reservation for 4 at 7pm on Nov 2 is confirmed. Reply CANCEL to cancel. [Restaurant Name]"

---

### User Story 3 - Manage Walk-In Waitlist (Priority: P2)

Saturday night rush, all tables occupied. Customer walks in requesting table for 2. Hostess adds to waitlist: name, phone, party size. System estimates 25-minute wait based on current table occupancy and average turnover. Customer receives SMS with wait estimate and queue position. When table available, system notifies hostess and sends SMS to customer "Your table is ready".

**Why this priority**: Important for busy restaurants managing walk-in traffic but not essential for reservation-only or quick-service restaurants.

**Independent Test**: Can be fully tested by marking all tables Occupied, adding walk-in "Jane Smith" party of 2 to waitlist, system calculating estimated wait time based on average table turnover (25min), customer receiving SMS "Estimated wait: 25min, Position #3", marking Table 5 Available after 20min, system notifying hostess and sending SMS "Your table is ready!".

**Acceptance Scenarios**:

1. **Given** hostess interface showing all 20 tables Occupied (red), **When** customer walks in requesting table for 2, hostess taps "Add to Waitlist", enters Name: "Jane Smith", Phone: "555-9876", Party Size: 2, **Then** system adds to waitlist queue, calculates estimated wait: 25 minutes (based on average 2-top turnover time), displays queue position: #3, sends SMS to customer "Your table will be ready in approx 25 min. You are #3 in line. [Restaurant Name]"
2. **Given** waitlist with Jane Smith #3 in queue for 2-top, **When** Table 5 (2-top) clears and hostess marks Available, **Then** system matches Jane Smith reservation to Table 5, moves to top of queue, displays alert on hostess interface "Table 5 ready for Jane Smith - Party of 2", sends SMS to customer "Your table is ready! Please proceed to hostess stand. [Restaurant Name]"
3. **Given** Jane Smith notified table ready, **When** 10 minutes pass with no response, **Then** system displays timeout warning on hostess interface "Jane Smith - No show (10min)", hostess can mark "No Show" to remove from queue and offer table to next waitlist guest

---

### User Story 4 - View Hostess Interface with Real-Time Status (Priority: P1)

Hostess views floor plan interface showing all 20 tables with color-coded statuses: 8 Available (green), 10 Occupied (red), 2 Reserved (yellow) with reservation times, 0 Needs Clearing (orange). Right panel shows upcoming reservations timeline (next 2 hours) and current waitlist (3 parties waiting). Hostess assigns walk-in party to Available table, status updates to Occupied immediately.

**Why this priority**: Core hostess workflow - must see real-time table status to seat customers efficiently.

**Independent Test**: Can be fully tested by opening hostess interface, verifying floor plan displays with color-coded tables matching actual statuses, viewing reservations panel showing next 5 reservations chronologically, assigning Table 3 to walk-in, verifying status changes from Available (green) to Occupied (red) immediately.

**Acceptance Scenarios**:

1. **Given** hostess opening interface at 6:45pm, **When** floor plan loads, **Then** displays 20 tables with real-time statuses: Table 1-8 Available (green), Table 9-18 Occupied (red), Table 19 Reserved for 7:00pm (yellow with "7:00pm Smith party of 4" tooltip), Table 20 Reserved for 7:15pm (yellow with "7:15pm Jones party of 2"), all tables clickable for details
2. **Given** hostess interface open, **When** right panel Reservations tab selected, **Then** displays upcoming reservations sorted chronologically: 7:00pm - Smith party of 4 (Table 19), 7:15pm - Jones party of 2 (Table 20), 7:30pm - Davis party of 6 (Pending assignment), 8:00pm - Wilson party of 4 (Pending assignment), each with party name, size, time, assigned table (or Pending)
3. **Given** walk-in customer arrives, **When** hostess taps Available (green) Table 3, selects "Seat Party", enters party size 2, confirms, **Then** Table 3 status updates to Occupied (red) immediately, timestamp records seating time for turnover tracking, table displays "Occupied - 2 guests - Seated 6:47pm"

---

### User Story 5 - Track Table Turnover Metrics (Priority: P3)

Restaurant manager views table turnover analytics: average occupancy time per table size (2-tops: 45min avg, 4-tops: 65min avg, 6-tops: 85min avg), busiest time slots (6:30pm-8:00pm highest turnover), estimated clear times for current Occupied tables. Manager uses data to optimize reservation slot intervals and staff scheduling.

**Why this priority**: Nice-to-have for optimization but not blocking for basic table management. Lower priority because reservations work without analytics.

**Independent Test**: Can be fully tested by completing 20 table seatings with recorded occupancy times, accessing Analytics dashboard, verifying average turnover calculation: 2-tops average 45min, 4-tops average 65min, viewing turnover by time slot chart showing peak at 7:00pm.

**Acceptance Scenarios**:

1. **Given** restaurant manager on Business Dashboard → Table Analytics, **When** dashboard loads with last 30 days data, **Then** displays metrics: Average Occupancy Time: 2-Top (45 min), 4-Top (65 min), 6-Top (85 min), 8-Top (95 min), Total Tables Seated: 450, Average Wait Time: 18 min, No-Show Rate: 5% (23 of 450 reservations)
2. **Given** table analytics dashboard, **When** manager views Turnover by Time Slot chart, **Then** displays bar chart: 5:00pm-6:00pm (avg 50min turnover), 6:00pm-7:00pm (avg 55min), 7:00pm-8:00pm (avg 70min - peak), 8:00pm-9:00pm (avg 60min), identifies 7pm-8pm as busiest period requiring more staff

---

### Edge Cases

- **What happens when reservation booked for party size exceeding table capacity?** System automatically suggests combining multiple tables (e.g., party of 10 requires 2x 6-tops or 1x 8-top + 1x 2-top), hostess manually assigns table combination
- **How does system handle reservation no-shows?** After 15-minute grace period, hostess marks reservation as "No Show", table status changes from Reserved to Available, no-show logged for customer profile (repeat no-shows may require deposit for future reservations)
- **What happens when reservation time conflict occurs (double booking)?** System validates availability before confirming reservation, prevents double bookings, if manual override attempted displays error "Table 5 already reserved for 7:00pm"
- **How does system handle special requests that cannot be accommodated?** Special requests stored as notes (not hard requirements), hostess reviews and attempts to accommodate (window seat, high chair), if unavailable hostess communicates to customer upon arrival
- **What happens when walk-in party size exceeds all available table capacities?** System displays "No available tables for party size 12", suggests waitlist with extended wait time, or hostess manually combines tables if layout permits
- **How does system handle table transfers mid-meal?** Hostess can transfer occupied party from Table 5 to Table 8 (e.g., larger party needs more space), updates both table statuses, maintains occupancy timer from original seating

---

## Requirements

### Functional Requirements

#### Floor Plan Configuration
- **FR-001**: System MUST provide floor plan editor in Business Dashboard for restaurant managers
- **FR-002**: System MUST support drag-and-drop table placement on canvas representing restaurant floor
- **FR-003**: System MUST provide table shape palette: 2-Top (circle), 4-Top (square), 6-Top (rectangle), 8-Top (long rectangle), Booth, Bar Seat
- **FR-004**: System MUST allow managers to position tables at pixel coordinates on canvas
- **FR-005**: System MUST allow managers to label tables with custom names/numbers (e.g., Table 1, Booth A, Bar 5)
- **FR-006**: System MUST validate no overlapping tables when saving floor plan
- **FR-007**: System MUST save floor plan to restaurant configuration and activate for hostess interface immediately

#### Table Status Tracking
- **FR-008**: System MUST track real-time table status: Available, Occupied, Reserved, Needs Clearing
- **FR-009**: System MUST display table status with color coding: Available (green), Occupied (red), Reserved (yellow), Needs Clearing (orange)
- **FR-010**: System MUST update table status in real-time (within 2 seconds) when changed by hostess
- **FR-011**: System MUST record table occupancy timestamps: seating time, estimated clear time, actual clear time
- **FR-012**: System MUST calculate table turnover time: actual clear time - seating time
- **FR-013**: System MUST allow hostess to manually update table status via floor plan interface

#### Reservation Booking
- **FR-014**: System MUST provide online reservation widget embeddable on restaurant website
- **FR-015**: System MUST allow customers to select party size, date, and time for reservation
- **FR-016**: System MUST display available time slots based on table capacity and existing reservations
- **FR-017**: System MUST collect reservation details: customer name, phone number, special requests (text field)
- **FR-018**: System MUST validate table availability before confirming reservation
- **FR-019**: System MUST prevent double-booking of tables for same time slot
- **FR-020**: System MUST assign reservation unique ID (format: R-####)
- **FR-021**: System MUST support phone reservations entered by hostess with same details
- **FR-022**: System MUST send confirmation email to customer with reservation details and ID
- **FR-023**: System MUST send confirmation SMS to customer with reservation details
- **FR-024**: System MUST allow customers to cancel reservation via SMS reply "CANCEL"

#### Table Assignment Algorithm
- **FR-025**: System MUST match reservations to available tables based on party size
- **FR-026**: System MUST assign smallest table that accommodates party size (e.g., party of 3 gets 4-top, not 6-top)
- **FR-027**: System MUST consider special requests when assigning tables (window seat, wheelchair accessible, quiet area) as preferences, not requirements
- **FR-028**: System MUST allow manual table assignment override by hostess
- **FR-029**: System MUST mark assigned table as Reserved (yellow) for reservation time slot

#### Waitlist Management
- **FR-030**: System MUST allow hostess to add walk-in parties to waitlist
- **FR-031**: System MUST collect waitlist details: customer name, phone, party size
- **FR-032**: System MUST calculate estimated wait time based on current table occupancy and average turnover time
- **FR-033**: System MUST assign queue position to waitlist entries
- **FR-034**: System MUST send SMS to waitlist customer with estimated wait time and queue position
- **FR-035**: System MUST automatically match waitlist party to available table when table clears
- **FR-036**: System MUST notify hostess when table ready for waitlist party
- **FR-037**: System MUST send SMS to waitlist customer when table ready
- **FR-038**: System MUST support waitlist timeout: mark "No Show" if customer doesn't respond within 10 minutes of notification

#### Hostess Interface
- **FR-039**: System MUST display hostess interface with visual floor plan showing all tables and real-time statuses
- **FR-040**: System MUST display reservations panel showing upcoming reservations sorted chronologically
- **FR-041**: System MUST display waitlist panel showing current queue with estimated wait times
- **FR-042**: System MUST allow hostess to seat walk-in parties by tapping Available table
- **FR-043**: System MUST allow hostess to seat reservation by tapping Reserved table and confirming arrival
- **FR-044**: System MUST allow hostess to mark tables Needs Clearing when guests leave
- **FR-045**: System MUST allow hostess to mark tables Available after clearing complete

#### Table Turnover Analytics
- **FR-046**: System MUST track table occupancy times: seating timestamp, clear timestamp, duration
- **FR-047**: System MUST calculate average occupancy time per table size category (2-top, 4-top, 6-top, 8-top)
- **FR-048**: System MUST display table turnover metrics in Business Dashboard analytics
- **FR-049**: System MUST calculate turnover by time slot (hourly breakdown showing busiest periods)
- **FR-050**: System MUST track reservation no-show rate (percentage of reservations marked no-show)

### Key Entities

- **Floor Plan**: Restaurant table layout - includes canvas dimensions, table list (positions, shapes, labels), creation timestamp, last modified
- **Table**: Individual table in restaurant - includes table ID, label (Table 1, Booth A), shape type (2-top/4-top/6-top/8-top/booth/bar), capacity (guest count), position coordinates (x, y), current status (Available/Occupied/Reserved/Needs Clearing), occupancy timestamps (seating time, estimated clear, actual clear)
- **Reservation**: Customer table booking - includes reservation ID (R-####), customer name, phone number, party size, reservation date/time, special requests (text), assigned table reference, reservation status (Pending/Confirmed/Seated/No Show/Cancelled)
- **Waitlist Entry**: Walk-in party waiting for table - includes entry ID, customer name, phone, party size, add timestamp, queue position, estimated wait time (minutes), status (Waiting/Notified/Seated/No Show)
- **Table Occupancy Record**: Historical tracking of table usage - includes table reference, seating timestamp, party size, clear timestamp, occupancy duration (minutes), turnover time, time slot category (5pm-6pm, 6pm-7pm, etc.)

---

## Success Criteria

### Measurable Outcomes

- **SC-001**: Floor plan configuration completes within 10 minutes for 20-table restaurant
- **SC-002**: Online reservation booking completes within 2 minutes from time selection to confirmation
- **SC-003**: Reservation confirmations (email + SMS) send within 30 seconds of booking
- **SC-004**: Table status updates reflect in hostess interface within 2 seconds of change
- **SC-005**: Waitlist estimated wait time accuracy within ±10 minutes of actual wait 80% of the time
- **SC-006**: Table assignment algorithm matches party size to appropriate table 95%+ of time

### Qualitative Measures

- Restaurant managers can configure floor plans intuitively without training
- Customers find online reservation booking straightforward and receive clear confirmations
- Hostess interface provides at-a-glance view of all table statuses for efficient seating
- Waitlist management reduces customer frustration through proactive SMS notifications

---

## Dependencies

### Related Specifications

- **SPEC 025 - POS Tablet Interface**: Hostess assigns tables to orders via POS, updates table status to Occupied

### External Services

- **SMS Service**: Sends reservation confirmations, waitlist notifications, and table-ready alerts to customers

---

## Assumptions

1. **Reservation Time Slots**: 30-minute intervals standard (5:00pm, 5:30pm, 6:00pm, etc.), configurable per restaurant
2. **Grace Period**: 15-minute grace period for late arrivals before marking reservation no-show
3. **Average Turnover Times**: Defaults based on industry standards (2-top: 45min, 4-top: 65min, 6-top: 85min, 8-top: 95min), refined by actual restaurant data
4. **Waitlist Timeout**: 10-minute response window after table-ready notification before offering to next party
5. **Table Capacity**: Standard capacities (2-top seats 2, 4-top seats 4, etc.), can seat 1 fewer or 1 more as needed (e.g., party of 3 at 4-top)

---

## Out of Scope

1. **Order Management**: Handled by SPEC 025 (POS Tablet Interface)
2. **Seating Charts for Staff**: Assigning servers/sections to tables deferred to future iteration
3. **Reservation Deposits**: Requiring payment to hold reservation deferred
4. **Multi-Restaurant Reservations**: Booking across multiple restaurant locations deferred
5. **Advanced Waitlist Features**: Virtual queueing, SMS check-in deferred

---

**Note**: This specification is archived for future implementation and not required for short-term ordering focus (primarily relevant for dine-in, not delivery/takeout operations).
