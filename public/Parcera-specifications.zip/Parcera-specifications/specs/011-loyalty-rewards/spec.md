# Feature Specification: Loyalty, Rewards & Promotions

**Feature Branch**: `011-loyalty-rewards`
**Created**: 2025-10-29
**Status**: Draft
**Input**: User description: "Loyalty, Rewards & Promotions - Customer engagement system with points earning on orders, tiered loyalty levels (Bronze, Silver, Gold), coupon management (percentage off, dollar off, BOGO, free item), promotional campaigns, referral rewards, birthday rewards, and redemption at checkout. Points and rewards work across all partner restaurants on the platform. Supports time-limited promotions, restaurant-specific and platform-wide campaigns, spend thresholds, and fraud prevention. Integrates with wallet for automatic application and mobile app for rewards catalog browsing."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Points Earning & Redemption (Priority: P1)

Customers earn points on every order placed through any channel (IVR, kiosk, mobile) and redeem accumulated points for discounts or free items at checkout across all partner restaurants.

**Why this priority**: Core value proposition for customer retention. Points earning creates incentive for repeat orders and platform loyalty over competitors.

**Independent Test**: Can be fully tested by placing orders, verifying points are credited to wallet, browsing rewards catalog in mobile app, and redeeming points at checkout with order total reduced accordingly.

**Acceptance Scenarios**:

1. **Given** customer completes $25 order, **When** order is marked as completed, **Then** 25 points are credited to customer wallet within 1 minute (1 point per dollar spent)
2. **Given** customer has 500 points accumulated, **When** they browse rewards catalog in mobile app, **Then** available rewards are shown with point costs ($5 off for 500 points, $10 off for 1000 points)
3. **Given** customer selects "$5 off" reward at checkout, **When** they confirm redemption, **Then** 500 points are deducted from wallet and order total is reduced by $5
4. **Given** customer redeems points at Restaurant A, **When** they check wallet, **Then** updated point balance is reflected and can be used at any other partner restaurant

---

### User Story 2 - Tiered Loyalty Levels (Priority: P1)

Customers progress through loyalty tiers (Bronze, Silver, Gold) based on cumulative spend or order count, unlocking tier-specific benefits like bonus point multipliers, exclusive rewards, and early access to promotions.

**Why this priority**: Differentiates high-value customers and incentivizes increased spending. Tier progression creates gamification and status recognition.

**Independent Test**: Can be fully tested by simulating customer orders reaching tier thresholds, verifying automatic tier upgrades, and confirming tier benefits are applied (bonus points, exclusive rewards visibility).

**Acceptance Scenarios**:

1. **Given** new customer places first order, **When** order completes, **Then** customer is assigned Bronze tier with standard 1x point multiplier
2. **Given** Bronze customer reaches $500 cumulative spend, **When** threshold is crossed, **Then** customer is automatically upgraded to Silver tier with 1.25x point multiplier and notification sent
3. **Given** Silver customer reaches $2000 cumulative spend, **When** threshold is crossed, **Then** customer is upgraded to Gold tier with 1.5x point multiplier and exclusive rewards unlocked
4. **Given** Gold tier customer places $20 order, **When** order completes, **Then** 30 points are earned (20 × 1.5 multiplier) instead of standard 20 points

---

### User Story 3 - Coupon Management & Application (Priority: P1)

Customers receive and apply coupons (percentage off, dollar off, BOGO, free item) at checkout through manual entry or automatic wallet application for targeted promotions.

**Why this priority**: Essential for promotional campaigns and customer acquisition. Coupons drive conversion and enable restaurant-specific marketing.

**Independent Test**: Can be fully tested by creating coupons in admin dashboard, distributing to customers, and verifying coupons are applied correctly at checkout with proper validation (expiration, minimum spend, single use).

**Acceptance Scenarios**:

1. **Given** customer receives "SAVE20" coupon for 20% off, **When** they enter code at checkout, **Then** coupon is validated and 20% discount is applied to order total
2. **Given** coupon has $30 minimum spend requirement, **When** customer with $25 cart applies coupon, **Then** error message displays "Minimum order of $30 required for this coupon"
3. **Given** customer has "BOGO burger" coupon saved in wallet, **When** they add burger to cart, **Then** coupon is automatically suggested and second burger is added free when applied
4. **Given** coupon is single-use only, **When** customer tries to apply same coupon code again, **Then** error displays "Coupon has already been used" and application is blocked

---

### User Story 4 - Referral Rewards Program (Priority: P1)

Customers refer friends via unique referral codes or links, earning bonus points for both referrer and referee when new customer completes first order, encouraging viral growth.

**Why this priority**: Cost-effective customer acquisition channel. Referral incentives reduce marketing costs while leveraging existing customer base for growth.

**Independent Test**: Can be fully tested by generating referral link, sharing with new customer, verifying new customer uses referral code, and confirming both parties receive bonus points after first order completion.

**Acceptance Scenarios**:

1. **Given** customer accesses referral section in mobile app, **When** they generate referral link, **Then** unique referral code is created and shareable link includes code (e.g., "parcera.com/ref/ABC123")
2. **Given** new customer signs up using referral code "ABC123", **When** they complete first order, **Then** both referrer and referee receive 200 bonus points within 1 minute
3. **Given** referrer has referred 5 customers, **When** they view referral dashboard, **Then** total referrals, successful conversions, and points earned are displayed
4. **Given** customer tries to use their own referral code, **When** they enter code at signup, **Then** error displays "You cannot use your own referral code" and code is rejected

---

### User Story 5 - Promotional Campaigns (Priority: P1)

Restaurants create time-limited promotional campaigns (happy hour discounts, weekend specials, new item launches) targeting specific customer segments or all platform users with automatic expiration.

**Why this priority**: Enables restaurant-driven marketing and revenue optimization. Platform-wide campaigns drive traffic across all partners.

**Independent Test**: Can be fully tested by creating campaign in admin dashboard with targeting rules, verifying eligible customers see promotion in mobile app, and confirming promotion applies at checkout within active time window.

**Acceptance Scenarios**:

1. **Given** restaurant creates "Happy Hour 30% off" campaign for Monday-Friday 2-5 PM, **When** customer browses menu at 3 PM on Tuesday, **Then** promotion banner displays and 30% discount is applied to eligible items
2. **Given** platform creates "First-Time User $10 off" campaign, **When** new customer places first order, **Then** $10 discount is automatically applied without requiring coupon code entry
3. **Given** campaign targets Gold tier customers only, **When** Bronze customer browses restaurant, **Then** promotion is not visible and does not apply at checkout
4. **Given** campaign expires at 5:00 PM, **When** customer adds item at 4:58 PM but checks out at 5:02 PM, **Then** promotion is no longer valid and full price is charged with expiration message

---

### User Story 6 - Birthday Rewards (Priority: P2)

Customers receive special birthday rewards (free item, bonus points, exclusive discount) during their birth month to celebrate and encourage ordering on special occasions.

**Why this priority**: Important for customer engagement and sentiment but not critical for core loyalty functionality. Drives orders during typically low-frequency periods.

**Independent Test**: Can be fully tested by setting customer birthdate in wallet, advancing system date to birth month, and verifying birthday reward is unlocked and redeemable during that month only.

**Acceptance Scenarios**:

1. **Given** customer's birthday is in current month, **When** they open mobile app, **Then** birthday message displays with special reward (e.g., "Happy Birthday! Enjoy a free dessert on us")
2. **Given** birthday reward is "Free item up to $10", **When** customer adds eligible item to cart, **Then** item is marked as free at checkout and reward is consumed
3. **Given** birthday reward expires at end of birth month, **When** customer attempts to use reward on first day of following month, **Then** reward is no longer available and message displays "Birthday reward has expired"
4. **Given** customer does not use birthday reward, **When** birth month ends, **Then** unused reward expires and does not carry over to next month or year

---

### User Story 7 - Fraud Prevention & Spend Thresholds (Priority: P2)

System detects and prevents fraudulent loyalty activity (fake accounts, coupon abuse, referral fraud) using spend thresholds, velocity checks, and account verification requirements.

**Why this priority**: Important to protect program integrity but not blocking for launch. Fraud detection rules can be added progressively based on observed abuse patterns.

**Independent Test**: Can be fully tested by simulating fraudulent scenarios (multiple accounts from same device, excessive referrals without orders, rapid coupon redemption) and verifying system blocks or flags suspicious activity.

**Acceptance Scenarios**:

1. **Given** customer creates 3 accounts from same device IP, **When** third account attempts to use referral code, **Then** referral bonus is held pending manual review and notification sent to admin
2. **Given** coupon has maximum 5 redemptions per day, **When** 6th redemption is attempted, **Then** error displays "Daily redemption limit reached. Try again tomorrow."
3. **Given** points redemption exceeds $100 value, **When** customer attempts redemption, **Then** additional verification is required (SMS code, recent order confirmation) before processing
4. **Given** customer has history of order cancellations after point earning, **When** they place new order, **Then** points are held in pending status until order is successfully fulfilled (not immediately credited)

---

### Edge Cases

- What happens when customer earns points but cancels order before fulfillment? Points should be held in pending status until order is marked as completed, then credited. Cancelled orders result in point reversal.
- How does system handle customers ordering across multiple restaurants simultaneously? Points are earned per completed order regardless of restaurant, with all points pooling in single wallet balance.
- What happens when promotion conflicts with coupon (e.g., 20% off promotion + 15% off coupon)? System applies better discount only (20% promotion) or allows stacking with maximum cap (e.g., 30% total max) based on campaign rules.
- How does system handle tier downgrades if customer stops ordering? Tiers are based on cumulative lifetime spend (never downgrade) or rolling 12-month spend (downgrade if threshold not maintained) - using lifetime model as default.
- What happens when customer redeems points but order fails or is rejected? Points are immediately refunded to wallet and customer is notified of failed redemption.
- How does system prevent coupon sharing/resale? Single-use coupons are tied to wallet_id, require account to redeem, and expire after first use. Unique codes generated per customer for non-transferable coupons.

## Requirements *(mandatory)*

### Functional Requirements

#### Points System
- **FR-001**: System MUST award points on completed orders at rate of 1 point per $1 spent (configurable per restaurant or platform-wide)
- **FR-002**: System MUST apply tier-based point multipliers automatically (Bronze 1x, Silver 1.25x, Gold 1.5x) at time of point earning
- **FR-003**: System MUST credit points to customer wallet within 1 minute of order completion confirmation
- **FR-004**: System MUST hold points in pending status until order is fulfilled (not cancelled or refunded)
- **FR-005**: System MUST support point redemption at checkout with real-time balance validation and deduction

#### Tiered Loyalty Levels
- **FR-006**: System MUST define tier thresholds: Bronze (default), Silver ($500 cumulative spend), Gold ($2000 cumulative spend)
- **FR-007**: System MUST automatically upgrade customers to higher tiers when spend thresholds are crossed with notification sent within 5 minutes
- **FR-008**: System MUST calculate cumulative spend using lifetime total (no tier downgrades) unless rolling 12-month window is configured
- **FR-009**: System MUST display current tier, progress to next tier, and tier benefits in mobile app wallet section
- **FR-010**: System MUST filter rewards catalog by tier eligibility (Gold-exclusive rewards only visible to Gold customers)

#### Coupon Management
- **FR-011**: System MUST support coupon types: percentage off, dollar off, BOGO (buy one get one), free item, and combination offers
- **FR-012**: System MUST validate coupon constraints: expiration date, minimum spend requirement, eligible items/categories, single-use vs multi-use, customer tier eligibility
- **FR-013**: System MUST allow manual coupon code entry at checkout with real-time validation and error messaging
- **FR-014**: System MUST automatically suggest applicable coupons saved in wallet when cart contents match eligibility criteria
- **FR-015**: System MUST mark single-use coupons as consumed after successful redemption and prevent reuse

#### Promotional Campaigns
- **FR-016**: System MUST support time-limited campaigns with start/end dates and active time windows (e.g., weekdays 2-5 PM)
- **FR-017**: System MUST support targeting rules: customer tier, first-time users, specific geographic locations, minimum order frequency
- **FR-018**: System MUST display active promotions in mobile app with banners, badges on eligible items, and automatic application at checkout
- **FR-019**: System MUST support restaurant-specific and platform-wide campaigns with priority rules when multiple promotions apply
- **FR-020**: System MUST automatically expire promotions when time window closes and remove from customer-facing displays

#### Referral Program
- **FR-021**: System MUST generate unique referral codes for each customer accessible in mobile app referral section
- **FR-022**: System MUST track referral usage when new customers sign up using referral code or link
- **FR-023**: System MUST award bonus points to both referrer and referee after referee completes first order (default 200 points each)
- **FR-024**: System MUST prevent self-referral by blocking customers from using their own referral codes
- **FR-025**: System MUST display referral dashboard showing total referrals, successful conversions, and total points earned

#### Rewards Catalog
- **FR-026**: System MUST maintain rewards catalog with predefined rewards ($ off, % off, free items) and point costs
- **FR-027**: System MUST display available rewards filtered by customer point balance and tier eligibility
- **FR-028**: System MUST support cross-restaurant redemption (points earned at Restaurant A can be redeemed at Restaurant B)
- **FR-029**: System MUST support platform-wide rewards (e.g., "$5 off any order") and restaurant-specific rewards (e.g., "Free pizza at Joe's Pizza")
- **FR-030**: System MUST allow customers to browse and preview rewards without committing to redemption until checkout

#### Birthday Rewards
- **FR-031**: System MUST unlock birthday rewards during customer's birth month using birthdate stored in wallet
- **FR-032**: System MUST send birthday notification via push/SMS on first day of birth month with reward details
- **FR-033**: System MUST automatically expire unused birthday rewards at end of birth month (no carry-over)
- **FR-034**: System MUST support configurable birthday rewards per restaurant or platform-wide default (e.g., free item up to $10 value)

#### Fraud Prevention
- **FR-035**: System MUST flag accounts creating excessive referrals without corresponding orders for manual review
- **FR-036**: System MUST enforce daily redemption limits per coupon code (configurable per campaign, default 5 per day)
- **FR-037**: System MUST require additional verification (SMS code) for point redemptions exceeding $100 value in single transaction
- **FR-038**: System MUST detect and flag multiple accounts from same device/IP attempting referral bonus abuse
- **FR-039**: System MUST hold points in pending status for customers with history of order cancellations (>30% cancellation rate)

#### Integration & Wallet
- **FR-040**: System MUST integrate with Customer Wallet (spec 008) for storing points balance, tier level, saved coupons, and redemption history
- **FR-041**: System MUST sync loyalty data across all ordering channels (IVR, kiosk, mobile) with real-time balance updates
- **FR-042**: System MUST display loyalty summary in mobile app wallet: points balance, tier level, active coupons, available rewards
- **FR-043**: System MUST allow operators to create and manage coupons/campaigns in Admin Dashboard (spec 009)

### Key Entities

- **LoyaltyAccount**: Customer's loyalty profile with wallet_id, current tier (Bronze/Silver/Gold), points balance, pending points, cumulative spend, tier upgrade date, referral code, account creation date
- **PointsTransaction**: Record of points earned or redeemed with transaction type (earn/redeem/bonus/refund), amount, order_id, restaurant_id, timestamp, description, status (pending/completed/reversed)
- **Coupon**: Promotional code with code string, type (percentage_off, dollar_off, bogo, free_item), discount value, constraints (min_spend, expiration_date, eligible_items, tier_requirement), usage_limit, usage_count, restaurant_id (null for platform-wide)
- **Campaign**: Time-limited promotion with name, description, discount rules, start_date, end_date, active_time_windows (e.g., weekdays 2-5 PM), targeting_rules (tier, location, first_time_user), priority level, restaurant_id (null for platform-wide)
- **Reward**: Redeemable loyalty item with name, description, point_cost, reward_type (dollar_off, percent_off, free_item), reward_value, tier_requirement, restaurant_id (null for platform-wide), active status
- **ReferralTracking**: Referral relationship with referrer_wallet_id, referee_wallet_id, referral_code_used, signup_date, first_order_date, bonus_awarded status, bonus_amount
- **RedemptionHistory**: Log of reward/coupon usage with wallet_id, redemption_type (points, coupon, birthday), order_id, discount_value, timestamp, status (success/failed/refunded)

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 60% of customers earn points on second order within 30 days of first order (repeat purchase rate)
- **SC-002**: 40% of customers redeem points or use coupons within 90 days of account creation (engagement rate)
- **SC-003**: Referral program drives 15% of new customer acquisitions within 6 months of launch (viral growth)
- **SC-004**: Average order value increases by 25% when customers use BOGO or tiered rewards compared to regular orders
- **SC-005**: 80% of eligible customers (birthdate provided) redeem birthday rewards during birth month (activation rate)
- **SC-006**: Tier progression increases customer lifetime value by 50% (Gold vs Bronze 12-month spend comparison)
- **SC-007**: Promotional campaigns drive 30% increase in orders during targeted time windows (campaign effectiveness)
- **SC-008**: Fraud detection flags <2% of legitimate transactions while catching >90% of abuse patterns (fraud accuracy)
- **SC-009**: 90% of customers can discover, select, and redeem rewards without support assistance (usability)
- **SC-010**: Points are credited within 1 minute of order completion for 99% of transactions (system performance)
- **SC-011**: Customer retention rate (orders in months 7-12) improves by 35% for loyalty program participants vs non-participants
- **SC-012**: Cross-restaurant redemption drives 20% of customers to try new restaurants they haven't ordered from previously (network effect)

## Assumptions *(mandatory)*

1. **Points Earning Rate**: Default 1 point per $1 spent applies to order subtotal before taxes and fees. Configurable per restaurant or platform-wide.
2. **Tier Model**: Using lifetime cumulative spend model (no downgrades) initially. Rolling 12-month window model is future enhancement requiring configuration option.
3. **Points Expiration**: Points do not expire. Future enhancement may introduce expiration (e.g., 12 months from earning) with configuration option.
4. **Referral Limits**: No cap on referrals per customer initially. Fraud prevention may introduce limits (e.g., 10 referrals per month) if abuse detected.
5. **Birthday Verification**: Birthdate is self-reported in wallet. No identity verification required. Future enhancement may require ID upload for birthday rewards >$25 value.
6. **Coupon Stacking**: Single coupon per order is default. Promotion + coupon stacking allowed only if campaign explicitly permits with defined stacking rules.
7. **Points Value**: 100 points = $1 redemption value (1 cent per point). Configurable in admin settings but consistent across platform initially.
8. **Redemption Minimums**: Minimum 500 points ($5 value) required for redemption. Prevents small-value redemptions that increase transaction costs.
9. **Campaign Conflicts**: When multiple promotions apply, better discount is used by default. Admin can configure priority rules or stacking allowances per campaign.
10. **Data Retention**: Points transactions, redemption history, and coupon usage are retained indefinitely for audit and analytics. Campaign history retained for 2 years.

## Constitution Alignment *(mandatory)*

### Principle I: AI-First Architecture
- Future AI-driven personalization: Predict best promotion timing based on customer behavior, recommend rewards likely to drive next order
- Conversation mining integration: Analyze voice orders to identify menu preferences and auto-suggest relevant coupons during IVR/kiosk ordering

### Principle II: Multi-Tenancy by Design
- Loyalty system supports platform-wide points pooling while allowing restaurant-specific campaigns and rewards
- Row-level security ensures restaurants can only create/manage their own campaigns while accessing platform-wide loyalty metrics
- Tiered pricing model: Restaurants pay percentage of redemption value or monthly fee for loyalty features

### Principle III: Privacy-First Customer Data
- Points balance, tier level, and redemption history stored in customer wallet (Parcera-controlled, spec 008)
- Restaurants see aggregated loyalty metrics (redemption rates, campaign performance) but not individual customer point balances or spending history
- Referral tracking uses wallet_id without exposing personal information to restaurants

### Principle IV: Omnichannel by Default
- Points earned consistently across all channels (IVR, kiosk, mobile) with same rates and rules
- Coupons and rewards redeemable on any channel without restriction
- Tier benefits apply uniformly regardless of ordering channel

### Principle V: Progressive Enhancement & MVP Discipline
- **P1 Features**: Points earning/redemption, tiered loyalty, coupon management, referral program, promotional campaigns (FR-001 to FR-025)
- **P2 Features**: Birthday rewards, fraud prevention, advanced targeting, campaign analytics (FR-026 to FR-039)
- **P3 Features (Deferred)**: AI personalization, gamification (badges, challenges), social sharing, charity point donations

### Principle VI: Network Effects & Platform Thinking
- **CRITICAL ALIGNMENT**: Cross-restaurant point redemption is core differentiator - customers earn at Restaurant A, redeem at Restaurant B
- Platform-wide campaigns drive traffic across all partners, increasing overall order volume
- Referral program creates viral loop where customers recruit friends who become multi-restaurant users

### Principle VII: Integration-Friendly Architecture
- RESTful APIs for points earning, redemption, coupon validation exposed for third-party integrations
- Webhook events for tier upgrades, reward unlocks enable partner integrations (e.g., email marketing platforms)
- OpenAPI spec for loyalty endpoints enables restaurant POS integrations to trigger point awards

## Dependencies *(mandatory)*

### Internal Dependencies (Parcera Platform)
- **Customer Identity (spec 008)**: Stores loyalty data in wallet (points balance, tier, birthdate, referral code)
- **Order Fulfillment (spec 006)**: Triggers point earning on order completion, applies discounts from coupons/rewards
- **Mobile App (spec 005)**: Displays loyalty summary, rewards catalog, referral dashboard, coupon entry
- **Admin Dashboard (spec 009)**: Provides interface for restaurant operators to create campaigns and coupons
- **Notification Infrastructure (spec 010)**: Sends tier upgrade notifications, birthday rewards, referral bonus confirmations

### External Dependencies
- None. Loyalty system is self-contained within Parcera platform without external service integrations for MVP.

## Future Considerations *(optional)*

### Post-MVP Enhancements (P2/P3)
- **AI Personalization Engine**: Recommend rewards and promotions based on order history, predict churn risk and trigger win-back campaigns
- **Gamification**: Badges, challenges (e.g., "Order from 5 different restaurants this month"), leaderboards for top earners
- **Social Sharing**: Share tier achievements, referral invites, and favorite rewards on social media with branded graphics
- **Charity Point Donations**: Allow customers to donate points to partner charities (e.g., 1000 points = $10 donation to local food bank)
- **Points Gifting**: Transfer points to other customers (birthday gifts, family sharing) with fraud prevention limits
- **Partner Rewards**: Integrate with third-party loyalty programs (airlines, credit cards) for point conversion or bonus offers
- **Dynamic Pricing**: Offer surge discounts during slow hours using loyalty points to drive demand smoothing
- **Subscription Tiers**: Monthly subscription fee for premium loyalty benefits (2x points, free delivery, exclusive rewards)
- **NFT Rewards**: Limited-edition digital collectibles as tier rewards for Gold customers (Web3 integration)
- **Corporate Accounts**: B2B loyalty programs for office lunch programs with centralized billing and employee point allocations
