# Feature Specification: Delivery Management & Driver Dispatch

**Feature Branch**: `027-delivery-management`
**Created**: 2025-10-30
**Status**: Draft - Archived for Future Implementation
**Input**: User description: "Delivery Management & Driver Dispatch - Manages delivery driver fleet, order dispatch, route optimization, and real-time tracking. Driver management: add/remove drivers, track availability status (Available, On Delivery, Off Duty), driver profiles with vehicle info. Order dispatch assigns delivery orders to available drivers based on proximity, current location, and delivery time constraints. Route optimization for multi-stop deliveries (driver picks up multiple orders, optimizes sequence). Real-time driver tracking shows current location on map for restaurant and customers. Delivery status updates: Order Ready → Driver Assigned → Picked Up → En Route → Delivered. Driver tips and end-of-shift settlements. Customer tracking link shows estimated delivery time and driver location. Scope: ONLY delivery logistics and driver management, NOT order creation (handled by POS/IVR/Kiosk), NOT payment processing (handled by SPEC 021). Archived for future - not required for short-term ordering focus."

## Overview

This specification defines the Delivery Management & Driver Dispatch system for managing delivery driver fleet, automated order dispatch, route optimization, and real-time delivery tracking. Restaurant managers add drivers with profiles (name, phone, vehicle info) and track availability status (Available, On Delivery, Off Duty). When delivery order ready, system automatically assigns to available driver based on proximity to restaurant, current location, and delivery time constraints. Supports route optimization for multi-stop deliveries where single driver picks up multiple orders and system calculates optimal delivery sequence. Real-time GPS tracking shows driver location on map for restaurant staff and customers. Delivery workflow: Order Ready → Driver Assigned → Picked Up → En Route → Delivered with automatic status updates. Handles driver tips and end-of-shift settlements. Customers receive tracking link showing estimated delivery time and live driver location.

**Scope**: ONLY delivery logistics and driver management. Order creation is handled by SPEC 025 (POS Tablet), SPEC 003 (IVR), SPEC 004 (Kiosk). Payment processing is handled by SPEC 021.

**Note**: This specification is archived for future implementation - not required for short-term ordering focus (primarily relevant for delivery-focused restaurants, not pickup/dine-in).

## User Scenarios & Testing

### User Story 1 - Add Driver and Manage Availability (Priority: P1)

Restaurant manager accesses Business Dashboard, adds new delivery driver: Name "John Smith", Phone "555-1234", Vehicle "2020 Honda Civic - Plate ABC123", sets initial status Available. Driver appears in driver list. During shift, driver toggles status: Available ↔ Off Duty. When assigned delivery, status auto-updates to On Delivery. Manager views driver list showing all drivers with current status and location.

**Why this priority**: Core functionality - must have drivers in system before any dispatch can occur.

**Independent Test**: Can be fully tested by accessing Driver Management, adding driver "John Smith" with phone/vehicle details, setting status Available, verifying driver appears in active driver list, toggling status to Off Duty, confirming driver no longer receives dispatch assignments.

**Acceptance Scenarios**:

1. **Given** restaurant manager on Business Dashboard → Delivery → Driver Management, **When** manager clicks "Add Driver", enters Name: "John Smith", Phone: "555-1234", Vehicle Type: Car, Make/Model: "2020 Honda Civic", License Plate: "ABC123", sets Status: Available, clicks Save, **Then** system creates driver profile, displays in driver list: "John Smith - Available - Honda Civic ABC123", driver can now receive dispatch assignments
2. **Given** driver John Smith currently Available, **When** driver uses mobile app to toggle status to "Off Duty", **Then** driver status updates in system immediately, shows "John Smith - Off Duty" in manager dashboard, system excludes driver from dispatch algorithm until back to Available
3. **Given** driver John Smith assigned to delivery order, **When** assignment processes, **Then** driver status auto-updates to "On Delivery", displays "John Smith - On Delivery - Order #1234 - ETA 15min", driver location tracked on map in real-time

---

### User Story 2 - Auto-Dispatch Order to Available Driver (Priority: P1)

Delivery order #1234 completed by kitchen, marked "Ready for Pickup". System checks available drivers, finds 3 drivers with status Available, calculates proximity to restaurant (Driver A: 0.5 miles, Driver B: 1.2 miles, Driver C: 3.0 miles), assigns to Driver A (closest). Driver A receives push notification "New delivery - Order #1234 - Pick up at [Restaurant] - Deliver to [Address]". Driver accepts, status updates to On Delivery.

**Why this priority**: Critical for automated dispatch - manual assignment inefficient and error-prone for busy restaurants.

**Independent Test**: Can be fully tested by marking order #1234 "Ready for Pickup", verifying system queries available drivers (3 found), calculates distances, assigns to closest driver (Driver A 0.5mi away), driver receives notification, driver accepts, status updates to On Delivery.

**Acceptance Scenarios**:

1. **Given** delivery order #1234 marked "Ready for Pickup" at 6:45pm with delivery address "123 Main St", promised delivery time 7:15pm (30min window), **When** dispatch algorithm runs, **Then** system queries all drivers with status Available (finds: Driver A 0.5mi away, Driver B 1.2mi, Driver C 3.0mi), calculates best match based on proximity + current deliveries, assigns to Driver A (closest, no current deliveries)
2. **Given** Driver A assigned to order #1234, **When** assignment confirms, **Then** driver receives push notification: "New Delivery - Order #1234, Pick up: [Restaurant Name] 456 Oak Ave, Deliver: 123 Main St, ETA: 7:15pm, Customer: Jane Doe", driver app displays order details with Accept/Decline buttons
3. **Given** Driver A receives assignment notification, **When** driver taps "Accept" within 60 seconds, **Then** driver status updates to "On Delivery - Order #1234", restaurant dashboard shows "Order #1234 - Assigned to Driver A - Estimated Pickup 5 min", customer receives SMS "Your order is being prepared for delivery. Track your order: [tracking link]"

---

### User Story 3 - Optimize Multi-Stop Delivery Route (Priority: P2)

Driver B picks up 3 delivery orders ready simultaneously: Order #2001 (Address A - 2mi north), Order #2002 (Address B - 1mi east), Order #2003 (Address C - 3mi northeast). System calculates optimal delivery sequence considering distances and delivery time promises: Restaurant → Address B (closest) → Address A → Address C. Driver follows route, marks each delivery complete sequentially.

**Why this priority**: Important for driver efficiency and meeting delivery promises but not essential for single-order deliveries.

**Independent Test**: Can be fully tested by assigning driver 3 orders with different addresses, system calculating route optimization (shortest total distance), displaying sequence: Stop 1 (Address B 1mi), Stop 2 (Address A 2mi), Stop 3 (Address C 3mi), driver delivering in optimized order.

**Acceptance Scenarios**:

1. **Given** 3 delivery orders ready: #2001 (Address A - 2mi north, promised 7:30pm), #2002 (Address B - 1mi east, promised 7:20pm), #2003 (Address C - 3mi northeast, promised 7:45pm), **When** Driver B accepts all 3 orders (driver has capacity for 3 orders), **Then** system calculates optimal route: Restaurant → Address B (1mi, closest + earliest promise 7:20pm) → Address A (1mi additional, 7:30pm) → Address C (2mi additional, 7:45pm), total route: 4mi, estimated completion 7:40pm
2. **Given** Driver B following optimized route with 3 stops, **When** driver completes delivery at Address B, taps "Mark Delivered" for Order #2002, **Then** system updates order status to Delivered (7:18pm - 2min early), removes Address B from driver's active route, displays next stop: "Address A - 1.2mi - ETA 7:28pm - Order #2001"
3. **Given** route optimization considering delivery time promises, **When** system detects Address C delivery (7:45pm promise) would be late if driver follows distance-optimized route, **Then** system re-prioritizes: Restaurant → Address C first (3mi, deliver by 7:40pm to meet 7:45pm promise) → Address B (2mi) → Address A (1mi), sacrifices distance efficiency to meet time commitments

---

### User Story 4 - Track Delivery with Customer Link (Priority: P2)

Customer receives SMS with tracking link after driver assigned. Customer clicks link, opens tracking page showing: driver name "John Smith", estimated delivery time "7:15pm (12 minutes)", live map with driver location (blue dot) moving toward customer address (red pin), delivery status "En Route". Map updates every 10 seconds. When driver arrives, status updates to "Delivered", customer can rate delivery experience.

**Why this priority**: Important for customer experience and reducing "where's my order?" calls but not blocking for basic delivery functionality.

**Independent Test**: Can be fully tested by clicking customer tracking link, viewing map with driver location, observing location updates every 10 seconds as driver moves, verifying estimated delivery time updates based on driver progress, confirming status changes from "En Route" to "Delivered" upon completion.

**Acceptance Scenarios**:

1. **Given** customer receives SMS "Your delivery is on the way! Track your order: [link]", **When** customer clicks tracking link, **Then** page loads showing: Order #1234 status "En Route", Driver: "John Smith - Honda Civic ABC123", Estimated Delivery: "7:15pm (12 min)", Live Map: driver location (blue dot) at intersection of Elm & 5th, customer address (red pin) at 123 Main St, route line connecting driver to destination
2. **Given** customer viewing tracking page, **When** driver moves from Elm & 5th to Main & 3rd (0.5mi closer), **Then** map updates driver location within 10 seconds, estimated delivery time recalculates: "7:13pm (10 min)" based on current speed and distance, route line shortens showing remaining distance
3. **Given** driver arrives at customer address 123 Main St, **When** driver taps "Mark Delivered" in driver app at 7:14pm, **Then** tracking page updates immediately: Status "Delivered at 7:14pm", displays "Enjoy your meal! Rate your delivery experience" with 5-star rating, map shows driver at customer location (blue dot overlaps red pin)

---

### User Story 5 - Settle Driver Tips and Shift Payments (Priority: P3)

End of shift, Driver A completed 8 deliveries. Manager accesses Driver Settlement, views summary: 8 deliveries, total tips $45 (5 cash tips $25, 3 card tips $20 auto-deposited), mileage 32 miles, estimated reimbursement $19.20 ($0.60/mile). Manager marks cash tips paid out, generates settlement report for driver and accounting.

**Why this priority**: Nice-to-have for administrative tracking but not blocking for core delivery operations. Lower priority because tip/payment tracking can be manual initially.

**Independent Test**: Can be fully tested by completing 8 test deliveries with various tip amounts (cash and card), accessing Driver Settlement interface, verifying tip totals calculated correctly ($45 total), mileage tracked (32mi), reimbursement calculated ($19.20), generating settlement report PDF.

**Acceptance Scenarios**:

1. **Given** Driver A ending shift after 8 deliveries, **When** manager accesses Business Dashboard → Delivery → Driver Settlement, selects Driver A, **Then** displays shift summary: Driver: John Smith, Shift: 5:00pm-9:00pm (4 hours), Deliveries Completed: 8, Total Tips: $45 (Cash: $25, Card: $20), Miles Driven: 32, Mileage Reimbursement: $19.20 ($0.60/mi), Total Owed: $44.20 (cash tips $25 + mileage $19.20, card tips already deposited to driver account)
2. **Given** settlement summary showing $44.20 owed to driver, **When** manager pays out cash $44.20 to driver, marks "Paid in Full", **Then** system records payment timestamp, generates settlement receipt PDF: driver name, shift details, delivery count, tips breakdown, mileage reimbursement, payment confirmation, manager can print or email to driver and accounting
3. **Given** driver settlement history, **When** manager views Driver A performance over last 30 days, **Then** displays metrics: Total Deliveries: 95, Average Deliveries/Shift: 12, Total Tips: $520 ($5.47 avg per delivery), Total Miles: 380, Average Rating: 4.7 stars (from customer feedback)

---

### Edge Cases

- **What happens when no drivers available for dispatch?** System displays alert "No available drivers - Order #1234 waiting for assignment", notifies manager, order queues until driver becomes available (completes current delivery or toggles to Available)
- **How does system handle driver declining assignment?** If driver declines within 60 seconds, system immediately reassigns to next closest available driver, logs decline for analytics (Driver A declined 3 times today - may need coaching)
- **What happens when driver app loses GPS signal?** Last known location displays on map with timestamp "Last updated 5 minutes ago", tracking page shows "Driver location temporarily unavailable", location resumes updating when signal restored
- **How does system handle late deliveries?** System tracks promised delivery time vs actual delivery time, flags late deliveries (>10min past promise), displays alert to manager "Order #1234 delivered late (7:35pm, promised 7:20pm)", logs for performance analytics
- **What happens when customer not home at delivery?** Driver marks "Customer Not Available", attempts contact via phone, leaves order at safe location if allowed (contactless delivery), takes photo proof of delivery, logs details in order notes
- **How does system handle driver vehicle breakdown?** Driver sets status to "Off Duty - Vehicle Issue", manager manually reassigns active deliveries to other available drivers, customer receives SMS "Your delivery driver changed - New ETA: [time]"

---

## Requirements

### Functional Requirements

#### Driver Management
- **FR-001**: System MUST allow restaurant managers to add delivery drivers with profile: name, phone, vehicle type/make/model, license plate
- **FR-002**: System MUST track driver availability status: Available, On Delivery, Off Duty
- **FR-003**: System MUST allow drivers to toggle status Available ↔ Off Duty via driver mobile app
- **FR-004**: System MUST auto-update driver status to "On Delivery" when assigned to delivery order
- **FR-005**: System MUST display driver list in manager dashboard showing: driver name, current status, current location (if on delivery), active orders
- **FR-006**: System MUST allow managers to remove drivers from active roster
- **FR-007**: System MUST track driver GPS location in real-time when on delivery (10-second update interval)

#### Order Dispatch
- **FR-008**: System MUST trigger dispatch algorithm when delivery order marked "Ready for Pickup"
- **FR-009**: System MUST query all drivers with status "Available" for dispatch consideration
- **FR-010**: System MUST calculate driver proximity to restaurant (distance in miles)
- **FR-011**: System MUST assign order to closest available driver by default
- **FR-012**: System MUST send push notification to assigned driver with order details: order ID, pickup location, delivery address, customer name, promised delivery time
- **FR-013**: System MUST allow driver to accept or decline assignment within 60 seconds
- **FR-014**: System MUST reassign order to next closest driver if first driver declines
- **FR-015**: System MUST queue order for assignment if no drivers available, notify manager
- **FR-016**: System MUST update order status to "Driver Assigned" when driver accepts

#### Route Optimization (Multi-Stop Deliveries)
- **FR-017**: System MUST support assigning multiple orders to single driver (batch dispatch)
- **FR-018**: System MUST calculate optimal delivery sequence for multi-stop routes based on: distances between stops, delivery time promises, traffic conditions (if available)
- **FR-019**: System MUST prioritize time-sensitive deliveries (orders close to promised delivery time) over distance optimization
- **FR-020**: System MUST display delivery sequence to driver: Stop 1 (Address A), Stop 2 (Address B), Stop 3 (Address C) with distances and ETAs
- **FR-021**: System MUST recalculate route when driver marks delivery complete and removes completed stop from sequence
- **FR-022**: System MUST limit maximum orders per driver (default: 3 simultaneous orders, configurable)

#### Delivery Tracking
- **FR-023**: System MUST track delivery status workflow: Order Ready → Driver Assigned → Picked Up → En Route → Delivered
- **FR-024**: System MUST allow driver to update status via driver app: "Mark Picked Up", "Mark Delivered"
- **FR-025**: System MUST auto-update delivery status based on driver actions and GPS proximity to addresses
- **FR-026**: System MUST generate customer tracking link unique per order
- **FR-027**: System MUST display on tracking page: order ID, driver name/vehicle, estimated delivery time, live map with driver location, delivery status
- **FR-028**: System MUST update driver location on tracking map every 10 seconds
- **FR-029**: System MUST recalculate estimated delivery time based on driver progress and remaining distance
- **FR-030**: System MUST send SMS to customer when driver assigned: "Your order is on the way! Track: [link]"
- **FR-031**: System MUST send SMS to customer when driver near destination: "Your driver is arriving in 2 minutes"

#### Driver Tips & Settlements
- **FR-032**: System MUST track tips per delivery: cash tips (entered by driver), card tips (auto-captured from payment processing)
- **FR-033**: System MUST track driver mileage per shift based on GPS odometer
- **FR-034**: System MUST calculate mileage reimbursement based on configurable rate (default: $0.60/mile)
- **FR-035**: System MUST generate driver settlement report showing: shift duration, deliveries completed, total tips (cash + card), mileage driven, reimbursement owed
- **FR-036**: System MUST allow manager to mark settlement as "Paid in Full" with payment timestamp
- **FR-037**: System MUST generate settlement receipt PDF for driver and accounting records

### Key Entities

- **Driver**: Delivery driver profile - includes driver ID, name, phone number, vehicle type, make/model, license plate, availability status (Available/On Delivery/Off Duty), current location (GPS coordinates), active orders list (order IDs), shift start time, cumulative mileage
- **Delivery Order**: Order requiring delivery - includes order reference, pickup location (restaurant address), delivery address, customer name/phone, promised delivery time, assigned driver ID (if assigned), delivery status (Ready/Assigned/Picked Up/En Route/Delivered), pickup timestamp, delivery timestamp, estimated delivery time
- **Delivery Route**: Multi-stop delivery plan - includes driver reference, stop list (ordered sequence of delivery addresses), distances between stops, estimated completion time per stop, total route distance, total estimated duration
- **Delivery Assignment**: Driver-order pairing - includes assignment ID, driver reference, order reference, assignment timestamp, acceptance status (Pending/Accepted/Declined), decline reason (if declined)
- **Driver Settlement**: End-of-shift payment record - includes driver reference, shift date, shift duration, deliveries completed count, cash tips total, card tips total, mileage driven, reimbursement amount, total owed, payment status (Pending/Paid), payment timestamp
- **Delivery Tracking**: Customer tracking session - includes tracking link ID, order reference, driver location history (GPS coordinates with timestamps), customer views count, last viewed timestamp

---

## Success Criteria

### Measurable Outcomes

- **SC-001**: Order dispatch assigns driver within 30 seconds of order marked "Ready for Pickup"
- **SC-002**: Driver location updates on tracking map within 10 seconds of GPS position change
- **SC-003**: Estimated delivery time accuracy within ±5 minutes 80% of the time
- **SC-004**: Route optimization reduces total delivery distance by 15%+ for multi-stop routes vs non-optimized
- **SC-005**: Driver accepts assignment within 60 seconds 90%+ of time (low decline rate)
- **SC-006**: On-time delivery rate >90% (delivered within 10 minutes of promised time)

### Qualitative Measures

- Managers can efficiently manage driver fleet with real-time status visibility
- Drivers receive clear delivery instructions with optimized routes for multi-stop deliveries
- Customers have transparency into delivery progress through live tracking
- Driver settlements process quickly with automated tip/mileage calculations

---

## Dependencies

### Related Specifications

- **SPEC 006 - Order Fulfillment**: Delivery orders flow from fulfillment system when marked "Ready for Pickup"
- **SPEC 021 - Payment Processing**: Card tips from customer orders automatically tracked for driver settlements

### External Services

- **GPS/Mapping Service**: Provides real-time driver location tracking, route optimization, distance calculations
- **SMS Service**: Sends delivery status notifications and tracking links to customers

---

## Assumptions

1. **Driver Mobile App**: Drivers use dedicated mobile app for receiving assignments, updating delivery status, tracking mileage
2. **GPS Availability**: Drivers have smartphones with GPS enabled for real-time location tracking
3. **Update Frequency**: 10-second GPS update interval balances real-time accuracy with battery/data usage
4. **Mileage Reimbursement**: Default $0.60/mile based on IRS standard mileage rate, configurable per restaurant
5. **Multi-Stop Limit**: Maximum 3 simultaneous orders per driver balances efficiency with food quality (deliveries complete before food cools)
6. **Delivery Radius**: Typical delivery radius 3-5 miles from restaurant (configurable), beyond which delivery fees increase

---

## Out of Scope

1. **Order Creation**: Handled by SPEC 025 (POS Tablet), SPEC 003 (IVR), SPEC 004 (Kiosk)
2. **Payment Processing**: Handled by SPEC 021 (Payment Processing)
3. **Driver Payroll Integration**: Full payroll processing deferred to external payroll system
4. **Third-Party Delivery Integration**: Integration with DoorDash/UberEats/Grubhub deferred
5. **Driver Background Checks**: Background check and onboarding workflows deferred
6. **Advanced Route Optimization**: Real-time traffic, weather-based routing deferred to future iteration
7. **Driver Performance Reviews**: Detailed performance analytics and review workflows deferred

---

**Note**: This specification is archived for future implementation and not required for short-term ordering focus (primarily relevant for delivery-focused restaurants, not pickup/dine-in operations).
