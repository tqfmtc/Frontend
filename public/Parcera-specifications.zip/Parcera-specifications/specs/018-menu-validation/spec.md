# Feature Specification: Real-Time Menu Validation Engine

**Feature Branch**: `018-menu-validation`
**Created**: 2025-10-30
**Status**: Draft
**Constitution Alignment**: Principles I (AI-First), IV (Omnichannel), V (MVP Discipline)

---

## Overview

Real-time validation system that ensures menu items and customizations are valid during order entry across all channels (IVR, kiosk, mobile app). Validates item existence, customization compatibility, modifier constraints, dietary restrictions, pricing accuracy, and availability. Prevents invalid orders from being submitted by checking combinations in real-time as customers build their orders. Provides immediate feedback and alternative suggestions when validation fails.

**Core Value**: Prevents order errors, reduces customer frustration, eliminates kitchen confusion, and ensures accurate pricing before order submission.

---

## User Scenarios & Testing

### User Story 1 - Validate Item and Customization Combination (Priority: P0)

**As a** customer ordering via IVR
**I want** the system to validate my item and customization choices in real-time
**So that** I know immediately if my order is valid and don't waste time building an impossible order

**Why this priority**: Core feature value. Without real-time validation, customers can build invalid orders that fail at submission, causing frustration and abandoned orders.

**Independent Test**: Can be fully tested by: (1) customer calls IVR, (2) requests "large pepperoni pizza with gluten-free crust", (3) system validates item exists, (4) validates gluten-free crust is available for pizzas, (5) calculates price with modifier, (6) confirms order is valid. Delivers standalone value by preventing invalid order attempts.

**Acceptance Scenarios**:

1. **Given** customer orders "large pepperoni pizza with gluten-free crust" via IVR, **When** system validates request, **Then** system confirms: ✅ large pepperoni pizza exists in catalog, ✅ gluten-free crust is valid modifier for pizzas (+$3.00), ✅ combination allowed, returns total price $18.99
2. **Given** customer orders "Caesar salad with gluten-free crust", **When** system validates request, **Then** system detects incompatibility: ❌ gluten-free crust not applicable to salads, responds "Gluten-free crust is only available for pizzas. Would you like something else for your salad?"
3. **Given** customer orders "large pizza", **When** system calculates pricing, **Then** system returns: base pizza price + large size modifier + any topping modifiers, shows itemized breakdown
4. **Given** customer adds valid customization, **When** validation completes, **Then** system responds within 200ms with confirmation and updated total

---

### User Story 2 - Detect Conflicting Modifiers (Priority: P0)

**As a** customer ordering via mobile app
**I want** the system to detect when I select conflicting modifiers
**So that** I don't accidentally order contradictory items like "no cheese" and "extra cheese" together

**Why this priority**: Critical for order accuracy. Conflicting modifiers cause kitchen confusion and customer complaints when order arrives wrong.

**Independent Test**: Can be fully tested by: (1) customer selects menu item, (2) adds "no cheese" modifier, (3) attempts to add "extra cheese" modifier, (4) system detects conflict and prevents addition or requests clarification. Delivers value by eliminating contradictory orders.

**Acceptance Scenarios**:

1. **Given** customer has added "no cheese" to pizza order, **When** they attempt to add "extra cheese", **Then** system detects conflict, displays error "Cannot add 'extra cheese' when 'no cheese' is selected. Please remove 'no cheese' first or choose one option."
2. **Given** customer orders burger with "no onions" and "extra onions", **When** system validates modifiers, **Then** system flags conflict, asks "You selected both 'no onions' and 'extra onions'. Which would you prefer?"
3. **Given** customer selects valid non-conflicting modifiers, **When** validation runs, **Then** system allows order to proceed without warnings
4. **Given** conflicting modifiers exist in saved favorites, **When** customer reorders favorite, **Then** system detects conflict on load and prompts for resolution before adding to cart

---

### User Story 3 - Enforce Modifier Group Constraints (Priority: P0)

**As a** customer ordering via kiosk
**I want** the system to enforce modifier selection rules
**So that** I can only choose valid combinations (e.g., exactly 1 size, up to 3 toppings)

**Why this priority**: Essential for menu integrity. Without constraint enforcement, customers can build orders that violate business rules (e.g., no size selected, 10 free toppings).

**Independent Test**: Can be fully tested by: (1) customer selects pizza, (2) system requires exactly 1 size selection, (3) customer attempts to select 4th topping when limit is 3, (4) system prevents selection and shows message "Maximum 3 toppings allowed". Delivers value through automatic rule enforcement.

**Acceptance Scenarios**:

1. **Given** pizza item has modifier group "Size" with rule "choose exactly 1", **When** customer attempts to proceed without selecting size, **Then** system blocks order, displays "Please select a size: Small, Medium, or Large"
2. **Given** modifier group "Toppings" has rule "choose up to 3", **When** customer has selected 3 toppings and attempts to add 4th, **Then** system prevents selection, shows "Maximum 3 toppings. Remove one to add another."
3. **Given** modifier group "Sauce" has rule "choose 1-2", **When** customer selects no sauce, **Then** system prompts "Please select at least 1 sauce option"
4. **Given** customer completes modifier selections satisfying all constraints, **When** validation runs, **Then** system confirms order is valid and allows proceed to checkout

---

### User Story 4 - Check Real-Time Availability (Priority: P1)

**As a** customer ordering via IVR
**I want** to know immediately if an item is unavailable
**So that** I can choose an alternative instead of discovering unavailability at order submission

**Why this priority**: Improves customer experience by failing fast. Prevents customer from building entire order around unavailable item only to start over.

**Independent Test**: Can be fully tested by: (1) restaurant marks item as 86'd in system, (2) customer requests that item, (3) system checks real-time availability, (4) system responds "Filet-O-Fish is currently unavailable. May I suggest our Big Mac or McChicken instead?". Delivers value through immediate alternative suggestions.

**Acceptance Scenarios**:

1. **Given** menu item is marked 86'd (unavailable) in system, **When** customer requests that item, **Then** system checks availability status, responds "I'm sorry, [item name] is currently unavailable", suggests 2-3 alternatives from same category
2. **Given** item was available but gets 86'd during order building, **When** customer attempts to add it to cart, **Then** system performs real-time check, detects unavailability, notifies customer and suggests alternatives
3. **Given** item is available, **When** system validates order, **Then** validation passes availability check without warnings
4. **Given** customer has unavailable item in cart from earlier, **When** they proceed to checkout, **Then** system re-validates availability, removes unavailable items, notifies customer with alternatives

---

### User Story 5 - Validate Dietary Restrictions (Priority: P1)

**As a** customer with dietary restrictions
**I want** the system to warn me about allergens in items I'm ordering
**So that** I can make informed decisions and avoid health risks

**Why this priority**: Customer safety and satisfaction. While not blocking invalid orders, dietary warnings prevent potentially dangerous situations.

**Independent Test**: Can be fully tested by: (1) customer profile indicates nut allergy, (2) customer orders item containing nuts, (3) system checks ingredients against dietary restrictions, (4) system warns "This item contains nuts. Would you like to choose something else?". Delivers health-safety value.

**Acceptance Scenarios**:

1. **Given** customer profile indicates "nut allergy", **When** customer orders item containing nuts, **Then** system displays warning "⚠️ Warning: This item contains nuts. Are you sure you want to proceed?"
2. **Given** customer requests "vegetarian" filter, **When** browsing menu, **Then** system highlights vegetarian-compatible items, dims non-vegetarian items
3. **Given** customer is gluten-free, **When** ordering pizza with regular crust, **Then** system suggests "Would you like to substitute gluten-free crust for +$3?"
4. **Given** item has multiple allergen warnings, **When** customer adds to cart, **Then** system shows all applicable warnings: "Contains: nuts, dairy, gluten"

---

### Edge Cases

- What happens when customer requests customization that doesn't exist in menu at all?
  - System responds "I'm not familiar with [customization]. Our available options are [list]. Which would you like?"

- How does system handle when modifier price changes between adding to cart and checkout?
  - System uses price locked at add-to-cart time, displays "(price updated)" if change occurs before checkout

- What happens when two modifiers are mutually exclusive but not technically conflicting?
  - System allows both but shows info message: "Note: 'vegan cheese' and 'dairy cheese' both selected. Kitchen will use vegan."

- How does system handle regional or location-specific menu differences?
  - Validation uses menu catalog for customer's selected location. Item valid at Location A may be invalid at Location B.

- What happens when customer rapid-fire adds items faster than validation can process?
  - System queues validations, shows loading indicator, completes in order received, may batch validations for efficiency

- How does system handle menu updates during active order building?
  - Customer's cart uses menu snapshot from session start. Changes apply to new sessions only to prevent mid-order confusion.

- What happens when validation service is temporarily unavailable?
  - System logs error, allows order to proceed with warning "Unable to validate some options. Your order may require confirmation." Graceful degradation.

---

## Requirements

### Functional Requirements

**Item Validation**

- **FR-001**: System MUST validate menu item exists in catalog before allowing add to cart
- **FR-002**: System MUST check item against customer's selected location menu (multi-location support)
- **FR-003**: System MUST validate item category matches expected category for customizations (crust only for pizzas, dressing only for salads)
- **FR-004**: System MUST return item details including: name, description, base price, available modifier groups, dietary tags, availability status

**Customization Validation**

- **FR-005**: System MUST validate customizations are allowed for specific items (e.g., gluten-free crust only valid for pizza items)
- **FR-006**: System MUST validate customization exists in item's available modifier groups
- **FR-007**: System MUST check customization compatibility rules defined in menu configuration
- **FR-008**: System MUST return customization price modifiers (upcharge or discount) with validation response

**Modifier Group Constraints**

- **FR-009**: System MUST enforce "choose exactly N" constraints (e.g., must select exactly 1 size)
- **FR-010**: System MUST enforce "choose at least N" constraints (e.g., at least 1 sauce required)
- **FR-011**: System MUST enforce "choose at most N" constraints (e.g., maximum 3 toppings)
- **FR-012**: System MUST enforce "choose N to M" range constraints (e.g., select 1-2 proteins)
- **FR-013**: System MUST block order progression when required modifier groups are incomplete
- **FR-014**: System MUST provide clear error messages indicating which constraints are violated and how to fix

**Conflict Detection**

- **FR-015**: System MUST detect conflicting modifiers within same modifier group (e.g., "no cheese" + "extra cheese")
- **FR-016**: System MUST detect conflicting modifiers across different groups (e.g., "vegan" option + "add bacon")
- **FR-017**: System MUST use conflict rules defined in menu configuration (extensible conflict matrix)
- **FR-018**: System MUST prevent adding conflicting modifier or prompt for resolution before allowing
- **FR-019**: System MUST validate saved favorites and customer history for conflicts before reordering

**Pricing Calculation**

- **FR-020**: System MUST calculate accurate total price including base item price + all modifier upcharges/discounts
- **FR-021**: System MUST return itemized price breakdown showing: base price, each modifier with price impact, subtotal
- **FR-022**: System MUST handle percentage-based modifier pricing (e.g., "double meat" = +50% of base protein cost)
- **FR-023**: System MUST handle tiered pricing (e.g., first topping free, additional toppings $1.50 each)
- **FR-024**: System MUST lock prices at add-to-cart time, flagging any price changes before final checkout

**Availability Checking**

- **FR-025**: System MUST check real-time availability status for menu items (86'd items marked unavailable)
- **FR-026**: System MUST check modifier availability (e.g., gluten-free crust out of stock)
- **FR-027**: System MUST re-validate availability before final order submission (items may become unavailable during order building)
- **FR-028**: System MUST suggest 2-3 alternatives from same category when item unavailable
- **FR-029**: System MUST remove unavailable items from cart at checkout with customer notification

**Dietary Restrictions**

- **FR-030**: System MUST validate items against customer's dietary profile (allergies, preferences, restrictions)
- **FR-031**: System MUST warn customer when ordering item containing allergens they've flagged
- **FR-032**: System MUST display allergen information for menu items (contains: nuts, dairy, gluten, shellfish, etc.)
- **FR-033**: System MUST suggest suitable alternatives when dietary conflict detected
- **FR-034**: System MUST allow customer to proceed with order despite warnings (inform but don't block)

**Alternative Suggestions**

- **FR-035**: System MUST suggest alternatives when validation fails (item unavailable, customization invalid, dietary conflict)
- **FR-036**: System MUST rank alternatives by: same category, similar price point, popularity
- **FR-037**: System MUST provide 2-3 alternative suggestions maximum (avoid overwhelming customer)
- **FR-038**: System MUST explain why alternative is suggested (e.g., "Similar pizza, also comes in gluten-free")

**Validation API**

- **FR-039**: System MUST provide validation API endpoint callable by all ordering channels (IVR, kiosk, mobile)
- **FR-040**: System MUST return validation response within 200ms for real-time ordering experience
- **FR-041**: System MUST return structured response including: valid (boolean), errors (array), warnings (array), price breakdown, alternatives (if applicable)
- **FR-042**: System MUST support batch validation (multiple items/modifiers validated in single request for efficiency)
- **FR-043**: System MUST handle validation failures gracefully, returning partial results with specific error messages

**Performance & Reliability**

- **FR-044**: System MUST cache menu catalog per location with 5-minute TTL for performance
- **FR-045**: System MUST validate 95% of requests within 200ms (P95 latency target)
- **FR-046**: System MUST degrade gracefully if validation service unavailable (allow order with warning)
- **FR-047**: System MUST log all validation failures for debugging and menu configuration improvements

---

### Key Entities

- **Validation Request**: Input data for validation containing item_id, selected_modifiers (array), customer_dietary_profile, location_id, and session_id. Sent from ordering channel to validation engine.

- **Validation Response**: Structured output containing validation_status (valid/invalid/warning), errors (array of validation errors), warnings (array of non-blocking issues), price_breakdown (itemized costs), total_price, suggested_alternatives (if applicable), and response_timestamp.

- **Menu Item**: Product in catalog with item_id, name, category, base_price, available_modifier_groups, dietary_tags (vegetarian, gluten-free, contains_nuts, etc.), availability_status, and location_id. Referenced during validation.

- **Modifier Group**: Collection of related modifiers with group_name, selection_constraints (min, max required selections), modifiers (array), and applicable_items. Enforces selection rules.

- **Modifier**: Customization option with modifier_id, name, price_adjustment (upcharge/discount), dietary_impact, applicable_item_categories, conflicts_with (array of conflicting modifier IDs), and availability_status.

- **Conflict Rule**: Business logic defining incompatible combinations with rule_id, conflict_type (within_group, across_groups, dietary), affected_modifiers (array), and conflict_message. Extensible conflict matrix.

- **Dietary Profile**: Customer's dietary restrictions and preferences with customer_id, allergens (array), dietary_preferences (vegetarian, vegan, kosher, halal), and restriction_severity (allergy vs preference).

- **Alternative Suggestion**: Recommendation when validation fails with suggested_item_id, reason_for_suggestion, similarity_score, and price_comparison. Ranked by relevance.

- **Price Breakdown**: Itemized cost calculation with base_price, modifier_adjustments (array of {modifier_name, price_impact}), subtotal, and locked_timestamp. Transparent pricing.

---

## Success Criteria

### Measurable Outcomes

- Validation requests complete in under 200ms for 95% of orders
- Invalid order submissions reduced by 100% (no invalid orders reach kitchen)
- Order error rate (wrong items/modifiers) reduced by 90% compared to pre-validation baseline
- Customer order abandonment due to confusion reduced by 60%
- Average order resolution time (from start to submission) reduced by 20% through immediate feedback
- Alternative suggestion acceptance rate of 40%+ when primary item unavailable
- Zero orders submitted with conflicting modifiers (100% conflict detection)
- Dietary restriction warnings shown for 100% of applicable allergen matches

### Qualitative Measures

- Customers report confidence in order accuracy before submission
- Kitchen staff report fewer confused or impossible orders
- Customer support tickets related to wrong orders decrease significantly
- Customers appreciate immediate feedback vs discovering errors at submission
- Staff efficiency improves by not having to call customers back to clarify invalid orders

---

## Dependencies and Assumptions

### Dependencies

- Spec 002 (Menu Management) must provide structured menu catalog with items, modifiers, constraints, and pricing
- Spec 007 (POS Integration) must sync availability status (86'd items) in real-time or near-real-time
- Spec 003 (IVR), Spec 004 (Kiosk), Spec 005 (Mobile App) must call validation API during order building
- Spec 008 (Customer Identity) must provide dietary profile for dietary restriction validation

### Assumptions

- Menu catalog includes complete metadata: modifier groups, constraints, conflicts, dietary tags, pricing rules
- Restaurant staff keeps availability status updated in real-time (marking items 86'd when out)
- Validation response time of 200ms is acceptable for real-time ordering (customers don't notice delay)
- Most validation requests are valid (80%+ pass rate) - majority of validations are confirmatory
- Customers prefer immediate validation feedback over submitting and waiting for server-side rejection
- Menu configurations change infrequently (hourly or less) allowing effective caching
- Ordering channels handle validation errors gracefully with clear user messaging
- Database supports read-heavy workload (many validation queries per order)

### Out of Scope

- Menu catalog creation and management (handled by Spec 002 Menu Management)
- Inventory tracking and automated 86'ing (future enhancement - manual marking in MVP)
- Dynamic pricing based on demand or time of day (static pricing in MVP)
- Nutritional information and calorie calculations (beyond basic allergen warnings)
- Cross-sell and upsell suggestions unrelated to validation (e.g., "add fries?")
- Order optimization recommendations (e.g., "combo meal is cheaper")
- Integration with third-party nutrition databases (future enhancement)

---

**Status**: ✅ Ready for validation and `/speckit.plan` command
