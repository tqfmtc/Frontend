# Data Model: Menu Management System

**Feature**: 002-menu-management
**Created**: 2025-11-03
**Status**: Technical Specification
**PostgreSQL Version**: 14+

---

## Overview

This document defines the complete data model for the Menu Management System, including PostgreSQL schema definitions, entity relationships, Row-Level Security (RLS) policies, indexes, validation rules, and state transitions for menus, categories, items, customizations, base menu inheritance, OCR extraction, and AI knowledge base.

**Architecture Pattern**: Multi-Tenancy with Row-Level Security (extends SPEC 001)

---

## Entity Relationship Diagram

```plaintext
┌──────────────────┐
│   Restaurants    │ (from SPEC 001)
│ ──────────────── │
│ id (UUID, PK)    │
│ tenant_id (UUID) │
└────────┬─────────┘
         │
         │ 1:N
         │
┌────────▼──────────────┐         ┌─────────────────────────┐
│      Menus            │◄────────┤  MenuInheritance        │
│ ───────────────────── │  N:1    │ ─────────────────────── │
│ id (UUID, PK)         │         │ id (UUID, PK)           │
│ restaurant_id (FK)    │         │ branch_menu_id (FK)     │
│ location_id (FK)      │         │ base_menu_id (FK)       │
│ is_base_menu (BOOL)   │         │ item_id                 │
│ inherits_from_id (FK) │         │ override_type           │
└────────┬──────────────┘         └─────────────────────────┘
         │
         │ 1:N
         │
┌────────▼──────────────┐
│   MenuCategories      │
│ ───────────────────── │
│ id (UUID, PK)         │
│ menu_id (FK)          │
│ name                  │
│ display_order         │
└────────┬──────────────┘
         │
         │ 1:N
         │
┌────────▼────────────────────┐
│      MenuItems              │
│ ─────────────────────────── │
│ id (UUID, PK)               │
│ category_id (FK)            │
│ name                        │
│ base_price                  │
│ tags (JSONB)                │
│ dietary_attributes (JSONB)  │
└──────┬──────────────────────┘
       │
       ├──────────────────┬──────────────────┬─────────────────┐
       │ 1:N              │ 1:N              │ 1:N             │
       │                  │                  │                 │
┌──────▼────────┐  ┌──────▼─────────┐  ┌───▼─────────────┐  ┌────────────────────┐
│  ItemSizes    │  │ ItemModifiers  │  │ LocationPricing │  │ TimeAvailability   │
│ ────────────── │  │ ────────────── │  │ ─────────────── │  │ ────────────────── │
│ id (UUID, PK) │  │ id (UUID, PK)  │  │ id (UUID, PK)   │  │ id (UUID, PK)      │
│ item_id (FK)  │  │ item_id (FK)   │  │ item_id (FK)    │  │ entity_id (FK)     │
│ size_name     │  │ name           │  │ location_id(FK) │  │ entity_type        │
│ price_adj     │  │ price_adj      │  │ override_price  │  │ days_of_week []    │
└───────────────┘  │ modifier_group │  └─────────────────┘  │ start_time         │
                   │ min_selections │                       │ end_time           │
                   │ max_selections │                       └────────────────────┘
                   └────────────────┘

┌─────────────────────────────┐        ┌──────────────────────────┐
│  SeasonalItemSchedule       │        │  OCRExtractionJob        │
│ ─────────────────────────── │        │ ──────────────────────── │
│ id (UUID, PK)               │        │ id (UUID, PK)            │
│ item_id (FK)                │        │ restaurant_id (FK)       │
│ seasonal_name               │        │ uploaded_file_url        │
│ start_date                  │        │ extraction_status        │
│ end_date                    │        │ extracted_data (JSONB)   │
│ badge_text                  │        │ confidence_score         │
│ recurrence_pattern          │        │ review_status            │
└─────────────────────────────┘        └──────────────────────────┘

┌─────────────────────────────┐        ┌──────────────────────────┐
│  UnansweredQuestion         │        │  KnowledgeBaseEntry      │
│ ─────────────────────────── │        │ ──────────────────────── │
│ id (UUID, PK)               │        │ id (UUID, PK)            │
│ question_text               │        │ restaurant_id (FK)       │
│ conversation_channel        │        │ question_text            │
│ customer_session_id         │        │ answer_text              │
│ frequency_count             │        │ category_id (FK)         │
│ status                      │        │ embedding vector(1536)   │
└─────────────────────────────┘        │ usage_count              │
                                        └──────────────────────────┘

┌──────────────────────────────┐       ┌──────────────────────────┐
│  KnowledgeBaseCategory       │       │ KnowledgeBaseUsageLog    │
│ ──────────────────────────── │       │ ──────────────────────── │
│ id (UUID, PK)                │       │ id (UUID, PK)            │
│ restaurant_id (FK)           │       │ kb_entry_id (FK)         │
│ category_name                │       │ customer_question        │
│ parent_category_id (FK)      │       │ similarity_score         │
│ question_count               │       │ conversation_outcome     │
└──────────────────────────────┘       └──────────────────────────┘
```

---

## Schema Definitions

### 1. Menus Table

**Purpose**: Restaurant menus with base menu inheritance support

```sql
CREATE TABLE menus (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    location_id UUID REFERENCES locations(id) ON DELETE CASCADE,  -- NULL = base menu
    tenant_id UUID NOT NULL,  -- Denormalized for RLS

    -- Menu metadata
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),

    -- Base menu inheritance
    is_base_menu BOOLEAN NOT NULL DEFAULT false,
    inherits_from_menu_id UUID REFERENCES menus(id) ON DELETE SET NULL,

    -- Sync tracking
    sync_status VARCHAR(50) DEFAULT 'pending' CHECK (
        sync_status IN ('pending', 'syncing', 'synced', 'failed')
    ),
    last_synced_at TIMESTAMPTZ,

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT one_base_menu_per_restaurant UNIQUE (restaurant_id, is_base_menu)
        WHERE is_base_menu = true,
    CONSTRAINT base_menu_no_location CHECK (
        is_base_menu = false OR location_id IS NULL
    ),
    CONSTRAINT branch_menu_has_location CHECK (
        is_base_menu = true OR location_id IS NOT NULL
    ),
    CONSTRAINT no_self_inheritance CHECK (
        inherits_from_menu_id IS NULL OR inherits_from_menu_id != id
    )
);

-- Enable RLS
ALTER TABLE menus ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY tenant_isolation_policy ON menus
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

CREATE POLICY tenant_insert_policy ON menus
    FOR INSERT
    WITH CHECK (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_menus_tenant_id ON menus(tenant_id);
CREATE INDEX idx_menus_restaurant_id ON menus(restaurant_id);
CREATE INDEX idx_menus_location_id ON menus(location_id) WHERE location_id IS NOT NULL;
CREATE INDEX idx_menus_base_inheritance ON menus(inherits_from_menu_id) WHERE inherits_from_menu_id IS NOT NULL;
CREATE INDEX idx_menus_status ON menus(status);

-- Update trigger
CREATE TRIGGER update_menus_updated_at BEFORE UPDATE ON menus
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Comment
COMMENT ON TABLE menus IS 'Restaurant menus with base menu inheritance for multi-location chains';
```

**Validation Rules**:
- One base menu per restaurant (unique constraint)
- Base menus must have NULL location_id
- Branch menus must have non-NULL location_id
- Menu name required (max 255 characters)
- Sync status tracks cross-channel synchronization

---

### 2. MenuInheritance Table

**Purpose**: Tracks base menu inheritance and local overrides for branch locations

```sql
CREATE TABLE menu_inheritance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_menu_id UUID NOT NULL REFERENCES menus(id) ON DELETE CASCADE,
    base_menu_id UUID NOT NULL REFERENCES menus(id) ON DELETE CASCADE,
    item_id UUID NOT NULL,  -- References menu_items.id
    tenant_id UUID NOT NULL,

    -- Override type and data
    override_type VARCHAR(50) NOT NULL CHECK (
        override_type IN ('hidden_item', 'local_item', 'price_override', 'custom_description')
    ),
    override_value JSONB,  -- Store override data (e.g., {"price": 15.00})

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT unique_override_per_item UNIQUE (branch_menu_id, item_id, override_type),
    CONSTRAINT fk_branch_menu FOREIGN KEY (branch_menu_id)
        REFERENCES menus(id) ON DELETE CASCADE,
    CONSTRAINT fk_base_menu FOREIGN KEY (base_menu_id)
        REFERENCES menus(id) ON DELETE CASCADE
);

-- Enable RLS
ALTER TABLE menu_inheritance ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON menu_inheritance
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_menu_inheritance_tenant_id ON menu_inheritance(tenant_id);
CREATE INDEX idx_menu_inheritance_branch ON menu_inheritance(branch_menu_id);
CREATE INDEX idx_menu_inheritance_base ON menu_inheritance(base_menu_id);
CREATE INDEX idx_menu_inheritance_item ON menu_inheritance(item_id);

-- Comment
COMMENT ON TABLE menu_inheritance IS 'Tracks base menu overrides for branch locations';
```

**Override Types**:
- `hidden_item`: Branch hides base menu item
- `local_item`: Branch adds location-specific item not in base
- `price_override`: Branch sets different price than base
- `custom_description`: Branch customizes item description

**Example Override Data**:
```json
// price_override
{"price": 15.00}

// custom_description
{"description": "Made with locally-sourced organic beef"}

// local_item (item added by branch, not in base)
{"category_name": "Texas BBQ Specials", "is_exclusive": true}
```

---

### 3. MenuCategories Table

**Purpose**: Menu sections (Appetizers, Pizzas, Desserts, etc.)

```sql
CREATE TABLE menu_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    menu_id UUID NOT NULL REFERENCES menus(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Category metadata
    name VARCHAR(255) NOT NULL,
    description TEXT,
    display_order INT NOT NULL DEFAULT 0,

    -- Visual
    category_image_url VARCHAR(500),

    -- Availability
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT unique_category_name_per_menu UNIQUE (menu_id, name)
);

-- Enable RLS
ALTER TABLE menu_categories ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON menu_categories
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_menu_categories_tenant_id ON menu_categories(tenant_id);
CREATE INDEX idx_menu_categories_menu_id ON menu_categories(menu_id);
CREATE INDEX idx_menu_categories_display_order ON menu_categories(menu_id, display_order);

-- Update trigger
CREATE TRIGGER update_menu_categories_updated_at BEFORE UPDATE ON menu_categories
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Comment
COMMENT ON TABLE menu_categories IS 'Menu category groupings (Appetizers, Pizzas, etc.)';
```

**Validation Rules**:
- Category name unique within menu
- Display order used for sorting (drag-drop reordering)
- Category image optional (max 500 char URL)

---

### 4. MenuItems Table

**Purpose**: Individual menu items customers can order

```sql
CREATE TABLE menu_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id UUID NOT NULL REFERENCES menu_categories(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Item details
    name VARCHAR(255) NOT NULL,
    description TEXT,
    base_price DECIMAL(10, 2) NOT NULL CHECK (base_price >= 0),
    display_order INT NOT NULL DEFAULT 0,

    -- Media
    item_image_urls TEXT[],  -- Array of image URLs (max 5 per spec FR-008)

    -- Status
    status VARCHAR(20) NOT NULL DEFAULT 'available' CHECK (
        status IN ('available', 'sold_out', 'archived')
    ),

    -- Ingredient and dietary info (JSONB for flexibility)
    tags JSONB DEFAULT '[]'::jsonb,  -- Ingredient tags: ["wheat", "dairy", "eggs"]
    dietary_attributes JSONB DEFAULT '{
        "vegetarian": false,
        "vegan": false,
        "gluten_free": false,
        "dairy_free": false,
        "nut_free": false
    }'::jsonb,

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT valid_dietary_attributes CHECK (
        jsonb_typeof(dietary_attributes) = 'object' AND
        dietary_attributes ? 'vegetarian' AND
        dietary_attributes ? 'vegan'
    ),
    CONSTRAINT valid_tags CHECK (jsonb_typeof(tags) = 'array'),
    CONSTRAINT max_image_urls CHECK (array_length(item_image_urls, 1) <= 5)
);

-- Enable RLS
ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON menu_items
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_menu_items_tenant_id ON menu_items(tenant_id);
CREATE INDEX idx_menu_items_category_id ON menu_items(category_id);
CREATE INDEX idx_menu_items_status ON menu_items(status);
CREATE INDEX idx_menu_items_display_order ON menu_items(category_id, display_order);

-- GIN index for dietary attributes filtering
CREATE INDEX idx_menu_items_dietary ON menu_items USING GIN (dietary_attributes);
CREATE INDEX idx_menu_items_tags ON menu_items USING GIN (tags);

-- Update trigger
CREATE TRIGGER update_menu_items_updated_at BEFORE UPDATE ON menu_items
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Comment
COMMENT ON TABLE menu_items IS 'Menu items with pricing, dietary info, and ingredient tags';
```

**Validation Rules**:
- Base price must be >= 0
- Max 5 item images (FR-008 specifies max 5MB per image, validated at application layer)
- Tags and dietary_attributes stored as JSONB for flexible querying
- Dietary attributes validated at application layer (e.g., vegan requires dairy_free)

**Dietary Attributes Schema**:
```json
{
  "vegetarian": true,
  "vegan": false,
  "gluten_free": true,
  "dairy_free": false,
  "nut_free": true
}
```

---

### 5. ItemSizes Table

**Purpose**: Size variations for menu items (Small, Medium, Large)

```sql
CREATE TABLE item_sizes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Size details
    size_name VARCHAR(100) NOT NULL,  -- "Small", "Medium", "Large", "12-inch", "16-inch"
    price_adjustment DECIMAL(10, 2),  -- +$4.00 or NULL for absolute price
    absolute_price DECIMAL(10, 2),  -- $14.00 (if not using price_adjustment)
    display_order INT NOT NULL DEFAULT 0,

    -- Availability
    status VARCHAR(20) NOT NULL DEFAULT 'available' CHECK (
        status IN ('available', 'unavailable')
    ),

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT size_pricing_method CHECK (
        (price_adjustment IS NOT NULL AND absolute_price IS NULL) OR
        (price_adjustment IS NULL AND absolute_price IS NOT NULL)
    ),
    CONSTRAINT unique_size_per_item UNIQUE (item_id, size_name)
);

-- Enable RLS
ALTER TABLE item_sizes ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON item_sizes
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_item_sizes_tenant_id ON item_sizes(tenant_id);
CREATE INDEX idx_item_sizes_item_id ON item_sizes(item_id);

-- Comment
COMMENT ON TABLE item_sizes IS 'Size variations for menu items with pricing adjustments';
```

**Validation Rules**:
- Size name unique per item
- Either price_adjustment OR absolute_price required (not both)
- Price adjustment can be negative (e.g., -$2 for "Small")

**Example Data**:
```sql
-- Pizza with 3 sizes (price adjustments)
INSERT INTO item_sizes (item_id, tenant_id, size_name, price_adjustment, display_order)
VALUES
    ('pizza-id', 'tenant-id', 'Small (10")', -2.00, 1),
    ('pizza-id', 'tenant-id', 'Medium (14")', 0.00, 2),  -- Base price
    ('pizza-id', 'tenant-id', 'Large (18")', 4.00, 3);
```

---

### 6. ItemModifiers Table

**Purpose**: Add-ons, toppings, customization options

```sql
CREATE TABLE item_modifiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Modifier details
    name VARCHAR(255) NOT NULL,
    price_adjustment DECIMAL(10, 2) NOT NULL DEFAULT 0.00,  -- +$2.00 for "Extra Cheese"
    modifier_group VARCHAR(100),  -- "Toppings", "Sauces", "Extras"

    -- Selection rules
    min_selections INT DEFAULT 0 CHECK (min_selections >= 0),
    max_selections INT CHECK (max_selections IS NULL OR max_selections >= min_selections),
    display_order INT NOT NULL DEFAULT 0,

    -- Availability
    status VARCHAR(20) NOT NULL DEFAULT 'available' CHECK (
        status IN ('available', 'unavailable')
    ),

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT valid_selection_rules CHECK (
        min_selections >= 0 AND
        (max_selections IS NULL OR max_selections >= min_selections)
    )
);

-- Enable RLS
ALTER TABLE item_modifiers ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON item_modifiers
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_item_modifiers_tenant_id ON item_modifiers(tenant_id);
CREATE INDEX idx_item_modifiers_item_id ON item_modifiers(item_id);
CREATE INDEX idx_item_modifiers_group ON item_modifiers(modifier_group);

-- Comment
COMMENT ON TABLE item_modifiers IS 'Item customization options (toppings, sauces, extras)';
```

**Validation Rules**:
- Min selections >= 0
- Max selections >= min selections (or NULL for unlimited)
- Price adjustment can be 0 (e.g., "Sauce choice" free)
- Modifier group used for UI grouping (e.g., "Choose 1-3 toppings")

**Example Data**:
```sql
-- Pizza toppings (choose 1-3, each $1.50)
INSERT INTO item_modifiers (item_id, tenant_id, name, price_adjustment, modifier_group, min_selections, max_selections)
VALUES
    ('pizza-id', 'tenant-id', 'Pepperoni', 1.50, 'Toppings', 1, 3),
    ('pizza-id', 'tenant-id', 'Mushrooms', 1.50, 'Toppings', 1, 3),
    ('pizza-id', 'tenant-id', 'Extra Cheese', 2.00, 'Toppings', 1, 3);

-- Sauce choice (choose exactly 1, free)
INSERT INTO item_modifiers (item_id, tenant_id, name, price_adjustment, modifier_group, min_selections, max_selections)
VALUES
    ('burger-id', 'tenant-id', 'Ketchup', 0.00, 'Sauce', 1, 1),
    ('burger-id', 'tenant-id', 'Mayo', 0.00, 'Sauce', 1, 1),
    ('burger-id', 'tenant-id', 'BBQ Sauce', 0.00, 'Sauce', 1, 1);
```

---

### 7. LocationPricing Table

**Purpose**: Location-specific price overrides for multi-location chains

```sql
CREATE TABLE location_pricing (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
    location_id UUID NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Pricing
    override_price DECIMAL(10, 2) NOT NULL CHECK (override_price >= 0),

    -- Date range (optional for temporary pricing)
    effective_start_date DATE,
    effective_end_date DATE,

    -- Status
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (
        status IN ('active', 'inactive')
    ),

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT unique_item_location_pricing UNIQUE (item_id, location_id),
    CONSTRAINT valid_date_range CHECK (
        effective_end_date IS NULL OR effective_start_date IS NULL OR
        effective_end_date >= effective_start_date
    )
);

-- Enable RLS
ALTER TABLE location_pricing ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON location_pricing
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_location_pricing_tenant_id ON location_pricing(tenant_id);
CREATE INDEX idx_location_pricing_item_id ON location_pricing(item_id);
CREATE INDEX idx_location_pricing_location_id ON location_pricing(location_id);

-- Update trigger
CREATE TRIGGER update_location_pricing_updated_at BEFORE UPDATE ON location_pricing
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Comment
COMMENT ON TABLE location_pricing IS 'Location-specific price overrides for multi-location restaurants';
```

**Validation Rules**:
- One price override per item per location
- Override price must be >= 0
- Optional date range for temporary pricing (e.g., promotional pricing)
- If no override exists, item uses base_price from menu_items

**Example Data**:
```sql
-- California location: Burger $15 (base price $12)
INSERT INTO location_pricing (item_id, location_id, tenant_id, override_price, status)
VALUES ('burger-id', 'california-location-id', 'tenant-id', 15.00, 'active');

-- Texas location: Burger $12 (uses base price, no override needed)
-- No row in location_pricing table
```

---

### 8. TimeAvailability Table

**Purpose**: Time-based availability for menu items and categories

```sql
CREATE TABLE time_availability (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_id UUID NOT NULL,  -- menu_items.id OR menu_categories.id
    entity_type VARCHAR(20) NOT NULL CHECK (entity_type IN ('item', 'category')),
    location_id UUID REFERENCES locations(id) ON DELETE CASCADE,  -- Optional: location-specific
    tenant_id UUID NOT NULL,

    -- Time window
    days_of_week INT[] NOT NULL,  -- [0,1,2,3,4,5,6] (Sunday=0)
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,

    -- Timezone reference (inherited from location)
    timezone VARCHAR(50),  -- IANA timezone identifier (e.g., "America/New_York")

    -- Status
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (
        status IN ('active', 'inactive')
    ),

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT valid_days CHECK (
        array_length(days_of_week, 1) > 0 AND
        days_of_week <@ ARRAY[0,1,2,3,4,5,6]
    ),
    CONSTRAINT valid_entity_type CHECK (entity_type IN ('item', 'category'))
);

-- Enable RLS
ALTER TABLE time_availability ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON time_availability
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_time_availability_tenant_id ON time_availability(tenant_id);
CREATE INDEX idx_time_availability_entity ON time_availability(entity_id, entity_type);
CREATE INDEX idx_time_availability_days ON time_availability USING GIN (days_of_week);

-- Update trigger
CREATE TRIGGER update_time_availability_updated_at BEFORE UPDATE ON time_availability
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Comment
COMMENT ON TABLE time_availability IS 'Time-based availability for menu items/categories (breakfast/lunch/dinner)';
```

**Validation Rules**:
- Days of week array must contain valid values (0-6)
- Supports overnight windows (e.g., 22:00-02:00 where end_time < start_time)
- Timezone optional (defaults to location timezone if not specified)

**Example Data**:
```sql
-- Breakfast Burrito: Available Mon-Fri 6AM-11AM
INSERT INTO time_availability (entity_id, entity_type, days_of_week, start_time, end_time, location_id, tenant_id, timezone)
VALUES (
    'breakfast-burrito-id',
    'item',
    ARRAY[1,2,3,4,5],  -- Mon-Fri
    '06:00:00',
    '11:00:00',
    'downtown-location-id',
    'tenant-id',
    'America/New_York'
);

-- Late Night Menu Category: Every day 10PM-2AM
INSERT INTO time_availability (entity_id, entity_type, days_of_week, start_time, end_time, tenant_id, timezone)
VALUES (
    'late-night-category-id',
    'category',
    ARRAY[0,1,2,3,4,5,6],  -- Every day
    '22:00:00',
    '02:00:00',  -- Overnight window
    'tenant-id',
    'America/Chicago'
);
```

---

### 9. SeasonalItemSchedule Table

**Purpose**: Seasonal menu items with auto-scheduling (Halloween specials, holiday items)

```sql
CREATE TABLE seasonal_item_schedule (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Seasonal metadata
    seasonal_name VARCHAR(255) NOT NULL,  -- "Halloween Special", "Holiday Favorite"
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,

    -- Recurrence (for yearly recurring items)
    recurrence_pattern VARCHAR(50) CHECK (
        recurrence_pattern IS NULL OR recurrence_pattern IN ('yearly', 'none')
    ),

    -- Display
    display_badge_text VARCHAR(100) NOT NULL,  -- "Limited Time - Halloween Special!"
    badge_icon VARCHAR(50),  -- Emoji or icon identifier (e.g., "🎃", "❄️")

    -- Status
    status VARCHAR(20) NOT NULL DEFAULT 'scheduled' CHECK (
        status IN ('scheduled', 'active', 'ended')
    ),
    manual_override_date DATE,  -- Admin can enable early or disable early

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT valid_date_range CHECK (end_date >= start_date),
    CONSTRAINT unique_seasonal_item UNIQUE (item_id, start_date)
);

-- Enable RLS
ALTER TABLE seasonal_item_schedule ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON seasonal_item_schedule
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_seasonal_schedule_tenant_id ON seasonal_item_schedule(tenant_id);
CREATE INDEX idx_seasonal_schedule_item_id ON seasonal_item_schedule(item_id);
CREATE INDEX idx_seasonal_schedule_dates ON seasonal_item_schedule(start_date, end_date);
CREATE INDEX idx_seasonal_schedule_status ON seasonal_item_schedule(status);

-- Auto-enable/disable function
CREATE OR REPLACE FUNCTION update_seasonal_item_status()
RETURNS void AS $$
BEGIN
    -- Enable items whose start date has arrived
    UPDATE seasonal_item_schedule
    SET status = 'active'
    WHERE status = 'scheduled'
      AND start_date <= CURRENT_DATE
      AND (manual_override_date IS NULL OR manual_override_date <= CURRENT_DATE);

    -- Disable items whose end date has passed
    UPDATE seasonal_item_schedule
    SET status = 'ended'
    WHERE status = 'active'
      AND end_date < CURRENT_DATE
      AND (manual_override_date IS NULL OR manual_override_date < CURRENT_DATE);
END;
$$ LANGUAGE plpgsql;

-- Scheduled job (requires pg_cron or application scheduler)
-- SELECT cron.schedule('update-seasonal-items', '0 0 * * *', 'SELECT update_seasonal_item_status()');

-- Update trigger
CREATE TRIGGER update_seasonal_schedule_updated_at BEFORE UPDATE ON seasonal_item_schedule
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Comment
COMMENT ON TABLE seasonal_item_schedule IS 'Seasonal menu items with auto-scheduling (holidays, limited-time offers)';
```

**Validation Rules**:
- Start date <= end date
- Display badge text required (max 100 chars)
- Badge icon optional (emoji or icon identifier)
- Status auto-updated daily via scheduled job
- Manual override allows early enable/disable

**Example Data**:
```sql
-- Pumpkin Spice Latte: October 1-31 (yearly recurring)
INSERT INTO seasonal_item_schedule (item_id, tenant_id, seasonal_name, start_date, end_date, recurrence_pattern, display_badge_text, badge_icon, status)
VALUES (
    'pumpkin-latte-id',
    'tenant-id',
    'Halloween Special',
    '2025-10-01',
    '2025-10-31',
    'yearly',
    'Limited Time - Halloween Special!',
    '🎃',
    'scheduled'
);
```

---

### 10. OCRExtractionJob Table

**Purpose**: Track OCR menu extraction jobs

```sql
CREATE TABLE ocr_extraction_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Uploaded file
    uploaded_file_url VARCHAR(500) NOT NULL,  -- Blob storage URL
    file_type VARCHAR(50) NOT NULL CHECK (file_type IN ('image/jpeg', 'image/png', 'application/pdf')),

    -- OCR processing
    extraction_status VARCHAR(50) NOT NULL DEFAULT 'pending' CHECK (
        extraction_status IN ('pending', 'processing', 'completed', 'failed')
    ),
    extracted_data JSONB,  -- Raw OCR output + GenAI-processed data
    confidence_score DECIMAL(5, 4),  -- Average confidence 0.0000-1.0000

    -- Review workflow
    review_status VARCHAR(50) DEFAULT 'pending_review' CHECK (
        review_status IN ('pending_review', 'confirmed', 'rejected')
    ),

    -- Timestamps
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    processing_started_at TIMESTAMPTZ,
    processing_completed_at TIMESTAMPTZ,
    reviewed_at TIMESTAMPTZ,

    -- Error handling
    error_log TEXT,

    -- Constraints
    CONSTRAINT completed_requires_data CHECK (
        extraction_status != 'completed' OR extracted_data IS NOT NULL
    )
);

-- Enable RLS
ALTER TABLE ocr_extraction_jobs ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON ocr_extraction_jobs
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_ocr_jobs_tenant_id ON ocr_extraction_jobs(tenant_id);
CREATE INDEX idx_ocr_jobs_restaurant_id ON ocr_extraction_jobs(restaurant_id);
CREATE INDEX idx_ocr_jobs_extraction_status ON ocr_extraction_jobs(extraction_status);
CREATE INDEX idx_ocr_jobs_review_status ON ocr_extraction_jobs(review_status);

-- Comment
COMMENT ON TABLE ocr_extraction_jobs IS 'OCR menu extraction job tracking and results';
```

**Validation Rules**:
- Uploaded file URL required (Blob Storage URL)
- Confidence score: 0.0-1.0 (null if extraction failed)
- Extracted data stored as JSONB (raw OCR + GenAI-processed)
- Error log populated if extraction_status = 'failed'

**Extracted Data Schema**:
```json
{
  "raw_ocr": {
    "tables": [...],
    "confidence_average": 0.78
  },
  "genai_processed": {
    "categories": [
      {
        "name": "Pizzas",
        "items": [
          {
            "name": "Margherita Pizza",
            "description": "Classic tomato and mozzarella",
            "base_price": 12.00,
            "sizes": [{"name": "Large", "price": 18.00}],
            "modifiers": [{"name": "Extra Cheese", "price": 2.00}],
            "raw_text": "Margherita - $12 (Lg $18, +Cheese $2)"
          }
        ]
      }
    ],
    "confidence": 0.92,
    "warnings": []
  }
}
```

---

### 11. UnansweredQuestion Table

**Purpose**: Customer questions captured during conversations (AI Knowledge Base harvesting)

```sql
CREATE TABLE unanswered_questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Question metadata
    question_text TEXT NOT NULL,
    conversation_channel VARCHAR(50) NOT NULL CHECK (
        conversation_channel IN ('ivr', 'kiosk', 'mobile', 'web')
    ),
    customer_session_id VARCHAR(255),  -- Anonymized session ID

    -- Frequency tracking
    frequency_count INT NOT NULL DEFAULT 1 CHECK (frequency_count > 0),

    -- Status
    status VARCHAR(20) NOT NULL DEFAULT 'unanswered' CHECK (
        status IN ('unanswered', 'answered')
    ),
    matched_kb_entry_id UUID,  -- Set when answered (references knowledge_base_entries.id)

    -- Timestamps
    first_asked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_asked_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT answered_requires_kb_entry CHECK (
        status != 'answered' OR matched_kb_entry_id IS NOT NULL
    )
);

-- Enable RLS
ALTER TABLE unanswered_questions ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON unanswered_questions
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_unanswered_questions_tenant_id ON unanswered_questions(tenant_id);
CREATE INDEX idx_unanswered_questions_restaurant_id ON unanswered_questions(restaurant_id);
CREATE INDEX idx_unanswered_questions_status ON unanswered_questions(status);
CREATE INDEX idx_unanswered_questions_frequency ON unanswered_questions(frequency_count DESC);

-- Comment
COMMENT ON TABLE unanswered_questions IS 'Customer questions captured for AI Knowledge Base harvesting';
```

**Validation Rules**:
- Frequency count >= 1 (incremented for duplicate questions)
- Matched KB entry ID required if status = 'answered'
- Customer session ID anonymized (no PII)

---

### 12. KnowledgeBaseEntry Table

**Purpose**: Restaurant-specific FAQ answers and operational information

```sql
CREATE TABLE knowledge_base_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Question and answer
    question_text TEXT NOT NULL,
    answer_text TEXT NOT NULL,

    -- Categorization
    category_id UUID REFERENCES knowledge_base_categories(id) ON DELETE SET NULL,

    -- Vector embedding for semantic search
    embedding vector(1536),  -- OpenAI ada-002 embedding size (requires pgvector extension)

    -- Usage tracking
    usage_count INT NOT NULL DEFAULT 0,

    -- Metadata
    created_by UUID,  -- User ID who created
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Status
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (
        status IN ('active', 'inactive', 'archived')
    )
);

-- Enable RLS
ALTER TABLE knowledge_base_entries ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON knowledge_base_entries
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_kb_entries_tenant_id ON knowledge_base_entries(tenant_id);
CREATE INDEX idx_kb_entries_restaurant_id ON knowledge_base_entries(restaurant_id);
CREATE INDEX idx_kb_entries_category_id ON knowledge_base_entries(category_id);
CREATE INDEX idx_kb_entries_status ON knowledge_base_entries(status);

-- Vector similarity search index (requires pgvector extension)
CREATE INDEX idx_kb_entries_embedding ON knowledge_base_entries
USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 100);  -- Adjust based on data size

-- Update trigger
CREATE TRIGGER update_kb_entries_updated_at BEFORE UPDATE ON knowledge_base_entries
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Comment
COMMENT ON TABLE knowledge_base_entries IS 'AI Knowledge Base for restaurant FAQ and operational information';
```

**Validation Rules**:
- Question and answer text required
- Embedding vector required for semantic search (1536 dimensions for OpenAI ada-002)
- Usage count incremented when AI references entry in conversation
- Category optional (can be uncategorized)

---

### 13. KnowledgeBaseCategory Table

**Purpose**: Hierarchical categorization of knowledge base content

```sql
CREATE TABLE knowledge_base_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Category metadata
    category_name VARCHAR(255) NOT NULL,
    description TEXT,
    parent_category_id UUID REFERENCES knowledge_base_categories(id) ON DELETE CASCADE,
    display_order INT NOT NULL DEFAULT 0,

    -- Denormalized count (for performance)
    question_count INT NOT NULL DEFAULT 0,

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT unique_category_per_restaurant UNIQUE (restaurant_id, category_name),
    CONSTRAINT no_self_parent CHECK (parent_category_id IS NULL OR parent_category_id != id)
);

-- Enable RLS
ALTER TABLE knowledge_base_categories ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON knowledge_base_categories
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_kb_categories_tenant_id ON knowledge_base_categories(tenant_id);
CREATE INDEX idx_kb_categories_restaurant_id ON knowledge_base_categories(restaurant_id);
CREATE INDEX idx_kb_categories_parent ON knowledge_base_categories(parent_category_id);

-- Comment
COMMENT ON TABLE knowledge_base_categories IS 'Hierarchical categories for knowledge base organization';
```

**Predefined Categories** (from spec FR-046):
- Restaurant Policies (delivery, catering, reservations)
- Operational Details (hours, parking, dress code)
- Ingredient Sourcing (organic, local, halal)
- Preparation Methods (wood-fired, charcoal grilled, scratch-made)
- Special Accommodations (wheelchair access, kids menu, outdoor seating)

---

### 14. KnowledgeBaseUsageLog Table

**Purpose**: Audit trail for AI knowledge base lookups

```sql
CREATE TABLE knowledge_base_usage_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kb_entry_id UUID NOT NULL REFERENCES knowledge_base_entries(id) ON DELETE CASCADE,
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL,

    -- Question asked by customer
    customer_question TEXT NOT NULL,

    -- Conversation metadata
    conversation_channel VARCHAR(50) NOT NULL CHECK (
        conversation_channel IN ('ivr', 'kiosk', 'mobile', 'web')
    ),
    customer_session_id VARCHAR(255),

    -- Matching details
    semantic_similarity_score DECIMAL(5, 4) NOT NULL CHECK (
        semantic_similarity_score BETWEEN 0.0000 AND 1.0000
    ),

    -- Outcome
    conversation_outcome VARCHAR(50) CHECK (
        conversation_outcome IN ('answered_from_kb', 'led_to_order', 'escalated_to_staff')
    ),

    logged_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE knowledge_base_usage_log ENABLE ROW LEVEL SECURITY;

-- RLS Policy
CREATE POLICY tenant_isolation_policy ON knowledge_base_usage_log
    USING (tenant_id = current_setting('app.current_tenant', true)::UUID);

-- Indexes
CREATE INDEX idx_kb_usage_tenant_id ON knowledge_base_usage_log(tenant_id);
CREATE INDEX idx_kb_usage_kb_entry_id ON knowledge_base_usage_log(kb_entry_id);
CREATE INDEX idx_kb_usage_logged_at ON knowledge_base_usage_log(logged_at);
CREATE INDEX idx_kb_usage_outcome ON knowledge_base_usage_log(conversation_outcome);

-- Comment
COMMENT ON TABLE knowledge_base_usage_log IS 'Audit trail for AI knowledge base usage and effectiveness';
```

**Validation Rules**:
- Semantic similarity score: 0.0-1.0 (threshold >0.75 per spec SC-016)
- Conversation outcome tracks effectiveness
- Logged for analytics (most referenced answers, coverage gaps)

---

## Indexes Summary

### Performance Considerations

**RLS Queries** (Critical for multi-tenant):
- All tables with `tenant_id`: B-tree index for RLS policy filtering
- Composite indexes for common query patterns (tenant_id + status, category_id + display_order)

**Lookup Patterns**:
- Menu hierarchy queries: `menu_id`, `category_id` indexes for fast traversal
- Base menu inheritance: Index on `inherits_from_menu_id` for propagation queries
- Dietary filtering: GIN indexes on JSONB `dietary_attributes` and `tags`
- Time availability: GIN index on `days_of_week` array
- Vector search: IVFFlat index on `embedding` (pgvector)

**Query Performance Targets**:
- Menu listing: <50ms (10-20 categories, 50-100 items per menu)
- Item availability check: <20ms (time-based + seasonal rules)
- Knowledge base semantic search: <50ms (5K vectors)
- Base menu propagation: <2 seconds (20 branches, 100 items each)

---

## State Transitions

### Menu Lifecycle

```plaintext
┌─────────┐
│  draft  │
└────┬────┘
     │
     ├──(owner publishes)──> ┌───────────┐
     │                        │ published │
     │                        └─────┬─────┘
     │                              │
     │                              ├──(owner archives)──> ┌──────────┐
     │                              │                       │ archived │
     │                              │                       └──────────┘
     │                              │
     │                              └──(owner edits)──> draft (for review)
     │
     └──(owner deletes)──> deleted (soft delete via status)
```

**Transitions**:
- `draft` → `published`: Menu validation passed (at least 1 category with 1 item)
- `published` → `archived`: Menu no longer in use (historical data retained)
- `published` → `draft`: Owner makes edits (re-review before publishing)

### OCR Extraction Job Lifecycle

```plaintext
┌─────────┐
│ pending │
└────┬────┘
     │
     ├──(worker picks up)──> ┌────────────┐
     │                        │ processing │
     │                        └──────┬─────┘
     │                               │
     │                               ├──(success)──> ┌───────────┐
     │                               │                │ completed │
     │                               │                └─────┬─────┘
     │                               │                      │
     │                               │                      ├──(owner confirms)──> review_status='confirmed'
     │                               │                      │
     │                               │                      └──(owner rejects)──> review_status='rejected'
     │                               │
     │                               └──(error)──> ┌────────┐
     │                                              │ failed │
     │                                              └────────┘
     │
     └──(timeout)──> failed
```

**Transitions**:
- `pending` → `processing`: Async worker starts OCR job
- `processing` → `completed`: OCR + GenAI processing successful
- `processing` → `failed`: Error during processing (logged in error_log)
- `completed` + review='confirmed': Menu items imported to production
- `completed` + review='rejected': Owner discards extraction, re-uploads

### Seasonal Item Lifecycle

```plaintext
┌───────────┐
│ scheduled │
└─────┬─────┘
      │
      ├──(start_date reached)──> ┌────────┐
      │                           │ active │
      │                           └───┬────┘
      │                               │
      │                               └──(end_date passed)──> ┌───────┐
      │                                                        │ ended │
      │                                                        └───────┘
      │
      └──(manual override: early enable)──> active
```

**Transitions**:
- `scheduled` → `active`: Automated via daily cron job (start_date <= CURRENT_DATE)
- `active` → `ended`: Automated via daily cron job (end_date < CURRENT_DATE)
- Manual override allows early enable/disable (admin action)

---

## Configuration Management

Following generalized configuration pattern from global instructions:

### config.json (Non-Secrets)

```json
{
  "menu": {
    "max_items_per_restaurant": 500,
    "max_categories_per_menu": 50,
    "max_item_images": 5,
    "max_image_size_mb": 5
  },
  "ocr": {
    "provider": "azure_document_intelligence",
    "confidence_threshold": 0.7,
    "max_pages_per_upload": 10,
    "supported_formats": ["image/jpeg", "image/png", "application/pdf"],
    "max_file_size_mb": 10,
    "processing_timeout_seconds": 180
  },
  "genai": {
    "model": "gpt-4",
    "temperature": 0.2,
    "max_tokens": 2000,
    "cleanup_confidence_threshold": 0.85
  },
  "knowledge_base": {
    "embedding_model": "text-embedding-ada-002",
    "embedding_dimensions": 1536,
    "similarity_threshold": 0.75,
    "max_results": 5,
    "predefined_categories": [
      "Restaurant Policies",
      "Operational Details",
      "Ingredient Sourcing",
      "Preparation Methods",
      "Special Accommodations"
    ]
  },
  "seasonal": {
    "default_badge_templates": {
      "halloween": {"text": "Limited Time - Halloween Special!", "icon": "🎃"},
      "christmas": {"text": "Holiday Favorite!", "icon": "🎄"},
      "summer": {"text": "Summer BBQ Special!", "icon": "☀️"}
    }
  },
  "sync": {
    "channels": ["ivr", "mobile", "kiosk"],
    "sync_timeout_seconds": 30,
    "retry_attempts": 3
  }
}
```

### .env (Secrets)

```bash
# Azure Computer Vision
AZURE_COMPUTER_VISION_ENDPOINT=https://eastus.api.cognitive.microsoft.com/
AZURE_COMPUTER_VISION_KEY=<secret-key>

# Azure OpenAI (GenAI)
AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/
AZURE_OPENAI_KEY=<secret-key>
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4

# Azure Blob Storage (Menu Images)
AZURE_BLOB_CONNECTION_STRING=DefaultEndpointsProtocol=https;AccountName=...

# OpenAI Embeddings (Knowledge Base)
OPENAI_API_KEY=<secret-key>

# Database (extends SPEC 001)
DATABASE_URL=postgresql://parcera_app:password@localhost:5432/parcera_dev

# Redis (Cache + Job Queue)
REDIS_URL=redis://localhost:6379/0
```

---

## Migration Strategy

### Initial Schema Setup (MVP)

```sql
-- migrations/010_create_menu_schema.sql
-- Run order:
-- 1. Create menus table
-- 2. Create menu_categories table
-- 3. Create menu_items table
-- 4. Create item customization tables (item_sizes, item_modifiers)
-- 5. Create location_pricing table
-- 6. Create time_availability table (P2, can defer)
-- 7. Create seasonal_item_schedule table (P2, can defer)
-- 8. Create OCR tables (ocr_extraction_jobs)
-- 9. Create knowledge base tables (knowledge_base_entries, etc.)
-- 10. Enable RLS on all tables
-- 11. Create indexes
```

### pgvector Extension Setup

```sql
-- migrations/011_enable_pgvector.sql
-- Enable vector extension for knowledge base semantic search
CREATE EXTENSION IF NOT EXISTS vector;

-- Verify extension
SELECT * FROM pg_extension WHERE extname = 'vector';
```

---

## Backup & Disaster Recovery

### Backup Strategy

**Menu Data** (Critical):
- Full database backup: Daily at 2 AM UTC (includes all menu tables)
- Point-in-time recovery: Enabled (WAL archiving)
- Retention: 30 days for production

**Menu Images** (Blob Storage):
- Azure Blob Storage automatic replication (LRS or GRS)
- Soft delete enabled (30-day retention for deleted blobs)
- Retention: Indefinite for active menu images, 90 days for archived menus

**Knowledge Base Vectors**:
- Included in database backup (pgvector data stored in PostgreSQL)
- Embedding regeneration possible if lost (re-run OpenAI API calls)

### Data Retention

| Entity | Retention Policy |
|--------|------------------|
| Menus (active/published) | Indefinite |
| Menus (archived) | 2 years |
| MenuItems (active) | Indefinite |
| MenuItems (archived) | 1 year (order history requires item references) |
| OCRExtractionJobs (completed) | 90 days |
| OCRExtractionJobs (failed) | 30 days |
| UnansweredQuestions (answered) | 1 year |
| UnansweredQuestions (unanswered) | Indefinite (until answered) |
| KnowledgeBaseUsageLog | 1 year (analytics) |

---

## Security Considerations

### SQL Injection Prevention

- **Parameterized Queries**: All application queries use parameter binding
- **RLS Policy Isolation**: Session variables set via middleware (not user input)
- **JSONB Validation**: Pydantic models validate JSONB data before database write

### Tenant Data Isolation

**RLS Enforcement**:
- All menu tables have RLS enabled
- Policies enforce `tenant_id = current_setting('app.current_tenant')`
- Database role `parcera_app` has no BYPASSRLS privilege

### Vector Search Security

**Embedding Data**:
- Embeddings generated from restaurant-provided content only
- No cross-tenant embedding search (RLS restricts queries to tenant)
- pgvector index scoped to tenant_id via RLS

---

## Change Log

| Date | Author | Change |
|------|--------|--------|
| 2025-11-03 | System | Initial data model specification |

---

**End of Data Model Specification**
