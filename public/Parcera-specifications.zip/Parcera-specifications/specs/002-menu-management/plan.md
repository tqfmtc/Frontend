# Implementation Plan: Menu Management System

**Branch**: `002-menu-management` | **Date**: 2025-11-03 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `/specs/002-menu-management/spec.md`

**Note**: This template is filled in by the `/speckit.plan` command. See `.specify/templates/commands/plan.md` for the execution workflow.

## Summary

Comprehensive menu management system providing OCR-based menu extraction, manual menu creation, item customization (sizes/modifiers), location-based pricing, time-based availability, seasonal items, base menu inheritance for multi-location chains, and AI Knowledge Base with semantic search for restaurant FAQs. This builds on SPEC 001 (Restaurant Management) as the menu layer that feeds all ordering channels (IVR, mobile, kiosk).

## Technical Context

**Language/Version**: Python 3.11+ (aligned with SPEC 001)
**Primary Dependencies**: FastAPI, PostgreSQL 14+ with RLS, Azure Computer Vision (OCR), OpenAI API (GenAI post-processing & embeddings), pgvector extension for semantic search
**Storage**: PostgreSQL 14+ with row-level security for tenant isolation, pgvector for knowledge base embeddings
**Testing**: pytest for unit/integration, contract tests via OpenAPI schema validation
**Target Platform**: Linux server (Docker + Kubernetes deployment), RESTful API backend
**Project Type**: Web application (backend API + frontend business portal)
**Performance Goals**: <200ms p95 for menu queries, <30s for menu sync across channels, OCR extraction <2min for standard menu (1-4 pages), semantic search <100ms for KB queries
**Constraints**: Menu changes propagate within 30 seconds, support 500+ items per restaurant, OCR 85%+ accuracy, zero AI hallucination (KB-only responses), seasonal items auto-enable/disable without manual intervention
**Scale/Scope**: MVP: 50-100 restaurants with 50-200 items each, Phase 2: 500 restaurants, 3-Year: 5000+ restaurants with base menu inheritance for multi-location chains

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

### Principle I: AI-First Architecture ✅ CRITICAL

**Requirements from Constitution:**
- MUST integrate AI for menu extraction (OCR)
- MUST provide AI Knowledge Base with semantic search
- MUST prevent AI hallucination (restrict to menu + KB data)
- SHOULD leverage AI for conversation enhancements

**Alignment with Spec:**
- ✅ FR-001, FR-002, FR-002a: OCR + GenAI post-processing for menu extraction
- ✅ FR-040-FR-059: Complete AI Knowledge Base system with semantic matching
- ✅ FR-052, FR-053: AI hallucination prevention (KB-only responses)
- ✅ FR-051: Semantic similarity matching using vector embeddings
- ✅ User Story 1: OCR-based menu upload (P0 - AI differentiation)
- ✅ User Story 9: AI Knowledge Base & FAQ harvesting (P1 - AI accuracy)

**Gate Status:** ✅ PASS - This feature IS a core implementation of AI-First principle

**Blocking Decisions:** 
1. OCR service selection: Azure Computer Vision vs Tesseract (research needed)
2. Embedding model: OpenAI embeddings vs Azure Cognitive Search vs open-source (research needed)
3. Vector database: pgvector vs Pinecone vs Qdrant (research needed)

---

### Principle II: Multi-Tenancy by Design ✅

**Requirements from Constitution:**
- MUST implement row-level security with tenant isolation
- MUST support multi-location chains with base menu inheritance
- MUST use tenant context in all requests

**Alignment with Spec:**
- ✅ FR-010a-FR-010e: Base menu inheritance for multi-location chains
- ✅ FR-011: Location-specific price overrides
- ✅ User Story 4: Base menu inheritance (P1)
- ✅ All tables require tenant_id for RLS (inherited from SPEC 001)

**Gate Status:** ✅ PASS - Multi-tenancy inherited from SPEC 001 foundation

---

### Principle V: Progressive Enhancement & MVP Discipline ✅

**Requirements from Constitution:**
- MUST define P0/P1/P2/P3 priorities
- MUST design features as independently testable
- MUST validate standalone value

**Alignment with Spec:**
- ✅ User Story 1: P0 - OCR menu upload (MVP-critical, onboarding speed)
- ✅ User Story 2: P0 - Manual menu creation (fallback for OCR failures)
- ✅ User Story 3: P1 - Item customization (standard QSR operations)
- ✅ User Story 4: P1 - Base menu inheritance (multi-location chains)
- ✅ User Story 6: P2 - Time-based availability (breakfast/lunch/dinner)
- ✅ User Story 7: P2 - Ingredient tracking (dietary info)
- ✅ User Story 8: P2 - Seasonal items (marketing, not blocking)
- ✅ User Story 9: P1 - AI Knowledge Base (prevents hallucination)
- ✅ All stories independently testable with clear acceptance criteria

**Gate Status:** ✅ PASS - Proper prioritization applied

---

### Principle IV: Omnichannel by Default ✅

**Requirements from Constitution:**
- MUST maintain menu state across all channels
- MUST sync changes within 30s across IVR, mobile, kiosk

**Alignment with Spec:**
- ✅ FR-016: Menu changes sync to all channels within 30 seconds
- ✅ FR-022: Preview menu across different channels
- ✅ SC-004: 30-second synchronization target

**Gate Status:** ✅ PASS - Menu serves all ordering channels

---

### Overall Gate Assessment

**STATUS: ✅ PROCEED TO PHASE 0**

**Critical Decisions Needed (Phase 0 Research):**
1. OCR service selection: Azure Computer Vision vs Tesseract custom solution
2. GenAI post-processing: GPT-4 vs Azure OpenAI vs alternatives
3. Vector embedding strategy: OpenAI embeddings vs Azure vs open-source
4. Vector storage: pgvector (PostgreSQL extension) vs dedicated vector DB
5. Semantic similarity threshold for KB matching (recommended: 0.75-0.85)
6. Seasonal scheduling: Cron-based vs database triggers vs application scheduler
7. Menu synchronization: Real-time WebSocket vs polling vs event-driven (Kafka/RabbitMQ)

## Project Structure

### Documentation (this feature)

```text
specs/002-menu-management/
├── plan.md              # This file (/speckit.plan command output)
├── research.md          # Phase 0 output (/speckit.plan command)
├── data-model.md        # Phase 1 output (/speckit.plan command)
├── quickstart.md        # Phase 1 output (/speckit.plan command)
├── contracts/           # Phase 1 output (/speckit.plan command)
│   ├── menus.yaml
│   ├── menu-items.yaml
│   ├── ocr.yaml
│   └── knowledge-base.yaml
└── tasks.md             # Phase 2 output (/speckit.tasks command - NOT created by /speckit.plan)
```

### Source Code (repository root)

```text
backend/
├── src/
│   ├── models/
│   │   ├── menu.py                  # Menu, MenuCategory, MenuItem
│   │   ├── menu_customization.py   # ItemSize, ItemModifier
│   │   ├── menu_inheritance.py     # MenuInheritance, LocationPricing
│   │   ├── availability.py         # TimeAvailability, SeasonalItemSchedule
│   │   ├── ocr.py                  # OCRExtractionJob
│   │   └── knowledge_base.py       # KnowledgeBaseEntry, UnansweredQuestion, KBUsageLog
│   ├── services/
│   │   ├── menu_service.py         # Menu CRUD, category/item management
│   │   ├── ocr_service.py          # Azure CV integration, GenAI post-processing
│   │   ├── inheritance_service.py  # Base menu propagation, local overrides
│   │   ├── pricing_service.py      # Location-based pricing logic
│   │   ├── availability_service.py # Time-based, seasonal scheduling
│   │   ├── kb_service.py           # Knowledge base CRUD
│   │   ├── semantic_search.py      # Vector embeddings, similarity matching
│   │   └── sync_service.py         # Cross-channel menu synchronization
│   ├── api/
│   │   ├── v1/
│   │   │   ├── menus.py            # Menu endpoints
│   │   │   ├── menu_items.py       # Item endpoints
│   │   │   ├── ocr.py              # OCR upload/extraction endpoints
│   │   │   ├── knowledge_base.py   # KB management endpoints
│   │   │   └── unanswered.py       # Unanswered questions dashboard
│   │   └── middleware/
│   │       └── tenant_context.py   # Reused from SPEC 001
│   └── db/
│       ├── migrations/              # Alembic migrations (menu tables)
│       └── rls_policies.sql        # RLS for menu tables
└── tests/
    ├── contract/
    │   └── openapi_validation_test.py
    ├── integration/
    │   ├── test_menu_inheritance.py # Base menu propagation tests
    │   ├── test_ocr_extraction.py   # OCR accuracy tests
    │   ├── test_semantic_search.py  # KB matching tests
    │   └── test_seasonal_scheduling.py # Auto-enable/disable tests
    └── unit/
        ├── test_menu_service.py
        ├── test_pricing_service.py
        ├── test_availability_service.py
        └── test_kb_service.py

frontend/
├── src/
│   ├── components/
│   │   ├── MenuBuilder/            # Drag-drop menu editor
│   │   ├── OCRUploadWizard/        # Menu image upload UI
│   │   ├── ItemCustomizationEditor/ # Sizes/modifiers UI
│   │   ├── KnowledgeBaseDashboard/ # Unanswered questions UI
│   │   └── SeasonalScheduler/      # Seasonal item calendar UI
│   ├── pages/
│   │   ├── MenuManagement.tsx      # Main menu editor
│   │   ├── OCRExtraction.tsx       # OCR review/confirmation
│   │   ├── KnowledgeBase.tsx       # KB management
│   │   └── MenuPreview.tsx         # Cross-channel preview
│   └── services/
│       ├── menuApi.ts              # API client for menu endpoints
│       └── kbApi.ts                # API client for KB endpoints
└── tests/
    └── e2e/
        ├── ocr_extraction.spec.ts  # OCR flow tests
        ├── menu_inheritance.spec.ts # Base menu propagation tests
        └── kb_management.spec.ts   # Knowledge base UI tests
```

**Structure Decision**: Web application (Option 2) - Backend API provides menu management, OCR processing, and KB services. Frontend business portal provides self-service menu builder, OCR upload wizard, and knowledge base dashboard. Inherits multi-tenant architecture from SPEC 001.

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

No constitution violations detected. All gates passed.

**Note on Complexity**:
- OCR + GenAI post-processing adds complexity but is P0 requirement (Constitution Principle I: AI-First)
- Vector embeddings + semantic search required for AI hallucination prevention (FR-052, FR-053)
- Seasonal scheduling adds automation complexity but deferred to P2 (not MVP-blocking)
- Base menu inheritance adds complexity but is P1 requirement (multi-location chains core use case)
