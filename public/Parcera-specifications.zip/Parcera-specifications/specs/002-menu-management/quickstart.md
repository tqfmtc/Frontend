# Quickstart Guide: Menu Management Service

**Feature**: 002-menu-management
**Target Audience**: Backend developers implementing menu management APIs
**Prerequisites**: Python 3.11+, PostgreSQL 14+, Redis, Docker

---

## Table of Contents

1. [Development Environment Setup](#development-environment-setup)
2. [Database Setup](#database-setup)
3. [External Service Integration](#external-service-integration)
4. [Running the Service](#running-the-service)
5. [API Testing](#api-testing)
6. [Common Development Tasks](#common-development-tasks)

---

## Development Environment Setup

### 1. Clone Repository and Install Dependencies

```bash
# Navigate to project root
cd /path/to/parcera-backend

# Create Python virtual environment
python3.11 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Install development dependencies
pip install -r requirements-dev.txt
```

### 2. Environment Variables

Create `.env` file in project root:

```bash
# Copy from example
cp .env.example .env

# Edit .env with your credentials
# Required variables:
DATABASE_URL=postgresql://user:password@localhost:5432/parcera_dev
REDIS_URL=redis://localhost:6379/0

# Azure Computer Vision (OCR)
AZURE_COMPUTER_VISION_ENDPOINT=https://<resource>.cognitiveservices.azure.com/
AZURE_COMPUTER_VISION_KEY=<your-api-key>

# OpenAI (GenAI post-processing + embeddings)
OPENAI_API_KEY=<your-api-key>
OPENAI_EMBEDDING_MODEL=text-embedding-3-small

# AWS S3 (Image storage)
AWS_ACCESS_KEY_ID=<your-access-key>
AWS_SECRET_ACCESS_KEY=<your-secret-key>
AWS_S3_BUCKET_NAME=parcera-menu-images
AWS_REGION=us-east-1

# CloudFront CDN (optional)
CLOUDFRONT_DISTRIBUTION_URL=https://cdn.parcera.com

# JWT Authentication
JWT_SECRET_KEY=<generate-random-secret>
JWT_ALGORITHM=HS256

# Application
APP_ENV=development
APP_DEBUG=true
LOG_LEVEL=DEBUG
```

---

## Database Setup

### 1. Install PostgreSQL Extensions

```bash
# Connect to PostgreSQL
psql -U postgres -d parcera_dev

# Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS vector;  # pgvector for embeddings
```

### 2. Run Database Migrations

```bash
# Apply all migrations
alembic upgrade head

# Verify migrations
alembic current

# Expected output:
# 002_001_menu_tables (head)
# 002_002_seasonal_tables
# 002_003_knowledge_base_tables
# 002_004_pgvector_extension
```

### 3. Seed Default Data

```bash
# Seed dietary tags and KB categories
python scripts/seed_menu_data.py

# Output:
# ✅ Inserted 9 dietary tags (Vegan, Vegetarian, Gluten-Free, ...)
# ✅ Inserted 5 KB categories (Restaurant Policies, Operational Details, ...)
```

### 4. Create Test Tenant

```bash
# Create test restaurant tenant
python scripts/create_test_tenant.py

# Output:
# ✅ Created tenant: test-restaurant-uuid
# ✅ Created base menu: test-menu-uuid
# ✅ Created 3 sample categories with 15 items
```

---

## External Service Integration

### 1. Azure Computer Vision (OCR)

**Setup**:
1. Create Azure Cognitive Services resource in Azure Portal
2. Navigate to "Keys and Endpoint"
3. Copy `Endpoint` and `Key 1` to `.env` file

**Test Connection**:
```bash
python tests/integration/test_ocr_service.py

# Expected output:
# ✅ Azure Computer Vision connection successful
# ✅ OCR extraction test passed (confidence: 0.87)
```

### 2. OpenAI API (GenAI + Embeddings)

**Setup**:
1. Create OpenAI account at https://platform.openai.com
2. Generate API key in "API Keys" section
3. Copy key to `.env` file

**Test Connection**:
```bash
python tests/integration/test_genai_service.py

# Expected output:
# ✅ OpenAI GPT-4 connection successful
# ✅ Embedding generation test passed (dimensions: 1536)
```

### 3. AWS S3 (Image Storage)

**Setup**:
1. Create S3 bucket: `parcera-menu-images`
2. Create IAM user with S3 permissions
3. Copy access key and secret to `.env` file

**Bucket Policy** (allow CDN access):
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowCloudFrontRead",
      "Effect": "Allow",
      "Principal": {
        "Service": "cloudfront.amazonaws.com"
      },
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::parcera-menu-images/*"
    }
  ]
}
```

**Test Connection**:
```bash
python tests/integration/test_image_storage.py

# Expected output:
# ✅ S3 connection successful
# ✅ Image upload test passed
# ✅ CDN URL generated: https://cdn.parcera.com/test-tenant/items/test.jpg
```

---

## Running the Service

### 1. Start Redis (Required for Real-Time Sync)

```bash
# Using Docker
docker run -d -p 6379:6379 redis:7-alpine

# Or using local Redis
redis-server
```

### 2. Start Celery Beat (Seasonal Scheduler)

```bash
# In separate terminal
celery -A src.celery_app beat --loglevel=info

# Expected output:
# [2025-11-03 12:00:00,000] INFO: Scheduler: Sending due task process_seasonal_item_schedules
```

### 3. Start Celery Worker (Background Tasks)

```bash
# In separate terminal
celery -A src.celery_app worker --loglevel=info

# Expected output:
# [2025-11-03 12:00:00,000] INFO: celery@hostname ready.
```

### 4. Start FastAPI Server

```bash
# Development server with auto-reload
uvicorn src.main:app --reload --host 0.0.0.0 --port 8000

# Expected output:
# INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
# INFO:     Started reloader process using StatReload
```

### 5. Verify Service Health

```bash
# Health check endpoint
curl http://localhost:8000/health

# Expected response:
{
  "status": "healthy",
  "database": "connected",
  "redis": "connected",
  "services": {
    "ocr": "available",
    "genai": "available",
    "s3": "available"
  }
}
```

---

## API Testing

### 1. Generate JWT Token (Development)

```bash
# Create JWT token for test tenant
python scripts/generate_dev_token.py --tenant-id <test-tenant-uuid>

# Output:
# JWT Token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
# Expires: 2025-11-04 12:00:00 UTC
```

### 2. Test Menu CRUD Endpoints

```bash
# Set JWT token as environment variable
export JWT_TOKEN="<token-from-above>"

# List menus
curl -H "Authorization: Bearer $JWT_TOKEN" \
  http://localhost:8000/v1/menus

# Create category
curl -X POST -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "Appetizers", "description": "Starters and small plates"}' \
  http://localhost:8000/v1/menus/<menu-id>/categories

# Create item
curl -X POST -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "Caesar Salad", "base_price": 12.99, "ingredients": ["lettuce", "parmesan", "croutons"]}' \
  http://localhost:8000/v1/categories/<category-id>/items
```

### 3. Test OCR Extraction

```bash
# Upload menu for OCR
curl -X POST -H "Authorization: Bearer $JWT_TOKEN" \
  -F "file=@/path/to/menu.pdf" \
  -F "menu_name=Main Menu" \
  http://localhost:8000/v1/ocr/jobs

# Response:
{
  "job_id": "ocr-job-uuid",
  "status": "processing",
  "uploaded_file_url": "https://s3.amazonaws.com/parcera-menu-images/tenant-123/ocr_uploads/job-uuid.pdf"
}

# Poll job status (wait 10-30 seconds)
curl -H "Authorization: Bearer $JWT_TOKEN" \
  http://localhost:8000/v1/ocr/jobs/<job-id>

# Confirm extraction
curl -X POST -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"publish_immediately": true}' \
  http://localhost:8000/v1/ocr/jobs/<job-id>/confirm
```

### 4. Test Knowledge Base Semantic Search

```bash
# Create KB entry
curl -X POST -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "question_text": "Do you deliver?",
    "answer_text": "Yes, we deliver within 5 miles with $20 minimum order.",
    "category_id": "<category-uuid>"
  }' \
  http://localhost:8000/v1/knowledge-base/entries

# Semantic search
curl -X POST -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"question": "Can you deliver to my address?"}' \
  http://localhost:8000/v1/knowledge-base/search

# Expected response (semantic match):
{
  "matches": [
    {
      "entry_id": "kb-entry-uuid",
      "question": "Do you deliver?",
      "answer": "Yes, we deliver within 5 miles with $20 minimum order.",
      "similarity_score": 0.89,
      "category": "Restaurant Policies"
    }
  ]
}
```

### 5. Test Seasonal Item Scheduling

```bash
# Create seasonal schedule
curl -X POST -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "seasonal_name": "Halloween Special",
    "start_date": "2025-10-01",
    "end_date": "2025-10-31",
    "display_badge_text": "Limited Time - Available until Oct 31",
    "badge_icon": "🎃"
  }' \
  http://localhost:8000/v1/items/<item-id>/seasonal

# Manually trigger scheduler (for testing)
curl -X POST -H "Authorization: Bearer $JWT_TOKEN" \
  http://localhost:8000/v1/seasonal/trigger-scheduler

# Check item status (should be 'available' on Oct 1, 'archived' on Nov 1)
curl -H "Authorization: Bearer $JWT_TOKEN" \
  http://localhost:8000/v1/items/<item-id>
```

---

## Common Development Tasks

### 1. Add New API Endpoint

**Example**: Add endpoint to search menu items by name

**Step 1**: Define route in `src/api/v1/items.py`

```python
@router.get("/items/search")
async def search_items(
    q: str,
    tenant_id: str = Depends(get_current_tenant_id)
):
    """Search menu items by name (full-text search)"""
    results = await item_service.search_by_name(tenant_id, q)
    return {"items": results}
```

**Step 2**: Add service method in `src/services/item_service.py`

```python
async def search_by_name(tenant_id: str, query: str):
    stmt = select(MenuItem).where(
        MenuItem.tenant_id == tenant_id,
        MenuItem.name.ilike(f"%{query}%"),
        MenuItem.status == "available"
    )
    results = await db.execute(stmt)
    return results.scalars().all()
```

**Step 3**: Add test in `tests/unit/test_item_service.py`

```python
async def test_search_items_by_name():
    results = await item_service.search_by_name(tenant_id, "Caesar")
    assert len(results) == 1
    assert results[0].name == "Caesar Salad"
```

**Step 4**: Update OpenAPI contract in `contracts/items.yaml`

### 2. Run Tests

```bash
# Run all tests
pytest

# Run specific test file
pytest tests/unit/test_item_service.py

# Run with coverage
pytest --cov=src --cov-report=html

# View coverage report
open htmlcov/index.html
```

### 3. Database Migration

```bash
# Create new migration
alembic revision --autogenerate -m "Add new_column to menu_items"

# Review generated migration file
cat alembic/versions/<revision-id>_add_new_column.py

# Apply migration
alembic upgrade head

# Rollback migration
alembic downgrade -1
```

### 4. Monitor Celery Tasks

```bash
# View Celery task logs
tail -f celery-worker.log

# View scheduled tasks
celery -A src.celery_app inspect scheduled

# Manually trigger seasonal scheduler
celery -A src.celery_app call src.services.seasonal_scheduler.process_seasonal_item_schedules
```

### 5. Debug Vector Embeddings

```bash
# Test embedding generation
python scripts/test_embeddings.py

# Output:
# Question: "Do you deliver?"
# Embedding dimensions: 1536
# Sample values: [0.023, -0.014, 0.089, ...]

# Test semantic similarity
python scripts/test_semantic_search.py \
  --query "Can you deliver to my address?" \
  --tenant-id <tenant-uuid>

# Output:
# Top 3 matches:
# 1. "Do you deliver?" (similarity: 0.89)
# 2. "What's your delivery radius?" (similarity: 0.76)
# 3. "Do you have a delivery minimum?" (similarity: 0.72)
```

---

## Troubleshooting

### Issue: OCR extraction fails with "Unauthorized"

**Solution**: Verify Azure Computer Vision API key and endpoint in `.env`

```bash
# Test connection
curl -H "Ocp-Apim-Subscription-Key: $AZURE_COMPUTER_VISION_KEY" \
  "$AZURE_COMPUTER_VISION_ENDPOINT/formrecognizer/documentModels/prebuilt-read:analyze?api-version=2023-07-31"
```

### Issue: Embeddings search returns no results

**Solution**: Verify pgvector extension is installed

```bash
psql -d parcera_dev -c "SELECT * FROM pg_extension WHERE extname = 'vector';"

# If not installed:
psql -d parcera_dev -c "CREATE EXTENSION vector;"
```

### Issue: Seasonal items not auto-enabling at midnight

**Solution**: Verify Celery Beat is running and timezone is correct

```bash
# Check Celery Beat logs
tail -f celery-beat.log

# Verify restaurant timezone
psql -d parcera_dev -c "SELECT id, name, timezone FROM restaurants;"

# Manually trigger scheduler for testing
celery -A src.celery_app call src.services.seasonal_scheduler.process_seasonal_item_schedules
```

---

## Next Steps

1. **Implement Menu Sync**: Integrate Redis pub/sub for real-time menu sync to IVR, mobile, kiosk
2. **Add Caching**: Implement Redis caching for menu queries (<200ms p95 target)
3. **Optimize Vector Search**: Tune pgvector `ivfflat` index parameters for <500ms KB search
4. **Add Analytics**: Implement KB usage tracking and effectiveness metrics
5. **Load Testing**: Verify performance targets (200ms menu queries, 500ms KB search)

---

## Resources

- [OpenAPI Contracts](./contracts/) - API specifications
- [Data Model](./data-model.md) - Database schema reference
- [Research Decisions](./research.md) - Technical architecture decisions
- [Constitution](../../.specify/memory/constitution.md) - Project principles and guidelines

---

**Last Updated**: 2025-11-03
**Maintained By**: Backend Team
**Questions?**: Contact #backend-team on Slack
