# Feature Specification: Menu Management System

**Feature Branch**: `002-menu-management`
**Created**: 2025-10-29
**Status**: Draft
**Input**: User description: "Menu Management System - Comprehensive menu creation and management with OCR-based menu extraction from images/PDFs, category organization, item customization (sizes, modifiers, ingredients), pricing with location-based variations, time-based availability (breakfast/lunch/dinner menus), and real-time synchronization across all ordering channels (IVR, mobile, kiosk)."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Quick Menu Upload via OCR (Priority: P0)

A restaurant owner uploads a photo or PDF of their existing menu, the system extracts items using OCR, and the owner reviews and confirms the extracted menu structure in under 15 minutes, making their menu immediately available for ordering.

**Why this priority**: This is the fastest path to getting restaurants operational on the platform. Without a menu, no ordering can occur. OCR reduces onboarding time from hours (manual entry) to minutes, critical for Constitution Principle V (MVP Discipline) and the 2-hour onboarding goal mentioned in VTT discussions.

**Independent Test**: Can be fully tested by uploading a sample menu image, verifying OCR extraction accuracy, confirming extracted items, and checking that menu appears in all ordering channels. Delivers immediate value: restaurant can start accepting orders.

**Acceptance Scenarios**:

1. **Given** I have a PDF or image of my menu, **When** I upload it to the menu builder, **Then** the system extracts menu categories and items with names and prices
2. **Given** OCR has extracted my menu, **When** I review the extracted items, **Then** I can see a list of categories and items with confidence scores indicating extraction accuracy
3. **Given** I am reviewing extracted items, **When** I find an incorrect item name or price, **Then** I can edit it inline before confirming
4. **Given** I have confirmed my extracted menu, **When** I publish the menu, **Then** it becomes available across IVR, mobile app, and kiosk channels within 30 seconds
5. **Given** my menu is published, **When** a customer orders via any channel, **Then** they see the complete menu with correct pricing

---

### User Story 2 - Manual Menu Creation & Organization (Priority: P0)

A restaurant owner creates their menu from scratch by adding categories (Pizzas, Appetizers, Drinks), adding items to each category with descriptions and base prices, and organizing items in their preferred display order.

**Why this priority**: Not all restaurants have existing menu PDFs, or OCR may not work perfectly. Manual creation is the fallback and provides full control. Required for MVP as it's the baseline menu management capability.

**Independent Test**: Can be tested by creating a new menu, adding 3 categories with 5 items each, setting prices, and verifying the menu structure is saved and displayed correctly in ordering channels.

**Acceptance Scenarios**:

1. **Given** I am creating a new menu, **When** I click "Add Category" and enter "Pizzas", **Then** a new category is created and I can add items to it
2. **Given** I have created a category, **When** I click "Add Item" and enter name, description, and price, **Then** the item is added to the category
3. **Given** I have multiple items in a category, **When** I drag items to reorder them, **Then** the display order is updated and saved
4. **Given** I have multiple categories, **When** I reorder categories via drag-and-drop, **Then** customers see categories in my preferred order
5. **Given** I have created my menu, **When** I save it, **Then** all changes are persisted and reflected across all channels

---

### User Story 3 - Item Customization with Sizes & Modifiers (Priority: P1)

A restaurant owner configures customization options for menu items including sizes (Small, Medium, Large with different prices), modifiers (toppings, add-ons), and special instructions capability, enabling customers to personalize their orders.

**Why this priority**: Customization is standard for QSR operations (pizza toppings, burger add-ons, drink sizes). Critical for customer satisfaction and average order value but can be added after basic menu is working. Supports goal-oriented conversation engine requirements from VTT Olivia demo.

**Independent Test**: Can be tested by creating a pizza item with 3 sizes and 10 topping modifiers, ordering via IVR with customizations, and verifying the AI correctly captures size and toppings.

**Acceptance Scenarios**:

1. **Given** I am editing a menu item, **When** I enable "Sizes" and add Small ($10), Medium ($14), Large ($18), **Then** customers must choose a size when ordering
2. **Given** I am configuring an item, **When** I add modifiers like "Extra Cheese (+$2)" and "Pepperoni (+$1.50)", **Then** customers can select multiple modifiers
3. **Given** I have configured modifiers, **When** I set minimum and maximum selections (e.g., "Choose 1-3 toppings"), **Then** the ordering system enforces these rules
4. **Given** a customer is ordering a customizable item via IVR, **When** Olivia asks about size and toppings, **Then** the AI presents all available options naturally
5. **Given** a customized order is placed, **When** the order reaches the kitchen or third-party POS, **Then** all customizations are clearly displayed

---

### User Story 4 - Base Menu Inheritance & Location Customization (Priority: P1)

A restaurant owner creates a base menu that all locations inherit by default, then customizes specific locations by adding regional items (e.g., Texas location adds BBQ items), adjusting prices for market conditions (e.g., California pricing higher), or removing items not available at certain locations.

**Why this priority**: Core multi-location capability. Enables efficient menu management across branches while supporting regional variations. Critical for chains wanting consistency with local flexibility (Texas BBQ example, California vs Texas pricing from VTT Meeting 2).

**Independent Test**: Create base menu with 10 items, add new branch that inherits all items, add Texas-only BBQ category with 3 items to Texas branch, verify California branch doesn't show BBQ items, change base menu item and verify both branches updated except where local override exists.

**Acceptance Scenarios**:
1. **Given** I have created a base menu for my restaurant chain, **When** I add a new location/branch, **Then** the new branch automatically inherits all menu categories and items from the base menu
2. **Given** my Texas branch has inherited the base menu, **When** I add a "BBQ Specials" category with regional items (Brisket Plate, Pulled Pork Sandwich), **Then** these items appear only at the Texas location, not at other branches
3. **Given** I update an item in the base menu (e.g., change "Burger" description), **When** the change is saved, **Then** all branches see the updated description unless they have a local override
4. **Given** my California branch needs higher pricing, **When** I set location-specific pricing for all items (+20%), **Then** California customers see higher prices while Texas customers see base prices
5. **Given** a branch wants to hide certain base menu items, **When** the branch manager marks items as "Not Available at This Location", **Then** those items don't appear for customers ordering from that branch but remain in the base menu

---

### User Story 5 - Location-Based Pricing Variations (Priority: P1)

A restaurant owner with multiple locations can set different prices for the same menu item at different locations (e.g., California location charges $15 for a burger, Texas location charges $12), ensuring accurate pricing based on customer's selected location.

**Why this priority**: Mentioned in VTT Meeting 2 as a specific use case (California vs Texas pricing). Important for multi-location chains but not needed for single-location MVP. Enables regional pricing strategies.

**Independent Test**: Can be tested by creating a menu item, setting different prices for two locations, and verifying customers see location-specific pricing when ordering.

**Acceptance Scenarios**:

1. **Given** I have a menu item configured, **When** I select "Location-Specific Pricing" and set different prices for each location, **Then** the system stores per-location pricing
2. **Given** I have location-specific pricing, **When** a customer in California selects my restaurant, **Then** they see California pricing ($15)
3. **Given** location-specific pricing is set, **When** a customer in Texas orders the same item, **Then** they see Texas pricing ($12)
4. **Given** I want to update pricing, **When** I change the base price, **Then** I can choose to update all locations or keep overrides
5. **Given** some locations have custom pricing, **When** I add a new location, **Then** it inherits the base price by default

---

### User Story 6 - Time-Based Menu Availability (Priority: P2)

A restaurant owner can configure menu items or entire categories to be available only during specific time windows (e.g., Breakfast Menu 6AM-11AM, Lunch Menu 11AM-4PM, Dinner Menu 4PM-10PM), preventing customers from ordering unavailable items.

**Why this priority**: Mentioned in VTT discussions about time-based menus (breakfast menus). Valuable for operational efficiency but can be implemented after core menu management. Reduces food waste and customer confusion.

**Independent Test**: Can be tested by setting a "Breakfast Burrito" available only 6AM-11AM, attempting to order at 2PM, and verifying the item is not shown or marked unavailable.

**Acceptance Scenarios**:

1. **Given** I am editing a menu item, **When** I enable "Time-Based Availability" and set hours 6:00 AM - 11:00 AM, **Then** the item is only orderable during that window
2. **Given** I have a Breakfast category, **When** I set category availability 6:00 AM - 11:00 AM, **Then** all items in that category are unavailable outside that time
3. **Given** a customer is ordering at 10:00 AM, **When** they browse the menu, **Then** they see both Breakfast and Lunch items (overlapping windows)
4. **Given** a customer is ordering at 2:00 PM, **When** they try to order a Breakfast item, **Then** the item is hidden or marked "Not available until tomorrow 6:00 AM"
5. **Given** time-based availability is configured, **When** different locations have different timezones, **Then** availability is calculated using each location's local time

---

### User Story 7 - Ingredient Tracking for Dietary Info (Priority: P2)

A restaurant owner can tag menu items with ingredients and dietary attributes (vegetarian, vegan, gluten-free, contains nuts), enabling customers to filter menu items and AI voice assistant to provide accurate dietary information.

**Why this priority**: Important for customer safety (allergies) and preferences but not blocking for MVP. Enhances AI conversation quality (Olivia can say "This item contains nuts"). Supports health-conscious customer segment.

**Independent Test**: Can be tested by tagging items with ingredients, filtering menu for "vegan" items via mobile app, and asking Olivia "What's gluten-free?" via IVR.

**Acceptance Scenarios**:

1. **Given** I am editing a menu item, **When** I add ingredients like "wheat, dairy, eggs" from a predefined list, **Then** the system tracks ingredients for that item
2. **Given** I have tagged ingredients, **When** I mark dietary attributes (vegetarian, vegan, gluten-free), **Then** the system validates compatibility (e.g., can't be vegan if contains dairy)
3. **Given** items are tagged with dietary info, **When** a customer browses the mobile app, **Then** they can filter by "Vegan" or "Gluten-Free" to see only matching items
4. **Given** a customer calls via IVR, **When** they ask Olivia "Do you have anything gluten-free?", **Then** Olivia lists gluten-free menu items
5. **Given** a customer has severe allergies, **When** they ask "Does the Caesar Salad contain nuts?", **Then** Olivia accurately confirms or denies based on ingredient data

---

### User Story 8 - Seasonal Menu Items with Auto-Scheduling (Priority: P2)

A restaurant owner configures seasonal menu items that automatically appear and disappear based on configured date ranges (Halloween Pumpkin Spice Latte Oct 1-31, Christmas Eggnog Latte Dec 1-25, Valentine's Day Heart-Shaped Pizza Feb 1-14, Summer BBQ Platter Jun 1-Aug 31). System displays seasonal badge to customers ("Limited Time - Halloween Special!") and auto-enables/disables items on schedule without manual intervention.

**Why this priority**: Important for marketing seasonal offerings and creating urgency, but not blocking for core menu functionality. Seasonal items drive incremental revenue and customer excitement but require date-based availability infrastructure already planned for P2.

**Independent Test**: Can be tested by creating "Pumpkin Spice Latte" with seasonal dates Oct 1-31, verifying item appears in menu on Oct 1 with "Limited Time - Halloween Special!" badge, confirming item automatically hides on Nov 1 without manual action.

**Acceptance Scenarios**:

1. **Given** restaurant owner editing menu item "Pumpkin Spice Latte", **When** owner enables "Seasonal Item" and sets dates Oct 1 - Oct 31, seasonal name "Halloween Special", **Then** system saves seasonal configuration and schedules auto-enable on Oct 1 and auto-disable on Nov 1
2. **Given** seasonal item configured for Oct 1-31, **When** date changes to Oct 1 at midnight, **Then** system automatically enables item in menu catalog, displays "Limited Time - Halloween Special!" badge on item card across IVR/Kiosk/Mobile, customers can order item
3. **Given** seasonal item active during Oct 1-31 period, **When** customer browses menu via mobile app on Oct 15, **Then** item displays with prominent seasonal badge, badge text "Halloween Special - Available until Oct 31", visual indicator (e.g., pumpkin icon) draws attention
4. **Given** seasonal item configured to end Oct 31, **When** date changes to Nov 1 at midnight, **Then** system automatically disables item (marks unavailable), item no longer appears in customer-facing menus, historical orders retain reference to item
5. **Given** restaurant owner planning ahead, **When** owner creates Christmas items in September with seasonal dates Dec 1-25, **Then** items remain in draft/scheduled state, appear in owner's menu editor with "Scheduled for Dec 1" indicator, automatically go live on Dec 1

---

### User Story 9 - AI Knowledge Base & FAQ Harvesting (Priority: P1)

System captures customer questions from IVR/Kiosk/Mobile conversations that menu data cannot answer (e.g., "Do you deliver?", "What are your hours?", "Is parking available?", "Do you cater?"), logs as unanswered questions, prompts restaurant owner to provide answers, stores answers in knowledge base, and enables AI to reference knowledge base for future similar questions. AI is restricted from hallucinating responses - if information not in menu data or knowledge base, AI responds "Let me connect you with staff who can help with that."

**Why this priority**: Critical for preventing AI hallucination and building comprehensive restaurant knowledge beyond menu items. Customers frequently ask operational questions (hours, delivery, parking) that menu data cannot answer. Without knowledge base, AI either makes up answers (dangerous) or constantly escalates to staff (poor experience). P1 priority because AI accuracy directly impacts trust and order completion rates.

**Independent Test**: Can be tested by customer asking Olivia via IVR "Do you deliver?", system detecting question not answerable from menu data, logging unanswered question, restaurant owner reviewing unanswered questions dashboard, adding answer "Yes, we deliver within 5 miles with $20 minimum order", next customer asking same question receives accurate response from knowledge base.

**Acceptance Scenarios**:

1. **Given** customer calling via IVR asks Olivia "Do you deliver?", **When** AI detects question cannot be answered from menu data (no delivery information in menu), **Then** AI responds "Let me connect you with staff who can help with that", logs question "Do you deliver?" in Unanswered Questions dashboard, increments question frequency counter if duplicate
2. **Given** restaurant owner accesses Business Dashboard → Knowledge Base → Unanswered Questions, **When** dashboard loads, **Then** displays list of unanswered questions sorted by frequency: "Do you deliver?" (asked 15 times), "Is parking available?" (asked 8 times), "Do you cater?" (asked 5 times), each with "Add Answer" button
3. **Given** owner reviewing unanswered question "Do you deliver?", **When** owner clicks "Add Answer", enters "Yes, we deliver within 5 miles with $20 minimum order. Call us at 555-1234 to place delivery orders.", selects category "Delivery Policy", saves answer, **Then** system stores answer in knowledge base, marks question as answered, suggests similar questions to batch-answer: "What's your delivery radius?", "Do you have a delivery minimum?"
4. **Given** knowledge base contains answer for "Do you deliver?", **When** next customer asks Olivia "Can you deliver to my address?", **Then** AI matches question to knowledge base entry using semantic similarity, responds with verified answer "Yes, we deliver within 5 miles with $20 minimum order. What's your delivery address?", logs successful knowledge base usage
5. **Given** customer asks "What kind of meat do you use in your tacos?" (ingredient sourcing question), **When** menu data shows "Beef Tacos" but no sourcing details, **Then** AI responds "Let me connect you with staff for details about our ingredients", logs question "What kind of meat do you use in your tacos?" for owner review, owner later adds "We use 100% grass-fed beef from local farms" to knowledge base
6. **Given** owner reviewing knowledge base weekly, **When** owner views Knowledge Base Categories, **Then** sees organized categories: Restaurant Policies (delivery, catering, reservations), Operational Details (hours, parking, dress code), Ingredient Sourcing (organic, local, halal), Preparation Methods (wood-fired, charcoal grilled, scratch-made), Special Accommodations (wheelchair access, kids menu, outdoor seating), each with question count
7. **Given** AI in conversation with customer, **When** customer asks question requiring information, **Then** AI checks sources in priority order: (1) Menu data (items, prices, modifiers, dietary info), (2) Knowledge base (restaurant policies, operational details), (3) If not found in either, respond "Let me connect you with staff who can help with that" - AI NEVER invents or hallucinates answers

---

### Edge Cases

- What happens when OCR extraction fails completely? (System provides "Manual Entry" fallback and notifies owner to create menu manually)
- What happens when a restaurant uploads a menu in a language other than English? (OCR supports multiple languages via Azure Computer Vision, or manual entry is available)
- What happens when a customer orders an item that was just marked unavailable? (System checks availability at order submission and rejects with "Item no longer available" message)
- What happens when location-specific pricing isn't set for a new location? (System uses base price as default and prompts owner to review pricing)
- What happens when a time-based menu item is ordered right at the boundary (e.g., 10:59:59 AM when cutoff is 11:00 AM)? (System uses order placement time and allows if within window, warns "Last call for breakfast" near boundaries)
- What happens when a modifier is removed but existing orders reference it? (Historical orders retain removed modifier for record-keeping, but new orders cannot select it)
- What happens when two items have the same name in different categories? (System allows duplicate names across categories but warns owner of potential customer confusion)

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST support OCR extraction of menu items from uploaded images (JPG, PNG) and PDFs using OCR service (Tesseract-based custom solution or Microsoft Azure Cognitive Services Document Intelligence)
- **FR-002**: System MUST extract menu item names, descriptions, and prices with confidence scores from OCR
- **FR-002a**: System MUST use GenAI (GPT-4 or similar LLM) to post-process OCR output for cleaning and enhancement including: categorizing items into logical groups, identifying modifiers/toppings/options and linking them to items, correcting OCR errors, structuring data consistently, and enhancing item descriptions
- **FR-003**: System MUST allow restaurant owners to review and edit OCR-extracted and GenAI-enhanced menu items before publishing
- **FR-004**: System MUST allow restaurant owners to manually create menu categories and items
- **FR-005**: System MUST support drag-and-drop reordering of categories and items
- **FR-006**: System MUST allow restaurant owners to set base prices for menu items in local currency
- **FR-007**: System MUST support item descriptions (plain text, max 500 characters)
- **FR-008**: System MUST allow restaurant owners to upload item images (JPG, PNG, max 5MB per image)
- **FR-009**: System MUST support item customization with sizes (multiple price points per item)
- **FR-010**: System MUST support modifiers (add-ons) with individual pricing and min/max selection rules
- **FR-010a**: System MUST support base menu creation at restaurant tenant level that serves as template for all locations/branches
- **FR-010b**: System MUST automatically inherit base menu for new branches with option to customize locally
- **FR-010c**: System MUST allow branches to add location-specific menu items and categories (e.g., Texas BBQ specials) that don't appear at other branches
- **FR-010d**: System MUST allow branches to hide or mark base menu items as "Not Available at This Location" without deleting from base menu
- **FR-010e**: System MUST propagate base menu changes (item descriptions, categories) to all branches unless branch has local override
- **FR-011**: System MUST allow location-specific price overrides for multi-location restaurants
- **FR-012**: System MUST support time-based availability for items or entire categories with day-of-week and hour granularity
- **FR-013**: System MUST allow restaurant owners to tag items with ingredients from a predefined list
- **FR-014**: System MUST allow restaurant owners to mark dietary attributes (vegetarian, vegan, gluten-free, dairy-free, nut-free)
- **FR-015**: System MUST validate dietary attribute consistency with ingredient tags (e.g., vegan cannot contain dairy)
- **FR-016**: System MUST synchronize menu changes to all ordering channels (IVR, mobile, kiosk) within 30 seconds
- **FR-017**: System MUST provide menu item search functionality by name or ingredient for restaurant owners
- **FR-018**: System MUST allow restaurant owners to mark items as "Sold Out" or "Temporarily Unavailable"
- **FR-019**: System MUST allow restaurant owners to duplicate existing items to create variants
- **FR-020**: System MUST support bulk enable/disable of items or categories
- **FR-021**: System MUST track menu change history with timestamps and user attribution
- **FR-022**: System MUST allow restaurant owners to preview menu as customers see it across different channels
- **FR-023**: System MUST validate menu completeness (at least 1 category with 1 item) before allowing publication
- **FR-024**: System MUST support archiving of deleted items (soft delete) to preserve order history
- **FR-025**: System MUST enforce unique item names within a category (warn on duplicates across categories)
- **FR-026**: System MUST provide menu templates for common cuisine types (Pizza, Burgers, Asian, etc.) to accelerate setup
- **FR-027**: System MUST support copying menus across locations with bulk pricing adjustments
- **FR-028**: System MUST integrate with third-party POS systems to sync menu data where applicable

#### Seasonal Menu Items

- **FR-029**: System MUST allow restaurant owners to configure menu items as seasonal with start date and end date
- **FR-030**: System MUST allow restaurant owners to set seasonal display name/badge text (e.g., "Halloween Special", "Holiday Favorite", "Summer BBQ")
- **FR-031**: System MUST automatically enable seasonal items on configured start date at midnight (restaurant local time)
- **FR-032**: System MUST automatically disable seasonal items on configured end date +1 day at midnight (item available through end date, disabled next day)
- **FR-033**: System MUST display seasonal badge on item cards across all ordering channels (IVR describes verbally, Kiosk/Mobile shows visual badge)
- **FR-034**: System MUST include availability end date in seasonal badge text: "Halloween Special - Available until Oct 31"
- **FR-035**: System MUST allow seasonal items to be created in advance with future start dates (scheduled/draft state until start date)
- **FR-036**: System MUST show seasonal schedule status in menu editor: "Active", "Scheduled for [date]", "Ended on [date]"
- **FR-037**: System MUST preserve historical orders referencing seasonal items after they expire (soft delete, archive)
- **FR-038**: System MUST allow restaurant owners to manually override seasonal availability (enable early, disable early, extend end date)
- **FR-039**: System MUST support recurring seasonal items (same item available every year during same date range)

#### AI Knowledge Base & FAQ Harvesting

- **FR-040**: System MUST capture customer questions from IVR/Kiosk/Mobile conversations that AI cannot answer from menu data
- **FR-041**: System MUST log unanswered questions with: question text, timestamp, conversation channel, customer session ID (anonymized)
- **FR-042**: System MUST deduplicate similar questions and increment frequency counter for repeats
- **FR-043**: System MUST provide "Unanswered Questions" dashboard in Business Dashboard accessible to restaurant owners
- **FR-044**: System MUST sort unanswered questions by frequency (most asked questions at top)
- **FR-045**: System MUST allow restaurant owners to add answers to unanswered questions with rich text formatting
- **FR-046**: System MUST organize knowledge base answers into categories: Restaurant Policies, Operational Details, Ingredient Sourcing, Preparation Methods, Special Accommodations
- **FR-047**: System MUST allow restaurant owners to assign category when answering questions
- **FR-048**: System MUST suggest similar unanswered questions when owner answers one question (batch answering capability)
- **FR-049**: System MUST store knowledge base answers with: question, answer text, category, creation date, last modified date, usage count
- **FR-050**: System MUST make knowledge base answers available to AI across all conversation channels (IVR, Kiosk, Mobile)
- **FR-051**: System MUST enable AI to match customer questions to knowledge base entries using semantic similarity (not exact text match)
- **FR-052**: System MUST restrict AI from generating responses not found in menu data or knowledge base (prevent hallucination)
- **FR-053**: System MUST require AI to respond "Let me connect you with staff who can help with that" when information not available in menu or knowledge base
- **FR-054**: System MUST log successful knowledge base usages: which question was asked, which KB entry matched, conversation outcome
- **FR-055**: System MUST provide knowledge base analytics: most referenced answers, answer effectiveness (led to order vs escalation), coverage gaps
- **FR-056**: System MUST allow restaurant owners to edit/update knowledge base answers over time
- **FR-057**: System MUST allow restaurant owners to mark knowledge base entries as inactive/archived without deleting
- **FR-058**: System MUST define AI information source priority: (1) Menu data (items, prices, modifiers, dietary info), (2) Knowledge base (policies, operational details), (3) Escalate to staff if not found
- **FR-059**: System MUST provide knowledge base seeding with common restaurant questions and template answers: "Do you deliver?", "What are your hours?", "Do you cater?", "Is parking available?", allowing owners to customize templates

### Key Entities

- **Menu**: The complete menu for a restaurant tenant. Contains menu ID, restaurant ID (foreign key), location ID (nullable - null indicates base menu for all locations), name, description, status (draft, published, archived), is_base_menu flag, inherits_from_menu_id (nullable - references base menu if this is branch customization), creation date, last modified date, and sync status across channels.

- **MenuInheritance**: Tracks base menu inheritance and local overrides. Contains inheritance ID, branch_location_id, base_menu_id, override_type (hidden_item, local_item, price_override, custom_description), item_id (affected item), override_value (JSON), created_date.

- **MenuCategory**: A grouping of related menu items (e.g., "Pizzas", "Appetizers"). Contains category ID, menu ID (foreign key), name, description, display order, time-based availability (optional start/end time), status (active, inactive), and category image URL.

- **MenuItem**: An individual item customers can order. Contains item ID, category ID (foreign key), name, description, base price, item image URLs (array), status (available, sold out, archived), tags (ingredients array), dietary attributes (flags for vegetarian, vegan, etc.), display order, creation date, and last modified date.

- **ItemSize**: Size variations for a menu item (Small, Medium, Large). Contains size ID, item ID (foreign key), size name, price adjustment (or absolute price), display order, and availability status.

- **ItemModifier**: Add-ons or customization options for items. Contains modifier ID, item ID (foreign key), name, price adjustment, modifier group (e.g., "Toppings"), min selections (default 0), max selections (default unlimited), display order, and availability status.

- **LocationPricing**: Location-specific price overrides. Contains pricing ID, item ID (foreign key), location ID (foreign key), override price, effective date range (optional), and status (active, inactive).

- **TimeAvailability**: Time-based availability rules. Contains availability ID, entity ID (menu item or category), entity type, days of week (array or bitmask), start time, end time, timezone reference, and status (active, inactive).

- **OCRExtractionJob**: Tracking for OCR processing. Contains job ID, restaurant ID, uploaded file URL, extraction status (pending, processing, completed, failed), confidence score, extracted data (JSON blob), review status (pending review, confirmed, rejected), and timestamps.

- **SeasonalItemSchedule**: Seasonal availability configuration for menu items. Contains schedule ID, item ID (foreign key), seasonal name (e.g., "Halloween Special", "Holiday Favorite"), start date, end date, recurrence pattern (nullable - for yearly recurring items), display badge text, badge icon/emoji, status (scheduled, active, ended), manual override (nullable - early enable/disable date), creation date, last modified date.

- **UnansweredQuestion**: Customer questions captured during conversations that AI could not answer from menu or knowledge base. Contains question ID, question text, conversation channel (IVR, Kiosk, Mobile), customer session ID (anonymized), timestamp, frequency count (incremented for duplicates), status (unanswered, answered), matched KB entry ID (nullable - set when answered), restaurant ID.

- **KnowledgeBaseEntry**: Restaurant-specific FAQ answers and operational information. Contains KB entry ID, restaurant ID, original question text, answer text (rich text/markdown), category ID (foreign key), creation date, last modified date, created by user ID, usage count (how many times AI referenced this), status (active, inactive, archived).

- **KnowledgeBaseCategory**: Hierarchical categorization of knowledge base content. Contains category ID, restaurant ID, category name (e.g., "Restaurant Policies", "Operational Details", "Ingredient Sourcing", "Preparation Methods", "Special Accommodations"), description, parent category ID (nullable - for sub-categories), display order, question count (denormalized for performance).

- **KnowledgeBaseUsageLog**: Audit trail for AI knowledge base lookups. Contains log ID, KB entry ID (foreign key), customer question asked, conversation channel, customer session ID (anonymized), timestamp, semantic similarity score (0-1), conversation outcome (answered_from_kb, led_to_order, escalated_to_staff), restaurant ID.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: Restaurant owners upload and publish OCR-extracted menus in under 15 minutes (from upload to confirmation)
- **SC-002**: OCR extraction achieves 85%+ accuracy on item names and prices for standard menu formats
- **SC-003**: Restaurant owners create menus manually (without OCR) with 20+ items in under 45 minutes
- **SC-004**: Menu changes propagate to all ordering channels (IVR, mobile, kiosk) within 30 seconds
- **SC-005**: 90% of restaurant owners successfully configure item sizes and modifiers on first attempt without support
- **SC-006**: System supports menus with up to 500 items per restaurant without performance degradation
- **SC-007**: 95% of time-based menu items correctly show/hide based on current time across all timezones
- **SC-008**: Customers can filter menus by dietary preferences (vegan, gluten-free) and see results in under 2 seconds
- **SC-009**: Multi-location restaurants set location-specific pricing for 50+ items in under 10 minutes using bulk tools
- **SC-010**: Zero menu synchronization failures across ordering channels (100% consistency)
- **SC-011**: 80% of restaurants use menu templates or OCR for initial setup (adoption metric)
- **SC-012**: Menu preview feature used by 70%+ of restaurant owners before publishing changes
- **SC-013**: Seasonal items automatically enable/disable on scheduled dates 100% of the time without manual intervention
- **SC-014**: AI hallucination rate 0% - AI only provides responses from menu data or knowledge base, never invents answers
- **SC-015**: Unanswered question capture rate >95% when AI cannot respond from available data sources
- **SC-016**: Knowledge base semantic matching accuracy >85% (correct KB entry retrieved for similar questions)
- **SC-017**: Restaurant owners answer 80%+ of unanswered questions within 7 days of question appearing in dashboard
- **SC-018**: Knowledge base coverage increases to answer 60%+ of non-menu questions within 30 days of restaurant going live
- **SC-019**: Seasonal item badge displays correctly across all ordering channels (IVR verbal, Kiosk/Mobile visual) 100% of time

### Assumptions

- Restaurant menus are primarily in English (initial MVP), with multi-language support planned for Phase 2
- OCR will use custom Tesseract-based solution or Microsoft Azure Cognitive Services Document Intelligence with proven accuracy for menu extraction
- GenAI post-processing (GPT-4 or Azure OpenAI) significantly improves OCR accuracy by cleaning errors and structuring data intelligently
- Most restaurants have menus with under 200 items; support for 500+ items covers edge cases
- Location-specific pricing applies to less than 30% of menu items on average
- Time-based availability is used primarily for breakfast/lunch/dinner splits, not individual items
- Ingredient and dietary information will be self-reported by restaurants (not validated by third parties)
- Menu images are optional for MVP but enhance customer experience
- Third-party POS menu synchronization is one-way (Parcera → POS) for MVP; two-way sync in Phase 2
- Restaurant owners have menu content ready (existing menu, menu photos, or can create from scratch)
- Customers expect menu accuracy and will contact restaurant directly for severe allergy concerns
- Menu changes during active ordering hours are infrequent (less than 5 changes per day on average)
- Seasonal items typically follow calendar-based patterns (holidays, seasons) with predictable start/end dates
- Restaurant owners will proactively review unanswered questions dashboard at least weekly to build knowledge base
- AI semantic similarity matching uses vector embeddings (e.g., OpenAI embeddings API or Azure Cognitive Search) with cosine similarity threshold >0.75 for KB matching
- Most non-menu customer questions fall into 5-7 common categories (policies, operations, sourcing, preparation, accommodations)
- Knowledge base will start empty and grow organically from customer questions (no pre-populated content beyond templates)
- AI escalation to staff ("Let me connect you with staff") is acceptable user experience when information unavailable (better than hallucination)
- Customers asking questions expect immediate answers; unanswered questions logged for future improvement but current conversation escalates to staff
