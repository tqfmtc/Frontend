# Phase 1: Data Model - Notification Infrastructure

**Date**: 2025-11-04 | **Status**: Complete | **Next**: contracts/

## 1. Entity Relationship Diagram (ERD)

```
┌─────────────────────────┐         ┌──────────────────────┐
│ NotificationTemplate    │         │ NotificationEvent    │
├─────────────────────────┤         ├──────────────────────┤
│ id: UUID (PK)           │         │ id: UUID (PK)        │
│ name: String            │◄────────│ template_id: UUID FK │
│ event_type: Enum        │         │ event_type: Enum     │
│ language: String        │         │ recipient_id: UUID   │
│ content_sms: String     │         │ wallet_id: UUID      │
│ content_push: String    │         │ variables: JSON      │
│ variables: JSON[]       │         │ priority: Int        │
│ active: Boolean         │         │ scheduled_time: TS   │
│ version: Int            │         │ created_at: TS       │
│ created_at: TS          │         │ expires_at: TS       │
│ updated_at: TS          │         │ status: Enum         │
│ restaurant_id: UUID (FK)│         │ restaurant_id: UUID  │
└─────────────────────────┘         └──────────┬───────────┘
                                                │
                                                │ has many
                                                │
                                    ┌───────────▼──────────────┐
                                    │ DeliveryAttempt         │
                                    ├─────────────────────────┤
                                    │ id: UUID (PK)           │
                                    │ notification_id: UUID FK│
                                    │ attempt_number: Int     │
                                    │ channel: Enum (SMS/Push)│
                                    │ gateway_msg_id: String  │
                                    │ status: Enum            │
                                    │ failure_reason: String  │
                                    │ failure_category: Enum  │
                                    │ latency_ms: Int         │
                                    │ timestamp: TS           │
                                    │ created_at: TS          │
                                    └─────────────────────────┘

┌──────────────────────────┐         ┌──────────────────────┐
│ CustomerContactInfo      │         │ OperatorAlertSettings│
├──────────────────────────┤         ├──────────────────────┤
│ id: UUID (PK)            │         │ id: UUID (PK)        │
│ wallet_id: UUID (UNIQUE) │         │ operator_id: UUID    │
│ phone_encrypted: String  │         │ restaurant_id: UUID  │
│ device_tokens: JSON[]    │         │ new_orders: Boolean  │
│ language_code: String    │         │ pos_failures: Bool   │
│ notification_prefs: JSON │         │ kiosk_offline: Bool  │
│ last_updated: TS         │         │ sms_enabled: Boolean │
│ phone_verified: Boolean  │         │ quiet_hours_start: T │
│ opt_out_reasons: String[]│         │ quiet_hours_end: T   │
└──────────────────────────┘         │ updated_at: TS       │
                                     └──────────────────────┘

┌──────────────────────────┐
│ NotificationQueue        │
├──────────────────────────┤
│ id: UUID (PK)            │
│ notification_id: UUID FK │
│ priority: Int            │
│ status: Enum             │
│ retry_count: Int         │
│ next_retry_time: TS      │
│ expiration_time: TS      │
│ created_at: TS           │
│ processed_at: TS         │
└──────────────────────────┘

┌──────────────────────────┐
│ DeliveryMetrics          │
├──────────────────────────┤
│ id: UUID (PK)            │
│ date: Date               │
│ restaurant_id: UUID (FK) │
│ event_type: String       │
│ total_sent: Int          │
│ delivered_count: Int     │
│ failed_count: Int        │
│ avg_latency_ms: Int      │
│ failure_reasons: JSON    │
│ created_at: TS           │
└──────────────────────────┘
```

---

## 2. Table Definitions (SQL DDL)

### Table: notification_templates

```sql
CREATE TABLE notification_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    event_type VARCHAR(50) NOT NULL, -- 'order_status', 'operator_alert', 'wallet_notification'
    language VARCHAR(10) NOT NULL DEFAULT 'en-US',
    content_sms TEXT NOT NULL,
    content_push_title VARCHAR(255) NOT NULL,
    content_push_body TEXT NOT NULL,
    variables JSONB NOT NULL DEFAULT '[]', -- e.g., ["order_id", "restaurant_name", "pickup_time"]
    version INTEGER NOT NULL DEFAULT 1,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    restaurant_id UUID, -- NULL for platform-wide templates, non-NULL for restaurant-specific
    
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT fk_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    CONSTRAINT unique_template_name_language UNIQUE (name, language, restaurant_id)
);

CREATE INDEX idx_template_event_type ON notification_templates(event_type, active);
CREATE INDEX idx_template_restaurant ON notification_templates(restaurant_id);
```

### Table: notification_events

```sql
CREATE TABLE notification_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    template_id UUID NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    recipient_id UUID NOT NULL, -- customer_id or operator_id
    wallet_id UUID NOT NULL, -- for privacy: indirect lookup of customer contact info
    variables JSONB NOT NULL, -- {"order_id": "123", "restaurant_name": "Pizza Palace"}
    priority INTEGER NOT NULL DEFAULT 50, -- 1-100, higher = more urgent
    scheduled_time TIMESTAMP WITH TIME ZONE, -- NULL = send immediately
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (NOW() + INTERVAL '24 hours'),
    status VARCHAR(20) NOT NULL DEFAULT 'queued', -- queued, sent, delivered, failed, expired
    restaurant_id UUID NOT NULL,
    
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT fk_template FOREIGN KEY (template_id) REFERENCES notification_templates(id),
    CONSTRAINT fk_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    CONSTRAINT valid_priority CHECK (priority >= 1 AND priority <= 100),
    CONSTRAINT valid_status CHECK (status IN ('queued', 'sent', 'delivered', 'failed', 'expired'))
);

CREATE INDEX idx_event_status ON notification_events(status);
CREATE INDEX idx_event_recipient ON notification_events(recipient_id);
CREATE INDEX idx_event_wallet ON notification_events(wallet_id);
CREATE INDEX idx_event_scheduled ON notification_events(scheduled_time) WHERE scheduled_time IS NOT NULL;
CREATE INDEX idx_event_expires ON notification_events(expires_at);
CREATE INDEX idx_event_restaurant ON notification_events(restaurant_id);
```

### Table: delivery_attempts

```sql
CREATE TABLE delivery_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    notification_id UUID NOT NULL,
    attempt_number INTEGER NOT NULL DEFAULT 1,
    channel VARCHAR(20) NOT NULL, -- 'sms' or 'push'
    gateway_msg_id VARCHAR(255), -- Twilio message SID or FCM message ID
    status VARCHAR(20) NOT NULL, -- queued, sent, delivered, failed
    failure_reason VARCHAR(255), -- 'invalid_phone', 'rate_limit', 'timeout', 'invalid_token', etc.
    failure_category VARCHAR(50), -- 'temporary' (retry), 'permanent' (no retry)
    latency_ms INTEGER, -- time from trigger to delivery
    retry_scheduled_for TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT fk_notification FOREIGN KEY (notification_id) REFERENCES notification_events(id),
    CONSTRAINT valid_channel CHECK (channel IN ('sms', 'push')),
    CONSTRAINT valid_status CHECK (status IN ('queued', 'sent', 'delivered', 'failed')),
    CONSTRAINT valid_category CHECK (failure_category IN ('temporary', 'permanent'))
);

CREATE INDEX idx_delivery_notification ON delivery_attempts(notification_id);
CREATE INDEX idx_delivery_status ON delivery_attempts(status);
CREATE INDEX idx_delivery_channel ON delivery_attempts(channel);
CREATE INDEX idx_delivery_gateway_msg ON delivery_attempts(gateway_msg_id);
CREATE INDEX idx_delivery_retry_scheduled ON delivery_attempts(retry_scheduled_for) WHERE retry_scheduled_for IS NOT NULL;
```

### Table: customer_contact_info

```sql
CREATE TABLE customer_contact_info (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    wallet_id UUID NOT NULL UNIQUE,
    phone_encrypted VARCHAR(255), -- AES-256 encrypted "+1234567890"
    phone_hash VARCHAR(255), -- SHA256(phone) for searching without decryption
    device_tokens JSONB NOT NULL DEFAULT '[]', -- [{"token": "...", "provider": "fcm", "expires_at": "2025-12-04"}]
    language_code VARCHAR(10) NOT NULL DEFAULT 'en-US',
    notification_prefs JSONB NOT NULL DEFAULT '{}', -- {"order_status": true, "wallet_alerts": false, ...}
    phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
    opt_out_categories TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[], -- ['promotional', 'marketing']
    last_updated TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT fk_wallet FOREIGN KEY (wallet_id) REFERENCES customer_wallets(id),
    CONSTRAINT check_language CHECK (language_code ~ '^[a-z]{2}-[A-Z]{2}$')
);

CREATE INDEX idx_contact_wallet ON customer_contact_info(wallet_id);
CREATE INDEX idx_contact_phone_hash ON customer_contact_info(phone_hash); -- for duplicate detection
CREATE INDEX idx_contact_last_updated ON customer_contact_info(last_updated);
```

### Table: operator_alert_settings

```sql
CREATE TABLE operator_alert_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    operator_id UUID NOT NULL,
    restaurant_id UUID NOT NULL,
    new_orders BOOLEAN NOT NULL DEFAULT TRUE,
    pos_failures BOOLEAN NOT NULL DEFAULT TRUE,
    kiosk_offline BOOLEAN NOT NULL DEFAULT TRUE,
    sms_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    quiet_hours_start TIME, -- NULL = no quiet hours
    quiet_hours_end TIME,
    quiet_hours_tz VARCHAR(50), -- America/New_York
    
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT fk_operator FOREIGN KEY (operator_id) REFERENCES operators(id),
    CONSTRAINT fk_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    CONSTRAINT check_quiet_hours CHECK (
        (quiet_hours_start IS NULL AND quiet_hours_end IS NULL) OR
        (quiet_hours_start IS NOT NULL AND quiet_hours_end IS NOT NULL)
    )
);

CREATE INDEX idx_alert_operator ON operator_alert_settings(operator_id);
CREATE INDEX idx_alert_restaurant ON operator_alert_settings(restaurant_id);
CREATE UNIQUE INDEX idx_alert_unique ON operator_alert_settings(operator_id, restaurant_id);
```

### Table: notification_queue

```sql
CREATE TABLE notification_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    notification_id UUID NOT NULL UNIQUE,
    priority INTEGER NOT NULL DEFAULT 50, -- 1-100
    status VARCHAR(20) NOT NULL DEFAULT 'queued', -- queued, processing, delivered, failed, expired
    retry_count INTEGER NOT NULL DEFAULT 0,
    next_retry_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    expiration_time TIMESTAMP WITH TIME ZONE NOT NULL,
    
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT fk_notification FOREIGN KEY (notification_id) REFERENCES notification_events(id),
    CONSTRAINT valid_retry CHECK (retry_count >= 0 AND retry_count <= 3),
    CONSTRAINT valid_status CHECK (status IN ('queued', 'processing', 'delivered', 'failed', 'expired'))
);

CREATE INDEX idx_queue_status_priority ON notification_queue(status, priority DESC, created_at ASC) 
    WHERE status = 'queued';
CREATE INDEX idx_queue_retry_time ON notification_queue(next_retry_time) 
    WHERE status IN ('queued', 'failed');
CREATE INDEX idx_queue_expiration ON notification_queue(expiration_time);
```

### Table: delivery_metrics

```sql
CREATE TABLE delivery_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    restaurant_id UUID,
    event_type VARCHAR(50) NOT NULL,
    channel VARCHAR(20), -- 'sms', 'push', or NULL for aggregate
    total_sent INTEGER NOT NULL DEFAULT 0,
    delivered_count INTEGER NOT NULL DEFAULT 0,
    failed_count INTEGER NOT NULL DEFAULT 0,
    avg_latency_ms INTEGER,
    p95_latency_ms INTEGER,
    failure_reasons JSONB NOT NULL DEFAULT '{}', -- {"invalid_phone": 15, "rate_limit": 3}
    
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT fk_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    CONSTRAINT unique_metric UNIQUE (date, restaurant_id, event_type, channel)
);

CREATE INDEX idx_metrics_date ON delivery_metrics(date DESC);
CREATE INDEX idx_metrics_restaurant ON delivery_metrics(restaurant_id);
CREATE INDEX idx_metrics_event_type ON delivery_metrics(event_type);
```

---

## 3. Key Design Decisions

### A. Privacy-First Design

**Decision**: Store wallet_id instead of phone in notification_events and delivery_attempts

**Rationale**:
- Restaurants can only see wallet_id in their delivery logs
- Phone lookup happens at delivery time (internal Wallet Service call)
- Prevents data breach exposure of phone numbers to restaurants
- Enables easy rotation of customer phone if compromised

**Constraint**: Customer contact info must always be fetched via Wallet Service, never joined directly

```python
# GOOD: Indirect lookup
event = db.query(NotificationEvent).get(event_id)
contact = wallet_service.get_customer_contact(event.wallet_id)  # phone_encrypted, device_tokens
```

```python
# BAD: Direct join (exposes phone)
# DO NOT DO: event.customer.phone
```

---

### B. JSON Storage for Flexibility

**Decision**: Use JSONB for variables, device_tokens, notification_prefs, failure_reasons

**Rationale**:
- Template variables change frequently (order_id, restaurant_name, ETA, etc.)
- Device tokens array grows dynamically (iOS + Android + web)
- Notification preferences differ per customer (per-category opt-out)
- Failure reasons require flexible structure (codes + messages)

**Indexing Strategy**:
```sql
-- Example: Find notifications with specific order_id
CREATE INDEX idx_event_variables_order_id 
    ON notification_events USING gin(variables)
    WHERE variables->>'order_id' IS NOT NULL;
```

---

### C. Queue Priorities & Latency SLA

**Decision**: Three-tier priority system in notification_queue

| Priority | Use Case | SLA |
|----------|----------|-----|
| 1-30 | Promotional, wallet alerts | Best effort, delay OK |
| 40-70 | Order status notifications | <10 seconds |
| 80-100 | Operator alerts (new order, POS failure) | <5 seconds |

**Processing**:
```sql
-- Dequeue highest priority first
SELECT * FROM notification_queue
WHERE status = 'queued' AND next_retry_time <= NOW()
ORDER BY priority DESC, created_at ASC
LIMIT 100
FOR UPDATE SKIP LOCKED;
```

---

### D. Encryption at Rest

**Decision**: Encrypt phone numbers in customer_contact_info, keep hash unencrypted

**Rationale**:
- Wallet Service provides decrypted phone to Notifications at delivery time
- Hash allows detecting duplicates/changes without decryption
- If DB is compromised, attackers see only encrypted blobs + hashes

**Implementation**:
```python
from cryptography.fernet import Fernet

CIPHER = Fernet(ENCRYPTION_KEY)

def encrypt_phone(phone: str) -> str:
    return CIPHER.encrypt(phone.encode()).decode()

def decrypt_phone(encrypted: str) -> str:
    return CIPHER.decrypt(encrypted.encode()).decode()

def phone_hash(phone: str) -> str:
    import hashlib
    return hashlib.sha256(phone.encode()).hexdigest()
```

---

### E. Exponential Backoff Timing

**Decision**: Retry delays = 30s, 60s, 120s (max 3 attempts)

**Rationale**:
- Most temporary failures resolve within 30-60 seconds
- After 3 attempts, assume permanent failure
- Total retry window = ~3 minutes (acceptable for order status)

**Table**: Captures next_retry_time, calculated by:
```
next_retry_time = NOW() + (30 * 2^retry_count) seconds
```

---

## 4. Relationships & Constraints

| Relationship | From | To | Type | Notes |
|--------------|------|----|----|-------|
| Event → Template | notification_events.template_id | notification_templates.id | N:1 | Required FK |
| Event → Wallet | notification_events.wallet_id | customer_wallets.id | N:1 | Privacy indirect lookup |
| Event → Restaurant | notification_events.restaurant_id | restaurants.id | N:1 | Tenant isolation |
| Attempt → Event | delivery_attempts.notification_id | notification_events.id | N:1 | Audit trail |
| Template → Restaurant | notification_templates.restaurant_id | restaurants.id | N:1 | Can be NULL (platform-wide) |
| Queue → Event | notification_queue.notification_id | notification_events.id | 1:1 | Unique constraint |
| AlertSettings → Operator | operator_alert_settings.operator_id | operators.id | N:1 | Per operator |
| AlertSettings → Restaurant | operator_alert_settings.restaurant_id | restaurants.id | N:1 | Per restaurant |
| ContactInfo → Wallet | customer_contact_info.wallet_id | customer_wallets.id | 1:1 | Unique |

---

## 5. Indexing Strategy

| Index | Table | Columns | Purpose | Cardinality |
|-------|-------|---------|---------|-------------|
| `idx_template_event_type` | templates | (event_type, active) | Find active templates by type | High |
| `idx_event_status` | events | (status) | Queue polling | High |
| `idx_event_scheduled` | events | (scheduled_time) WHERE scheduled_time IS NOT NULL | Find scheduled notifications | Medium |
| `idx_queue_status_priority` | queue | (status, priority DESC, created_at) WHERE status='queued' | Dequeue polling (hot path) | **CRITICAL** |
| `idx_queue_retry_time` | queue | (next_retry_time) WHERE status IN (...) | Retry scheduler | High |
| `idx_delivery_gateway_msg` | attempts | (gateway_msg_id) | Webhook lookup | Medium |
| `idx_contact_phone_hash` | contact_info | (phone_hash) | Duplicate detection | Medium |
| `idx_metrics_date` | metrics | (date DESC) | Dashboard queries | Medium |

---

## 6. Capacity Planning

| Metric | Estimate | Notes |
|--------|----------|-------|
| Notifications/day | 500k | 250k orders × 2 per order |
| Queue peak depth | 5k | Burst during peak ordering hours |
| Delivery attempts/day | 750k | 500k original + 250k retries (50%) |
| DB storage/year | 50GB | 500k notifications × 365 days; delivery logs compressed after 90d |
| Concurrent workers | 5 | Process 500k/day at 60 msgs/sec per worker |

---

## 7. Migration Strategy (Alembic)

### File: `alembic/versions/001_initial_schema.py`

```python
# Creates all tables listed above in order:
# 1. notification_templates
# 2. notification_events
# 3. delivery_attempts
# 4. customer_contact_info
# 5. operator_alert_settings
# 6. notification_queue
# 7. delivery_metrics

# Also creates all indexes and constraints
```

**Usage**:
```bash
alembic upgrade head  # Deploy schema
alembic downgrade -1  # Rollback last migration
```

---

## Conclusion

**Schema Validation**:
- ✓ All 30 FRs (FR-001 to FR-030) mapped to tables/columns
- ✓ Privacy constraints enforced (wallet_id, phone encryption)
- ✓ Indexing optimized for dequeue polling (hot path)
- ✓ Capacity handles 500k notifications/day with headroom
- ✓ Relationships ensure data integrity via FKs

**Next**: Generate API contracts (OpenAPI) and quickstart guide.
