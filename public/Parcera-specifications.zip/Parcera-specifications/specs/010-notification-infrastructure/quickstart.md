# Quickstart: Notification Infrastructure

**Status**: Ready for local development | **Duration**: ~15 minutes | **Prerequisites**: Docker, Python 3.11+

---

## Part 1: Setup (5 minutes)

### 1.1 Clone & Navigate

```bash
cd backend
python -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows
pip install -r requirements.txt
```

### 1.2 Environment Configuration

Create `.env` file in `backend/`:

```plaintext
# === TWILIO ===
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_PHONE_NUMBER=+1234567890
TWILIO_API_KEY=your_api_key

# === FIREBASE ===
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_PRIVATE_KEY_ID=key_id
FIREBASE_PRIVATE_KEY=-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----

# === DATABASE ===
DATABASE_URL=postgresql://parcera:password@localhost:5432/parcera
SQLALCHEMY_ECHO=False

# === CELERY ===
CELERY_BROKER_URL=sqla+postgresql://parcera:password@localhost:5432/parcera
CELERY_RESULT_BACKEND=db+postgresql://parcera:password@localhost:5432/parcera

# === SERVICES ===
WALLET_SERVICE_URL=http://wallet-service:8000
RESTAURANT_SERVICE_URL=http://restaurant-service:8000

# === LOGGING ===
LOG_LEVEL=INFO
SENTRY_DSN=  # Optional

# === FEATURE FLAGS ===
ENABLE_SMS_DELIVERY=True
ENABLE_PUSH_DELIVERY=True
ENABLE_RETRY_PROCESSOR=True
MOCK_GATEWAYS=False  # Set to True for testing without real Twilio/FCM
```

### 1.3 Start Services (Docker)

```bash
docker-compose up -d postgres redis
```

Or use `.env.example` as template:

```bash
cp .env.example .env
# Edit .env with your credentials
```

### 1.4 Initialize Database

```bash
alembic upgrade head
```

---

## Part 2: Create & Test Notification (5 minutes)

### 2.1 Start API Server

```bash
# Terminal 1: FastAPI
python -m uvicorn src.main:app --reload --host 0.0.0.0 --port 8000
```

### 2.2 Start Celery Worker

```bash
# Terminal 2: Celery worker
celery -A src.notifications.workers.tasks worker --loglevel=info --concurrency=2
```

### 2.3 Start Celery Beat (Scheduler)

```bash
# Terminal 3: Celery Beat (for retries)
celery -A src.notifications.workers.scheduled beat --loglevel=info
```

### 2.4 Test Health Check

```bash
curl http://localhost:8000/health
# Response:
# {
#   "status": "healthy",
#   "checks": {
#     "db": true,
#     "celery": true,
#     "twilio": true,
#     "fcm": true
#   }
# }
```

### 2.5 Create Template

```bash
curl -X POST http://localhost:8000/api/v1/templates \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "order_confirmed",
    "event_type": "order_status",
    "language": "en-US",
    "content_sms": "Order #{{ order_id }} confirmed! Ready at {{ pickup_time }}.",
    "content_push_title": "Order Confirmed",
    "content_push_body": "Your order #{{ order_id }} is confirmed. Ready at {{ pickup_time }}.",
    "variables": ["order_id", "pickup_time"]
  }'
```

**Response** (save the `id`):
```json
{
  "id": "tmpl-uuid-abc123",
  "name": "order_confirmed",
  "event_type": "order_status",
  "language": "en-US",
  "active": true,
  "created_at": "2025-11-04T15:30:00Z"
}
```

### 2.6 Send Test Notification

```bash
curl -X POST http://localhost:8000/api/v1/notifications/send \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "event_type": "order_status",
    "recipient_id": "cust-uuid-123",
    "wallet_id": "wallet-uuid-456",
    "template_id": "tmpl-uuid-abc123",
    "variables": {
      "order_id": "ORD-2025-001234",
      "pickup_time": "6:30 PM"
    },
    "priority": 90,
    "restaurant_id": "rest-uuid-789"
  }'
```

**Response** (202 Accepted):
```json
{
  "id": "notif-uuid-111",
  "status": "queued",
  "created_at": "2025-11-04T15:30:00Z"
}
```

### 2.7 Check Notification Status

```bash
curl http://localhost:8000/api/v1/notifications/notif-uuid-111 \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Response**:
```json
{
  "id": "notif-uuid-111",
  "event_type": "order_status",
  "status": "delivered",
  "delivery_attempts": [
    {
      "attempt_number": 1,
      "channel": "sms",
      "status": "delivered",
      "gateway_msg_id": "SMxxxxxxxxxxxxxxxxxxxxxxxxxx",
      "latency_ms": 1250,
      "timestamp": "2025-11-04T15:30:15Z"
    }
  ]
}
```

---

## Part 3: Monitoring & Debugging (5 minutes)

### 3.1 View Delivery Logs

```bash
curl 'http://localhost:8000/api/v1/notifications/logs?restaurant_id=rest-uuid-789&limit=10' \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### 3.2 Check Metrics Dashboard

```bash
curl 'http://localhost:8000/api/v1/metrics?restaurant_id=rest-uuid-789&date_start=2025-11-01&date_end=2025-11-04' \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Response**:
```json
{
  "period": {
    "start_date": "2025-11-01",
    "end_date": "2025-11-04"
  },
  "summary": {
    "total_sent": 1250,
    "total_delivered": 1225,
    "total_failed": 25,
    "success_rate_percent": 98.0,
    "avg_latency_ms": 2150
  },
  "by_channel": {
    "sms": {"sent": 750, "delivered": 735, "success_rate": 98.0},
    "push": {"sent": 500, "delivered": 490, "success_rate": 98.0}
  },
  "top_failure_reasons": [
    {"reason": "invalid_phone", "count": 15},
    {"reason": "InvalidToken", "count": 10}
  ]
}
```

### 3.3 Watch Celery Tasks

```bash
# In Terminal 2, watch task output
# You should see:
# [2025-11-04 15:30:00] Task send_sms_task[abc123] started
# [2025-11-04 15:30:01] Task send_sms_task[abc123] succeeded
```

### 3.4 Debug Database

```bash
# Connect to PostgreSQL
psql postgresql://parcera:password@localhost:5432/parcera

# Check queued notifications
SELECT id, status, priority, created_at 
FROM notification_queue 
WHERE status = 'queued' 
ORDER BY priority DESC 
LIMIT 10;

# Check delivery attempts
SELECT notification_id, attempt_number, channel, status, failure_reason
FROM delivery_attempts
WHERE created_at > NOW() - INTERVAL '1 hour'
ORDER BY created_at DESC
LIMIT 20;
```

---

## Part 4: Testing with Mock Gateways (Optional)

If you don't have Twilio/Firebase credentials yet, use mock mode:

### 4.1 Enable Mocks

Set in `.env`:
```plaintext
MOCK_GATEWAYS=True
```

This makes Twilio/FCM calls return success immediately without contacting real services.

### 4.2 Test SMS Delivery

```bash
# The SMS will be "sent" instantly (mocked)
curl -X POST http://localhost:8000/api/v1/notifications/send \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "event_type": "order_status",
    "recipient_id": "cust-uuid-123",
    "wallet_id": "wallet-uuid-456",
    "template_id": "tmpl-uuid-abc123",
    "variables": {"order_id": "ORD-123", "pickup_time": "6:30 PM"},
    "priority": 90,
    "restaurant_id": "rest-uuid-789"
  }'

# Check status - should be "delivered" immediately
curl http://localhost:8000/api/v1/notifications/notif-uuid-111 \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

---

## Part 5: Integration with Other Services

### 5.1 How Order Service Triggers Notification

```python
# src/orders/services/order_service.py
from src.notifications.api.client import NotificationClient

class OrderService:
    def confirm_order(self, order_id: str):
        order = db.get_order(order_id)
        order.status = "confirmed"
        db.save(order)
        
        # Trigger notification
        NotificationClient.send(
            event_type="order_status",
            recipient_id=order.customer_id,
            wallet_id=order.wallet_id,
            template_id="tmpl-order-confirmed",
            variables={
                "order_id": order_id,
                "restaurant_name": order.restaurant.name,
                "pickup_time": order.estimated_pickup_time
            },
            restaurant_id=order.restaurant_id
        )
```

### 5.2 How Wallet Service Provides Contact Info

```python
# src/notifications/services/privacy_service.py
from src.wallet.api.client import WalletServiceClient

class PrivacyService:
    def get_customer_contact(self, wallet_id: str):
        """
        Fetch customer phone & device tokens from Wallet Service.
        Phone is returned encrypted; Notification Service never stores decrypted.
        """
        response = WalletServiceClient.get_customer_contact(wallet_id)
        return {
            "phone_encrypted": response.phone_encrypted,
            "device_tokens": response.device_tokens,
            "language": response.language
        }
```

---

## Part 6: Real Gateway Setup (Twilio)

### 6.1 Create Twilio Account

1. Go to https://www.twilio.com/console
2. Create a Free Trial account
3. Get your **Account SID** and **Auth Token**

### 6.2 Get Phone Number

1. In Twilio Console → Phone Numbers → Buy a Number
2. Choose your country/area code
3. Purchase (free trial includes credits)

### 6.3 Setup Webhook

1. Phone Numbers → Manage Numbers → Your Number
2. **Messaging** section → Webhook URL for Status Callbacks
3. Set to: `https://your-api.com/webhooks/twilio/delivery`
4. Make sure POST is selected

### 6.4 Update .env

```plaintext
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_token_here
TWILIO_PHONE_NUMBER=+15551234567
MOCK_GATEWAYS=False
```

### 6.5 Test Real SMS

```bash
curl -X POST http://localhost:8000/api/v1/notifications/send \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "event_type": "order_status",
    "recipient_id": "cust-uuid-123",
    "wallet_id": "wallet-uuid-456",
    "template_id": "tmpl-uuid-abc123",
    "variables": {"order_id": "ORD-123", "pickup_time": "6:30 PM"},
    "priority": 90,
    "restaurant_id": "rest-uuid-789"
  }'
```

Check Twilio Console → Messages for delivery status.

---

## Part 7: Real Gateway Setup (Firebase)

### 7.1 Create Firebase Project

1. Go to https://console.firebase.google.com/
2. Create New Project
3. Enable Cloud Messaging

### 7.2 Create Service Account

1. Project Settings → Service Accounts
2. Generate New Private Key (JSON)
3. Save as `firebase-key.json`

### 7.3 Update .env

```plaintext
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_PRIVATE_KEY_ID=key_id_from_json
FIREBASE_PRIVATE_KEY=-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----
```

### 7.4 Mobile App Integration

In your mobile app (iOS/Android):
```swift
// iOS example
import FirebaseMessaging

let token = Messaging.messaging().fcmToken ?? "unknown"
// Send this token to Notification Service via Wallet Service
// When notification arrives, forward delivery callback:
// POST /webhooks/fcm/delivery with event_type="delivered"
```

---

## Troubleshooting

### SMS Not Sending

```bash
# Check worker logs
# Look for: "Task send_sms_task[...] started"
# If failed:
# - Verify TWILIO_ACCOUNT_SID/AUTH_TOKEN in .env
# - Check Twilio console for any errors
# - Test with MOCK_GATEWAYS=True first
```

### Push Not Delivering

```bash
# Check if device token is valid and up-to-date
# In mobile app:
// iOS
UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
    if granted {
        DispatchQueue.main.async {
            UIApplication.shared.registerForRemoteNotifications()
        }
    }
}

// Android
FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task in
    if (task.isSuccessful()) {
        String token = task.getResult();
        // Send token to backend
    }
})
```

### Database Connection Error

```bash
# Verify PostgreSQL is running
docker-compose ps

# Check connection string
psql postgresql://parcera:password@localhost:5432/parcera

# If fails, restart services
docker-compose down
docker-compose up -d postgres
sleep 5
alembic upgrade head
```

### Celery Tasks Not Running

```bash
# Verify broker URL is correct
echo $CELERY_BROKER_URL

# Check if worker is connected
# In Terminal 2, should see: "Connected to sqla+postgresql://..."

# Inspect active tasks
celery -A src.notifications.workers.tasks inspect active
```

---

## Next Steps

1. **Understand data model**: Read [data-model.md](data-model.md)
2. **Review API contracts**: See [contracts/notification-api.yaml](contracts/notification-api.yaml)
3. **Deploy**: Follow deployment guide in main README
4. **Monitor**: Set up Sentry alerts for delivery failures
5. **Optimize**: Monitor metrics, adjust retry logic, tune worker concurrency

---

## Support

For issues or questions:
1. Check Celery worker logs (Terminal 2)
2. Check API server logs (Terminal 1)
3. Query database: `SELECT * FROM delivery_attempts WHERE created_at > NOW() - INTERVAL '1 hour'`
4. Review [research.md](research.md) for architecture details

