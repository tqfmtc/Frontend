# Implementation Plan: Notification Infrastructure (SMS/Email)

**Branch**: `010-notification-infrastructure` | **Date**: 2025-11-04 | **Spec**: [spec.md](spec.md)
**Input**: Feature specification from `/specs/010-notification-infrastructure/spec.md`

## Summary

**Requirement**: Build a unified notification service delivering SMS and push notifications for order status updates, operator alerts, and wallet events while protecting customer privacy by routing through wallet_id without exposing phone numbers to restaurants.

**Technical Approach**: FastAPI backend with Celery async workers, Twilio for SMS, Firebase Cloud Messaging (FCM) for mobile push, PostgreSQL-backed queue with priority scheduling, and template engine for variable substitution.

## Technical Context

**Language/Version**: Python 3.11+  
**Primary Dependencies**: FastAPI, Celery, Twilio SDK, Firebase Admin SDK, SQLAlchemy, Pydantic  
**Storage**: PostgreSQL (queue, delivery logs, templates, metrics)  
**Testing**: pytest with fixtures for Twilio/FCM mocking  
**Target Platform**: Linux server (Docker containerized)  
**Project Type**: Backend microservice (web/REST API)  
**Performance Goals**: 10,000+ notifications/hour, <5s end-to-end latency for 90% of deliveries  
**Constraints**: <10 second delivery SLA for order status, <5 second for operator alerts, 98%+ success rate  
**Scale/Scope**: Multi-tenant (per-restaurant isolation), supports 100k+ customers, 10k+ restaurants

## Constitution Check

**GATE**: Pass ✓

| Principle | Status | Notes |
|-----------|--------|-------|
| I: AI-First | Aligned | Template content mining, send-time optimization deferred to P2 |
| II: Multi-Tenancy | ✓ Aligned | Row-level security enforced via restaurant_id, tenant isolation in templates |
| III: Privacy-First | ✓ CRITICAL | Wallet_id routing, no PII exposure to restaurants, encrypted phone storage |
| IV: Omnichannel | ✓ Aligned | Channel-agnostic event triggers, delivery method selected by availability |
| V: Progressive | ✓ MVP Focused | P0: delivery + privacy; P1: templates + retry; P2: multi-lang + AI |
| VI: Network Effects | ✓ Aligned | Centralized metrics for platform reliability, shared template library (future) |
| VII: Integration-Friendly | ✓ Aligned | RESTful API, webhook callbacks, pluggable gateway architecture |

## Project Structure

### Documentation (this feature)

```text
specs/010-notification-infrastructure/
├── plan.md                  # This file (implementation plan)
├── research.md              # Phase 0: technology research & options
├── data-model.md            # Phase 1: database schema & entity details
├── quickstart.md            # Phase 1: setup guide & API examples
├── contracts/               # Phase 1: OpenAPI specs & message formats
│   ├── notification-api.yaml
│   ├── delivery-webhook.yaml
│   └── messages.yaml
└── checklists/              # Acceptance criteria checklists
```

### Source Code

```text
backend/
├── src/
│   ├── notifications/
│   │   ├── models.py              # SQLAlchemy: NotificationEvent, Template, DeliveryAttempt
│   │   ├── schemas.py             # Pydantic: request/response DTOs
│   │   ├── api/
│   │   │   ├── routes.py          # FastAPI endpoints (/api/v1/notifications/*)
│   │   │   └── webhooks.py        # Delivery status callbacks from Twilio/FCM
│   │   ├── services/
│   │   │   ├── notification_service.py    # Queue & dispatch logic
│   │   │   ├── delivery_service.py        # Twilio/FCM integration
│   │   │   ├── template_service.py        # Template rendering, validation
│   │   │   └── privacy_service.py         # Wallet_id lookup, PII masking
│   │   ├── workers/
│   │   │   ├── tasks.py           # Celery: send_sms, send_push, process_queue
│   │   │   └── scheduled.py        # Beat: retry processor, metrics aggregator
│   │   └── config.py              # Gateway credentials, retry policies
│   ├── migrations/
│   │   └── alembic/               # Database migrations
│   └── tests/
│       ├── notifications/
│       │   ├── test_api.py        # API endpoint tests
│       │   ├── test_delivery.py    # Twilio/FCM integration tests
│       │   ├── test_templates.py   # Template rendering tests
│       │   └── test_privacy.py     # PII masking, wallet lookup tests
│       └── integration/
│           └── test_e2e_workflow.py
```

## Complexity Tracking

> **No violations** — Architecture aligns with Constitution and MVP discipline

| Item | Justification |
|------|---------------|
| Multi-gateway support | Required by spec: primary + fallback for SMS, push alternatives |
| Async queue (Celery) | Order-critical notifications demand reliable async processing; sync would block API |
| Template engine | Business requirement for content consistency without code changes |
| Privacy layer | Constitutional (Principle III) + competitive advantage + legal compliance |

## Execution Workflow

### Phase 0: Research (→ research.md)

**Deliverable**: Technology evaluation, vendor comparison, architecture decision records

Topics to cover:
- Twilio SMS integration options (REST API, webhooks for delivery status)
- Firebase Cloud Messaging setup, device token management, fallback strategy
- Queue systems comparison (PostgreSQL SKIP LOCKED vs Redis)
- Template engines (Mustache vs Jinja2 vs custom)
- Privacy patterns for wallet_id routing
- Async task frameworks (Celery vs RQ vs APScheduler)

**Outputs**:
- Tech stack validation
- Service integration recipes
- Privacy architecture diagram
- Decision rationale for chosen tech

---

### Phase 1: Design (→ data-model.md, contracts/*, quickstart.md)

**Deliverable**: Complete schema, API contracts, deployment guide

#### 1a. Data Model

Entities:
- `NotificationEvent` — request to send (event_type, recipient_id, template_id, priority, scheduled_time)
- `NotificationTemplate` — reusable message template (name, event_type, content_variants, variables, language)
- `DeliveryAttempt` — audit trail of each delivery (status, channel, gateway_msg_id, latency, failure_reason)
- `CustomerContactInfo` — cached customer phone + tokens from wallet service (wallet_id, phone_encrypted, device_tokens)
- `OperatorAlertSettings` — per-operator preferences (alert_types, channels, quiet_hours)
- `NotificationQueue` — queued items with priority, retry count, next_retry_time
- `DeliveryMetrics` — aggregated daily stats (success_rate, avg_latency, failure_breakdown)

**Outputs**:
- data-model.md with full schema, relationships, indexes
- SQL migration files (Alembic)

#### 1b. API Contracts

**Endpoints**:
1. `POST /api/v1/notifications/send` — Trigger notification delivery
2. `GET /api/v1/notifications/{id}` — Fetch notification status
3. `GET /api/v1/notifications/logs` — Delivery log search (admin)
4. `POST /api/v1/notifications/templates` — Create/update templates (admin)
5. `GET /api/v1/notifications/metrics` — Delivery metrics dashboard (admin)
6. `POST /webhooks/twilio/delivery` — Twilio delivery status callback
7. `POST /webhooks/fcm/delivery` — FCM delivery status callback (app)

**Outputs**:
- notification-api.yaml (OpenAPI 3.0)
- delivery-webhook.yaml (callback formats)
- messages.yaml (event/template message examples)

#### 1c. Quickstart

**Topics**:
- Local setup (PostgreSQL, Redis, Celery, env vars)
- Test with Twilio trial account
- Trigger order status notification
- Monitor delivery via dashboard
- Admin template management

**Outputs**:
- quickstart.md with copy-paste examples
- docker-compose.yml for local dev
- .env.example with all required vars

---

### Phase 2: Implementation (→ tasks.md)

**Not executed by /speckit.plan**, triggered by `/speckit.tasks` after Phase 1 review.

Will generate:
- Sprint-sized tasks (10-20 days)
- Dependencies, owners, acceptance criteria
- Risk mitigations

---

## Success Metrics

- **Specification Completeness**: All 30 functional requirements (FR-001 to FR-030) mapped to data model + API
- **Privacy Validation**: Zero PII exposure paths in delivery logs, masking implemented
- **Contract Clarity**: API contracts unambiguous, webhook examples working
- **Deployment Readiness**: Quickstart runnable end-to-end in <15 minutes
- **Testing Strategy**: Unit + integration test scaffold in place, mocks for Twilio/FCM

---

## Next Steps

1. Run `/speckit.plan research` to generate **research.md**
2. Run `/speckit.plan design` to generate **data-model.md**, **quickstart.md**, **contracts/\*.yaml**
3. Review with team, confirm architecture, adjust constraints if needed
4. Run `/speckit.tasks` to generate sprint-sized implementation tasks
5. Execute tasks, track in project management
