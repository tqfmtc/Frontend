# Feature Specification: Notification Infrastructure

**Feature Branch**: `010-notification-infrastructure`
**Created**: 2025-10-29
**Status**: Draft
**Input**: User description: "Notification Infrastructure - Backend service for delivering SMS and push notifications to customers and restaurant operators. Handles order status updates (confirmed, ready for pickup, delivered), restaurant alerts (new orders, POS failures, kiosk offline), customer wallet notifications (payment method expiring), and delivery driver notifications. Integrates with Twilio for SMS, Firebase Cloud Messaging for mobile push, and includes template management, delivery tracking, retry logic, and privacy-first routing (customers identified by wallet_id, not exposed phone numbers)."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Order Status Notifications to Customers (Priority: P0)

Customers need to receive timely notifications about their order status (confirmed, in preparation, ready for pickup, delivered) via SMS or mobile push to know when to pick up their food or track delivery progress.

**Why this priority**: Core customer experience requirement. Without status notifications, customers don't know order progress, leading to missed pickups, cold food, and support calls.

**Independent Test**: Can be fully tested by placing test orders through any channel (IVR, mobile, kiosk), progressing through order statuses, and verifying customers receive notifications via SMS and/or push with correct timing and content.

**Acceptance Scenarios**:

1. **Given** customer places order via mobile app, **When** restaurant confirms order, **Then** customer receives notification within 10 seconds stating "Order confirmed! Estimated ready time: [time]"
2. **Given** order is confirmed, **When** restaurant marks order as "Ready for Pickup", **Then** customer receives notification within 10 seconds with "Your order is ready for pickup at [restaurant name]!"
3. **Given** customer has mobile app installed, **When** order status changes, **Then** push notification is sent first, with SMS as fallback only if push fails after 30 seconds
4. **Given** customer places order via IVR (no app), **When** order status changes, **Then** SMS notification is sent to phone number used for order within 10 seconds

---

### User Story 2 - Restaurant Operator Alerts (Priority: P0)

Restaurant operators need to receive alerts for critical events (new orders, POS connection failures, kiosk offline) to respond quickly and prevent lost orders or service disruptions.

**Why this priority**: Essential for restaurant operations. Missed order alerts lead to delayed fulfillment and lost revenue. System failures require immediate operator attention.

**Independent Test**: Can be fully tested by simulating events (new order via mobile, POS connection failure, kiosk going offline) and verifying operators with appropriate roles receive notifications via dashboard and SMS.

**Acceptance Scenarios**:

1. **Given** new order is placed on any channel, **When** order enters fulfillment queue, **Then** operator receives dashboard notification within 5 seconds with order summary and audio alert
2. **Given** POS connection fails during order submission, **When** failure is detected after 3 retry attempts, **Then** operator receives SMS alert "POS connection failed for [restaurant name]. Manual intervention required."
3. **Given** kiosk device goes offline, **When** device misses 2 consecutive heartbeats (>2 minutes), **Then** operator receives dashboard alert with device ID and last known status
4. **Given** operator has "Staff" role, **When** new order alert is triggered, **Then** they receive dashboard notification only (no SMS), while "Owner" and "Manager" roles receive both dashboard and SMS

---

### User Story 3 - Privacy-First Notification Routing (Priority: P0)

Customers receive order notifications routed through Parcera's privacy-first system where restaurants cannot access customer phone numbers, preventing spam and protecting customer data.

**Why this priority**: Constitutional requirement (Principle III: Privacy-First Customer Data). Critical for customer trust and platform differentiation.

**Independent Test**: Can be fully tested by placing orders, verifying notifications are delivered successfully, and confirming restaurant operators cannot view or access customer phone numbers in any dashboard or API response.

**Acceptance Scenarios**:

1. **Given** restaurant wants to notify customer of order status, **When** notification is triggered, **Then** system looks up customer phone number via wallet_id internally without exposing it to restaurant
2. **Given** operator views order details in dashboard, **When** they see customer information, **Then** only pickup name and masked phone (last 4 digits) are displayed, never full phone number
3. **Given** notification delivery succeeds, **When** delivery log is created, **Then** log records wallet_id and delivery status but not customer phone number (audit compliance)
4. **Given** customer places orders at multiple restaurants, **When** each restaurant sends notifications, **Then** all notifications route through Parcera using same wallet_id without exposing customer data to restaurants

---

### User Story 4 - Notification Template Management (Priority: P1)

Platform administrators need to create and manage notification templates for different event types with variable substitution (order ID, restaurant name, pickup time) to ensure consistent messaging.

**Why this priority**: Important for scalability and branding consistency, but system can function with hardcoded messages initially. Templates enable easy updates without code changes.

**Independent Test**: Can be fully tested by creating/editing templates via admin interface, triggering notifications that use those templates, and verifying variables are correctly substituted and content matches template.

**Acceptance Scenarios**:

1. **Given** admin creates template "Order confirmed at {{restaurant_name}}. Ready at {{pickup_time}}", **When** order confirmation notification is triggered, **Then** system substitutes variables and sends "Order confirmed at Pizza Palace. Ready at 6:30 PM"
2. **Given** template includes multiple languages, **When** customer's preferred language is Spanish, **Then** Spanish template version is used for notification
3. **Given** admin updates existing template, **When** template is saved, **Then** all subsequent notifications use new template immediately (no code deployment required)
4. **Given** template uses invalid variable {{unknown_field}}, **When** notification is triggered, **Then** system logs error and uses default template as fallback

---

### User Story 5 - Delivery Tracking & Retry Logic (Priority: P1)

System needs to track notification delivery status (sent, delivered, failed) and automatically retry failed notifications to ensure critical messages reach recipients.

**Why this priority**: Important for reliability but not blocking for MVP. Manual monitoring can substitute initially. Automated retry improves customer experience.

**Independent Test**: Can be fully tested by simulating delivery failures (invalid phone number, gateway timeout), verifying system retries with exponential backoff, and confirming delivery status is tracked in logs.

**Acceptance Scenarios**:

1. **Given** SMS delivery fails with temporary error (gateway timeout), **When** failure is detected, **Then** system retries up to 3 times with delays of 30s, 60s, 120s (exponential backoff)
2. **Given** push notification fails (device token expired), **When** failure reason is "InvalidToken", **Then** system falls back to SMS immediately without retries and marks device token for refresh
3. **Given** notification delivery succeeds, **When** confirmation is received from gateway, **Then** delivery status is recorded with timestamp, message ID, and delivery latency
4. **Given** notification fails permanently (invalid phone number), **When** all retries exhausted, **Then** system logs failure, alerts admin if critical (order confirmation), and does not retry again

---

### User Story 6 - Customer Wallet Notifications (Priority: P2)

Customers receive proactive notifications about wallet events (payment method expiring soon, new saved address, loyalty points earned) to maintain account health and engagement.

**Why this priority**: Nice-to-have for customer engagement but not critical for core ordering functionality. Can be deferred to post-MVP.

**Independent Test**: Can be fully tested by simulating wallet events (payment method expiring in 7 days, customer saves new address), verifying notifications are sent with appropriate content and timing.

**Acceptance Scenarios**:

1. **Given** customer's payment method expires in 7 days, **When** daily wallet check job runs, **Then** customer receives notification "Your payment card ending in [last4] expires soon. Update in your wallet."
2. **Given** customer earns loyalty points (post-MVP feature), **When** points are credited to wallet, **Then** customer receives notification "You earned 50 points at [restaurant]! Total: [balance] points."
3. **Given** customer saves new delivery address, **When** address is confirmed, **Then** customer receives confirmation notification "New address saved: [address]. Use it on your next order."
4. **Given** customer wants to opt out of wallet notifications, **When** they disable wallet alerts in preferences, **Then** system stops sending wallet notifications but continues order status notifications

---

### Edge Cases

- What happens when customer's phone number is invalid or disconnected? System logs delivery failure, alerts admin for order-critical notifications, and falls back to email if available (future enhancement).
- How does system handle SMS rate limits from Twilio? Implement queue throttling to respect rate limits, prioritize order-critical notifications over promotional messages, and delay non-urgent notifications.
- What happens when Firebase Cloud Messaging quota is exceeded? Fall back to SMS for all push notifications, alert admin of quota issue, and implement daily quota monitoring.
- How does system handle notifications for scheduled orders (placed today for pickup tomorrow)? Store scheduled notifications in queue with trigger time, process via cron job or scheduled queue, send notifications at appropriate times relative to pickup time.
- What happens when notification template has syntax errors? System detects errors during template validation, prevents saving invalid templates, and uses fallback template if error occurs at runtime.
- How does system prevent notification spam to customers? Implement rate limiting (max 10 notifications per customer per hour), deduplicate identical notifications within 5-minute window, and respect customer notification preferences.

## Requirements *(mandatory)*

### Functional Requirements

#### Notification Delivery
- **FR-001**: System MUST send order status notifications (confirmed, in-preparation, ready, completed, cancelled) to customers within 10 seconds of status change
- **FR-002**: System MUST support SMS delivery via Twilio with automatic fallback if primary gateway fails
- **FR-003**: System MUST support mobile push notifications via Firebase Cloud Messaging for customers with mobile app installed
- **FR-004**: System MUST prioritize push over SMS (send push first, SMS only if push fails after 30 seconds) to reduce costs
- **FR-005**: System MUST deliver restaurant operator alerts (new orders, POS failures, kiosk offline) within 5 seconds for time-sensitive events

#### Privacy-First Routing
- **FR-006**: System MUST route notifications using wallet_id without exposing customer phone numbers to restaurants or operators
- **FR-007**: System MUST look up customer contact info (phone, device tokens) from Customer Wallet service using wallet_id
- **FR-008**: System MUST never include customer PII (full phone number, email) in notification delivery logs accessible to restaurants
- **FR-009**: System MUST mask customer phone numbers in all restaurant-facing interfaces (show only last 4 digits)
- **FR-010**: System MUST enforce row-level security ensuring restaurants can only trigger notifications for their own orders

#### Template Management
- **FR-011**: System MUST support notification templates with variable substitution (order_id, restaurant_name, pickup_time, customer_name, etc.)
- **FR-012**: System MUST validate templates for syntax errors before saving and prevent deployment of invalid templates
- **FR-013**: System MUST support multiple template versions for A/B testing (percentage-based rollout)
- **FR-014**: System MUST support multi-language templates with automatic selection based on customer language preference
- **FR-015**: System MUST use fallback default template if specific template is unavailable or fails validation at runtime

#### Delivery Tracking & Retry
- **FR-016**: System MUST track notification delivery status (queued, sent, delivered, failed) with timestamps and gateway message IDs
- **FR-017**: System MUST retry failed notifications up to 3 times with exponential backoff (30s, 60s, 120s) for temporary failures
- **FR-018**: System MUST immediately fall back to SMS if push notification fails due to invalid device token (no retries)
- **FR-019**: System MUST log permanent failures (invalid phone, blocked number) and alert admin for order-critical notifications
- **FR-020**: System MUST provide delivery metrics dashboard showing success rate, average latency, failure reasons by notification type

#### Rate Limiting & Queuing
- **FR-021**: System MUST implement per-customer rate limiting (max 10 notifications per hour) to prevent spam
- **FR-022**: System MUST deduplicate identical notifications to same recipient within 5-minute window
- **FR-023**: System MUST prioritize notifications by type (order status > operator alerts > wallet notifications > promotional)
- **FR-024**: System MUST respect SMS gateway rate limits with queue throttling and delayed processing for non-urgent notifications
- **FR-025**: System MUST support scheduled notifications for future delivery (e.g., "Order ready soon" notification 10 minutes before pickup time)

#### Operator & Admin Features
- **FR-026**: System MUST send restaurant operator alerts via both dashboard notifications (in-app) and SMS for critical events
- **FR-027**: System MUST respect operator role permissions (Owners/Managers receive SMS alerts, Staff receive dashboard only)
- **FR-028**: System MUST provide admin interface for viewing notification delivery logs filtered by restaurant, customer, date range, status
- **FR-029**: System MUST alert admin when delivery success rate drops below 90% or average latency exceeds 15 seconds
- **FR-030**: System MUST support manual notification resend by admin for failed deliveries (with approval for privacy compliance)

### Key Entities

- **NotificationEvent**: Represents a notification to be sent with event type (order_status, operator_alert, wallet_notification), recipient (wallet_id or operator_id), template_id, variables (order_id, restaurant_name, etc.), priority level, scheduled delivery time
- **NotificationTemplate**: Stores message templates with template name, event type, content (SMS and push variants), variables list, language code, active/inactive status, version number for A/B testing
- **DeliveryAttempt**: Tracks each delivery attempt with notification_event_id, attempt number, delivery channel (SMS/push), gateway message ID, status (queued, sent, delivered, failed), failure reason, timestamp, latency
- **CustomerContactInfo**: Cached customer contact data retrieved from Customer Wallet service with wallet_id, phone number (encrypted), device tokens (FCM), language preference, notification preferences, last updated timestamp
- **OperatorAlertSettings**: Stores operator notification preferences with operator_id, restaurant_id, alert types enabled (new_orders, pos_failures, kiosk_offline), delivery channels (dashboard, SMS), quiet hours
- **NotificationQueue**: Manages queued notifications with priority ranking, scheduled delivery time, retry count, next retry time, expiration time (discard if not sent within X hours)
- **DeliveryMetrics**: Aggregated metrics for monitoring with restaurant_id, date, notification type, total sent, delivered count, failed count, average latency, failure reasons breakdown

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 95% of order status notifications are delivered to customers within 10 seconds of status change
- **SC-002**: 99% of critical operator alerts (new orders, POS failures) are delivered within 5 seconds of event
- **SC-003**: Notification delivery success rate exceeds 98% for SMS and 95% for push notifications (accounting for device token expirations)
- **SC-004**: System processes 10,000 notifications per hour during peak hours without delivery delays
- **SC-005**: Privacy architecture ensures 0 incidents of customer PII exposure to restaurants in first 6 months
- **SC-006**: Failed notifications are retried automatically with 90% ultimate delivery success after retries
- **SC-007**: Push notification prioritization reduces SMS costs by 60% compared to SMS-only approach
- **SC-008**: Average notification delivery latency (trigger to delivery) is under 5 seconds for 90% of notifications
- **SC-009**: Template updates are deployed within 1 minute without requiring code changes or service restarts
- **SC-010**: Admin can diagnose delivery failures within 2 minutes using delivery tracking dashboard
- **SC-011**: Customer complaints about missed or late notifications reduced by 80% compared to manual notification process
- **SC-012**: Rate limiting prevents notification spam with 0 customer complaints about excessive messages

## Assumptions *(mandatory)*

1. **SMS Gateway**: Twilio will be used for SMS delivery with standard US phone number support. International SMS support is out of scope for MVP.
2. **Push Notifications**: Firebase Cloud Messaging (FCM) will be used for mobile push. Apple Push Notification Service (APNS) will be handled through FCM's APNS integration.
3. **Message Content**: Notification messages will be in English initially. Multi-language support is P1 feature using template management.
4. **Delivery Guarantees**: System provides "at-least-once" delivery (may send duplicates on retry). Exactly-once delivery is not guaranteed due to gateway limitations.
5. **Customer Consent**: Customers implicitly consent to order-related notifications when placing orders. Opt-out is available only for promotional messages, not order status updates.
6. **Operator Consent**: Operators consent to operational alerts when creating accounts. No opt-out for critical alerts (new orders).
7. **Cost Management**: SMS costs will be managed through push prioritization and rate limiting. Budget is allocated for average 2 SMS per order (confirmation + ready).
8. **Queue Persistence**: Notification queue will use database-backed queue (PostgreSQL) initially. Redis-backed queue for higher throughput is P2 optimization.
9. **Template Ownership**: Platform administrators manage templates centrally. Per-restaurant template customization is out of scope for MVP.
10. **Audit Retention**: Notification delivery logs will be retained for 90 days in hot storage, 2 years in cold storage for compliance and analytics.

## Constitution Alignment *(mandatory)*

### Principle I: AI-First Architecture
- Future integration with conversation mining: Analyze notification open rates and customer responses to optimize timing and content
- AI-driven notification scheduling: Predict optimal send times based on customer behavior patterns (post-MVP)

### Principle II: Multi-Tenancy by Design
- Notification service enforces row-level security with restaurant_id tenant isolation
- Each restaurant can only trigger notifications for their own orders
- Templates and delivery settings are tenant-specific where applicable (operator alert preferences)

### Principle III: Privacy-First Customer Data
- **CRITICAL ALIGNMENT**: Notification routing uses wallet_id without exposing customer phone numbers to restaurants
- Customer contact info lookup is internal service call to Customer Wallet service
- Delivery logs never expose customer PII to restaurant-accessible interfaces
- Masked phone numbers (last 4 digits) shown in operator dashboards

### Principle IV: Omnichannel by Default
- Notification infrastructure supports all ordering channels (IVR, kiosk, mobile, future web portal) with channel-agnostic event triggers
- Delivery method selection (push vs SMS) is based on customer app installation status, not ordering channel
- Order status notifications work identically regardless of which channel customer used to place order

### Principle V: Progressive Enhancement & MVP Discipline
- **P0 Features**: Order status notifications, operator alerts, privacy-first routing, basic delivery tracking (FR-001 to FR-010, FR-016 to FR-019)
- **P1 Features**: Template management, advanced retry logic, rate limiting, scheduled notifications (FR-011 to FR-015, FR-020 to FR-025)
- **P2/P3 Features (Deferred)**: Multi-language templates, A/B testing, AI-driven send time optimization, promotional notifications, customer preference center

### Principle VI: Network Effects & Platform Thinking
- Centralized notification infrastructure enables cross-restaurant features (future loyalty programs, network-wide promotions)
- Aggregated delivery metrics provide platform-wide reliability monitoring
- Template library can be shared across restaurants with customization options (post-MVP)

### Principle VII: Integration-Friendly Architecture
- Notification service exposes RESTful API for triggering notifications from all platform services (Order Fulfillment, Admin Dashboard, Customer Wallet)
- Webhook support for delivery status callbacks to external systems (future)
- Pluggable gateway architecture allows adding new SMS/push providers without core changes

## Dependencies *(mandatory)*

### Internal Dependencies (Parcera Platform)
- **Order Fulfillment (spec 006)**: Triggers order status change notifications
- **Admin Dashboard (spec 009)**: Displays operator alerts and delivery tracking dashboard
- **Customer Identity (spec 008)**: Provides customer contact info (phone, device tokens) via wallet_id lookup
- **Restaurant Management (spec 001)**: Provides restaurant details for notification content (name, address, contact info)
- **Kiosk Ordering (spec 004)**: Triggers kiosk offline alerts to operators

### External Dependencies
- **Twilio SMS Gateway**: For SMS delivery with delivery confirmation webhooks
- **Firebase Cloud Messaging (FCM)**: For mobile push notifications to iOS and Android devices
- **Queue System**: Database-backed queue (PostgreSQL) or Redis for high throughput
- **Template Engine**: Mustache or Handlebars for variable substitution in templates

## Future Considerations *(optional)*

### Post-MVP Enhancements (P2/P3)
- **Multi-Language Support**: Template translations with automatic language selection based on customer preference
- **A/B Testing Framework**: Percentage-based template rollout with conversion tracking
- **Customer Preference Center**: Self-service opt-in/opt-out for notification types (wallet alerts, promotions) via mobile app
- **AI-Driven Send Time Optimization**: Machine learning model to predict optimal notification send times based on customer engagement patterns
- **Rich Push Notifications**: Action buttons ("View Order", "Call Restaurant"), inline images, notification grouping
- **Email Notifications**: Backup channel for customers who opt out of SMS, order confirmation emails with PDF receipts
- **Promotional Campaigns**: Scheduled bulk notifications for restaurant promotions with segmentation and personalization
- **Two-Way SMS**: Customers can reply to order notifications with questions or changes (routes to operator chat)
- **Delivery Driver Notifications**: Real-time updates to delivery drivers for order pickup and delivery coordination
- **Advanced Analytics**: Notification performance dashboard with open rates, click-through rates, opt-out rates by segment
