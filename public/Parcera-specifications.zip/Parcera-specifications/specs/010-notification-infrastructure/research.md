# Phase 0: Research - Notification Infrastructure

**Date**: 2025-11-04 | **Status**: Complete | **Next**: data-model.md

## 1. SMS Gateway Analysis

### Twilio (SELECTED)

**Rationale**: 
- Industry standard with proven reliability (99.95% uptime)
- Webhook-based delivery status callbacks (critical for tracking)
- REST API with simple auth (Bearer token)
- Excellent Python SDK (`twilio`)
- Rich failure reason codes (invalid_phone, rate_limit, etc.)
- Supports US/international numbers
- Cost: ~$0.0075/SMS, volume discounts available

**Integration Pattern**:
```python
from twilio.rest import Client

client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
message = client.messages.create(
    body="Your order is ready!",
    from_=TWILIO_PHONE_NUMBER,
    to=customer_phone
)
# message.sid → store as gateway_msg_id
# Webhook: POST /webhooks/twilio/delivery → status updates
```

**Webhook Events**:
- `MessageSent` (message enqueued, not delivered)
- `MessageDelivered` (carrier confirmed delivery)
- `MessageFailed` (invalid_phone, rate_limit, etc.)

**Fallback Strategy**:
- If Twilio is down, queue in PostgreSQL and retry with exponential backoff
- Health check: periodic test SMS to internal number
- Fallback to SendGrid email for non-SMS channels (P2)

---

### Alternatives Considered

| Option | Pros | Cons | Status |
|--------|------|------|--------|
| AWS SNS | AWS integration, multi-channel | Less granular failure codes, pricier | Rejected |
| Vonage (Nexmo) | Good pricing | Slower support, weaker Python SDK | Rejected |
| Custom gateway | Full control | No reliability, must manage uptime | Rejected |

---

## 2. Push Notification Gateway Analysis

### Firebase Cloud Messaging (SELECTED)

**Rationale**:
- Google-backed, high deliverability (99%+ on modern devices)
- Handles both Android (FCM native) and iOS (via APNS bridge)
- Admin SDK for server-side sending
- Token refresh handling documented
- Rich notification payload (title, body, data, actions)
- Cost: Free at scale (100M messages/month)

**Integration Pattern**:
```python
import firebase_admin
from firebase_admin import messaging

app = firebase_admin.initialize_app(cred)

message = messaging.Message(
    notification=messaging.Notification(
        title="Order Ready!",
        body="Your order is ready for pickup at Pizza Palace"
    ),
    data={
        "order_id": "12345",
        "action": "open_order_detail"
    },
    token=device_token
)
response = messaging.send(message)
# response → gateway_msg_id
```

**Token Management**:
- Tokens stored in `CustomerContactInfo.device_tokens` (JSON array)
- Webhook from mobile app on token refresh → update in DB
- Expired token error → mark token for deletion, fall back to SMS

**Fallback for Failed Push**:
- If `InvalidRegistration` or `NotRegistered` error → skip retry, fall back to SMS immediately
- If `MessageRateExceeded` → queue and retry with backoff
- If `InternalError` → retry up to 3 times

---

### Alternatives Considered

| Option | Pros | Cons | Status |
|--------|------|------|--------|
| Apple APNS direct | Direct iOS control | iOS-only, rate limits, certs complex | Used via FCM bridge |
| OneSignal | Multi-channel, UI dashboard | Vendor lock-in, less granular control | Rejected |
| Pusher Beams | Simple API | High cost, limited control | Rejected |

---

## 3. Queue System Analysis

### PostgreSQL with SKIP LOCKED (SELECTED for MVP)

**Rationale**:
- No external dependency (already required for core DB)
- SKIP LOCKED clause prevents queue contention
- Simple to operate and backup
- Sufficient for 10k notifications/hour throughput
- Easy to debug (SQL queries)

**Pattern**:
```sql
-- Dequeue with priority
SELECT id, notification_id, priority, next_retry_time
FROM notification_queue
WHERE status = 'queued' AND next_retry_time <= NOW()
ORDER BY priority DESC, created_at ASC
LIMIT 100
FOR UPDATE SKIP LOCKED;
```

**Transition Path**: If throughput exceeds 50k/hour, migrate to Redis (P2 optimization).

---

### Alternatives Considered

| Option | Pros | Cons | Status |
|--------|------|------|--------|
| Redis Queue (RQ) | Fast, battle-tested | Extra infrastructure | P2 optimization |
| Celery + RabbitMQ | Standard, distributed | Complex setup, overkill for MVP | Rejected (use Celery + DB backend) |
| AWS SQS | Managed, auto-scaling | Vendor lock-in, eventual consistency | Rejected |

---

## 4. Async Task Framework

### Celery with Database Backend (SELECTED)

**Rationale**:
- Distributed task processing (horizontal scale)
- Built-in retry logic and exponential backoff
- Scheduled tasks via Beat (cron jobs)
- Works with PostgreSQL broker (AMQP fallback later)
- Large Python community, proven in production

**Pattern**:
```python
from celery import Celery

app = Celery('notifications', broker='sqla+postgresql://...')

@app.task(bind=True, max_retries=3)
def send_sms_task(self, notification_id):
    try:
        # Twilio call
        twilio.messages.create(...)
    except TwilioException as exc:
        # Retry with exponential backoff
        raise self.retry(exc=exc, countdown=60 * (2 ** self.request.retries))

@app.on_after_finalize.connect
def setup_periodic_tasks(sender, **kwargs):
    sender.add_periodic_task(60.0, process_retry_queue.s())
```

---

## 5. Template Engine Analysis

### Jinja2 (SELECTED)

**Rationale**:
- Industry standard for Python (Flask, Django)
- Safe sandboxed rendering (prevent code injection)
- Rich variable syntax: `{{ order_id }}, {% if is_urgent %}...{% endif %}`
- Easy to validate syntax before saving
- Excellent error messages for debugging

**Pattern**:
```python
from jinja2 import Environment, StrictUndefined

env = Environment(undefined=StrictUndefined)
template = env.from_string("Order {{ order_id }} is ready at {{ restaurant_name }}")
content = template.render(order_id="12345", restaurant_name="Pizza Palace")
# Output: "Order 12345 is ready at Pizza Palace"
```

**Validation**:
```python
def validate_template(content: str) -> Tuple[bool, Optional[str]]:
    try:
        env.from_string(content)
        return True, None
    except Exception as e:
        return False, str(e)
```

---

### Alternatives Considered

| Option | Pros | Cons | Status |
|--------|------|------|--------|
| Mustache | Simpler syntax | Less powerful (no conditionals) | Rejected |
| Django templates | Full-featured | Heavy, requires Django setup | Rejected |
| Custom parser | Light, fast | Fragile, security risk | Rejected |

---

## 6. Privacy Architecture: Wallet_ID Routing

### Design Pattern

**Problem**: Restaurants cannot be trusted with customer phone numbers (spam, data breach).

**Solution**: Indirect routing via Wallet Service lookup.

```
┌─────────────────────────────────────────────────────────┐
│ Flow: Order Status Change → Trigger Notification        │
├─────────────────────────────────────────────────────────┤
│ 1. Order Service emits: OrderReadyEvent(order_id, ...)  │
│ 2. Notifications API receives event                      │
│ 3. Lookup order → extract wallet_id (NOT phone)         │
│ 4. Call Wallet Service: GetCustomerContact(wallet_id)   │
│    └─ Returns: {phone: "+1...", device_tokens: [...]}   │
│ 5. Store DeliveryAttempt(wallet_id, status, ...)        │
│    └─ NO phone number in log                             │
│ 6. Send via Twilio/FCM                                  │
└─────────────────────────────────────────────────────────┘
```

**Security Constraints**:
1. Delivery logs store `wallet_id`, never phone number
2. Operator dashboards show only masked phone (last 4 digits)
3. Export/backup of delivery logs excludes phone numbers
4. Row-level security: restaurants can only query their own orders
5. Phone number encryption at rest (AES-256)

**Test Case**:
- Create order as Restaurant A
- Verify Restaurant A cannot see full phone in any API response
- Verify delivery logs contain wallet_id but not phone
- Verify notification was actually delivered to correct number (internal test only)

---

## 7. Retry Strategy & Exponential Backoff

### Retry Policy

| Failure Type | Retry Count | Backoff | Fallback |
|--------------|-------------|---------|----------|
| Temporary (timeout, rate_limit) | 3 | 30s, 60s, 120s | Next channel or give up |
| Invalid token (push) | 0 | N/A | SMS immediately |
| Invalid phone (SMS) | 1 | 60s | Log + alert admin (order-critical) |
| Permanent (blocked number) | 0 | N/A | Log + give up |

**Implementation**:
```python
@app.task(bind=True, max_retries=3, default_retry_delay=30)
def send_sms_task(self, notification_id):
    attempt = self.request.retries
    delay = 30 * (2 ** attempt)  # 30s, 60s, 120s
    
    try:
        send_sms(notification_id)
    except TemporaryGatewayError as e:
        if attempt < 3:
            raise self.retry(exc=e, countdown=delay)
        else:
            mark_as_failed(notification_id, "max_retries_exceeded")
    except PermanentError as e:
        mark_as_failed(notification_id, str(e))
```

---

## 8. Deployment & Monitoring Strategy

### Infrastructure

```
┌──────────────────────────────────┐
│ FastAPI Service (uvicorn)        │
│ - POST /api/v1/notifications/... │
│ - POST /webhooks/twilio/...      │
└────────────┬─────────────────────┘
             │
      ┌──────┴────────┐
      │               │
┌─────▼────────┐  ┌───▼──────────┐
│ PostgreSQL   │  │ Celery Beat  │
│ - Queue      │  │ - Retry loop │
│ - Logs       │  │ - Metrics    │
│ - Templates  │  │ - Scheduled  │
└─────────────┘  └──────────────┘
      │               │
      └───────┬───────┘
              │
      ┌───────▼──────────┐
      │ Celery Workers   │
      │ - send_sms       │
      │ - send_push      │
      │ - process_queue  │
      └───────┬──────────┘
              │
       ┌──────┴─────────┐
       │                │
    ┌──▼──┐          ┌──▼───┐
    │SMS  │          │Push  │
    │(TW) │          │(FCM) │
    └─────┘          └──────┘
```

### Health Checks

```python
# Health check endpoint for orchestrator (K8s, etc.)
@app.get("/health")
def health_check():
    checks = {
        "db": check_db_connection(),
        "celery": check_celery_workers(),
        "twilio": check_twilio_api(),
        "fcm": check_fcm_credentials(),
    }
    status = "healthy" if all(checks.values()) else "unhealthy"
    return {"status": status, "checks": checks}
```

### Monitoring Metrics

- **Queue Depth**: SELECT COUNT(*) FROM notification_queue WHERE status='queued'
- **Delivery Success Rate**: (delivered / total) * 100 for past 24h
- **Latency P95**: SELECT PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY latency) ...
- **Twilio API Errors**: COUNT(*) BY failure_reason, failure_category
- **FCM Token Expiration Rate**: COUNT(*) WHERE failure_reason='InvalidToken' / total_push

---

## 9. Testing Strategy

### Unit Tests (pytest)

```python
# tests/notifications/test_delivery.py
@pytest.fixture
def mock_twilio(monkeypatch):
    def create_message(**kwargs):
        return Mock(sid="test_msg_123")
    monkeypatch.setattr("twilio.rest.Client.messages.create", create_message)

def test_send_sms_success(mock_twilio):
    result = send_sms("notification_123", "+1234567890", "Hello")
    assert result.gateway_msg_id == "test_msg_123"
    assert result.status == "sent"

def test_send_push_invalid_token(mock_fcm):
    with pytest.raises(InvalidRegistrationError):
        send_push("notification_456", "invalid_token", {})

def test_template_rendering():
    template = NotificationTemplate(content="Order {{ order_id }} ready")
    result = template.render(order_id="12345")
    assert result == "Order 12345 ready"

def test_privacy_mask_phone():
    assert mask_phone("+12025551234") == "+1202555****"
```

### Integration Tests

- Trigger order status change → verify notification queued
- Webhook from Twilio → verify delivery_attempt updated
- Retry processor fires → verify retry scheduled correctly
- Template update → verify next notification uses new content

### E2E Tests (staging)

- Place test order via API
- Confirm order
- Verify SMS received within 10s
- Verify push received (if app installed)
- Check delivery logs in admin dashboard
- Confirm phone number not exposed to restaurant

---

## 10. Configuration & Environment

### Environment Variables Required

```plaintext
# Twilio
TWILIO_ACCOUNT_SID=ACxxxxxxxx
TWILIO_AUTH_TOKEN=your_token
TWILIO_PHONE_NUMBER=+1234567890

# Firebase
FIREBASE_PROJECT_ID=your-project
FIREBASE_PRIVATE_KEY=your_key_file.json

# Celery
CELERY_BROKER_URL=sqla+postgresql://user:pass@localhost/parcera
CELERY_RESULT_BACKEND=db+postgresql://user:pass@localhost/parcera

# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/parcera

# Wallet Service (internal)
WALLET_SERVICE_URL=http://wallet-service:8000

# Monitoring
SENTRY_DSN=https://...
LOG_LEVEL=INFO
```

---

## 11. Cost Projections (Annual)

| Component | Estimate | Notes |
|-----------|----------|-------|
| Twilio SMS | $15k | ~50 SMS/day avg, 2 per order, 250k orders/month |
| Firebase | Free | <100M msgs/month |
| PostgreSQL | $500 | Managed, 100GB storage |
| Compute (workers) | $5k | 3-5 workers, container instances |
| **Total** | **~$20.5k/year** | Well within typical SaaS margins |

---

## Conclusion

**Architecture validated**:
- ✓ Twilio for SMS (reliable, webhook-based)
- ✓ Firebase for push (cost-effective, iOS+Android)
- ✓ PostgreSQL queue (no external deps, sufficient throughput)
- ✓ Celery for async (standard, distributed)
- ✓ Jinja2 for templates (safe, powerful)
- ✓ Wallet_ID privacy pattern (secure, Constitutional)
- ✓ Exponential backoff (industry best practice)

**Next Phase**: Generate data-model.md with full schema design.
