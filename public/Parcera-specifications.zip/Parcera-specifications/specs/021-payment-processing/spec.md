# Feature Specification: Payment Processing & Gateway Integration

**Feature Branch**: `021-payment-processing`
**Created**: 2025-10-30
**Status**: Draft
**Constitution Alignment**: Principles IV (Omnichannel), VI (Integration-Friendly)

---

## Overview

Comprehensive payment handling system supporting in-person and remote transactions across all ordering channels (POS tablet, kiosk, mobile app, IVR). Provides secure payment processing with physical card readers, contactless payments, stored payment methods for repeat customers, split payments, configurable tipping, refunds, and multi-gateway support. Ensures PCI-compliant handling with tokenization, offline payment queuing, and detailed reconciliation reporting.

**Core Value**: Enables seamless, secure payment acceptance across all channels while maintaining PCI compliance, supporting multiple payment methods, and providing operational visibility through analytics and reconciliation.

---

## User Scenarios & Testing

### User Story 1 - Process In-Person Card Payment at POS (Priority: P0)

**As a** restaurant staff member using POS tablet
**I want to** process customer payment using physical card reader
**So that** customers can pay quickly and securely with their credit/debit cards

**Why this priority**: Core revenue-generating capability. Without in-person payment processing, restaurants cannot accept card payments at point of sale.

**Independent Test**: Can be fully tested by: (1) staff completes customer order on POS, (2) selects "Card Payment", (3) customer taps/inserts/swipes card on reader, (4) payment processes successfully, (5) receipt prints/displays. Delivers standalone value by enabling primary payment method.

**Acceptance Scenarios**:

1. **Given** order total is $45.50, **When** staff selects "Card Payment" on POS, **Then** card reader activates, displays "Present Card" message, and waits for customer action
2. **Given** card reader active, **When** customer taps contactless card (tap-to-pay, Apple Pay, Google Pay), **Then** payment processes in under 3 seconds, displays "Approved" message, updates order status to "Paid"
3. **Given** customer inserts chip card, **When** payment processes, **Then** reader prompts "Do Not Remove Card", processes EMV chip transaction, displays "Remove Card" when complete
4. **Given** payment approved, **When** transaction completes, **Then** system generates receipt with: transaction ID, timestamp, last 4 digits of card, payment amount, tip (if added), total, prints or emails receipt based on customer preference
5. **Given** payment declined, **When** card issuer rejects transaction, **Then** system displays decline reason ("Insufficient funds", "Card declined - contact bank"), allows retry or alternative payment method

---

### User Story 2 - Add Tip Before Payment (Priority: P0)

**As a** customer paying at POS or kiosk
**I want to** add a tip before completing payment
**So that** I can show appreciation for good service

**Why this priority**: Standard restaurant payment flow requirement. Tip functionality expected for full-service and counter-service restaurants.

**Independent Test**: Can be fully tested by: (1) order reaches payment step, (2) tip screen displays with suggested percentages, (3) customer selects tip amount, (4) payment processes with tip included in total. Delivers value through expected payment experience.

**Acceptance Scenarios**:

1. **Given** order subtotal is $40.00, **When** payment flow begins, **Then** tip screen displays suggested amounts: 15% ($6.00), 18% ($7.20), 20% ($8.00), Custom, No Tip
2. **Given** customer selects 18% tip, **When** selection made, **Then** tip amount ($7.20) adds to order, total updates to $47.20, payment proceeds with new total
3. **Given** customer selects "Custom", **When** custom tip screen displays, **Then** customer can enter specific dollar amount, system validates (positive number, reasonable limit), adds to total
4. **Given** customer selects "No Tip", **When** selection made, **Then** payment proceeds with original subtotal only, no tip added
5. **Given** tip configuration set by restaurant, **When** tip screen loads, **Then** system uses restaurant's configured percentages (default: 15%, 18%, 20% or custom settings from restaurant preferences)

---

### User Story 3 - Split Payment Across Multiple Methods (Priority: P1)

**As a** group of customers paying together
**I want to** split payment across multiple cards or cash + card
**So that** each person can pay their portion

**Why this priority**: Common in full-service restaurants but not essential for quick-service. Improves customer experience but payment still works without it.

**Independent Test**: Can be fully tested by: (1) order total $100, (2) customer 1 pays $50 with Card A, (3) customer 2 pays $50 with Card B, (4) both payments process, (5) order marked fully paid. Delivers value through flexible payment options.

**Acceptance Scenarios**:

1. **Given** order total is $100.00, **When** staff selects "Split Payment", **Then** system prompts "Enter first payment amount" with numeric keypad
2. **Given** staff enters $50.00 for first payment, **When** amount confirmed, **Then** system processes $50 card payment, marks $50 as paid, shows remaining balance $50.00
3. **Given** first payment successful, **When** second payment begins, **Then** card reader activates for remaining $50.00, processes second card, completes order when fully paid
4. **Given** split payment includes cash, **When** staff selects "Cash" for second portion, **Then** system accepts cash amount entry, calculates change if needed, marks order fully paid when cash + card equals total
5. **Given** split payment fails mid-process, **When** second payment declines, **Then** system holds first payment (already captured), allows retry of second payment or refund of first payment to cancel order

---

### User Story 4 - Store Payment Method for Repeat Customer (Priority: P1)

**As a** repeat customer
**I want** my payment method securely stored
**So that** I can pay quickly on future orders without re-entering card details

**Why this priority**: Convenience feature that improves repeat customer experience but not blocking for first-time transactions.

**Independent Test**: Can be fully tested by: (1) customer completes first order, opts to save payment method, (2) system tokenizes and stores, (3) on second order, customer selects saved payment method, (4) payment processes without re-entering card. Delivers value through faster checkout.

**Acceptance Scenarios**:

1. **Given** customer completing payment via mobile app, **When** payment screen displays, **Then** checkbox shows "Save payment method for faster checkout"
2. **Given** customer checks "Save payment method", **When** payment processes successfully, **Then** system tokenizes card with payment gateway, stores token (not raw card data) linked to customer wallet ID
3. **Given** repeat customer placing new order, **When** they reach payment step, **Then** system displays saved payment methods: "Visa •••• 1234 (expires 12/25)" with option to "Use this card" or "Pay with new card"
4. **Given** customer selects saved payment method, **When** "Use this card" clicked, **Then** payment processes using stored token, requires CVV re-entry for security (CVV never stored), completes payment
5. **Given** customer wants to remove saved payment method, **When** they access wallet payment settings, **Then** list of saved cards displays with "Remove" button, confirmation dialog prevents accidental deletion

---

### User Story 5 - Process Refund for Cancelled Order (Priority: P1)

**As a** restaurant manager
**I want to** process refunds for cancelled or incorrect orders
**So that** customers receive their money back and maintain satisfaction

**Why this priority**: Essential for customer service but not part of happy path payment flow. Refunds are exception cases.

**Independent Test**: Can be fully tested by: (1) manager accesses completed order with payment, (2) selects "Refund", (3) enters refund amount and reason, (4) confirms refund, (5) payment gateway processes refund. Delivers value through customer service recovery.

**Acceptance Scenarios**:

1. **Given** completed order with payment $50.00, **When** manager views order details, **Then** "Refund" button displays alongside order information
2. **Given** manager clicks "Refund", **When** refund dialog opens, **Then** system shows: original payment amount, refund amount field (default: full amount), refund reason dropdown (incorrect order, cancelled, customer request, other), notes field
3. **Given** manager enters partial refund $25.00 with reason "Incorrect order - remade", **When** "Process Refund" clicked, **Then** system confirms "Refund $25.00 to Visa ••••1234?", manager confirms, refund submits to payment gateway
4. **Given** refund processes successfully, **When** gateway confirms, **Then** system updates order status to "Partially Refunded" or "Fully Refunded", displays refund transaction in payment history, customer receives refund notification
5. **Given** refund fails (expired authorization, gateway error), **When** error occurs, **Then** system displays specific error message, logs failure, suggests manual refund via payment gateway dashboard

---

### User Story 6 - Reconcile Daily Payments (Priority: P1)

**As a** restaurant owner or accountant
**I want to** reconcile POS payments against payment gateway deposits
**So that** I can verify all transactions processed correctly and identify discrepancies

**Why this priority**: Operational necessity for financial accuracy but can be done manually initially. Automated reconciliation improves efficiency.

**Independent Test**: Can be fully tested by: (1) restaurant processes 50 orders in a day, (2) owner runs reconciliation report, (3) system matches POS transactions to gateway settlements, (4) report shows matched/unmatched transactions. Delivers value through financial confidence.

**Acceptance Scenarios**:

1. **Given** business day ends, **When** owner accesses "Payment Reconciliation" in dashboard, **Then** system displays: date selector, "Run Reconciliation" button, previous reconciliation reports list
2. **Given** owner selects date and runs reconciliation, **When** report generates, **Then** system retrieves: all POS transactions for date from order system, all gateway transactions for date from payment provider, matches by transaction ID
3. **Given** reconciliation completes, **When** report displays, **Then** summary shows: total POS transactions (count, amount), total gateway settlements (count, amount), matched transactions (count, amount), discrepancies (count, amount)
4. **Given** discrepancies exist, **When** owner views discrepancy details, **Then** report lists: transactions in POS but not in gateway (potential processing failures), transactions in gateway but not in POS (potential duplicate charges), amount mismatches with details
5. **Given** report generated, **When** owner clicks "Export", **Then** system downloads CSV or PDF with all transaction details for accounting records

---

### Edge Cases

- What happens when card reader loses connection during transaction?
  - System detects disconnection, displays "Connection Lost" error, queues transaction for retry when connection restores (if order captured), or cancels and allows retry

- How does system handle when payment gateway is temporarily unavailable?
  - System enters offline mode, stores payment details securely, displays "Processing Offline" to staff, automatically processes queued payments when gateway reconnects (within 24 hours)

- What happens when customer dispute/chargeback occurs weeks after order?
  - Payment gateway notifies system via webhook, system flags order with "Disputed" status, alerts restaurant owner, provides dispute details and evidence submission deadline

- How does system handle currency conversion for international cards?
  - Payment gateway handles conversion automatically at current exchange rate, customer sees charge in their home currency, restaurant receives settlement in configured currency (USD default)

- What happens when refund amount exceeds original payment (e.g., compensation)?
  - System prevents refunds exceeding original payment amount, displays error "Refund cannot exceed $X.XX", requires manager to issue separate compensation payment if needed

- How does system handle partial refunds on split payments?
  - System refunds to original payment methods proportionally, or allows manual allocation if manager specifies which payment method receives refund

- What happens when stored payment method expires or card is reported lost/stolen?
  - Gateway declines payment, system notifies customer "Saved payment method declined", prompts to update payment method, removes expired/invalid card from saved methods

---

## Requirements

### Functional Requirements

**Payment Gateway Integration**

- **FR-001**: System MUST integrate with Stripe as primary payment gateway supporting card payments, ACH, and digital wallets
- **FR-002**: System MUST provide adapter pattern architecture allowing integration with alternative gateways (Square, Authorize.Net, Adyen) without core system changes
- **FR-003**: System MUST configure gateway per tenant allowing different restaurants to use different payment providers
- **FR-004**: System MUST handle gateway webhook events (payment succeeded, failed, refunded, disputed) and update order status accordingly
- **FR-005**: System MUST retry failed webhook processing with exponential backoff (3 attempts over 1 hour) before alerting staff

**In-Person Card Payments**

- **FR-006**: System MUST integrate with card reader hardware at POS supporting: tap (contactless NFC), chip (EMV), swipe (magnetic stripe fallback)
- **FR-007**: System MUST activate card reader when payment flow begins, displaying "Present Card" prompt to customer
- **FR-008**: System MUST process contactless payments (tap-to-pay, Apple Pay, Google Pay) in under 3 seconds average transaction time
- **FR-009**: System MUST process chip card payments displaying "Do Not Remove Card" during processing, "Remove Card" when complete
- **FR-010**: System MUST handle payment declines gracefully displaying reason ("Insufficient funds", "Card declined", "Try another card"), allowing retry
- **FR-011**: System MUST support signature capture for transactions exceeding $25 (configurable threshold) on card reader or tablet display

**Contactless and Digital Wallet Payments**

- **FR-012**: System MUST support Apple Pay processing at POS, kiosk, and mobile app
- **FR-013**: System MUST support Google Pay processing at POS, kiosk, and mobile app
- **FR-014**: System MUST support Samsung Pay and other NFC-based payment methods
- **FR-015**: System MUST validate digital wallet token before processing, handling expired or invalid tokens with clear error messages

**Stored Payment Methods**

- **FR-016**: System MUST allow customers to save payment methods during checkout with explicit opt-in ("Save for future use" checkbox)
- **FR-017**: System MUST tokenize payment methods with gateway, storing only token (not raw card data) linked to customer wallet ID
- **FR-018**: System MUST display saved payment methods as "Card Type •••• Last4Digits (Expires MM/YY)" protecting full card number
- **FR-019**: System MUST require CVV re-entry when using saved payment method (CVV never stored per PCI requirements)
- **FR-020**: System MUST allow customers to remove saved payment methods with confirmation dialog preventing accidental deletion
- **FR-021**: System MUST automatically remove expired payment methods after expiration date passes

**Split Payments**

- **FR-022**: System MUST allow splitting payment across multiple payment methods (card + card, cash + card, multiple cards)
- **FR-023**: System MUST prompt for first payment amount, process payment, display remaining balance, repeat until fully paid
- **FR-024**: System MUST track partial payments showing: payment method, amount, status for each portion
- **FR-025**: System MUST complete order only when sum of all partial payments equals or exceeds total (with change calculation for overpayment)
- **FR-026**: System MUST handle split payment failures by holding successful payments, allowing retry of failed portion or refunding successful portions to cancel

**Tip Handling**

- **FR-027**: System MUST display tip screen after order total calculated, before payment processes
- **FR-028**: System MUST show suggested tip percentages configurable per restaurant (default: 15%, 18%, 20%)
- **FR-029**: System MUST calculate suggested tip amounts based on subtotal (before tax per US convention)
- **FR-030**: System MUST provide "Custom Tip" option allowing customer to enter specific dollar amount
- **FR-031**: System MUST provide "No Tip" option for customer opt-out
- **FR-032**: System MUST add selected tip to total before payment processing
- **FR-033**: System MUST display tip separately on receipt showing: subtotal, tax, tip, total

**Refunds and Voids**

- **FR-034**: System MUST allow authorized staff (managers, owners) to process refunds from order detail page
- **FR-035**: System MUST support full refunds (entire payment amount) and partial refunds (specified amount up to original total)
- **FR-036**: System MUST require refund reason selection (incorrect order, cancelled, customer request, quality issue, other) with optional notes
- **FR-037**: System MUST confirm refund amount and payment method before processing: "Refund $X.XX to [Card Type] ••••[Last4]?"
- **FR-038**: System MUST process refund through payment gateway, updating order status to "Refunded" or "Partially Refunded"
- **FR-039**: System MUST prevent refunds exceeding original payment amount with validation error
- **FR-040**: System MUST record refund transaction in payment history with: timestamp, amount, reason, staff member who processed
- **FR-041**: System MUST void (cancel) payments that haven't been captured yet (authorization only) instead of refunding when possible

**Payment Validation**

- **FR-042**: System MUST validate payment amount matches order total before processing, preventing under/over-charges
- **FR-043**: System MUST validate minimum transaction amount (typically $0.50) required by payment processors
- **FR-044**: System MUST validate card expiration date is in future, declining expired cards
- **FR-045**: System MUST validate CVV format (3-4 digits) when provided, passing to gateway for verification

**Receipt Generation**

- **FR-046**: System MUST generate receipts containing: business name, order number, transaction ID, timestamp, itemized order, subtotal, tax, tip, total, payment method (type + last 4 digits), staff member name
- **FR-047**: System MUST offer receipt delivery options: printed (if printer available), emailed, SMS, digital (displayed on screen only)
- **FR-048**: System MUST store receipt data with order for reprint requests
- **FR-049**: System MUST generate merchant copy and customer copy for card payments per payment card rules

**Payment Status Tracking**

- **FR-050**: System MUST track payment status through lifecycle: pending → authorized → captured → settled (or failed/refunded)
- **FR-051**: System MUST display payment status on order details page for staff visibility
- **FR-052**: System MUST automatically capture authorized payments within 7 days (per card network rules) or void to prevent chargebacks
- **FR-053**: System MUST handle authorization expiry (typically 7 days) by voiding uncaptured authorizations and alerting staff

**PCI Compliance**

- **FR-054**: System MUST never store raw card numbers (PAN), only tokenized references from payment gateway
- **FR-055**: System MUST never store CVV/CVC security codes per PCI-DSS requirements
- **FR-056**: System MUST never log full card numbers in system logs or error messages
- **FR-057**: System MUST use end-to-end encryption (E2EE) for card data transmitted from reader to gateway
- **FR-058**: System MUST validate PCI-compliant card readers before allowing payment processing

**Offline Payment Queue**

- **FR-059**: System MUST detect payment gateway unavailability and enter offline mode
- **FR-060**: System MUST queue payment requests locally when offline with encrypted storage
- **FR-061**: System MUST display "Offline Payment - Will Process When Connected" message to staff
- **FR-062**: System MUST automatically process queued payments when connection restores, updating order status
- **FR-063**: System MUST expire offline payment queue after 24 hours, alerting staff of unprocessed payments requiring manual handling

**Payment Reconciliation**

- **FR-064**: System MUST provide payment reconciliation report comparing POS transactions to gateway settlements by date
- **FR-065**: System MUST match transactions by transaction ID, flagging: unmatched POS transactions, unmatched gateway transactions, amount discrepancies
- **FR-066**: System MUST calculate reconciliation summary: total expected (POS), total received (gateway), difference (discrepancy amount)
- **FR-067**: System MUST export reconciliation reports as CSV or PDF for accounting records
- **FR-068**: System MUST highlight discrepancies requiring investigation with drill-down to transaction details

**Payment Analytics**

- **FR-069**: System MUST track daily payment totals by method (card, cash, digital wallet)
- **FR-070**: System MUST calculate average transaction value across all payments
- **FR-071**: System MUST track average tip percentage for business performance insights
- **FR-072**: System MUST provide payment method breakdown showing percentage of revenue by method type
- **FR-073**: System MUST track refund rate (refunds / total transactions) as business health metric

**Multi-Currency Support**

- **FR-074**: System MUST support restaurant-configured default currency (USD, CAD, EUR, GBP, etc.)
- **FR-075**: System MUST allow payment processing in default currency only in MVP (no multi-currency checkout)
- **FR-076**: System MUST display all prices, tips, and totals in configured currency with proper formatting (symbol, decimal places)
- **FR-077**: System MUST handle international cards through gateway's automatic currency conversion

---

### Key Entities

- **Payment Transaction**: Record of payment attempt or completion. Contains transaction_id (unique from gateway), order_id, amount, currency, payment_method_type (card/cash/digital_wallet), status (pending/authorized/captured/failed/refunded), gateway_response, created_at, captured_at. Immutable audit trail.

- **Payment Method**: Stored payment option for repeat customer. Contains method_id, customer_wallet_id, payment_gateway, token (from gateway, not raw card), card_brand (Visa/Mastercard/Amex), last_4_digits, expiry_month, expiry_year, billing_zip, is_default, created_at. Tokenized for PCI compliance.

- **Payment Gateway Config**: Per-tenant gateway settings. Contains tenant_id, gateway_provider (stripe/square/authnet), api_credentials (encrypted), currency, test_mode_enabled, webhook_secret. Allows different restaurants to use different processors.

- **Refund Transaction**: Record of refund processed. Contains refund_id, original_transaction_id, amount, reason, reason_notes, processed_by_staff_id, processed_at, gateway_refund_id, status (pending/completed/failed). Links to original payment.

- **Split Payment**: Tracks multi-method payment. Contains split_id, order_id, total_amount, payments (array of partial payment records), status (in_progress/completed/failed). Coordinates multiple transactions for single order.

- **Tip Configuration**: Restaurant-specific tip settings. Contains tenant_id, suggested_percentages (array: [15, 18, 20]), tip_calculation_base (subtotal/total), allow_custom, allow_no_tip. Configurable by restaurant.

- **Payment Receipt**: Generated receipt record. Contains receipt_id, transaction_id, order_id, receipt_type (customer/merchant), delivery_method (printed/emailed/sms), generated_at, receipt_data (JSON with all details). Allows reprinting.

- **Reconciliation Report**: Daily settlement matching record. Contains report_id, date, pos_transaction_count, pos_total_amount, gateway_transaction_count, gateway_total_amount, discrepancy_count, discrepancy_amount, matched_transactions (array), unmatched_transactions (array), generated_at.

- **Offline Payment Queue**: Temporarily stored payment during gateway outage. Contains queue_id, order_id, payment_data (encrypted), queued_at, expires_at (24 hours), status (queued/processing/completed/expired). Processes when connection restores.

- **Payment Analytics Summary**: Aggregated payment metrics. Contains date, total_transactions, total_amount, payment_method_breakdown (JSON: card/cash/wallet percentages), average_transaction_value, average_tip_percentage, refund_count, refund_amount. Daily rollup for reporting.

---

## Success Criteria

### Measurable Outcomes

- Card payments process successfully in under 3 seconds for 95% of tap-to-pay transactions
- Payment failure rate below 2% (excluding legitimate declines like insufficient funds)
- Stored payment method usage rate of 40%+ among repeat customers
- Tip opt-in rate of 70%+ for full-service restaurants
- Refund processing completes in under 30 seconds
- Payment reconciliation identifies 100% of discrepancies (zero undetected mismatches)
- Offline payment queue processes 100% of queued payments within 1 hour of connection restoration
- PCI compliance audit passes with zero violations (no raw card data stored)
- Average transaction value increases by 15% with digital payment methods vs cash-only
- Payment gateway integration supports 1000+ concurrent transactions without degradation

### Qualitative Measures

- Customers report confidence in payment security (no concerns about card data safety)
- Staff report payment processing is faster than previous cash register systems
- Restaurant owners report financial accuracy improved through automated reconciliation
- Reduced payment disputes due to clear receipts and transaction records
- Customers appreciate saved payment methods for repeat visits
- Staff training time reduced with intuitive payment flow

---

## Dependencies and Assumptions

### Dependencies

- Spec 006 (Order Fulfillment) provides order totals and status management that payment integrates with
- Spec 008 (Customer Identity & Wallet) provides customer wallet ID for stored payment methods
- Payment gateway account (Stripe, Square, etc.) must be provisioned before payment processing
- Card reader hardware must be certified PCI PTS (PIN Transaction Security) compliant
- Internet connectivity required for real-time payment processing (offline queue for outages)

### Assumptions

- Restaurants have reliable internet connectivity for payment processing (cellular backup for outages)
- Card readers are physically secured at POS to prevent tampering or theft
- Staff receive training on payment processing, refunds, and troubleshooting declines
- Most transactions are card-based (80%+) with declining cash usage trend
- Payment gateway provides webhooks for event notifications (payment status changes)
- Gateway settlement occurs within 2-3 business days (standard ACH timing)
- Customers trust contactless and digital wallet payments (adoption growing)
- Refunds are exceptional cases (< 5% of transactions) not primary flow

### Out of Scope

- Cash management and till balancing (cash drawer tracking) - deferred to future release
- Check payment processing - uncommon in restaurant industry, deferred
- Gift card and loyalty point redemption as payment - separate loyalty feature
- Cryptocurrency payments (Bitcoin, Ethereum) - not mainstream yet, future consideration
- Installment payments or "buy now, pay later" - not typical for restaurant transactions
- Dynamic currency conversion (DCC) at terminal - gateway handles, not restaurant system
- Automatic gratuity calculation for large parties - manual adjustment in MVP
- Employee meal comp/discount payment handling - part of order management, not payment gateway

---

**Status**: ✅ Ready for validation and `/speckit.plan` command
