# Feature Specification: Order Display & Monitoring

**Feature Branch**: `029-order-display`
**Created**: 2025-10-31
**Status**: Draft
**Input**: User description: "Order Display & Monitoring - Simple web-based order display system for restaurant staff to monitor incoming orders from Parcera ordering channels (IVR, Mobile, Kiosk). Provides read-only view of orders received, order details (items, customer info, channel source), and basic status. NOT a full Kitchen Display System (KDS) with fulfillment workflow, station routing, or order bumping - this is a lightweight monitoring solution. Scope: Display orders from Parcera channels only, show order details, filter by status/channel/time, auto-refresh. Excludes: Kitchen workflow management, order fulfillment, station assignment, ticket age tracking, order bumping (covered by SPEC 024 - full KDS, deferred to future)."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Real-Time Order Monitoring Display (Priority: P1)

Restaurant staff (kitchen, front-of-house) accesses web-based Order Display on tablet/monitor showing all incoming orders from Parcera channels (IVR, Mobile, Kiosk) in real-time. Display shows order number, channel source (phone icon for IVR, mobile icon for app, kiosk icon), order timestamp, customer name, items ordered with modifiers, and current status (New, Preparing, Ready). Screen auto-refreshes every 10 seconds to show new orders without manual reload. Staff can see at-a-glance what orders are pending and what's in progress.

**Why this priority**: This is the CORE use case - restaurant staff needs visibility into orders coming through Parcera channels. Without this, staff must rely on email/SMS notifications alone, which don't provide centralized view. Critical for restaurants integrating Parcera as additional ordering channel alongside existing POS. P1 because it provides immediate operational value.

**Independent Test**: Can be fully tested by placing 3 orders via different channels (1 IVR, 1 Mobile, 1 Kiosk), opening Order Display on tablet, verifying all 3 orders appear with correct details, icons, timestamps. Delivers value: staff can see and track all Parcera orders in one place.

**Acceptance Scenarios**:

1. **Given** restaurant has received 5 orders today (2 IVR, 2 Mobile, 1 Kiosk), **When** staff opens Order Display URL on tablet, **Then** displays all 5 orders in reverse chronological order (newest first), each showing: order #, channel icon, timestamp, customer name, items with quantities/modifiers, total, status

2. **Given** Order Display is open on kitchen monitor, **When** new order arrives via IVR at 2:30 PM, **Then** within 10 seconds (next auto-refresh), new order appears at top of list with "New" status badge, phone icon, flashing animation to draw attention, audio notification plays (optional)

3. **Given** 10 orders displayed (mix of New, Preparing, Ready statuses), **When** staff views screen, **Then** orders grouped by status: "New Orders" section at top (red badge), "Preparing" section middle (yellow badge), "Ready" section bottom (green badge), each section sorted by oldest first within group

4. **Given** staff clicks on order #1234 in list, **When** order detail expands, **Then** shows full breakdown: customer name, phone number, channel source, order timestamp, payment method, each item with customizations (e.g., "Large Pepperoni Pizza - Extra Cheese (+$2), No Mushrooms"), special instructions, subtotal, tax, total, estimated ready time

5. **Given** Order Display has been open for 30 minutes, **When** connection to server is lost, **Then** displays "Connection Lost - Reconnecting..." banner at top, attempts auto-reconnect every 5 seconds, shows last successful refresh timestamp, resumes normal operation when connection restored

---

### User Story 2 - Order Status Filtering & Search (Priority: P2)

Restaurant staff filters Order Display to show only specific order statuses (New, Preparing, Ready) or specific channels (IVR only, Mobile only, Kiosk only) or time ranges (last hour, today, yesterday). Staff searches for specific order by order number or customer name to quickly locate and review details. Filtering helps focus on relevant orders during busy periods (e.g., show only "New" orders needing attention).

**Why this priority**: Filtering improves usability during high-volume periods (lunch rush, dinner rush) by reducing visual clutter. Staff can focus on actionable orders (New, Preparing) and hide completed orders. P2 because basic list view (User Story 1) is functional; filtering is enhancement for efficiency.

**Independent Test**: Can be tested by creating 20 orders with various statuses/channels, applying filter "Status: New, Channel: IVR", verifying only New IVR orders display, clearing filter to show all orders again. Delivers value: faster order lookup during busy times.

**Acceptance Scenarios**:

1. **Given** 50 orders displayed from today (20 New, 15 Preparing, 15 Ready), **When** staff clicks "Status Filter" and selects "New" only, **Then** display shows only 20 New orders, filter badge shows "Filtered (1 active)", "Clear Filters" button appears

2. **Given** staff needs to check all phone orders, **When** clicks "Channel Filter" and selects "IVR" icon, **Then** display shows only IVR orders across all statuses, channel filter badge highlights IVR icon in blue

3. **Given** customer calls asking "Where's my order?", **When** staff types order number "4567" in search box, **Then** display immediately filters to show only order #4567 with highlighted search term, shows full order details including status and estimated ready time

4. **Given** manager wants to review yesterday's orders, **When** clicks "Time Range" filter and selects "Yesterday", **Then** display shows all orders from previous calendar day (midnight to midnight), disables real-time auto-refresh (historical view), shows "Historical View - Auto-refresh disabled" notice

5. **Given** multiple filters active (Status: New, Channel: Mobile, Time: Last Hour), **When** staff clicks "Clear Filters", **Then** all filters reset, display shows all orders from today, auto-refresh re-enables if was disabled, filter badges disappear

---

### User Story 3 - Multi-Device Display Support (Priority: P2)

Restaurant operates Order Display on multiple devices simultaneously (kitchen monitor showing all orders, expo station tablet showing "Ready" orders only, front desk phone showing "New" orders). Each device can configure independent filters/view preferences. Display works on various screen sizes (phone 5", tablet 10", monitor 24"+) with responsive layout. Staff can access same Order Display URL from any device without separate logins.

**Why this priority**: Restaurants have multiple staff stations (kitchen, expo, cashier) needing different views. Multi-device support enables distributed order monitoring. P2 because single-device view (User Story 1) is sufficient for MVP; multi-device is operational enhancement.

**Independent Test**: Can be tested by opening Order Display URL on 3 devices (phone, tablet, monitor), setting different filters on each (phone: New only, tablet: Ready only, monitor: all), verifying each shows correct filtered view independently. Delivers value: tailored views per station.

**Acceptance Scenarios**:

1. **Given** kitchen monitor displays all orders, expo tablet displays "Ready" orders only, **When** new order marked Ready, **Then** both devices show order (kitchen in full list, expo in Ready section), expo tablet plays notification sound, kitchen monitor shows status change animation

2. **Given** staff accesses Order Display on phone (5" screen), **When** page loads, **Then** displays mobile-optimized layout: condensed order cards (order # and status only), tap to expand full details, bottom navigation for filters, auto-hides header on scroll for screen space

3. **Given** Order Display open on 24" kitchen monitor, **When** page loads, **Then** displays desktop layout: 3-column grid (New | Preparing | Ready), larger text for readability from distance, each order shows full details without click, color-coded status badges

4. **Given** front desk tablet has filter "Channel: Mobile" active, **When** staff refreshes page or reopens URL, **Then** filter preference persists (saved in browser localStorage), tablet automatically applies Mobile filter, staff doesn't need to reconfigure

5. **Given** expo station tablet showing "Ready" orders, **When** order marked as Picked Up (removed from system), **Then** tablet auto-removes order from display after 10-second delay (with "Completed" flash animation), keeps display focused on pending Ready orders

---

### User Story 4 - Display Configuration & Customization (Priority: P3)

Restaurant owner/manager configures Order Display preferences: auto-refresh interval (5s, 10s, 30s, 60s), audio notifications (on/off, volume), default filter (e.g., always show today's orders), display theme (light, dark, high-contrast), font size (small, medium, large for accessibility), items per page (10, 25, 50, all). Configuration saved per device or per restaurant (global setting). Staff can toggle settings via gear icon without leaving Order Display.

**Why this priority**: Configuration enhances usability for different restaurant environments (noisy kitchen needs visual alerts, quiet office uses audio, bright kitchen needs dark theme to reduce glare). P3 because default settings work for most cases; customization is nice-to-have.

**Independent Test**: Can be tested by opening settings panel, changing auto-refresh to 30s, theme to dark, font size to large, saving settings, verifying display updates immediately and persists after page reload. Delivers value: tailored experience per environment.

**Acceptance Scenarios**:

1. **Given** kitchen is noisy, **When** staff opens settings and disables audio notifications, increases font size to Large, **Then** Order Display stops playing sounds, text size increases by 40%, new orders still show visual flash animation, settings saved to browser

2. **Given** bright kitchen environment, **When** staff selects "Dark Theme" in settings, **Then** background changes to dark gray (#1a1a1a), text to white, status badges to high-contrast colors (red/yellow/green with dark backgrounds), reduces eye strain

3. **Given** restaurant wants 5-second refresh for high-volume periods, **When** manager sets auto-refresh interval to 5 seconds, **Then** display polls server every 5 seconds instead of default 10 seconds, shows "Last updated: 3 seconds ago" timestamp, increases server load monitoring alert threshold

4. **Given** restaurant has slow internet, **When** staff increases auto-refresh interval to 60 seconds, **Then** reduces network requests, display shows "Refreshing in 45 seconds..." countdown, manual "Refresh Now" button available for immediate update

5. **Given** restaurant wants global settings for all devices, **When** owner configures settings in Business Dashboard and enables "Apply to All Devices", **Then** all tablets/monitors automatically adopt restaurant-wide settings (theme, refresh interval, filters), individual devices can still override locally

---

### Edge Cases

- What happens when 100+ orders load on page (performance)? (Display paginates orders: 50 per page default, "Load More" button for older orders, virtual scrolling for smooth performance)
- What happens when order data changes during page load? (Optimistic UI updates: show change immediately, rollback if server sync fails, retry in background, show conflict indicator if detected)
- What happens when auto-refresh fails repeatedly (network issues)? (After 3 failed attempts, show "Offline Mode" banner, stop auto-refresh to reduce error noise, manual refresh available, auto-resume when connection detected)
- What happens when two staff mark same order status simultaneously? (Last write wins, both devices sync to final state on next refresh, no conflict resolution needed for read-only display)
- What happens when displaying orders from multiple restaurant locations? (Filter dropdown includes location selector, defaults to current user's assigned location, admin can view all locations, location name shown on each order card)
- What happens when order contains 20+ items (very large order)? (Order card shows first 5 items with "...and 15 more items" link, click to expand full list, keeps display compact)
- What happens when customer name is missing (guest checkout)? (Display shows "Guest Customer" with order # as primary identifier, phone number if available, ensures every order has identifiable label)
- What happens when screen sleeps/device locks? (Browser detects visibility change, pauses auto-refresh, resumes when screen active, prevents unnecessary network calls, shows "Paused - Screen Inactive" indicator)
- What happens when multiple identical orders placed within 1 minute (suspected duplicates)? (Display shows both orders with "Possible Duplicate?" warning icon, staff can compare details, manually mark as duplicate, doesn't auto-merge to prevent data loss)
- What happens during midnight transition (date boundary)? (Auto-switches "Today" filter to new date at midnight, archives previous day's orders to "Yesterday" view, shows notification "Date changed - showing orders from [new date]")

## Requirements *(mandatory)*

### Functional Requirements

#### Display & Layout

- **FR-001**: System MUST provide web-based Order Display accessible via URL (no login required, URL includes auth token)
- **FR-002**: System MUST display all orders received from Parcera channels (IVR, Mobile, Kiosk) in unified list view
- **FR-003**: System MUST show order details: order number, channel source (icon), timestamp, customer name, items with modifiers, total, status
- **FR-004**: System MUST group orders by status: New (red badge), Preparing (yellow badge), Ready (green badge)
- **FR-005**: System MUST sort orders within each status group by timestamp (oldest first for actionable orders, newest first for completed)
- **FR-006**: System MUST provide responsive layout supporting screen sizes from 5" (phone) to 24"+ (monitor)
- **FR-007**: System MUST use channel-specific icons: phone for IVR, mobile device for Mobile app, kiosk screen for Kiosk
- **FR-008**: System MUST display item modifiers and customizations (e.g., "Extra Cheese (+$2)", "No Mushrooms")
- **FR-009**: System MUST show special instructions/notes entered by customer in order detail view
- **FR-010**: System MUST display payment method (Card, Cash, Card-on-file) and payment status (Paid, Pending)

#### Real-Time Updates

- **FR-011**: System MUST auto-refresh order list at configurable interval (default 10 seconds)
- **FR-012**: System MUST detect new orders and display with visual indicator (flash animation, "NEW" badge)
- **FR-013**: System MUST update order status changes in real-time (New → Preparing → Ready)
- **FR-014**: System MUST show "Last Updated" timestamp indicating most recent refresh
- **FR-015**: System MUST handle connection loss gracefully (show "Reconnecting..." banner, attempt auto-reconnect every 5 seconds)
- **FR-016**: System MUST resume auto-refresh automatically when connection restored
- **FR-017**: System MUST support manual refresh via "Refresh Now" button (bypasses auto-refresh timer)
- **FR-018**: System MUST play audio notification when new order arrives (optional, configurable on/off)

#### Filtering & Search

- **FR-019**: System MUST provide status filter: New, Preparing, Ready, All (multi-select)
- **FR-020**: System MUST provide channel filter: IVR, Mobile, Kiosk, All (multi-select)
- **FR-021**: System MUST provide time range filter: Last Hour, Today, Yesterday, Last 7 Days, Custom Date Range
- **FR-022**: System MUST provide search by order number (exact match or partial)
- **FR-023**: System MUST provide search by customer name (fuzzy match, case-insensitive)
- **FR-024**: System MUST display active filter badges (e.g., "Status: New", "Channel: IVR")
- **FR-025**: System MUST provide "Clear Filters" button to reset all filters to default (Today, All Statuses, All Channels)
- **FR-026**: System MUST persist filter preferences in browser localStorage (per device)
- **FR-027**: System MUST disable auto-refresh when viewing historical data (Yesterday, Last 7 Days, Custom Range)

#### Multi-Device Support

- **FR-028**: System MUST support concurrent access from multiple devices (kitchen monitor, expo tablet, front desk phone)
- **FR-029**: System MUST allow independent filter configurations per device (saved locally)
- **FR-030**: System MUST synchronize order data across all devices (via auto-refresh polling)
- **FR-031**: System MUST optimize layout for device type: condensed mobile view, detailed desktop view
- **FR-032**: System MUST detect screen orientation changes (portrait/landscape) and adjust layout responsively

#### Configuration & Customization

- **FR-033**: System MUST allow configuring auto-refresh interval: 5s, 10s, 30s, 60s (default 10s)
- **FR-034**: System MUST allow enabling/disabling audio notifications for new orders
- **FR-035**: System MUST provide theme selection: Light, Dark, High-Contrast (default Light)
- **FR-036**: System MUST allow font size adjustment: Small, Medium, Large (default Medium)
- **FR-037**: System MUST allow setting default filter preferences (e.g., always show "Today" + "New" status)
- **FR-038**: System MUST save configuration settings in browser localStorage (device-specific)
- **FR-039**: System MUST provide "Reset to Defaults" option to clear all custom settings
- **FR-040**: System MUST support restaurant-wide settings (configured in Business Dashboard, applied to all devices)

#### Performance & Reliability

- **FR-041**: System MUST load initial order list (50 orders) in under 2 seconds on 4G network
- **FR-042**: System MUST paginate orders for large datasets (50 orders per page, "Load More" for older orders)
- **FR-043**: System MUST use optimistic UI updates (show changes immediately, sync with server asynchronously)
- **FR-044**: System MUST handle server errors gracefully (show error message, allow retry, don't crash page)
- **FR-045**: System MUST pause auto-refresh when browser tab/window not visible (battery/network optimization)
- **FR-046**: System MUST resume auto-refresh when tab becomes active again
- **FR-047**: System MUST cache order data locally for offline viewing (last successful refresh data)
- **FR-048**: System MUST show "Offline Mode" indicator when server unreachable

#### Access & Security

- **FR-049**: System MUST generate unique Order Display URL per restaurant (includes auth token in URL)
- **FR-050**: System MUST validate auth token on every request to prevent unauthorized access
- **FR-051**: System MUST support auth token rotation (invalidate old URLs, generate new when requested by owner)
- **FR-052**: System MUST provide read-only access (no order status updates, no order modifications)
- **FR-053**: System MUST log access events for audit trail (device IP, timestamp, orders viewed)

### Key Entities

- **OrderDisplayView**: Configuration for Order Display instance. Contains view ID, restaurant ID (foreign key), display name (e.g., "Kitchen Monitor", "Expo Tablet"), auth token (unique URL identifier), active filters (JSON: status, channel, time range), configuration settings (refresh interval, theme, font size, audio enabled), device info (user agent, screen size), last accessed timestamp, creation date.

- **DisplaySession**: Tracking for active Order Display sessions. Contains session ID, view ID (foreign key), device fingerprint, IP address, session start timestamp, last heartbeat timestamp, active status (connected, disconnected), access count (number of refreshes), restaurant ID.

- **OrderDisplayConfig**: Restaurant-wide configuration for Order Display. Contains config ID, restaurant ID (foreign key), global settings (JSON: default filters, theme, refresh interval, audio), apply to all devices flag, custom CSS overrides (for branding), creation date, last modified date.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: Restaurant staff can view all orders from Parcera channels on Order Display within 2 seconds of page load
- **SC-002**: New orders appear in Order Display within 10 seconds of customer order confirmation (auto-refresh interval)
- **SC-003**: Order Display supports 100+ concurrent orders without performance degradation (page load <3 seconds, smooth scrolling)
- **SC-004**: Multi-device access works reliably - 3+ devices display independently with <1 second sync lag
- **SC-005**: 90% of restaurant staff find Order Display easier than email/SMS notifications for tracking orders (user feedback survey)
- **SC-006**: Order Display uptime ≥99.5% (excludes scheduled maintenance)
- **SC-007**: Connection loss recovery succeeds automatically within 30 seconds in 95% of cases
- **SC-008**: Staff locate specific order using search in <10 seconds (average time from search start to order found)
- **SC-009**: Filtering operations complete in <500ms (status filter, channel filter, date range filter)
- **SC-010**: Order Display works on 95% of modern browsers (Chrome, Safari, Firefox, Edge - last 2 versions)

### Qualitative Outcomes

- Restaurant staff have centralized view of all Parcera orders without switching between email/SMS/dashboard
- Kitchen staff can glance at monitor and immediately see pending orders needing preparation
- Front-of-house staff can answer customer "Where's my order?" questions instantly by checking display
- Order Display reduces missed orders from Parcera channels (visual monitoring vs relying on notifications)
- Restaurants using multiple ordering channels (Parcera + POS) can dedicate separate display to Parcera orders

### Assumptions

- Restaurant staff have access to devices with web browsers (tablets, monitors, phones) for displaying Order Display
- Stable internet connection available at restaurant (WiFi or wired) for auto-refresh functionality
- Order Display is supplementary monitoring tool, not primary order management system (SPEC 007 handles core workflow)
- Most restaurants will use 1-3 devices for Order Display (kitchen, expo, front desk)
- Auto-refresh polling (every 10 seconds) is acceptable latency vs complexity of WebSocket real-time push
- Order Display URL sharing is controlled by restaurant owner (they decide which staff get access)
- Display used primarily during operating hours (9AM-10PM typical), not 24/7 monitoring
- Order volume is <500 orders per day per restaurant (MVP scope), pagination handles higher volumes
- Staff accessing Order Display are technically capable of opening URL on device browser (no specialized training needed)
- Dark theme preference is environmental (bright kitchens) not personal preference (one theme per device)
- Order Display does NOT replace SPEC 024 (full KDS) - this is lightweight monitoring, KDS is fulfillment workflow
