# Implementation Plan: Admin Dashboard & Restaurant Portal

**Branch**: `009-admin-dashboard` | **Date**: 2025-11-04 | **Spec**: [spec.md](spec.md)
**Input**: Feature specification from `/specs/009-admin-dashboard/spec.md`

## Summary

Admin Dashboard is a web-based management interface enabling restaurant operators to manage orders in real-time, configure business settings, toggle menu availability, monitor device status, and access analytics. Multi-tenant architecture with role-based access control (Owner/Manager/Employee) supporting single and multi-location restaurants.

**Technical Approach**: React 18 + Redux frontend with TypeScript, FastAPI async backend with WebSocket real-time updates, PostgreSQL persistence, JWT authentication, pre-aggregated analytics for performance.

---

## Technical Context

**Language/Version**: Python 3.11 (backend), Node.js 18+ (frontend)  
**Primary Dependencies**: FastAPI, React 18, SQLAlchemy, Pydantic, Chart.js/Recharts, Socket.io/WebSocket  
**Storage**: PostgreSQL 13+  
**Testing**: pytest (backend), Jest/React Testing Library (frontend), Cypress/Playwright (E2E)  
**Target Platform**: Web (desktop/tablet optimized)  
**Project Type**: Web application (frontend + backend)  
**Performance Goals**: Order updates <2s latency, 50+ concurrent WebSocket connections, analytics queries <3s  
**Constraints**: <200ms page load p95, <1min for settings propagation, multi-tenant isolation enforced  
**Scale/Scope**: 10-100 locations per restaurant group, 100+ concurrent operators, 90-day order retention

---

## Constitution Check

**Gates**:
- [x] Principle I (AI-First): Dashboard integrates conversation mining (P2 feature)
- [x] Principle II (Multi-Tenancy): Row-level security with restaurant_id filtering at ORM + middleware level
- [x] Principle III (Privacy-First): Customer phone masked (last 4 digits), no PII exposure, wallet data never visible
- [x] Principle IV (Omnichannel): Orders from IVR/Kiosk/Mobile unified in single dashboard
- [x] Principle V (MVP Discipline): P0 (orders, settings, menu), P1 (analytics, kiosk monitoring, advanced RBAC)
- [x] Principle VI (Network Effects): Cross-restaurant benchmarks deferred to P2
- [x] Principle VII (Integration-Friendly): RESTful API contracts, WebSocket extensibility, no proprietary protocols

**Status**: PASS - No violations. Architecture aligns with all principles.

---

## Project Structure

### Documentation (this feature)

```plaintext
specs/009-admin-dashboard/
├── spec.md              # Feature specification (user stories, requirements)
├── plan.md              # This file (implementation plan)
├── research.md          # Phase 0: Architecture decisions, tech stack, dependency analysis
├── data-model.md        # Phase 1: Entity definitions, schemas, validation rules
├── quickstart.md        # Phase 1: Local dev setup, workflows, deployment
├── contracts/           # Phase 1: OpenAPI contracts for API endpoints
│   ├── orders.yaml
│   ├── settings.yaml
│   └── menu.yaml
└── tasks.md             # Phase 2: Implementation tasks (created by /speckit.tasks)
```

### Source Code (repository root)

```plaintext
backend/
├── app/
│   ├── main.py                 # FastAPI app initialization + CORS + middleware
│   ├── api/
│   │   ├── orders.py          # GET /orders, POST accept/reject/complete, WebSocket
│   │   ├── settings.py        # GET/PUT settings, close-temporarily endpoint
│   │   ├── menu.py            # POST toggle item/modifier, bulk-toggle
│   │   ├── auth.py            # POST /login, POST /logout
│   │   └── analytics.py       # GET daily/weekly/monthly snapshots (P1)
│   ├── models/
│   │   ├── user.py            # DashboardUser ORM model
│   │   ├── order.py           # OrderDashboardView read model
│   │   ├── settings.py        # RestaurantBusinessSettings ORM
│   │   ├── menu.py            # MenuAvailabilityOverride ORM
│   │   ├── kiosk.py           # KioskDevice ORM (P1)
│   │   ├── analytics.py       # AnalyticsSnapshot ORM
│   │   └── audit.py           # AuditLog ORM
│   ├── schemas/
│   │   ├── order.py           # Pydantic schemas for requests/responses
│   │   ├── settings.py
│   │   ├── user.py
│   │   └── menu.py
│   ├── services/
│   │   ├── order_service.py   # Order business logic (accept/reject/complete)
│   │   ├── auth_service.py    # JWT generation, password hashing, RBAC
│   │   ├── settings_service.py # Settings updates, cache invalidation
│   │   └── menu_service.py    # Availability override logic
│   ├── middleware/
│   │   ├── auth.py            # JWT validation middleware
│   │   └── multi_tenant.py    # restaurant_id injection + validation
│   ├── websockets/
│   │   └── manager.py         # Connection manager, broadcast logic
│   ├── cache/
│   │   └── redis.py           # Redis TTL cache (future optimization)
│   └── utils/
│       ├── validators.py
│       └── datetime.py
├── alembic/                    # DB migrations
│   └── versions/
│       └── 001_initial_schema.py
├── tests/
│   ├── unit/
│   │   ├── test_auth_service.py
│   │   ├── test_order_service.py
│   │   ├── test_menu_service.py
│   │   └── test_validators.py
│   ├── integration/
│   │   ├── test_orders_api.py
│   │   ├── test_multi_tenancy.py
│   │   ├── test_websocket_broadcast.py
│   │   └── test_settings_api.py
│   ├── conftest.py             # pytest fixtures
│   └── factories.py            # Test data factories
├── requirements.txt
├── Dockerfile.backend
├── .dockerignore
├── .env.example
└── alembic.ini

frontend/
├── src/
│   ├── components/
│   │   ├── Navbar.tsx          # Header with restaurant selector, logout
│   │   ├── Sidebar.tsx         # Nav menu (Orders, Settings, Menu, Analytics)
│   │   ├── OrderList.tsx       # Paginated order list with filtering/sorting
│   │   ├── OrderCard.tsx       # Single order card with accept/reject buttons
│   │   ├── OrderDetail.tsx     # Modal/panel with full order details
│   │   ├── BusinessSettings.tsx # Hours, address, contact, temporary close
│   │   ├── MenuAvailability.tsx # Item/modifier toggle UI, bulk actions
│   │   ├── Layout.tsx          # Outer shell combining navbar + sidebar
│   │   ├── OfflineBanner.tsx   # "Offline" indicator when no connection
│   │   ├── LoadingSpinner.tsx
│   │   └── AlertNotification.tsx
│   ├── pages/
│   │   ├── LoginPage.tsx       # Email/password login form
│   │   ├── DashboardPage.tsx   # Main dashboard with order list
│   │   ├── SettingsPage.tsx    # Business settings form
│   │   ├── MenuPage.tsx        # Menu availability management
│   │   ├── AnalyticsPage.tsx   # Analytics charts (P1)
│   │   └── DevicesPage.tsx     # Kiosk monitoring (P1)
│   ├── services/
│   │   ├── api.ts              # axios instance with auth header injection
│   │   ├── ws.ts               # WebSocket manager (connect, subscribe, broadcast)
│   │   ├── auth.ts             # localStorage token mgmt, JWT decode
│   │   └── cache.ts            # Browser cache helpers
│   ├── store/
│   │   ├── slices/
│   │   │   ├── orderSlice.ts   # Redux slice for orders (list, detail, status)
│   │   │   ├── authSlice.ts    # User, token, permissions
│   │   │   ├── settingsSlice.ts # Restaurant settings cache
│   │   │   ├── menuSlice.ts    # Menu availability overrides
│   │   │   └── uiSlice.ts      # Modal state, notifications
│   │   ├── store.ts            # Redux store configuration
│   │   └── hooks.ts            # Custom hooks (useAppDispatch, useAppSelector)
│   ├── hooks/
│   │   ├── useWebSocket.ts     # WebSocket subscription hook
│   │   ├── useAuth.ts          # Auth context/state
│   │   └── useRestaurant.ts    # Current restaurant context
│   ├── utils/
│   │   ├── formatters.ts       # Phone masking, currency, datetime
│   │   ├── validators.ts       # Form validation
│   │   └── constants.ts        # Enums, status labels
│   ├── styles/
│   │   └── globals.css         # Tailwind/Material-UI config
│   ├── App.tsx
│   ├── index.tsx
│   └── react-app-env.d.ts
├── public/
│   ├── index.html
│   └── favicon.ico
├── tests/
│   ├── unit/
│   │   ├── components/
│   │   ├── services/
│   │   └── utils/
│   ├── integration/
│   │   ├── LoginFlow.test.tsx
│   │   ├── OrderAcceptance.test.tsx
│   │   └── SettingsUpdate.test.tsx
│   └── cypress/
│       └── e2e/
│           ├── login.cy.ts
│           ├── order_management.cy.ts
│           ├── settings.cy.ts
│           └── menu_toggle.cy.ts
├── .env.example
├── package.json
├── tsconfig.json
├── Dockerfile.frontend
└── .dockerignore
```

**Structure Decision**: Web application (frontend + backend) option selected. React SPA frontend communicates with FastAPI REST + WebSocket backend. Separate Docker images for CI/CD pipeline.

---

## Complexity Tracking

No violations of constitution. Architecture is straightforward with clean separation of concerns:

| Aspect | Decision | Rationale |
|--------|----------|-----------|
| Monolithic vs Microservices | Monolithic backend | Single responsibility (order/menu mgmt), easier to scale vertically initially |
| WebSocket Library | Socket.io with fallback | Auto-handles connection loss, supported by FastAPI, client-side ease |
| Analytics Pre-aggregation | Daily snapshots + cron | Real-time analytics would require expensive queries; snapshots give 95% of value |
| Cache Strategy | Redis (future) + browser cache | Django-style TTL invalidation; browser cache for menu/settings |
| Authentication | JWT in localStorage | Stateless, works with horizontal scaling, CORS-friendly |

---

## Deliverables from Phase 1

1. **research.md**: Architecture decisions (React 18, FastAPI, WebSocket, PostgreSQL, multi-tenancy enforcement)
2. **data-model.md**: 7 core entities (DashboardUser, RestaurantBusinessSettings, OrderDashboardView, MenuAvailabilityOverride, KioskDevice, AnalyticsSnapshot, AuditLog) with schemas, validation, indexing
3. **quickstart.md**: 15-min setup guide (backend/frontend/DB), core workflows, test commands, deployment guide
4. **contracts/orders.yaml**: OpenAPI contract for order endpoints (list, detail, accept, reject, complete, WebSocket)
5. **contracts/settings.yaml**: OpenAPI contract for settings endpoints (get, put, close-temporarily, update hours)
6. **contracts/menu.yaml**: OpenAPI contract for menu endpoints (toggle item, toggle modifier, bulk toggle)

---

## Success Criteria (Phase 1)

- [x] All entities designed with clear relationships and validation
- [x] API contracts defined with concrete examples
- [x] Architecture documented with rationale
- [x] Quickstart guide enables local dev setup in <15 minutes
- [x] Multi-tenancy isolation specified at DB + ORM + middleware + WebSocket level
- [x] RBAC model defined (Owner/Manager/Employee with permission matrix)

---

## Phase 2 Deliverables (Tasks)

Generated by `/speckit.tasks` command. Includes:
- Backend implementation (models, services, API endpoints, WebSocket manager, auth middleware)
- Frontend implementation (components, pages, Redux store, API client, WebSocket client)
- Database migrations and seed data
- Unit/integration/E2E tests
- Docker image definitions
- Deployment playbooks

---

## Timeline Estimate

- **Phase 1 (Research & Design)**: 1 day (complete)
- **Phase 2 (Implementation)**: 2 weeks (backend core logic, frontend components, tests)
- **Phase 3 (Testing & Deployment)**: 1 week (staging validation, production rollout)
- **Phase 4 (P1 Features)**: 2 weeks (analytics, kiosk monitoring, advanced RBAC)

---

## Dependencies & Blockers

**Internal**:
- Spec 001 (Restaurant Management): Required for restaurant context
- Spec 002 (Menu Management): Required for menu structure + availability toggles
- Spec 006 (Order Fulfillment): Required for order events + status updates
- Spec 007 (POS Integration): Required for POS config validation

**External**:
- PostgreSQL 13+
- WebSocket-capable deployment infrastructure (most cloud providers support)

**No critical blockers identified**.

---

## Next Steps

1. ✅ Phase 1 complete (research.md, data-model.md, quickstart.md, contracts)
2. → Run `/speckit.tasks` to generate Phase 2 task breakdown
3. → Begin backend implementation (models, migrations, services)
4. → Begin frontend scaffolding (layout, pages, Redux store)
5. → Integration testing once backend/frontend communicate
6. → Staging deployment + user acceptance testing
7. → Production rollout with monitoring

---

## References

- **Main Spec**: [spec.md](spec.md)
- **Architecture**: [research.md](research.md)
- **Data Model**: [data-model.md](data-model.md)
- **Setup Guide**: [quickstart.md](quickstart.md)
- **API Contracts**: [contracts/](contracts/)

