# Research & Architecture: Admin Dashboard & Restaurant Portal

**Spec**: 009-admin-dashboard  
**Date**: 2025-11-04  
**Research Phase**: Complete

## Executive Summary

Admin Dashboard is a web-based management interface for restaurant operators. Core requirements include:
- Real-time order management (2s latency target)
- Business settings configuration 
- Menu availability toggles
- Analytics & reporting
- Multi-tenant with RBAC
- Kiosk device monitoring (P1)

**Technical Stack**: React 18+ frontend, FastAPI backend, WebSocket for real-time, PostgreSQL persistence, Chart.js/Recharts for visualizations.

---

## Architecture Decision Summary

### Frontend Architecture
**Choice**: React 18 with TypeScript, Material-UI or TailwindCSS, Redux/Context for state management

**Rationale**:
- React 18 async rendering allows incremental page updates for high order volume
- TypeScript ensures type safety for complex dashboard state
- Material-UI provides accessible, enterprise-grade component library
- Server-sent events (WebSocket fallback to long-polling) for real-time updates

**Key Patterns**:
- Component tree: Layout → Navbar → Sidebar → Main content (Order List | Analytics | Settings | Devices)
- Real-time state: WebSocket listener → Redux dispatch → UI re-render
- Pagination: 20 orders/page with infinite scroll on supported browsers
- Offline resilience: Service worker caches menu/settings; shows "Offline" banner if no connection

### Backend Architecture
**Choice**: FastAPI with async/await, SQLAlchemy ORM, Pydantic for validation

**Rationale**:
- FastAPI provides native async support for handling 50+ concurrent WebSocket connections
- SQLAlchemy enables flexible querying for multi-tenant row-level security
- Pydantic ensures request/response validation at API boundaries
- WebSocket endpoint for broadcasting order updates to multiple connected operators

**Key Patterns**:
- Endpoint structure: `/api/restaurants/{restaurant_id}/orders`, `/api/restaurants/{restaurant_id}/settings`, etc.
- Auth middleware: JWT token validation with restaurant_id + user role
- Multi-tenancy: All queries filtered by `restaurant_id` at ORM level
- Real-time broadcasting: Order status change → event published to all WebSocket subscribers for that restaurant

### Data Flow
1. Order placed via IVR/kiosk/mobile → Order Fulfillment system (spec 006) publishes event
2. Dashboard backend listens to Order events, transforms to OrderDashboardView
3. Backend broadcasts via WebSocket to all connected operators for that restaurant
4. Frontend receives update, Redux dispatches state change, React re-renders order list

### Database Schema (Core Tables)
```
dashboard_users (id, email, password_hash, restaurant_id, role, active, created_at)
restaurant_business_settings (id, restaurant_id, hours_json, closed_until, address, phone, pos_config_json)
menu_availability_overrides (id, restaurant_id, menu_item_id, available, scheduled_until, created_by, created_at)
kiosk_devices (id, restaurant_id, device_id, online, last_heartbeat, error_log_json, software_version)
analytics_snapshots (id, restaurant_id, date, order_count, revenue, channel_breakdown_json, top_items_json)
audit_logs (id, restaurant_id, user_id, action_type, affected_entity, created_at)
```

---

## Dependency Analysis

### Internal (Parcera Platform)
- **Order Fulfillment (spec 006)**: Consumes order events + submits status changes
- **Menu Management (spec 002)**: Reads menu structure, updates availability overrides
- **POS Integration (spec 007)**: Displays POS config UI, validates connection
- **Restaurant Management (spec 001)**: Reads business profile, locations, hours
- **Customer Identity (spec 008)**: Customer lookup (name only, no PII)

### External Libraries
- **Frontend**: React 18, axios, react-router-dom, @reduxjs/toolkit, @mui/material or tailwindcss, recharts, date-fns
- **Backend**: FastAPI, SQLAlchemy, pydantic, python-jose (JWT), websockets, psycopg2-binary
- **DevOps**: Docker, PostgreSQL 13+, pytest for testing

---

## Performance Considerations

### Caching Strategy
- Browser cache: Menu structure (5min TTL), business settings (2min TTL)
- Redis cache (future): Analytics snapshots, frequently accessed queries
- CDN: Static assets (React bundle, images, logos)

### Scaling Thresholds
- **Dashboard target**: 50 concurrent WebSocket connections per restaurant
- **Analytics queries**: Pre-aggregated daily snapshots to avoid expensive calculations
- **Order list pagination**: 20 items/page to limit DOM nodes
- **Real-time broadcast**: Group subscriptions by restaurant_id to avoid cross-tenant event pollution

### Bottleneck Mitigation
- Order list: Virtualization (react-window) for 100+ historical orders
- Analytics: Query caching with 1-hour invalidation for hourly/daily rollups
- Settings updates: Optimistic UI updates with server confirmation

---

## Security & Compliance

### Multi-Tenancy Enforcement
- JWT payload includes `restaurant_id` + `user_id` + `role`
- All API queries append WHERE clause: `restaurant_id = request.user.restaurant_id`
- WebSocket subscription tied to authenticated user + restaurant
- No cross-restaurant data leakage

### Authentication & RBAC
- Email/password login with hashed passwords (bcrypt)
- JWT tokens valid for 8 hours, auto-logout on expiry
- Role enforcement at middleware level (Owner | Manager | Employee)
- Session tracking for audit compliance

### Data Privacy
- No full phone numbers, email addresses, or payment methods displayed
- Customer wallet data never exposed to operators
- Operator actions logged in audit trail (what, who, when, which restaurant)
- GDPR-ready: customer data deletion cascades to orders after 90-day retention

---

## Testing Strategy

### Unit Tests (Backend)
- API endpoint tests (FastAPI TestClient)
- Auth/RBAC validation (permission checks)
- Data model validation (Pydantic schemas)

### Integration Tests
- Multi-tenant isolation (verify restaurant_id filtering)
- WebSocket broadcast (order update reaches all subscribers)
- POS integration flow (config + connection test + error handling)

### E2E Tests (Cypress/Playwright)
- Login → Accept order → Order status updates in real-time
- Business settings change → Reflected on mobile/IVR within 1 min
- Menu item toggle → Disappears from IVR/mobile/kiosk within 30s

---

## MVP Scope (P0)

✅ Real-time order management (accept/reject/complete)  
✅ Business settings (hours, closed toggle, address)  
✅ Menu availability (toggle items, bulk disable)  
✅ Order filtering + sorting  
✅ Basic RBAC (Owner/Manager/Employee)  
✅ Session management + audit logs  
✅ WebSocket real-time updates  

**P1 Deferred**:
- Analytics dashboard (pre-build daily snapshots)
- Kiosk monitoring (add device status endpoints)
- Advanced RBAC (location-level granularity)
- Multi-location analytics comparisons

---

## Open Technical Questions (Resolved)

Q: Should real-time updates use WebSocket or polling?  
**A**: WebSocket primary, with long-polling fallback (Socket.io handles auto-fallback)

Q: How to handle simultaneous menu availability edits by multiple operators?  
**A**: Last-write-wins with notification to other operators (optimistic locking not needed for MVP)

Q: Should analytics be real-time or pre-aggregated?  
**A**: Pre-aggregated daily snapshots (calculate at end-of-day or via cron), real-time metrics in P2

Q: POS integration—how detailed should config UI be?  
**A**: Basic (select POS type, enter key/secret, test connection). Detailed setup per spec 007.

---

## Next Steps

1. ✅ Research complete
2. → Data model design (phase 1)
3. → API contract definitions (phase 1)
4. → Quickstart guide (phase 1)
5. → Agent context update + commit

