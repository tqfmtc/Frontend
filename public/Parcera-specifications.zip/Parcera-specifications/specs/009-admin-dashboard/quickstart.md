# Quickstart: Admin Dashboard Implementation

**Spec**: 009-admin-dashboard  
**Date**: 2025-11-04  
**Target**: Local development setup + minimal backend + frontend scaffold

---

## Prerequisites

- Docker & Docker Compose
- Node.js 18+
- Python 3.11+
- PostgreSQL 13+ (or use Docker)
- Git

---

## Quick Start (15 minutes)

### 1. Backend Setup

```bash
cd backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install fastapi uvicorn sqlalchemy pydantic python-jose psycopg2-binary websockets

# Create .env
cat > .env << 'ENVEOF'
DATABASE_URL=postgresql://parcera:password@localhost:5432/admin_dashboard
JWT_SECRET=your-secret-key-change-in-production
ENVIRONMENT=development
ENVEOF

# Start PostgreSQL (if using Docker)
docker run -d \
  --name postgres-admin-dash \
  -e POSTGRES_USER=parcera \
  -e POSTGRES_PASSWORD=password \
  -e POSTGRES_DB=admin_dashboard \
  -p 5432:5432 \
  postgres:13

# Wait 5 seconds for DB to be ready
sleep 5

# Run migrations (create tables)
alembic upgrade head

# Start server
uvicorn app.main:app --reload --port 8000
```

Backend runs on http://localhost:8000  
API docs: http://localhost:8000/docs

### 2. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Create .env
cat > .env << 'ENVEOF'
REACT_APP_API_URL=http://localhost:8000
REACT_APP_WS_URL=ws://localhost:8000
ENVEOF

# Start development server
npm start
```

Frontend runs on http://localhost:3000

### 3. Test the Setup

**Login** (test credentials):
```
Email: owner@test.restaurant.local
Password: TestPassword123!
```

**Create a test order via mock endpoint**:
```bash
curl -X POST http://localhost:8000/api/test/orders \
  -H "Content-Type: application/json" \
  -d '{
    "restaurant_id": "550e8400-e29b-41d4-a716-446655440000",
    "customer_name": "John Doe",
    "items": [{"menu_item_id": "...", "quantity": 1}],
    "pickup_time_estimated": "2025-11-04T14:30:00Z"
  }'
```

**View the order** on dashboard at http://localhost:3000

---

## Project Structure

```
backend/
├── app/
│   ├── main.py                 # FastAPI app initialization
│   ├── api/
│   │   ├── orders.py          # Order management endpoints
│   │   ├── settings.py        # Business settings endpoints
│   │   ├── menu.py            # Menu availability endpoints
│   │   └── auth.py            # Auth endpoints
│   ├── models/
│   │   ├── user.py            # DashboardUser
│   │   ├── order.py           # OrderDashboardView
│   │   ├── settings.py        # RestaurantBusinessSettings
│   │   ├── menu.py            # MenuAvailabilityOverride
│   │   └── audit.py           # AuditLog
│   ├── services/
│   │   ├── order_service.py   # Order business logic
│   │   └── auth_service.py    # Auth/RBAC logic
│   ├── middleware/
│   │   └── auth.py            # JWT validation + multi-tenancy
│   └── websockets/
│       └── manager.py         # WebSocket connection manager
├── migrations/                # Alembic DB migrations
├── tests/
│   ├── unit/
│   ├── integration/
│   └── conftest.py
├── requirements.txt
└── .env (git-ignored)

frontend/
├── src/
│   ├── components/
│   │   ├── Navbar.tsx
│   │   ├── OrderList.tsx
│   │   ├── OrderDetail.tsx
│   │   ├── BusinessSettings.tsx
│   │   ├── MenuAvailability.tsx
│   │   └── Layout.tsx
│   ├── pages/
│   │   ├── LoginPage.tsx
│   │   ├── DashboardPage.tsx
│   │   ├── SettingsPage.tsx
│   │   └── AnalyticsPage.tsx
│   ├── services/
│   │   ├── api.ts             # API client (axios)
│   │   ├── ws.ts              # WebSocket client
│   │   └── auth.ts            # Auth helpers
│   ├── store/
│   │   ├── slices/
│   │   │   ├── orderSlice.ts
│   │   │   ├── authSlice.ts
│   │   │   └── settingsSlice.ts
│   │   └── store.ts           # Redux store
│   ├── App.tsx
│   └── index.tsx
├── .env (git-ignored)
└── package.json
```

---

## Core Workflows Implemented (MVP)

### 1. Login
```
User enters email/password
→ POST /api/auth/login
→ Returns JWT token
→ Store in localStorage
→ All future requests include Authorization header
```

### 2. View Orders (Real-Time)
```
Page loads
→ GET /api/restaurants/{restaurant_id}/orders (initial load)
→ Open WebSocket at /api/restaurants/{restaurant_id}/orders/subscribe
→ New order placed in Order Fulfillment system
→ Backend publishes event to WebSocket
→ Frontend receives update, Redux dispatches, UI re-renders
→ Order appears in list within 2 seconds
```

### 3. Accept Order
```
User clicks "Accept" button on order card
→ POST /api/restaurants/{restaurant_id}/orders/{order_id}/accept
→ Backend updates order status to ACCEPTED
→ Backend logs audit event
→ WebSocket broadcasts update to all operators
→ UI updates order status + disables "Accept" button
→ Customer notified via notification system (spec 005)
```

### 4. Toggle Menu Item Availability
```
User clicks toggle on menu item
→ POST /api/restaurants/{restaurant_id}/menu/items/{item_id}/toggle
→ Backend creates MenuAvailabilityOverride or updates existing
→ Backend invalidates availability cache (30s TTL)
→ WebSocket broadcasts event
→ IVR/Mobile/Kiosk systems query availability, see override, hide item
→ Change reflected within 30 seconds
```

### 5. Update Business Settings
```
User modifies hours, address, or other settings
→ PUT /api/restaurants/{restaurant_id}/settings
→ Backend validates (hours have all 7 days, open < close, etc.)
→ Backend updates RestaurantBusinessSettings
→ Backend invalidates settings cache (2min TTL)
→ WebSocket broadcasts event
→ IVR/Mobile query new settings, hours updated
→ Change reflected within 1 minute
```

---

## Testing the MVP

### Unit Tests (Backend)
```bash
pytest tests/unit/ -v
```

Covers:
- Auth/RBAC validation
- Data model validation
- Permission checks

### Integration Tests (Backend)
```bash
pytest tests/integration/ -v
```

Covers:
- Multi-tenant isolation
- WebSocket broadcast
- Order state transitions

### E2E Tests (Frontend)
```bash
npm run e2e
```

Covers:
- Login → accept order → real-time update
- Settings change propagation
- Menu item toggle

---

## Database Schema (Auto-Created)

Alembic migrations create the following tables on `alembic upgrade head`:

```sql
-- dashboard_users
CREATE TABLE dashboard_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  restaurant_id UUID NOT NULL,
  role VARCHAR(20) NOT NULL,
  active BOOLEAN DEFAULT true,
  last_login TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(restaurant_id, email),
  FOREIGN KEY(restaurant_id) REFERENCES restaurants(id)
);

-- restaurant_business_settings
CREATE TABLE restaurant_business_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID UNIQUE NOT NULL,
  hours_json JSONB NOT NULL,
  temporarily_closed BOOLEAN DEFAULT false,
  closed_until TIMESTAMP,
  closed_message TEXT,
  address VARCHAR(500),
  phone VARCHAR(20),
  email VARCHAR(255),
  logo_url VARCHAR(2048),
  pos_connected BOOLEAN DEFAULT false,
  pos_config_json JSONB,
  delivery_enabled BOOLEAN DEFAULT false,
  delivery_zones_json JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(restaurant_id) REFERENCES restaurants(id)
);

-- menu_availability_overrides
CREATE TABLE menu_availability_overrides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL,
  menu_item_id UUID,
  modifier_id UUID,
  available BOOLEAN NOT NULL,
  scheduled_start TIMESTAMP,
  scheduled_end TIMESTAMP,
  created_by UUID NOT NULL,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(restaurant_id) REFERENCES restaurants(id),
  FOREIGN KEY(created_by) REFERENCES dashboard_users(id)
);

-- kiosk_devices
CREATE TABLE kiosk_devices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL,
  device_id VARCHAR(128) NOT NULL,
  device_name VARCHAR(255),
  location_name VARCHAR(255),
  online BOOLEAN DEFAULT false,
  last_heartbeat TIMESTAMP,
  last_error TEXT,
  error_count INT DEFAULT 0,
  software_version VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(restaurant_id, device_id),
  FOREIGN KEY(restaurant_id) REFERENCES restaurants(id)
);

-- analytics_snapshots
CREATE TABLE analytics_snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL,
  snapshot_date DATE NOT NULL,
  snapshot_hour INT,
  order_count INT DEFAULT 0,
  order_count_by_channel JSONB,
  total_revenue DECIMAL(12, 2),
  revenue_by_channel JSONB,
  average_order_value DECIMAL(12, 2),
  top_items JSONB,
  peak_hour INT,
  orders_by_status JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(restaurant_id, snapshot_date, snapshot_hour),
  FOREIGN KEY(restaurant_id) REFERENCES restaurants(id)
);

-- audit_logs
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL,
  user_id UUID NOT NULL,
  action_type VARCHAR(50) NOT NULL,
  affected_entity_type VARCHAR(50) NOT NULL,
  affected_entity_id UUID,
  old_values JSONB,
  new_values JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(restaurant_id) REFERENCES restaurants(id),
  FOREIGN KEY(user_id) REFERENCES dashboard_users(id)
);

-- Indexes
CREATE INDEX idx_dashboard_users_restaurant_id ON dashboard_users(restaurant_id);
CREATE INDEX idx_menu_availability_overrides_restaurant_id ON menu_availability_overrides(restaurant_id);
CREATE INDEX idx_kiosk_devices_last_heartbeat ON kiosk_devices(last_heartbeat);
CREATE INDEX idx_analytics_snapshots_date ON analytics_snapshots(snapshot_date DESC);
CREATE INDEX idx_audit_logs_restaurant_created ON audit_logs(restaurant_id, created_at DESC);
```

---

## Deployment (Production)

### Backend (Docker)
```bash
docker build -f Dockerfile.backend -t admin-dashboard-backend:latest .
docker run -d \
  -e DATABASE_URL=postgresql://... \
  -e JWT_SECRET=... \
  -p 8000:8000 \
  admin-dashboard-backend:latest
```

### Frontend (Docker + Nginx)
```bash
docker build -f Dockerfile.frontend -t admin-dashboard-frontend:latest .
docker run -d \
  -e REACT_APP_API_URL=https://api.restaurant.com \
  -p 80:80 \
  admin-dashboard-frontend:latest
```

### Environment Variables Required
```
DATABASE_URL              # PostgreSQL connection string
JWT_SECRET               # HS256 signing key (min 32 chars)
ENVIRONMENT              # development | staging | production
REACT_APP_API_URL        # Backend API URL
REACT_APP_WS_URL         # WebSocket URL
CORS_ORIGINS             # Comma-separated list of allowed origins
```

---

## Known Limitations (MVP)

- Analytics dashboard is a P1 feature (not in this quickstart)
- Kiosk monitoring endpoints defined but functionality deferred to P1
- No email/SMS notifications (in-app notifications only)
- No offline mode (requires internet connection)
- No multi-language support

---

## Next Steps

1. ✅ Quickstart complete
2. → Implement unit tests
3. → Implement integration tests
4. → Deploy to staging
5. → User acceptance testing
6. → Production rollout

---

## References

- API Contracts: `./contracts/orders.yaml`, `./contracts/settings.yaml`, `./contracts/menu.yaml`
- Data Model: `./data-model.md`
- Research/Architecture: `./research.md`
- Main Spec: `./spec.md`

