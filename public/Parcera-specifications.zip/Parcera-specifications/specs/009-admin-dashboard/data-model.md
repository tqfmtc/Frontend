# Data Model: Admin Dashboard

**Spec**: 009-admin-dashboard  
**Date**: 2025-11-04  
**Phase**: 1 (Design)

---

## Core Entities

### 1. DashboardUser
**Purpose**: Authenticate operators and enforce role-based access control

```plaintext
id (UUID)
email (String, unique)
password_hash (String)
restaurant_id (UUID, foreign key → Restaurant.id)
role (Enum: OWNER | MANAGER | EMPLOYEE)
active (Boolean)
last_login (DateTime, nullable)
created_at (DateTime)
updated_at (DateTime)
```

**Constraints**:
- Email must be unique per restaurant (allow same email across restaurants)
- Password hash using bcrypt with salt
- Role enum enforced at application layer

**Relationships**:
- 1:N with AuditLog (user performed action)
- 1:N with MenuAvailabilityOverride (user created override)

---

### 2. RestaurantBusinessSettings
**Purpose**: Store mutable restaurant configuration (hours, contact, POS, delivery zones)

```plaintext
id (UUID)
restaurant_id (UUID, foreign key → Restaurant.id, unique)
hours_json (JSON) → {"monday": {"open": "09:00", "close": "22:00"}, ...}
temporarily_closed (Boolean)
closed_until (DateTime, nullable) → if temporarily_closed=true
closed_message (String, nullable)
address (String)
phone (String)
email (String)
logo_url (String, nullable)
pos_config_json (JSON) → {"type": "toast", "api_key": "...", "api_secret": "..."}
pos_connected (Boolean)
delivery_enabled (Boolean)
delivery_zones_json (JSON, nullable) → polygon or radius-based zones
created_at (DateTime)
updated_at (DateTime)
```

**Constraints**:
- hours_json must have all 7 days of week
- temporarily_closed requires closed_until timestamp
- pos_config_json encrypted at rest (PII handling)
- delivery_zones_json validated as valid GeoJSON or radius objects

**Relationships**:
- 1:1 with Restaurant (settings for a single restaurant)
- Referenced by AuditLog (setting changes logged)

---

### 3. OrderDashboardView
**Purpose**: Denormalized read model of orders for dashboard display (non-persistent, computed on-the-fly or materialized)

```plaintext
id (UUID) → from Order
restaurant_id (UUID)
order_number (String)
status (Enum: PENDING | ACCEPTED | IN_PROGRESS | COMPLETED | REJECTED)
channel (Enum: IVR | KIOSK | MOBILE | WEB)
customer_name (String)
customer_phone (String) → masked (last 4 digits only)
customer_email (String, nullable)
pickup_or_delivery (Enum: PICKUP | DELIVERY)
pickup_time_estimated (DateTime)
order_placed_at (DateTime)
order_accepted_at (DateTime, nullable)
order_completed_at (DateTime, nullable)
items (Array of OrderItem objects)
special_instructions (String, nullable)
payment_method (Enum: CASH | CARD | WALLET)
payment_status (Enum: PENDING | AUTHORIZED | CAPTURED | FAILED)
total_amount (Decimal)
urgency_flag (Boolean) → true if pickup_time_estimated < NOW
created_at (DateTime)
updated_at (DateTime)
```

**OrderItem**:
```plaintext
menu_item_id (UUID)
menu_item_name (String)
quantity (Integer)
unit_price (Decimal)
modifiers (Array of Modifier objects)
special_instructions (String, nullable)
```

**Modifier**:
```plaintext
modifier_id (UUID)
modifier_name (String)
unit_price (Decimal)
```

**Constraints**:
- status transition: PENDING → ACCEPTED → IN_PROGRESS → COMPLETED OR PENDING → REJECTED (no backwards)
- urgency_flag computed at query time or trigger time
- customer_phone masked for PII compliance

**Relationships**:
- Read from Order (spec 006) via event subscription or direct query
- 1:N references to MenuAvailabilityOverride (check if items/modifiers in order are currently available)

---

### 4. MenuAvailabilityOverride
**Purpose**: Track temporary item/modifier availability overrides (out of stock, time-based schedules)

```plaintext
id (UUID)
restaurant_id (UUID, foreign key → Restaurant.id)
menu_item_id (UUID, nullable) → if item-level override
modifier_id (UUID, nullable) → if modifier-level override
available (Boolean)
scheduled_start (DateTime, nullable)
scheduled_end (DateTime, nullable)
created_by (UUID, foreign key → DashboardUser.id)
created_at (DateTime)
updated_at (DateTime)
active (Boolean) → soft-delete or time-based expiry
```

**Constraints**:
- Either menu_item_id OR modifier_id must be set (not both null, not both set for MVP)
- scheduled_start and scheduled_end both null or both set
- created_by must be valid DashboardUser in same restaurant
- active flag used for soft deletes

**Relationships**:
- N:1 with DashboardUser (who made the override)
- N:1 with Restaurant (scoped to restaurant_id)
- Referenced by AuditLog (availability changes logged)

---

### 5. KioskDevice
**Purpose**: Track physical kiosk devices and their operational status

```plaintext
id (UUID)
restaurant_id (UUID, foreign key → Restaurant.id)
device_id (String, unique) → hardware serial or MAC address
device_name (String)
location_name (String) → physical location within restaurant
online (Boolean)
last_heartbeat (DateTime)
last_error (String, nullable)
error_count (Integer)
uptime_percent (Decimal, nullable) → computed as (heartbeat_received_count / expected_heartbeat_count) * 100
software_version (String)
created_at (DateTime)
updated_at (DateTime)
```

**Constraints**:
- device_id unique per restaurant (allow same device_id across different restaurants)
- last_heartbeat used to determine online status (offline if > 2 minutes old)
- uptime_percent computed from heartbeat metrics (not stored, derived at query)

**Relationships**:
- N:1 with Restaurant
- Referenced by AuditLog (device actions logged)

---

### 6. AnalyticsSnapshot
**Purpose**: Pre-aggregated daily/hourly metrics for fast analytics queries

```plaintext
id (UUID)
restaurant_id (UUID, foreign key → Restaurant.id)
snapshot_date (Date)
snapshot_hour (Integer, nullable) → 0-23 if hourly snapshot
order_count (Integer)
order_count_by_channel (JSON) → {"IVR": 5, "KIOSK": 3, "MOBILE": 12}
total_revenue (Decimal)
revenue_by_channel (JSON) → {"IVR": 45.50, "KIOSK": 67.00, "MOBILE": 123.45}
average_order_value (Decimal)
top_items (JSON) → [{"item_id": "...", "item_name": "...", "quantity": 15, "revenue": 67.50}, ...]
peak_hour (Integer, nullable) → hour with highest order count
orders_by_status (JSON) → {"completed": 20, "rejected": 1}
created_at (DateTime)
```

**Constraints**:
- Unique index on (restaurant_id, snapshot_date, snapshot_hour)
- Snapshot generated nightly for daily records via cron or event trigger
- Hourly snapshots optional (P2 feature)

**Relationships**:
- N:1 with Restaurant
- Source: aggregation query over Order + OrderDashboardView

---

### 7. AuditLog
**Purpose**: Track all operator actions for compliance and debugging

```plaintext
id (UUID)
restaurant_id (UUID, foreign key → Restaurant.id)
user_id (UUID, foreign key → DashboardUser.id)
action_type (Enum: ORDER_ACCEPTED | ORDER_REJECTED | ORDER_COMPLETED | SETTING_CHANGED | MENU_ITEM_TOGGLED | DEVICE_RESTARTED)
affected_entity_type (Enum: ORDER | RESTAURANT_SETTINGS | MENU_ITEM | KIOSK_DEVICE)
affected_entity_id (UUID)
old_values (JSON, nullable)
new_values (JSON, nullable)
created_at (DateTime)
```

**Constraints**:
- All fields required except old_values/new_values (for non-detail-tracking actions)
- created_at indexed for quick range queries (compliance reports)
- old_values and new_values stored as JSON diffs (minimal storage)

**Relationships**:
- N:1 with DashboardUser
- N:1 with Restaurant

---

## Relationships & Constraints

### Foreign Key Hierarchy
```
Restaurant (external, spec 001)
├── DashboardUser (1:N)
├── RestaurantBusinessSettings (1:1)
├── MenuAvailabilityOverride (1:N)
│   └── DashboardUser (N:1) [created_by]
├── KioskDevice (1:N)
├── AnalyticsSnapshot (1:N)
└── AuditLog (1:N)
    └── DashboardUser (N:1) [user_id]
```

### Multi-Tenancy Isolation
- All tables have `restaurant_id` column
- Foreign key constraints on restaurant_id ensure no cross-tenant data
- Query middleware enforces WHERE restaurant_id = authenticated_user.restaurant_id

### Transaction Boundaries
- **Order Accept**: Update order status → Emit WebSocket event → Log audit
- **Menu Item Toggle**: Update MenuAvailabilityOverride → Invalidate cache → Log audit → Emit broadcast event
- **Business Settings Change**: Update RestaurantBusinessSettings → Invalidate cache → Log audit → Broadcast to connected operators

---

## Validation Rules

### DashboardUser
- Email: valid email format, unique per restaurant
- Password: min 12 chars, 1 uppercase, 1 number, 1 special char (at registration)
- Role: enum OWNER | MANAGER | EMPLOYEE only

### RestaurantBusinessSettings
- Hours: all 7 days required, open < close time
- Phone: valid E.164 format
- POS config: if provided, validate POS type + required fields per spec 007

### MenuAvailabilityOverride
- Exactly one of menu_item_id or modifier_id set
- If scheduled, start < end and both in future or current time

### KioskDevice
- device_id: non-empty string, 1-128 chars
- software_version: semantic version format (x.y.z)

### AuditLog
- action_type and affected_entity_type must match (ORDER_ACCEPTED → ORDER, etc.)

---

## Database Indexing Strategy

```plaintext
dashboard_users: (restaurant_id, email), (restaurant_id, active)
restaurant_business_settings: (restaurant_id) PRIMARY
menu_availability_overrides: (restaurant_id, menu_item_id), (restaurant_id, modifier_id), (restaurant_id, active, updated_at)
kiosk_devices: (restaurant_id, device_id), (restaurant_id, last_heartbeat)
analytics_snapshots: (restaurant_id, snapshot_date DESC), (restaurant_id, snapshot_hour)
audit_logs: (restaurant_id, created_at DESC), (restaurant_id, user_id, created_at DESC), (restaurant_id, affected_entity_id)
```

---

## Caching Strategy

| Entity | TTL | Invalidation Trigger |
|--------|-----|----------------------|
| RestaurantBusinessSettings | 2 min | SETTING_CHANGED audit event |
| MenuAvailabilityOverride | 30 sec | Override create/update/delete |
| AnalyticsSnapshot | 1 hour | Nightly cron (data is immutable after snapshot) |
| DashboardUser permissions | 30 min | User role/restaurant change |

---

## Next Steps

1. ✅ Data model complete
2. → API contracts (phase 1)
3. → Quickstart guide (phase 1)

