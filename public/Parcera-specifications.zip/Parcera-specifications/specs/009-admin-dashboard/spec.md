# Feature Specification: Admin Dashboard & Restaurant Portal

**Feature Branch**: `009-admin-dashboard`
**Created**: 2025-10-29
**Status**: Draft
**Input**: User description: "Admin Dashboard & Restaurant Portal - Web-based management interface for restaurant operators to configure business settings, view and manage orders in real-time, update menu availability, monitor kiosk devices, view order analytics, and manage operational settings (hours, delivery zones, POS configuration). Multi-tenant with role-based access control supporting both single-location and multi-location restaurant groups."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Real-Time Order Management (Priority: P0)

Restaurant operators need to view and manage incoming orders from all channels (IVR, kiosk, mobile) in real-time to ensure timely fulfillment and handle order issues.

**Why this priority**: Core operational requirement for any restaurant using the platform. Without this, operators cannot see or manage orders from Parcera channels.

**Independent Test**: Can be fully tested by placing test orders through IVR/kiosk/mobile channels and verifying they appear in the dashboard with correct status, can be accepted/rejected, and status updates are reflected in customer-facing channels.

**Acceptance Scenarios**:

1. **Given** a new order is placed via any channel, **When** the operator views the dashboard, **Then** the order appears within 2 seconds with complete details (items, modifiers, customer pickup/delivery info, payment status)
2. **Given** an order is in "pending" status, **When** operator clicks "Accept Order", **Then** order status changes to "accepted", customer receives notification, and POS system is updated (if integrated)
3. **Given** operator needs to reject an order due to unavailable items, **When** they select "Reject Order" and provide reason, **Then** customer receives notification with refund instructions and reason for rejection
4. **Given** multiple orders are active, **When** operator views order list, **Then** orders are sorted by urgency (pickup time) with visual indicators for delayed orders (>5 minutes past estimated time)

---

### User Story 2 - Business Settings Configuration (Priority: P0)

Restaurant operators need to configure core business settings (hours of operation, location details, contact info, delivery zones, POS connection) to ensure accurate information across all ordering channels.

**Why this priority**: Required for platform to function correctly. Hours, location, and POS settings directly impact order routing and fulfillment.

**Independent Test**: Can be fully tested by updating business settings (e.g., change closing time from 10 PM to 9 PM) and verifying that IVR/mobile apps reflect updated information, and orders cannot be placed outside new hours.

**Acceptance Scenarios**:

1. **Given** operator accesses business settings, **When** they update hours of operation, **Then** changes are reflected across all channels (IVR, mobile, kiosk) within 1 minute and future orders respect new hours
2. **Given** operator needs to close temporarily (e.g., equipment failure), **When** they toggle "Temporarily Closed" with optional message, **Then** all ordering channels display closure message and prevent new orders
3. **Given** operator needs to configure POS integration, **When** they select POS type (Toast/Square/Clover), enter credentials, and test connection, **Then** system validates connection and enables order submission to POS
4. **Given** operator manages multiple locations, **When** they switch between locations, **Then** dashboard shows location-specific settings, orders, and menu without requiring re-login

---

### User Story 3 - Menu Availability Management (Priority: P0)

Restaurant operators need to quickly enable/disable menu items or modifiers when ingredients run out or items are unavailable, without requiring full menu edits.

**Why this priority**: Critical for day-to-day operations. Out-of-stock items must be disabled immediately to prevent customer frustration and failed orders.

**Independent Test**: Can be fully tested by disabling a menu item in the dashboard and verifying it no longer appears in IVR/mobile/kiosk ordering interfaces, then re-enabling and confirming it reappears.

**Acceptance Scenarios**:

1. **Given** operator needs to disable an item temporarily, **When** they toggle item availability to "Unavailable", **Then** item is hidden from all ordering channels within 30 seconds and existing orders are unaffected
2. **Given** operator needs to disable a modifier (e.g., "Extra Cheese"), **When** they mark modifier as unavailable, **Then** customers cannot select that modifier on new orders and receive appropriate messaging ("Currently unavailable")
3. **Given** operator needs to manage multiple unavailable items, **When** they use bulk actions to disable multiple items at once, **Then** all selected items are disabled simultaneously and changes propagate to all channels
4. **Given** operator wants to schedule availability (e.g., breakfast items only 6-11 AM), **When** they set time-based availability rules, **Then** items automatically appear/disappear based on current time

---

### User Story 4 - Order Analytics & Reporting (Priority: P1)

Restaurant operators need to view analytics on order volume, revenue, popular items, and channel performance to make informed business decisions.

**Why this priority**: Important for business intelligence but not required for core operations. Operators can function without analytics initially.

**Independent Test**: Can be fully tested by generating test orders across different channels over multiple days, then verifying dashboard displays accurate metrics (total orders, revenue, breakdown by channel, popular items).

**Acceptance Scenarios**:

1. **Given** operator accesses analytics dashboard, **When** they select date range, **Then** system displays order count, total revenue, average order value, and channel breakdown (IVR vs mobile vs kiosk) for selected period
2. **Given** operator wants to identify popular items, **When** they view "Top Items" report, **Then** system shows ranked list of most-ordered items with quantity and revenue contribution
3. **Given** operator needs to compare performance, **When** they select two date ranges for comparison, **Then** dashboard shows side-by-side metrics with percentage change indicators
4. **Given** operator manages multiple locations, **When** they view analytics, **Then** system provides location-level comparisons and identifies highest/lowest performing locations

---

### User Story 5 - Kiosk Device Monitoring (Priority: P1)

Restaurant operators need to monitor kiosk device status (online/offline, last activity, error states) to ensure kiosks are operational and address issues promptly.

**Why this priority**: Important for operations using kiosks, but many restaurants won't have kiosks initially. Can be added after MVP if resources are limited.

**Independent Test**: Can be fully tested by deploying test kiosk devices, simulating online/offline states and errors, and verifying dashboard reflects accurate device status with appropriate alerts.

**Acceptance Scenarios**:

1. **Given** restaurant has kiosk devices deployed, **When** operator views device monitoring page, **Then** each kiosk shows status (online/offline), last order time, and uptime percentage
2. **Given** a kiosk goes offline, **When** device loses connection for >2 minutes, **Then** dashboard displays alert and sends notification to operator
3. **Given** kiosk reports error (e.g., payment terminal disconnected), **When** error occurs, **Then** dashboard shows error details and recommended troubleshooting steps
4. **Given** operator needs to restart a kiosk remotely, **When** they trigger remote restart, **Then** kiosk reboots and returns to operational state within 2 minutes

---

### User Story 6 - Role-Based Access Control (Priority: P1)

Restaurant groups with multiple locations need to assign different permission levels to users (owner, manager, staff) to control access to sensitive settings and financial information.

**Why this priority**: Important for multi-location groups and franchises but not critical for single-location restaurants in MVP. Can be simplified with basic authentication initially.

**Independent Test**: Can be fully tested by creating users with different roles, attempting to access restricted features, and verifying appropriate permission enforcement (e.g., staff cannot view analytics or change POS settings).

**Acceptance Scenarios**:

1. **Given** owner creates new user account, **When** they assign "Manager" role, **Then** user can view orders and manage menu availability but cannot access business settings or financial reports
2. **Given** employee logs in, **When** they access dashboard, **Then** they can only view orders and mark them as completed, plus toggle individual menu items unavailable (for out-of-stock items during shift), with no access to business settings, analytics, or full menu editing
3. **Given** multi-location restaurant group, **When** manager is assigned to specific locations, **Then** they can only view and manage orders/settings for their assigned locations
4. **Given** owner needs to revoke access, **When** they deactivate a user account, **Then** user is immediately logged out and cannot access dashboard until reactivated

---

### Edge Cases

- What happens when operator loses internet connection while viewing dashboard? System should show cached data with clear "Offline" indicator and queue actions for sync when reconnected.
- How does system handle simultaneous edits by multiple users? Implement optimistic locking with conflict detection and "last write wins" with notification to other users.
- What happens when POS connection fails during order submission? Dashboard should display failed submission alert with retry options and manual override to mark order as handled.
- How does system handle high order volume during peak hours? Dashboard should implement pagination and real-time updates via WebSocket to prevent performance degradation.
- What happens when operator tries to disable a menu item that's in active orders? System allows disabling (affects future orders only) but shows warning with count of active orders containing that item.

## Requirements *(mandatory)*

### Functional Requirements

#### Order Management
- **FR-001**: System MUST display real-time orders from all channels (IVR, kiosk, mobile, future web portal) with updates within 2 seconds of order placement
- **FR-002**: System MUST allow operators to accept, reject, or mark orders as completed with status changes reflected to customers within 5 seconds
- **FR-003**: System MUST provide order detail view showing all items, modifiers, special instructions, customer info (pickup name/phone), payment status, and timestamps
- **FR-004**: System MUST sort orders by urgency with visual indicators for delayed orders (>5 minutes past estimated pickup time)
- **FR-005**: System MUST support order filtering by status (pending, accepted, in-progress, completed, rejected), channel, date range, and customer name

#### Business Settings
- **FR-006**: System MUST allow operators to configure hours of operation (open/close times by day of week) with changes reflected across all channels within 1 minute
- **FR-007**: System MUST provide "Temporarily Closed" toggle with optional custom message that disables ordering on all channels
- **FR-008**: System MUST support business profile configuration (name, address, phone, email, logo, description) with changes visible on customer-facing channels
- **FR-009**: System MUST allow POS integration setup with connection testing and validation (Toast, Square, Clover adapters per spec 007)
- **FR-010**: System MUST support delivery zone configuration with radius-based or polygon-based areas for delivery-enabled restaurants

#### Menu Availability
- **FR-011**: System MUST allow operators to toggle individual menu items or modifiers as available/unavailable with changes reflected in ordering channels within 30 seconds
- **FR-012**: System MUST support bulk availability actions (disable multiple items simultaneously)
- **FR-013**: System MUST allow time-based availability scheduling (e.g., breakfast items 6-11 AM) with automatic show/hide based on current time
- **FR-014**: System MUST display unavailable items with greyed-out styling and prevent selection on ordering channels while showing "Currently unavailable" message
- **FR-015**: System MUST preserve menu structure and pricing when items are marked unavailable (no data loss)

#### Analytics & Reporting
- **FR-016**: System MUST display order metrics (count, total revenue, average order value) for selected date ranges (today, yesterday, last 7/30 days, custom range)
- **FR-017**: System MUST provide channel breakdown showing order distribution across IVR, kiosk, mobile, and future channels
- **FR-018**: System MUST display "Top Items" report ranking menu items by order frequency and revenue contribution
- **FR-019**: System MUST support date range comparison with percentage change indicators for key metrics
- **FR-020**: System MUST provide multi-location analytics for restaurant groups with location-level comparisons
- **FR-020a**: System MUST display peak hours analytics showing order volume by hour of day with visual heatmap (busiest hours highlighted)
- **FR-020b**: System MUST show popular items trending over time with week-over-week or month-over-month comparison
- **FR-020c**: System MUST provide operational metrics including average order fulfillment time, order acceptance rate, and rejection reasons breakdown
- **FR-020d**: System MUST display channel performance metrics showing conversion rates and average order values by channel (IVR, kiosk, mobile)
- **FR-020e**: System MUST provide revenue trends with daily, weekly, and monthly visualizations including growth percentages

#### Kiosk Monitoring
- **FR-021**: System MUST display kiosk device status (online/offline), last activity timestamp, and uptime percentage
- **FR-022**: System MUST alert operators when kiosk goes offline for >2 minutes via dashboard notification
- **FR-023**: System MUST show kiosk error states (payment terminal disconnected, printer error, etc.) with troubleshooting guidance
- **FR-024**: System MUST support remote kiosk restart capability with confirmation and status feedback

#### Multi-Tenancy & Access Control
- **FR-025**: System MUST enforce row-level security ensuring operators can only view/manage data for their assigned restaurant(s)
- **FR-026**: System MUST support role-based access control with predefined roles: Owner (full access), Manager (no financial settings/billing), Employee (orders and basic menu availability only)
- **FR-027**: System MUST allow owners to create/deactivate user accounts and assign roles and location access
- **FR-028**: System MUST provide location switcher for multi-location users with context preserved per location
- **FR-029**: System MUST implement session management with JWT tokens and auto-logout after 8 hours of inactivity

#### Performance & Real-Time
- **FR-030**: System MUST use WebSocket connections for real-time order updates to avoid polling and reduce latency
- **FR-031**: System MUST cache frequently accessed data (menu structure, business settings) with TTL-based invalidation
- **FR-032**: System MUST implement pagination for order lists (20 orders per page) with infinite scroll on supported devices

### Key Entities *(include if feature involves data)*

- **DashboardUser**: Represents operators with login credentials, assigned role (Owner/Manager/Employee), assigned restaurant/location IDs, last login timestamp, active session token, role permissions (Owner: full access; Manager: orders, menu, analytics; Employee: orders only + item availability toggle)
- **RestaurantBusinessSettings**: Stores hours of operation, temporarily closed flag, location details, contact info, POS configuration, delivery zones, branding assets (logo)
- **OrderDashboardView**: Aggregated view of order data from Order Fulfillment system (spec 006) with real-time status, channel source, customer info, line items, timestamps
- **MenuAvailabilityOverride**: Tracks temporary item/modifier availability changes with timestamp, operator who made change, schedule rules (time-based availability)
- **KioskDevice**: Represents physical kiosk devices with device ID, location, online status, last heartbeat, error logs, software version
- **AnalyticsSnapshot**: Pre-aggregated analytics data (daily/hourly) showing order counts, revenue, channel breakdown, popular items for performance optimization
- **AuditLog**: Records all operator actions (order status changes, settings updates, menu changes) with timestamp, user, action type, affected entities for compliance

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: Operators can view new orders within 2 seconds of placement across all channels (IVR, kiosk, mobile)
- **SC-002**: Business settings changes (hours, temporarily closed, menu availability) are reflected on customer-facing channels within 1 minute
- **SC-003**: Dashboard supports 50+ concurrent operator sessions without performance degradation (page load <3 seconds, order updates <2 seconds)
- **SC-004**: 95% of operators can complete common tasks (accept order, disable menu item, view analytics) without training or documentation
- **SC-005**: Multi-location restaurant groups can manage 10+ locations from single dashboard with location switching <1 second
- **SC-006**: Analytics reports generate within 3 seconds for date ranges up to 90 days
- **SC-007**: Dashboard achieves 99.9% uptime (excluding planned maintenance) measured over 30-day periods
- **SC-008**: Role-based access control prevents unauthorized access with 0 security incidents in first 6 months
- **SC-009**: Kiosk device monitoring detects offline devices within 2 minutes with 95% alert delivery success rate
- **SC-010**: Operators report 80%+ satisfaction with dashboard usability in post-MVP user surveys
- **SC-011**: Dashboard reduces average order acceptance time by 40% compared to manual phone order processing
- **SC-012**: 90% of menu availability changes take <30 seconds to complete (from login to saving change)

## Assumptions *(mandatory)*

1. **Authentication**: Operators will use email/password authentication with optional SMS-based two-factor authentication (2FA). No social login initially.
2. **Browser Support**: Dashboard will support modern browsers (Chrome 90+, Firefox 88+, Safari 14+, Edge 90+). No Internet Explorer support.
3. **Mobile Responsiveness**: Dashboard will be optimized for desktop/laptop use first, with basic mobile browser support for viewing orders on tablets. Native mobile app for operators is out of scope.
4. **Real-Time Technology**: WebSocket connections will be used for real-time order updates. Fallback to long-polling if WebSocket connection fails.
5. **Data Retention**: Order data will be retained for 90 days in hot storage (dashboard access), 2 years in cold storage (analytics exports only).
6. **Notification Channels**: Dashboard notifications only (in-app alerts). Email/SMS notifications for critical events (kiosk offline, POS connection failure) are out of scope for MVP.
7. **Analytics Granularity**: Analytics will provide daily aggregates initially. Hourly breakdowns and real-time metrics are P2 features.
8. **Multi-Location Limits**: Single dashboard instance will support up to 100 locations per restaurant group. Larger enterprise clients may require dedicated instances.
9. **Customization**: Dashboard branding (logo, colors) will use restaurant business settings. White-label customization per location is out of scope.
10. **Offline Support**: Dashboard requires internet connection to function. No offline mode or progressive web app (PWA) capabilities in MVP.

## Constitution Alignment *(mandatory)*

### Principle I: AI-First Architecture
- Dashboard will integrate conversation mining data from Olivia.io (P2 feature) to provide operators with insights on common customer queries and failed conversation flows
- Analytics will surface AI-driven recommendations for menu optimization based on order patterns (post-MVP)

### Principle II: Multi-Tenancy by Design
- Dashboard implements strict row-level security ensuring operators can only access data for their assigned restaurant(s)
- All API requests include tenant context (restaurant_id) with server-side validation
- Supports both single-location restaurants and multi-location groups with shared authentication

### Principle III: Privacy-First Customer Data
- Dashboard displays customer order data (pickup name, order ID) but not sensitive PII (full phone numbers, email addresses) per privacy-first architecture
- Customer wallet data (payment methods, addresses) is never exposed in dashboard (customers manage via mobile app)
- Operators can send order status notifications but cannot directly access customer contact information

### Principle IV: Omnichannel by Default
- Dashboard displays orders from all channels (IVR, kiosk, mobile, future web portal) in unified view with channel attribution
- Business settings changes (hours, menu availability) propagate to all channels automatically
- No channel-specific management required (single pane of glass for all ordering channels)

### Principle V: Progressive Enhancement & MVP Discipline
- **P0 Features**: Real-time order management, business settings, menu availability management (FR-001 to FR-015)
- **P1 Features**: Analytics & reporting, kiosk monitoring, role-based access control (FR-016 to FR-029)
- **P2/P3 Features (Deferred)**: AI-driven insights, conversation mining analytics, white-label customization, advanced scheduling

### Principle VI: Network Effects & Platform Thinking
- Analytics will eventually include anonymized cross-restaurant benchmarks (e.g., "Your order volume is 20% higher than average for similar restaurants") - P2 feature
- Dashboard design allows for future marketplace integrations (third-party apps, review platforms) via widget/plugin architecture

### Principle VII: Integration-Friendly Architecture
- Dashboard consumes RESTful APIs from Order Fulfillment (spec 006), POS Integration (spec 007), Menu Management (spec 002), and Restaurant Management (spec 001)
- All dashboard actions (order status changes, settings updates) are exposed via same APIs used by dashboard for third-party integrations
- WebSocket events follow standard protocol (Socket.io or native WebSocket with fallback) for extensibility

## Open Questions *(optional - only if critical unknowns exist)*

None. All critical decisions have reasonable defaults based on industry standards for restaurant management dashboards.

## Dependencies *(mandatory)*

### Internal Dependencies (Parcera Platform)
- **Restaurant Management (spec 001)**: Dashboard reads business profile, locations, hours of operation
- **Menu Management (spec 002)**: Dashboard reads menu structure and updates availability overrides
- **Order Fulfillment (spec 006)**: Dashboard consumes real-time order events and submits status changes
- **POS Integration (spec 007)**: Dashboard configures POS connection settings and displays submission status
- **Customer Identity (spec 008)**: Dashboard references customer wallet IDs for order attribution (no PII access)

### External Dependencies
- **WebSocket Library**: Socket.io or native WebSocket implementation for real-time updates
- **Authentication**: JWT-based session management with secure token storage
- **Charting Library**: Chart.js, D3.js, or Recharts for analytics visualizations
- **UI Framework**: React 18+ with Material-UI or TailwindCSS per constitution technical standards

## Future Considerations *(optional)*

### Post-MVP Enhancements (P2/P3)
- **AI-Driven Insights**: Conversation mining analytics showing common customer queries, failed ordering attempts, and optimization recommendations
- **Advanced Analytics**: Hourly granularity, real-time metrics, customer cohort analysis, revenue forecasting
- **Mobile Operator App**: Native iOS/Android app for on-the-go order management and notifications
- **White-Label Customization**: Per-location dashboard branding for franchises and restaurant groups
- **Third-Party Integrations**: Widgets for review platforms (Yelp, Google), delivery services (DoorDash, Uber Eats), accounting software (QuickBooks)
- **Automated Alerts**: Email/SMS notifications for critical events (order backlog, kiosk offline, inventory thresholds)
- **Multi-Language Support**: Dashboard localization for international restaurant operators
- **Advanced Scheduling**: Staff shift management, menu schedules (seasonal items), promotional campaigns
