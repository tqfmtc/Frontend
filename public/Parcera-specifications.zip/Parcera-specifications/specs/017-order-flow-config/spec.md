# Feature Specification: Order Flow Configuration & Execution

**Feature Branch**: `017-order-flow-config`
**Created**: 2025-10-30
**Status**: Draft
**Constitution Alignment**: Principles IV (Omnichannel), V (MVP Discipline)

---

## Overview

Configurable order workflow system that allows restaurant owners to customize the ordering experience by reordering, enabling, or disabling workflow steps to match their business model. Fast food restaurants can configure "order → pay → kitchen → pickup" flows, while sit-down restaurants use "order → kitchen → deliver → payment" patterns. Provides drag-and-drop flow editor with pre-built templates and validates logic before saving. Flow execution engine enforces configured checkpoints during order processing across all channels (IVR, kiosk, mobile app).

**Scope**: ONLY ordering experience flow customization from order initiation to completion. Does NOT include provisioning/fulfillment operations after order submission (handled by incumbent POS systems).

---

## User Scenarios & Testing

### User Story 1 - Configure Custom Order Flow (Priority: P0)

**As a** sit-down restaurant owner
**I want to** configure my order workflow so payment happens after food delivery
**So that** customers can enjoy their meal before paying, matching traditional dining expectations

**Why this priority**: Core value proposition. Without flow customization, the feature provides no value. Different business models require fundamentally different workflows.

**Independent Test**: Can be fully tested by: (1) logging in as restaurant owner, (2) accessing flow editor in dashboard, (3) reordering steps so "payment" comes after "deliver_to_table", (4) saving configuration, (5) creating test order and verifying it follows configured flow. Delivers standalone value by enabling one complete workflow pattern.

**Acceptance Scenarios**:

1. **Given** restaurant owner is logged into dashboard, **When** they navigate to Settings → Order Flow Configuration, **Then** they see current workflow steps displayed in vertical list with step numbers, names, and enabled/disabled status
2. **Given** owner is viewing flow editor, **When** they drag "Process Payment" step from position 2 to position 5 (after "Deliver to Table"), **Then** step order updates visually, step numbers renumber automatically, and reorder is reflected immediately
3. **Given** owner has reordered steps, **When** they click "Save Flow", **Then** system validates flow logic, shows success message if valid, and applies configuration to new orders
4. **Given** valid flow has been saved, **When** new order is created via any channel (IVR/kiosk/mobile), **Then** order progresses through steps in configured sequence with each checkpoint enforced

---

### User Story 2 - Use Pre-built Flow Template (Priority: P1)

**As a** fast food restaurant owner setting up for the first time
**I want to** quickly apply a "Fast Food" template
**So that** I can have a working order flow without manually configuring all steps

**Why this priority**: Significantly improves onboarding experience and reduces setup time, but feature remains functional without templates (owners can configure manually).

**Independent Test**: Can be tested by: (1) opening flow editor on new location, (2) clicking "Load Template" button, (3) selecting "Fast Food" template, (4) verifying all steps automatically configure in correct order. Delivers value through instant, industry-standard configurations.

**Acceptance Scenarios**:

1. **Given** owner is in flow editor, **When** they click "Load Template" button, **Then** they see list of pre-built templates: Fast Food, Sit-Down Restaurant, Food Truck, Buffet Self-Service
2. **Given** owner selects "Fast Food" template, **When** they click "Apply", **Then** flow steps automatically configure to: Take Order → Process Payment → Send to Kitchen → Prepare Food → Mark Ready → Customer Pickup → Complete Order
3. **Given** template has been applied, **When** owner reviews the steps, **Then** all steps are enabled and numbered sequentially in correct order for that business model
4. **Given** template is applied, **When** owner modifies any step (reorder or disable), **Then** customizations are preserved and override template defaults

---

### User Story 3 - Enable/Disable Optional Steps (Priority: P1)

**As a** coffee shop owner
**I want to** disable the "Deliver to Table" step
**So that** my workflow reflects counter-pickup-only service and eliminates unnecessary steps

**Why this priority**: Improves workflow efficiency and reduces UI clutter, but core flow configuration works without this capability.

**Independent Test**: Can be tested by: (1) viewing flow with optional steps visible, (2) toggling "enabled" switch on "Deliver to Table" step to disabled, (3) saving flow, (4) creating order and verifying disabled step is automatically skipped. Delivers value by allowing workflow optimization.

**Acceptance Scenarios**:

1. **Given** owner is viewing flow editor, **When** they look at each step, **Then** they can identify which steps are marked "Required" (grayed-out toggle) and which are "Optional" (active toggle)
2. **Given** optional step "Deliver to Table", **When** owner toggles enabled switch to disabled, **Then** step is visually dimmed with strikethrough effect and marked as inactive
3. **Given** step has been disabled, **When** owner saves flow, **Then** system persists disabled state and includes in validation check
4. **Given** order is being processed, **When** order reaches disabled step, **Then** system automatically advances to next enabled step without user interaction
5. **Given** owner tries to disable required step "Take Order", **When** they attempt to toggle it off, **Then** toggle is non-functional and tooltip displays "This step is required and cannot be disabled"

---

### User Story 4 - Validate Flow Configuration (Priority: P0)

**As a** restaurant owner
**I want** the system to warn me about potentially problematic flow configurations
**So that** I don't accidentally configure a workflow that causes business problems (like customers leaving without paying)

**Why this priority**: Critical for preventing revenue-damaging configurations. Without validation, feature could cause financial loss through misconfiguration.

**Independent Test**: Can be tested by: (1) configuring invalid flow where payment comes after customer pickup, (2) attempting to save, (3) verifying system shows validation warnings with specific issues, (4) correcting flow, (5) successfully saving valid configuration. Delivers critical protection against configuration mistakes.

**Acceptance Scenarios**:

1. **Given** owner configured flow where "Process Payment" comes after "Customer Pickup", **When** they click "Save Flow", **Then** system displays warning: "⚠️ Payment occurs after customer pickup - customers may leave without paying. Continue anyway?"
2. **Given** owner configured flow without "Take Order" as first step, **When** they attempt to save, **Then** system displays error: "❌ Take Order must be the first step" and prevents saving until corrected
3. **Given** owner configured flow without "Complete Order" as final step, **When** they attempt to save, **Then** system displays error: "❌ Complete Order must be the last step" and blocks save action
4. **Given** owner configured valid flow, **When** they click "Save Flow", **Then** system validates successfully, shows "✅ Flow configuration saved" message, and applies immediately to new orders
5. **Given** validation warnings (not errors) are shown, **When** owner clicks "Save Anyway", **Then** system saves flow configuration despite warnings (warnings inform but don't block, errors do block)

---

### User Story 5 - Configure Per-Location Workflows (Priority: P2)

**As a** restaurant chain owner with multiple locations
**I want** different workflows for each branch location
**So that** my downtown sit-down location and food court quick-service location can each use appropriate workflows

**Why this priority**: Important for multi-location businesses, but most restaurants start with single location. Enhancement for scalability rather than core functionality.

**Independent Test**: Can be tested by: (1) creating two locations in system, (2) configuring different flows for Location A and Location B, (3) creating orders at each location, (4) verifying orders follow their location-specific workflow. Delivers value for multi-location operators.

**Acceptance Scenarios**:

1. **Given** owner has multiple locations, **When** they open flow editor, **Then** they see location selector dropdown at top showing "All Locations (Default)" and list of individual locations
2. **Given** owner selects "Downtown Branch" from location selector, **When** they configure workflow, **Then** configuration applies only to that location and is saved separately from default
3. **Given** owner selects "All Locations (Default)", **When** they configure workflow, **Then** configuration becomes default template applied to any location without custom workflow
4. **Given** different workflows are configured for different locations, **When** order is created at specific location, **Then** order follows workflow configured for that location (or inherits default if no custom configuration exists)

---

### Edge Cases

- What happens when owner tries to drag required step "Take Order" to middle of flow?
  - System prevents drag operation, shows tooltip "Required first step - cannot be moved"

- How does system handle orders in-progress when workflow configuration changes mid-day?
  - Orders in-progress complete using workflow they started with (workflow version stored with order). New orders use updated configuration.

- What happens if owner deletes all optional steps leaving only required steps?
  - System allows this as valid minimal flow: Take Order → Complete Order. Validates that at least two required steps remain.

- How does system handle simultaneous workflow edits from multiple browser sessions?
  - Last-write-wins with optimistic locking. User saving second receives warning "Configuration was modified by another user. Reload and try again?"

- What happens when owner tries to configure circular workflow where steps loop back?
  - System validates flow is directed acyclic graph (DAG). Circular dependencies trigger error: "Invalid flow - steps cannot loop back"

- How does system behave if database transaction fails halfway through saving multi-step flow changes?
  - All-or-nothing transaction. Rollback on failure, show error message, preserve previous working configuration.

- What happens to orders created under old workflow when new workflow is applied?
  - Orders store workflow_version_id at creation. System continues executing old workflow for those orders. New orders get new workflow_version_id.

---

## Requirements

### Functional Requirements

**Flow Configuration Management**

- **FR-001**: System MUST allow restaurant owners, business admins, and store managers to access order flow configuration interface
- **FR-002**: System MUST display current workflow as vertical list showing: step order number, step name, step description, enabled/disabled status, required/optional indicator
- **FR-003**: System MUST allow owners to reorder workflow steps using drag-and-drop interaction, updating step numbers in real-time
- **FR-004**: System MUST prevent reordering of mandatory first step ("Take Order") and mandatory last step ("Complete Order")
- **FR-005**: System MUST allow owners to enable or disable optional workflow steps using toggle control
- **FR-006**: System MUST prevent disabling of required workflow steps (Take Order, Complete Order, and any business-specific required steps)
- **FR-007**: System MUST provide "Save Flow" action that persists workflow configuration with validation checks
- **FR-008**: System MUST provide "Reset to Default" action that reverts to default workflow configuration for selected location

**Flow Templates**

- **FR-009**: System MUST provide pre-built workflow templates: Fast Food, Sit-Down Restaurant, Food Truck, Buffet Self-Service
- **FR-010**: System MUST allow owners to apply template with one click, automatically configuring all steps to match template pattern
- **FR-011**: Fast Food template MUST configure flow: Take Order → Process Payment → Send to Kitchen → Prepare Food → Mark Ready → Customer Pickup → Complete Order
- **FR-012**: Sit-Down Restaurant template MUST configure flow: Take Order → Send to Kitchen → Prepare Food → Deliver to Table → Process Payment → Complete Order
- **FR-013**: Food Truck template MUST configure flow: Take Order → Process Payment → Send to Kitchen → Prepare Food → Call Order Number → Customer Pickup → Complete Order
- **FR-014**: Buffet Self-Service template MUST configure flow: Assign Table → Customer Self-Serves → Process Payment (by weight or flat fee) → Complete Order

**Location-Specific Configuration**

- **FR-015**: System MUST support location-specific workflow configuration for multi-location businesses
- **FR-016**: System MUST provide location selector dropdown showing "All Locations (Default)" and individual location names
- **FR-017**: System MUST apply default workflow to locations without custom configuration
- **FR-018**: System MUST allow independent workflow configuration per location without affecting other locations

**Flow Validation**

- **FR-019**: System MUST validate workflow configuration before saving using these rules: "Take Order" first, "Complete Order" last, no circular dependencies, at least 2 required steps present
- **FR-020**: System MUST display validation warnings for potentially problematic configurations (payment after delivery, payment after customer pickup)
- **FR-021**: System MUST block saving when critical validation errors exist (missing required steps, circular dependencies, first/last step violations)
- **FR-022**: System MUST allow saving with validation warnings after owner acknowledges risk by clicking "Save Anyway"

**Flow Execution**

- **FR-023**: System MUST apply new workflow configuration to all orders created after save timestamp
- **FR-024**: System MUST allow orders in-progress at time of workflow change to complete using workflow they started with (store workflow_version_id with order)
- **FR-025**: System MUST enforce checkpoint progression - order cannot advance to next step until current step requirements are satisfied
- **FR-026**: System MUST automatically skip disabled steps during order execution, advancing to next enabled step
- **FR-027**: System MUST track current step for each order and prevent skipping ahead or going backward arbitrarily

**Step Types**

- **FR-028**: System MUST support these standard workflow step types: Take Order (required first), Confirm Order, Process Payment, Split Payment, Add Tip, Send to Kitchen, Prepare Food, Quality Check, Mark Ready, Assign Table, Deliver to Table, Customer Pickup, Call Order Number, Dispatch Delivery, Customer Feedback, Complete Order (required last)
- **FR-029**: System MUST categorize steps as Required (Take Order, Complete Order) or Optional (all others - can be disabled)
- **FR-030**: System MUST provide default enabled/disabled state for each step type when template is applied

**Audit & Tracking**

- **FR-031**: System MUST track which workflow configuration was active when each order was created (workflow_version_id) for audit purposes
- **FR-032**: System MUST create new workflow version record each time configuration is saved with timestamp and user who made changes
- **FR-033**: System MUST retain workflow version history for minimum 90 days for debugging and compliance

**Visual Feedback**

- **FR-034**: System MUST provide visual feedback when steps are reordered (animated position change, updated step numbers)
- **FR-035**: System MUST visually distinguish between Required steps (grayed-out toggle, lock icon) and Optional steps (active toggle, no lock)
- **FR-036**: System MUST display disabled steps with dimmed appearance and strikethrough effect
- **FR-037**: System MUST show validation errors in red with error icon and warnings in yellow with warning icon

---

### Key Entities

- **Order Flow Configuration**: Complete workflow configuration for a location (or default). Contains ordered list of flow steps, location reference (null for default), workflow version number, and timestamp of activation. One active configuration per location. Relationships: belongs to location (or is default), contains multiple flow steps, has version history.

- **Flow Step**: Single step in workflow. Contains step type (from predefined list), display name, description, order position (sequence number), enabled/disabled status, required/optional flag, and step-specific configuration options. Relationships: belongs to flow configuration, may have predecessor and successor steps in sequence.

- **Flow Template**: Pre-built workflow pattern for common restaurant types. Contains template name (Fast Food, Sit-Down, Food Truck, Buffet), description, intended business model, and ordered list of default steps with configurations. Independent entity used to initialize flow configurations.

- **Order**: Existing entity extended with workflow tracking. Stores workflow_version_id indicating which configuration was active when order was created, current_step_id showing progress, and step_history tracking completion timestamps. Relationships: references flow configuration version it's executing, tracks current position in workflow.

- **Location**: Existing entity that can have custom flow configuration. Relationships: may have one custom flow configuration, inherits default flow if no custom configuration exists.

- **Workflow Version**: Historical snapshot of flow configuration. Tracks version number, configuration state (JSON of steps), timestamp, user who made changes, and active status. Enables audit trail and allows orders to complete using version they started with.

---

## Success Criteria

### Measurable Outcomes

- Restaurant owners can configure custom order workflow in under 5 minutes
- 80% of new restaurants use pre-built templates instead of manual configuration
- Orders execute through configured workflows with 100% checkpoint compliance (no skipped required steps)
- Workflow changes apply to new orders within 1 second of saving
- System prevents 100% of invalid configurations (payment after pickup, missing required steps) from being saved
- Multi-location businesses can configure different workflows per branch with zero cross-contamination
- Flow editor UI loads current configuration in under 2 seconds
- Owners successfully reorder steps using drag-and-drop with 95% success rate (no confusion or errors)

### Qualitative Measures

- Restaurant owners report workflow matches their business model without workarounds
- Staff training time reduced by eliminating steps that don't apply to business type
- Order processing errors (wrong sequence) eliminated through automated checkpoint enforcement
- Customer experience consistency improved across all ordering channels (IVR, kiosk, mobile)

---

## Dependencies and Assumptions

### Dependencies

- Spec 006 (Order Fulfillment) must provide order state management and checkpoint tracking
- Spec 009 (Admin Dashboard) must provide settings interface where flow editor is accessed
- Spec 002 (Menu Management) must be functional for orders to have items to process
- All ordering channels (Spec 003 IVR, Spec 004 Kiosk, Spec 005 Mobile App) must respect flow execution engine

### Assumptions

- Restaurant workflows are linear progressions (no branching or parallel paths in MVP)
- Flow configurations change infrequently (weekly or less, not multiple times per day)
- Owners have clear understanding of their business model and can select appropriate template
- Drag-and-drop interaction is intuitive for non-technical restaurant owners using tablets or desktops
- Most restaurants use one of four standard flow patterns (Fast Food, Sit-Down, Food Truck, Buffet)
- Multi-location businesses typically have 2-10 locations, not hundreds (affects UI scalability)
- Orders in-progress when flow changes are rare edge case (most orders complete within 30-60 minutes)
- Database supports transactions for atomic flow configuration saves

### Out of Scope

- Complex branching workflows (if condition A then step X, else step Y) - deferred to future release
- Time-based flow variations (different flow for lunch vs dinner) - deferred to future release
- Parallel step execution (kitchen and payment happening simultaneously) - MVP is sequential only
- Provisioning/fulfillment flow customization after order submission to POS - handled by incumbent POS systems
- Custom step creation by restaurant owners - MVP uses predefined step types only

---

**Status**: ✅ Ready for validation and `/speckit.plan` command
