# Phase 0 Research: Order Fulfillment Workflow Engine

**Branch**: `006-order-fulfillment` | **Date**: 2025-11-04 | **Spec**: `specs/006-order-fulfillment/spec.md`

## Executive Summary

Comprehensive research into order fulfillment architecture for multi-channel restaurant ordering. Validates POS API integration patterns, state machine design, queue-based processing, and idempotency mechanisms. FastAPI backend with PostgreSQL and RLS provides secure multi-tenant isolation.

---

## 1. Technology Stack Validation

### Language & Framework
- **Language**: Python 3.11+
- **Framework**: FastAPI (async-first, high-performance)
- **Rationale**: 
  - Async I/O native for handling concurrent POS API calls
  - Built-in OpenAPI/Swagger for clear API contracts
  - Mature ecosystem for background jobs (Celery/APScheduler)
  - Strong PostgreSQL integration via SQLAlchemy ORM
  - Excellent for state machine patterns via Python enums

### Primary Dependencies
```plaintext
fastapi==0.109.0+
sqlalchemy==2.0+
alembic==1.13+ (migrations)
psycopg2-binary==2.9+ (PostgreSQL driver)
pydantic==2.0+ (validation)
celery==5.3+ (async job processing)
redis==5.0+ (cache/distributed locks)
httpx==0.25+ (async HTTP client for POS APIs)
tenacity==8.2+ (retry logic)
apscheduler==3.10+ (scheduled orders)
pytest==7.4+ (testing)
```

### Storage
- **Primary**: PostgreSQL 14+
  - Row-Level Security (RLS) for multi-tenant isolation
  - JSONB for flexible order items, credentials storage
  - Materialized views for analytics
  - Native UUID and enum types
  - LISTEN/NOTIFY for webhook simulation

### Message Queue
- **Queue Service**: AWS SQS or RabbitMQ
- **Rationale**: 
  - Decouples order ingestion from POS submission
  - Handles traffic spikes via queue buffering
  - Enables horizontal scaling of workers
  - SQS for AWS-native deployments, RabbitMQ for self-hosted

### Background Job Processor
- **Service**: Celery with Redis backend OR APScheduler
- **Use Cases**:
  - Recurring POS status polling (every 30s for active orders)
  - Scheduled order submission (submit at scheduled_time - prep_buffer)
  - Retry logic with exponential backoff
  - Cleanup tasks (mark old orders as completed)

### Distributed Coordination
- **Service**: Redis (for locks, cache) or PostgreSQL advisory locks
- **Purpose**: 
  - Idempotency: prevent duplicate POS submissions
  - Distributed locking: ensure only one worker processes an order
  - Rate limiting: track POS API call quotas per restaurant

---

## 2. State Machine Design

### Order Lifecycle States
```plaintext
pending
  └─> scheduled (if scheduled_time provided)
       └─> submitted (at scheduled_time - prep_buffer)
            └─> confirmed (POS accepted)
                 └─> preparing (kitchen started)
                      └─> ready (ready for pickup)
                           └─> completed (customer picked up)

FAILURE PATHS:
  └─> failed (3 retry attempts exhausted)
       └─> (awaiting manual intervention)
  └─> cancelled (by customer or system)

POS_STATES (incoming from POS polling):
  pending | confirmed | preparing | ready | completed | cancelled
```

### State Transitions
- **pending → submitted**: Only after order validated and payment authorized
- **submitted → confirmed**: POS API returns success, pos_order_id captured
- **confirmed → preparing**: POS polling detects status change
- **preparing → ready**: POS polling detects status change
- **ready → completed**: Time-based (assume pickup after 4 hours) or explicit confirmation
- **Any → failed**: After 3 unsuccessful submission attempts
- **Any → cancelled**: Customer or admin cancellation request

### Validation Rules
- No backward transitions except failed → pending (manual retry by admin)
- Scheduled orders must have scheduled_time > current_time
- Payment status must be 'authorized' or 'captured' before submission
- Customer contact info required for notification states

---

## 3. POS Integration Architecture

### Supported POS Systems (MVP)
1. **Toast** (SaaS, large enterprise chains)
   - API: RESTful, OAuth 2.0 authentication
   - Order Endpoint: `POST /orders` with custom fields
   - Status Polling: `GET /orders/{orderId}`
   - Webhook: Supported for real-time updates
   - Rate Limits: 100 req/min per API key

2. **Square** (Cloud, mid-market + SMB)
   - API: RESTful, OAuth 2.0 authentication
   - Order Endpoint: `POST /v2/orders` (accepts LineItems)
   - Status Polling: `GET /v2/orders/{orderId}`
   - Webhook: Supported for order.updated events
   - Rate Limits: 3000 req/min burst, 10 req/sec sustained

3. **Clover** (Cloud, SMB + franchises)
   - API: RESTful, custom token authentication
   - Order Endpoint: `POST /v3/merchants/{merchantId}/orders`
   - Status Polling: `GET /v3/merchants/{merchantId}/orders/{orderId}`
   - Webhook: Limited webhook support
   - Rate Limits: 100 req/min per merchant

### Adapter Pattern
```python
class POSAdapter(ABC):
    async def submit_order(order: FulfillmentOrder) -> POSSubmissionResult
    async def get_order_status(pos_order_id: str) -> OrderStatus
    async def cancel_order(pos_order_id: str) -> bool

class ToastAdapter(POSAdapter): ...
class SquareAdapter(POSAdapter): ...
class CloverAdapter(POSAdapter): ...
```

### Credential Management
- Credentials stored in `RestaurantPOSConfig.api_credentials` (JSONB, encrypted at rest)
- OAuth tokens stored with refresh_token for long-lived integrations
- Credentials never logged or exposed in error messages
- Key rotation handled via admin dashboard

---

## 4. Idempotency & Duplicate Prevention

### Strategy
- **Idempotency Key**: `order_id` (UUID, assigned by fulfillment engine)
- **Duplicate Detection**: Check `POSSubmissionAttempt` table for existing order_id before submission
- **Distributed Lock**: Redis key `order:submit:{order_id}` ensures only one worker processes
- **Response Caching**: Return cached POS response for duplicate submissions within 5s

### Implementation
```python
async def submit_order(order_id: UUID):
    # Acquire distributed lock (fail-safe, 30s TTL)
    lock = await redis.lock(f"order:submit:{order_id}", timeout=30)
    
    # Check if already submitted
    existing = await db.query(POSSubmissionAttempt).filter(
        POSSubmissionAttempt.fulfillment_order_id == order_id,
        POSSubmissionAttempt.success == True
    ).first()
    
    if existing:
        return existing.response_body  # Return cached response
    
    # Proceed with submission
    ...
```

---

## 5. Error Handling & Retry Strategy

### Retry Logic
- **Attempts**: 3 total attempts
- **Backoff**: Exponential (2s, 4s, 8s) + jitter
- **Condition**: Retry on 5xx, timeout, connection errors; NOT on 4xx (invalid payload)
- **Circuit Breaker**: If restaurant's POS fails 10x in 5 minutes, mark as "rate_limited" and alert admin

### Error Categories
| Error | Retry? | Action |
|-------|--------|--------|
| 5xx (server error) | Yes | Exponential backoff |
| 429 (rate limit) | Yes | Adaptive backoff, alert admin |
| 401/403 (auth) | Once | Token refresh attempt, then mark as "authentication_failed" |
| 4xx (validation) | No | Mark as "failed", alert restaurant |
| Network timeout | Yes | Exponential backoff |
| Connection refused | Yes | Exponential backoff |

### Failed Order Handling
- After 3 failed attempts: Mark as "failed", create alert in admin dashboard
- Restaurant receives SMS/email: "Order #123 failed to submit. Manual intervention required."
- Admin dashboard shows: Order details, all attempt logs, one-click "retry" button
- Alternative flow: Staff can manually create order in POS, then link to Parcera order

---

## 6. Status Polling Strategy

### Polling Mechanism
- **Frequency**: Every 30 seconds for active orders (pending, submitted, confirmed, preparing)
- **Stop Condition**: When order reaches terminal state (ready, completed, cancelled, failed)
- **Timeout**: Mark as "stale" if status not updated after 24 hours
- **Rate Limit Adaptation**: If 429 errors, back off to 60s, 120s, etc.

### Polling Job Architecture
```python
# Job runs every 30 seconds globally
async def poll_pos_status():
    # Fetch all active orders grouped by restaurant POS type
    orders = await db.query(FulfillmentOrder).filter(
        FulfillmentOrder.status.in_(['submitted', 'confirmed', 'preparing', 'ready'])
    ).all()
    
    # Batch by restaurant for connection pooling
    for restaurant_id, orders_batch in group_by(orders, 'restaurant_id'):
        adapter = get_adapter(restaurant_id)
        for order in orders_batch:
            try:
                status = await adapter.get_order_status(order.pos_order_id)
                if status != order.status:
                    # Update status, trigger notifications
                    await update_order_status(order, status)
            except RateLimitError:
                # Back off polling for this restaurant
                mark_restaurant_rate_limited(restaurant_id)
```

---

## 7. Notification Delivery

### Notification Channels
| Channel | Trigger | Audience | Provider |
|---------|---------|----------|----------|
| Push | confirmed, ready, cancelled | Mobile app users | Firebase Cloud Messaging |
| SMS | confirmed, ready, cancelled | IVR/Kiosk users | Twilio or AWS SNS |
| Email | ready (optional) | Mobile/Web users | AWS SES |
| Webhook | Any status change | Restaurant | Optional, configured per restaurant |

### Rate Limiting
- Max 1 notification per order per 5 minutes (prevent spam)
- Implement token bucket: 1 token = 1 notification, refill every 5 minutes

### Retry Logic for Notifications
- Failed notification: Retry 3 times with exponential backoff
- After 3 failures: Log error, skip (don't block order fulfillment)
- Admin can manually resend from dashboard

---

## 8. Multi-Tenancy & Row-Level Security

### RLS Policy Design
```sql
-- Enable RLS on all fulfillment tables
ALTER TABLE fulfillment_order ENABLE ROW LEVEL SECURITY;

-- Policy: Users can only see orders for their restaurant
CREATE POLICY fulfillment_order_isolation ON fulfillment_order
  USING (restaurant_id = current_user_restaurant_id());

-- Function to get current user's restaurant
CREATE FUNCTION current_user_restaurant_id() RETURNS UUID AS $$
  SELECT restaurant_id FROM restaurant_user 
  WHERE user_id = current_user_id() LIMIT 1;
$$ LANGUAGE SQL;
```

### Benefits
- Database-level isolation: No application logic needed to filter data
- Prevents cross-tenant data leaks even if code has bugs
- Each API call automatically filtered by restaurant_id
- Admin users can bypass RLS via special role

---

## 9. Scalability Considerations

### Horizontal Scaling
- **Stateless API Servers**: Multiple FastAPI instances behind load balancer
- **Worker Scaling**: Celery workers consume from queue, auto-scale based on depth
- **Database Scaling**: Read replicas for polling queries, write primary for submissions
- **Cache Scaling**: Redis cluster for distributed locks, session cache

### Throughput Target
- **MVP Goal**: 1,000 orders/hour (17 orders/min)
- **Achievable with**: 1 API server, 2 worker processes, 1 PostgreSQL instance
- **Headroom for 10x growth**: Already in design (async, queue-based, stateless)

### Bottleneck Analysis
1. **POS API Rate Limits**: Each POS has rate limits (100-3000 req/min)
   - Mitigation: Batch status polling, queue submissions, circuit breaker
2. **Database Connections**: Default PostgreSQL max 100 connections
   - Mitigation: Connection pooling (PgBouncer), optimize query count
3. **Queue Depth**: If submissions back up, queue grows
   - Mitigation: Auto-scale workers, increase concurrency, optimize POS API calls

---

## 10. Data Retention & Privacy

### Retention Policy
- **Order History**: Retain 90 days (configurable per compliance needs)
- **Audit Trail**: Retain indefinitely for regulatory compliance
- **Failed Attempts**: Retain 30 days for debugging
- **Notifications**: Retain 30 days for delivery confirmation

### Privacy Considerations
- Customer contact info (phone, email) encrypted at rest
- POS credentials encrypted at rest, never logged
- Wallet_id used as stable identifier instead of phone/email in queries
- Compliance with GDPR: Support data deletion requests via audit trail

---

## 11. Testing Strategy

### Test Pyramid
- **Unit Tests**: State machine transitions, validation logic, adapter contracts
- **Integration Tests**: E2E order flow (ingestion → POS submission → status polling → notifications)
- **Contract Tests**: Verify Parcera order format matches POS API expectations
- **Load Tests**: 1000 orders/hour sustained, burst to 5000/hour
- **Chaos Tests**: Simulate POS failures, network timeouts, duplicate submissions

### Key Test Scenarios
1. Happy path: Order submission → POS confirmation → status polling → notification
2. Retry success: 1st attempt fails, 2nd succeeds
3. Max retries exceeded: All 3 attempts fail, marked as failed
4. Duplicate detection: Same order submitted twice, only 1 POS submission
5. Scheduled order: Order submitted at correct time (scheduled_time - prep_buffer)
6. Notification rate limiting: Multiple status changes, only 1 notification per 5m

---

## 12. Deployment Strategy

### Containerization
- **Base Image**: `python:3.11-slim`
- **Framework**: Docker, deployed to Kubernetes or ECS
- **Health Checks**: Liveness (FastAPI /health), readiness (DB connectivity)

### Environment Variables
```plaintext
# Secrets (from .env)
DB_PASSWORD=***
REDIS_URL=redis://***
CELERY_BROKER_URL=sqs://***
POS_TOAST_OAUTH_SECRET=***
POS_SQUARE_OAUTH_SECRET=***
POS_CLOVER_OAUTH_SECRET=***

# Config (from config/app.json)
DATABASE_URL=postgresql://user@host/db
POLLING_INTERVAL_SECONDS=30
SUBMISSION_TIMEOUT_SECONDS=2
RETRY_ATTEMPTS=3
```

### Migrations
- **Tool**: Alembic for schema versioning
- **Strategy**: Auto-migrate on container startup (0-downtime with read replicas)
- **Rollback**: Versioned migrations allow quick rollback if needed

---

## 13. Open Research Items

- [ ] **POS Webhook Support**: Confirm which POS systems provide webhooks vs require polling
- [ ] **Notification Provider**: Evaluate Firebase vs AWS SNS vs Twilio for push/SMS
- [ ] **Rate Limit Specifics**: Document actual rate limits for Toast, Square, Clover APIs
- [ ] **Refund Processing**: Coordinate with payment service for failed order refunds
- [ ] **Analytics Integration**: Should fulfillment engine push metrics to analytics platform?

---

## Summary

**Order Fulfillment** is a queue-based, state-machine-driven service that orchestrates orders across multiple channels through various POS systems. FastAPI + PostgreSQL with RLS provides the foundation, while Celery handles async job processing. State machine design ensures consistent order lifecycle, adapter pattern supports multi-POS integrations, and idempotency mechanisms prevent duplicate submissions. Horizontal scaling via stateless architecture and queue-based processing supports 1000+ orders/hour with room for growth.

**Technology Decision**: ✅ Validated. FastAPI + PostgreSQL + Celery + Redis is optimal for this workload.

