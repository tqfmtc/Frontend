# Quickstart: Order Fulfillment Implementation

**Branch**: `006-order-fulfillment` | **Date**: 2025-11-04 | **Spec**: `specs/006-order-fulfillment/spec.md`

## Phase Overview

This quickstart maps the specification to a 3-phase implementation timeline with clear deliverables.

---

## Phase 1: Core Order Fulfillment (Week 1-2)

### Goal
Establish basic order ingestion, POS submission, and status tracking for single POS type.

### Deliverables

#### 1. Database Schema (Day 1)
- Create `fulfillment_order` table with RLS policies
- Create `restaurant_pos_config` table
- Create `order_status_history` table
- Create indexes for polling queries
- **Alembic migration**: `001_create_fulfillment_tables.py`

#### 2. FastAPI Project Structure
```plaintext
backend/
├── fulfillment/
│   ├── __init__.py
│   ├── models/
│   │   ├── __init__.py
│   │   ├── fulfillment_order.py      # SQLAlchemy models
│   │   ├── status_history.py
│   │   └── pos_config.py
│   ├── schemas/
│   │   ├── __init__.py
│   │   └── order_schemas.py          # Pydantic request/response models
│   ├── services/
│   │   ├── __init__.py
│   │   ├── order_service.py          # Business logic
│   │   ├── pos_adapter.py            # POS adapter base class
│   │   └── toast_adapter.py          # Toast POS implementation
│   ├── api/
│   │   ├── __init__.py
│   │   └── orders.py                 # FastAPI routes
│   └── tests/
│       ├── __init__.py
│       ├── test_order_service.py
│       └── test_orders_api.py
├── shared/
│   ├── auth.py                       # Authentication middleware
│   ├── database.py                   # DB connection, session management
│   └── config.py                     # Configuration loading
└── main.py                           # FastAPI app entrypoint
```

#### 3. Core Services (Day 1-2)
- `OrderService`: Create order, validate payload, assign order number
- `TOASTAdapter`: Implement Toast POS order submission
- `StatusPoller`: Basic polling mechanism (not yet scheduled)

#### 4. API Endpoints (Day 2)
- `POST /v1/fulfillment/orders` - Create and submit order
- `GET /v1/fulfillment/orders/{order_id}` - Get order details
- `GET /v1/fulfillment/orders?status=pending` - List orders by status

#### 5. Tests (Day 2)
- Unit tests for OrderService validation logic
- Integration tests for order submission flow
- API contract tests against OpenAPI spec

### Success Criteria (Phase 1)
- Order successfully created in database with generated order_number
- Order submitted to Toast API within 2 seconds
- POS order_id captured and stored
- Order status transitions: pending → submitted → confirmed
- All 3 tests passing (unit, integration, api)
- No RLS data leakage in test scenarios

---

## Phase 2: Status Polling & Notifications (Week 2-3)

### Goal
Implement automated POS status polling and customer notification delivery.

### Deliverables

#### 1. Polling Architecture (Day 3)
- Create `POSStatusPoller` service using APScheduler
- Implement job: Fetch all active orders, batch by restaurant
- Call POS adapter `get_status()` for each order
- Update `fulfillment_order.status` on changes
- Create audit entry in `order_status_history`

#### 2. Notification Infrastructure (Day 3-4)
- Create `NotificationEvent` table
- Implement `NotificationService` with channel abstraction
- Add Firebase Cloud Messaging (FCM) provider
- Add Twilio SMS provider
- Implement rate limiting (1 notification per order per 5 min)

#### 3. Notification Flow (Day 4)
- On status change → Create NotificationEvent (queued)
- Background job consumes pending notifications
- Send via appropriate channel (push/SMS)
- Update delivery_status (sent/delivered/failed)
- Retry failed notifications 3 times with backoff

#### 4. POS Adapters Phase 2 (Day 4)
- Implement `SquareAdapter` (second POS type)
- Test with Toast + Square simultaneously
- Factory pattern for adapter selection

#### 5. Tests (Day 4)
- Polling job: Mock POS API, verify status updates
- Notifications: Verify correct channel selection per order
- Rate limiting: Multiple status changes, only 1 notification per 5m
- Adapter factory: Verify correct adapter selected by pos_type

### Success Criteria (Phase 2)
- Status polling runs every 30 seconds
- POS status changes detected within 60 seconds
- Notifications sent within 10 seconds of status change
- 0 duplicate notifications (rate limiting working)
- Toast + Square both functioning simultaneously
- Notification delivery rate > 95%

---

## Phase 3: Scheduled Orders & Failure Recovery (Week 3-4)

### Goal
Add scheduled order submission and robust failure handling.

### Deliverables

#### 1. Scheduled Orders (Day 5)
- Create `ScheduledOrderQueue` table
- On order creation: If `scheduled_time` provided, insert into queue as "scheduled"
- Background job: Query queue for orders due (submission_time <= NOW())
- Submit to POS at calculated submission_time
- Transition from "scheduled" → "submitted"

#### 2. Failure Recovery (Day 5-6)
- Create `POSSubmissionAttempt` table
- On submission failure: Log attempt details
- Implement retry logic: 3 attempts with exponential backoff (2s, 4s, 8s)
- After 3 failures: Mark order as "failed", create admin alert
- Admin dashboard endpoint: List failed orders, one-click retry button

#### 3. Circuit Breaker (Day 6)
- Track POS failures per restaurant
- If > 10 failures in 5 minutes: Mark connection_status as "rate_limited"
- Alert admin via email/Slack
- Implement manual retry after admin fixes POS credentials

#### 4. Clover Adapter (Day 6)
- Complete third POS type integration
- All three adapters (Toast, Square, Clover) tested together

#### 5. Tests (Day 6)
- Scheduled order: Placed at 5 PM, submitted at 4:40 PM (20min prep buffer)
- Retry success: Attempt 1 fails, attempt 2 succeeds
- Max retries: 3 attempts all fail, marked as failed, admin alert created
- Duplicate detection: Same order_id submitted twice, only 1 POS submission
- Circuit breaker: 10+ failures trigger connection_status update

### Success Criteria (Phase 3)
- 99% of scheduled orders submitted within 2 min of target time
- 99.5% of orders succeed on first or retry attempt
- Failed orders flagged in admin dashboard within 1 minute
- 0 duplicate POS submissions (idempotency working)
- Circuit breaker prevents cascade failures
- All three POS adapters production-ready

---

## Development Setup

### Local Environment

```bash
# Clone repo
git clone <repo>
cd parcera-backend

# Create virtual env
python3.11 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Setup .env
cp .env.example .env
# Edit .env with local DB credentials, Toast API key, etc.

# Run migrations
alembic upgrade head

# Start server
uvicorn fulfillment.main:app --reload --port 8000

# Start polling worker (separate terminal)
celery -A fulfillment.tasks worker --loglevel=info

# Run tests
pytest fulfillment/tests/ -v
```

### Docker Compose

```yaml
version: '3.8'
services:
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: parcera_dev
      POSTGRES_USER: dev
      POSTGRES_PASSWORD: dev
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  api:
    build: .
    environment:
      DATABASE_URL: postgresql://dev:dev@db:5432/parcera_dev
      REDIS_URL: redis://redis:6379/0
    ports:
      - "8000:8000"
    depends_on:
      - db
      - redis

  worker:
    build: .
    command: celery -A fulfillment.tasks worker
    environment:
      DATABASE_URL: postgresql://dev:dev@db:5432/parcera_dev
      REDIS_URL: redis://redis:6379/0
    depends_on:
      - db
      - redis
```

---

## Key Files to Create

### Database Migrations
- `alembic/versions/001_create_fulfillment_tables.py` - Phase 1 schema
- `alembic/versions/002_add_notifications.py` - Phase 2 notifications table
- `alembic/versions/003_add_scheduled_orders.py` - Phase 3 scheduled queue

### Models (SQLAlchemy)
```python
# fulfillment/models/fulfillment_order.py
from sqlalchemy import Column, UUID, String, DECIMAL, JSONB, TIMESTAMP
from sqlalchemy.orm import relationship

class FulfillmentOrder(Base):
    __tablename__ = 'fulfillment_order'
    
    fulfillment_order_id = Column(UUID, primary_key=True)
    order_id = Column(UUID, nullable=False)
    restaurant_id = Column(UUID, ForeignKey('restaurant.restaurant_id'))
    channel = Column(String(20), nullable=False)  # ivr, kiosk, mobile
    status = Column(String(30), nullable=False, default='pending')
    pos_order_id = Column(String(255))
    items = Column(JSONB, nullable=False)
    total = Column(DECIMAL(12,2), nullable=False)
    created_at = Column(TIMESTAMP, nullable=False, server_default=func.now())
    
    # Relationships
    status_history = relationship('OrderStatusHistory', back_populates='order')
    notifications = relationship('NotificationEvent', back_populates='order')
```

### Services (Business Logic)
```python
# fulfillment/services/order_service.py
class OrderService:
    async def create_order(self, req: CreateFulfillmentOrderRequest) -> FulfillmentOrder:
        # Validate payment_status is authorized/captured
        # Assign order_number (daily sequence per restaurant)
        # Create FulfillmentOrder in DB
        # Queue for POS submission
        pass
    
    async def submit_to_pos(self, order_id: UUID) -> POSSubmissionResult:
        # Get restaurant POS config
        # Get adapter (Toast/Square/Clover)
        # Call adapter.submit_order()
        # Log attempt
        # On success: update status to 'submitted', store pos_order_id
        # On failure: schedule retry or mark failed
        pass
```

### Adapters (POS Integration)
```python
# fulfillment/services/pos_adapter.py
from abc import ABC, abstractmethod

class POSAdapter(ABC):
    @abstractmethod
    async def submit_order(self, order: FulfillmentOrder) -> POSSubmissionResult:
        pass
    
    @abstractmethod
    async def get_status(self, pos_order_id: str) -> OrderStatus:
        pass
    
    @abstractmethod
    async def cancel_order(self, pos_order_id: str) -> bool:
        pass

# fulfillment/services/toast_adapter.py
class TOASTAdapter(POSAdapter):
    def __init__(self, api_key: str, base_url: str):
        self.client = httpx.AsyncClient(
            auth=('api-key', api_key),
            base_url=base_url
        )
    
    async def submit_order(self, order: FulfillmentOrder) -> POSSubmissionResult:
        payload = self._map_order_to_toast(order)
        resp = await self.client.post('/orders', json=payload)
        # Handle response, extract pos_order_id
        return POSSubmissionResult(success=True, pos_order_id=resp.json()['id'])
```

### API Routes
```python
# fulfillment/api/orders.py
from fastapi import APIRouter, Depends, HTTPException

router = APIRouter(prefix='/v1/fulfillment', tags=['Orders'])

@router.post('/orders')
async def submit_order(
    req: CreateFulfillmentOrderRequest,
    user: User = Depends(get_current_user)
) -> FulfillmentOrderResponse:
    order = await OrderService().create_order(req, user.restaurant_id)
    return FulfillmentOrderResponse.from_orm(order)

@router.get('/orders/{order_id}')
async def get_order(order_id: UUID, user: User = Depends(get_current_user)):
    order = await db.query(FulfillmentOrder).filter(
        FulfillmentOrder.fulfillment_order_id == order_id,
        FulfillmentOrder.restaurant_id == user.restaurant_id  # RLS via ORM
    ).first()
    if not order:
        raise HTTPException(404, 'Order not found')
    return FulfillmentOrderResponse.from_orm(order)
```

---

## Testing Strategy

### Unit Tests (Services)
```python
# fulfillment/tests/test_order_service.py
@pytest.mark.asyncio
async def test_create_order_assigns_order_number():
    service = OrderService()
    req = CreateFulfillmentOrderRequest(restaurant_id=RESTAURANT_ID, ...)
    order = await service.create_order(req)
    
    assert order.order_number > 0
    assert order.status == 'pending'

@pytest.mark.asyncio
async def test_submit_to_pos_captures_pos_order_id(mocker):
    mock_adapter = mocker.patch('fulfillment.services.toast_adapter.TOASTAdapter')
    mock_adapter.submit_order.return_value = POSSubmissionResult(
        success=True, pos_order_id='pos_123'
    )
    
    service = OrderService()
    result = await service.submit_to_pos(order_id=ORDER_ID)
    
    assert result.pos_order_id == 'pos_123'
```

### Integration Tests (E2E Flow)
```python
@pytest.mark.asyncio
async def test_order_flow_happy_path(db_session, toast_mock):
    # Create order
    order = await create_test_order(db_session)
    assert order.status == 'pending'
    
    # Submit to POS
    await OrderService().submit_to_pos(order.fulfillment_order_id)
    order = await db_session.query(FulfillmentOrder).get(order.fulfillment_order_id)
    assert order.status == 'submitted'
    assert order.pos_order_id is not None
    
    # Poll and get status
    toast_mock.get_status.return_value = OrderStatus.CONFIRMED
    await POSStatusPoller().poll()
    
    order = await db_session.query(FulfillmentOrder).get(order.fulfillment_order_id)
    assert order.status == 'confirmed'
```

### API Contract Tests
```python
def test_submit_order_api_201_response(client):
    resp = client.post('/v1/fulfillment/orders', json={
        'order_id': '550e8400-e29b-41d4-a716-446655440000',
        'restaurant_id': '550e8400-e29b-41d4-a716-446655440001',
        'channel': 'mobile',
        'order_type': 'pickup',
        'items': [...],
        'total': 25.99,
        ...
    })
    
    assert resp.status_code == 201
    data = resp.json()
    assert 'fulfillment_order_id' in data
    assert data['status'] == 'pending'
```

---

## Deployment Checklist

### Pre-Production
- [ ] Database migrations tested on staging
- [ ] All tests passing (unit, integration, api)
- [ ] Load test: 1000 orders/hour sustained
- [ ] Chaos test: POS API failures handled gracefully
- [ ] Security audit: No credential leaks in logs, RLS working
- [ ] Documentation: API docs (Swagger), deployment guide, runbook

### Production Rollout
- [ ] Canary: 5% traffic to new fulfillment service
- [ ] Monitor: Error rate, latency, POS submission success rate
- [ ] Alert: On >1% error rate, >5s latency, <95% POS success
- [ ] Rollback: If metrics degraded, traffic back to old system
- [ ] Full rollout: After 24 hours stable operation

---

## Configuration

### Environment Variables (`.env`)
```plaintext
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/parcera

# Cache & Queue
REDIS_URL=redis://localhost:6379/0
CELERY_BROKER_URL=redis://localhost:6379/1

# POS APIs
TOAST_API_BASE_URL=https://api.toasttab.com
TOAST_API_KEY=sk_live_abc123

SQUARE_API_BASE_URL=https://connect.squareup.com
SQUARE_OAUTH_CLIENT_ID=...
SQUARE_OAUTH_CLIENT_SECRET=...

CLOVER_API_BASE_URL=https://api.clover.com
CLOVER_OAUTH_CLIENT_ID=...
CLOVER_OAUTH_CLIENT_SECRET=...

# Notifications
FCM_CREDENTIALS_JSON=/path/to/firebase.json
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...

# Application
LOG_LEVEL=INFO
POLLING_INTERVAL_SECONDS=30
SUBMISSION_TIMEOUT_SECONDS=2
RETRY_ATTEMPTS=3
RETRY_BACKOFF_BASE=2
```

### Config File (`config/app.json`)
```json
{
  "features": {
    "scheduled_orders_enabled": true,
    "webhook_polling_enabled": true
  },
  "timeouts": {
    "pos_submission_ms": 2000,
    "pos_status_polling_ms": 30000
  },
  "retry": {
    "max_attempts": 3,
    "backoff_base_seconds": 2,
    "jitter_max_seconds": 1
  },
  "notifications": {
    "rate_limit_per_order_minutes": 5,
    "delivery_retry_attempts": 3,
    "delivery_timeout_seconds": 10
  }
}
```

---

## Success Metrics (Phase 3 Complete)

| Metric | Target | Acceptance |
|--------|--------|-----------|
| Order Submission Success Rate | 99.5% | >= 99.5% on first or retry |
| Order Submission Latency (P95) | 2s | < 2 seconds |
| Status Update Latency (P95) | 60s | < 60 seconds (30s poll + 30s processing) |
| Notification Delivery Rate | 98% | >= 98% delivered within 10s |
| Scheduled Order Accuracy | 99% | >= 99% submitted within 2 min of target |
| Duplicate Prevention | 100% | 0 duplicate POS submissions |
| System Uptime | 99.9% | >= 99.9% (8.64 hours/month downtime) |
| Error Rate | <0.5% | < 0.5% of all requests |

---

## Next Steps After Phase 3

- **Phase 4 (P2)**: Admin dashboard for failed order management
- **Phase 5 (P2)**: Analytics: Order flow metrics, POS health scoring
- **Phase 6 (P2)**: Multi-location restaurant routing
- **Phase 7 (Future)**: Order modification support, advanced kitchen workflows

