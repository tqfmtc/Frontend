# Phase 1 Data Model: Order Fulfillment

**Branch**: `006-order-fulfillment` | **Date**: 2025-11-04 | **Spec**: `specs/006-order-fulfillment/spec.md`

## 1. Entity-Relationship Diagram (ERD)

```plaintext
FulfillmentOrder
├── OrderStatusHistory* (1:N)
├── POSSubmissionAttempt* (1:N)
├── NotificationEvent* (1:N)
└── ScheduledOrderQueue? (1:1, optional)

RestaurantPOSConfig
└── FulfillmentOrder* (1:N)

Note: * = one-to-many, ? = optional one-to-one
```

---

## 2. Core Entities

### FulfillmentOrder
**Purpose**: Central order record tracking lifecycle from submission through fulfillment

```sql
CREATE TABLE fulfillment_order (
  fulfillment_order_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Foreign Keys
  order_id UUID NOT NULL,  -- Reference to source (IVR/Kiosk/Mobile order)
  restaurant_id UUID NOT NULL REFERENCES restaurant(restaurant_id),
  
  -- Identifiers
  channel VARCHAR(20) NOT NULL CHECK (channel IN ('ivr', 'kiosk', 'mobile')),
  order_number BIGINT NOT NULL,  -- Daily sequence per restaurant
  pos_order_id VARCHAR(255),  -- ID returned by POS API (nullable until submitted)
  pos_type VARCHAR(20) NOT NULL CHECK (pos_type IN ('toast', 'square', 'clover')),
  
  -- Order Details
  order_type VARCHAR(20) NOT NULL CHECK (order_type IN ('pickup', 'delivery')),
  items JSONB NOT NULL,  -- [{item_id, name, quantity, modifiers: [{mod_id, name, value}]}]
  subtotal NUMERIC(12,2) NOT NULL,
  tax NUMERIC(12,2) NOT NULL,
  tip NUMERIC(12,2) DEFAULT 0,
  total NUMERIC(12,2) NOT NULL,
  special_instructions TEXT,
  
  -- Timing
  scheduled_time TIMESTAMP WITH TIME ZONE,  -- NULL = ASAP
  submission_time TIMESTAMP WITH TIME ZONE,  -- Calculated for scheduled orders
  
  -- Customer Contact (for notifications)
  customer_contact JSONB NOT NULL,  -- {phone, email, wallet_id}
  
  -- Status
  status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK (status IN (
    'pending', 'scheduled', 'submitted', 'confirmed', 'preparing', 'ready',
    'completed', 'cancelled', 'failed'
  )),
  payment_status VARCHAR(20) NOT NULL CHECK (payment_status IN (
    'pending', 'authorized', 'captured', 'refunded'
  )),
  
  -- Audit
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP WITH TIME ZONE,
  
  -- Constraints
  UNIQUE (restaurant_id, order_number, CAST(created_at AT TIME ZONE 'UTC' AS DATE)),
  CONSTRAINT scheduled_time_future CHECK (
    scheduled_time IS NULL OR scheduled_time > CURRENT_TIMESTAMP
  ),
  CONSTRAINT total_positive CHECK (total > 0)
);

-- Indexes
CREATE INDEX idx_fulfillment_order_restaurant_id 
  ON fulfillment_order(restaurant_id);
CREATE INDEX idx_fulfillment_order_status 
  ON fulfillment_order(status) WHERE status NOT IN ('completed', 'cancelled', 'failed');
CREATE INDEX idx_fulfillment_order_created_at 
  ON fulfillment_order(created_at DESC);
CREATE INDEX idx_fulfillment_order_pos_order_id 
  ON fulfillment_order(pos_order_id) WHERE pos_order_id IS NOT NULL;

-- Row-Level Security
ALTER TABLE fulfillment_order ENABLE ROW LEVEL SECURITY;
CREATE POLICY fulfillment_order_select ON fulfillment_order FOR SELECT
  USING (restaurant_id = current_user_restaurant_id());
CREATE POLICY fulfillment_order_insert ON fulfillment_order FOR INSERT
  WITH CHECK (restaurant_id = current_user_restaurant_id());
CREATE POLICY fulfillment_order_update ON fulfillment_order FOR UPDATE
  USING (restaurant_id = current_user_restaurant_id());
```

### OrderStatusHistory
**Purpose**: Audit trail of all status transitions with root cause

```sql
CREATE TABLE order_status_history (
  status_history_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fulfillment_order_id UUID NOT NULL REFERENCES fulfillment_order(fulfillment_order_id) ON DELETE CASCADE,
  
  old_status VARCHAR(30),  -- NULL for initial status
  new_status VARCHAR(30) NOT NULL,
  changed_by VARCHAR(20) NOT NULL CHECK (changed_by IN (
    'system', 'pos_api', 'admin', 'customer'
  )),
  change_reason TEXT,  -- e.g., "POS API returned 'preparing' status"
  
  timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (fulfillment_order_id) REFERENCES fulfillment_order(fulfillment_order_id)
);

-- Index for audit queries
CREATE INDEX idx_order_status_history_fulfillment_order_id 
  ON order_status_history(fulfillment_order_id);
CREATE INDEX idx_order_status_history_timestamp 
  ON order_status_history(timestamp DESC);

-- RLS
ALTER TABLE order_status_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY order_status_history_visibility ON order_status_history
  USING (fulfillment_order_id IN (
    SELECT fulfillment_order_id FROM fulfillment_order 
    WHERE restaurant_id = current_user_restaurant_id()
  ));
```

### POSSubmissionAttempt
**Purpose**: Track all submission attempts for debugging and retry management

```sql
CREATE TABLE pos_submission_attempt (
  attempt_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fulfillment_order_id UUID NOT NULL REFERENCES fulfillment_order(fulfillment_order_id) ON DELETE CASCADE,
  
  attempt_number INTEGER NOT NULL CHECK (attempt_number BETWEEN 1 AND 3),
  pos_api_endpoint VARCHAR(255) NOT NULL,  -- e.g., "POST /v2/orders"
  
  -- Request/Response
  request_payload JSONB NOT NULL,  -- Full request sent to POS
  response_status INTEGER,  -- HTTP status code (nullable if no response)
  response_body JSONB,  -- Full POS API response
  
  -- Result
  success BOOLEAN NOT NULL,
  error_message TEXT,  -- e.g., "Connection timeout", "Rate limit exceeded"
  
  -- Retry Scheduling
  retry_at TIMESTAMP WITH TIME ZONE,  -- When next retry scheduled
  
  timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (fulfillment_order_id) REFERENCES fulfillment_order(fulfillment_order_id)
);

-- Indexes
CREATE INDEX idx_pos_submission_attempt_fulfillment_order_id 
  ON pos_submission_attempt(fulfillment_order_id);
CREATE INDEX idx_pos_submission_attempt_success 
  ON pos_submission_attempt(success, timestamp DESC);
CREATE INDEX idx_pos_submission_attempt_retry_at 
  ON pos_submission_attempt(retry_at) WHERE retry_at IS NOT NULL;

-- RLS
ALTER TABLE pos_submission_attempt ENABLE ROW LEVEL SECURITY;
CREATE POLICY pos_submission_attempt_visibility ON pos_submission_attempt
  USING (fulfillment_order_id IN (
    SELECT fulfillment_order_id FROM fulfillment_order 
    WHERE restaurant_id = current_user_restaurant_id()
  ));
```

### NotificationEvent
**Purpose**: Track all customer/restaurant notifications with delivery status

```sql
CREATE TABLE notification_event (
  notification_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fulfillment_order_id UUID NOT NULL REFERENCES fulfillment_order(fulfillment_order_id) ON DELETE CASCADE,
  
  -- Recipient
  recipient_type VARCHAR(20) NOT NULL CHECK (recipient_type IN ('customer', 'restaurant')),
  recipient_id UUID NOT NULL,  -- wallet_id (customer) or restaurant_id
  channel VARCHAR(20) NOT NULL CHECK (channel IN ('push', 'sms', 'email', 'webhook')),
  
  -- Trigger
  trigger_status VARCHAR(30) NOT NULL,  -- Which status triggered this notification
  
  -- Content
  notification_content JSONB NOT NULL,  -- {title, body, action_url, metadata}
  
  -- Delivery
  delivery_status VARCHAR(20) NOT NULL DEFAULT 'queued' CHECK (delivery_status IN (
    'queued', 'sent', 'delivered', 'failed'
  )),
  sent_at TIMESTAMP WITH TIME ZONE,
  delivered_at TIMESTAMP WITH TIME ZONE,
  error_message TEXT,
  
  -- Audit
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (fulfillment_order_id) REFERENCES fulfillment_order(fulfillment_order_id)
);

-- Indexes
CREATE INDEX idx_notification_event_fulfillment_order_id 
  ON notification_event(fulfillment_order_id);
CREATE INDEX idx_notification_event_delivery_status 
  ON notification_event(delivery_status) WHERE delivery_status IN ('queued', 'failed');
CREATE INDEX idx_notification_event_recipient_id 
  ON notification_event(recipient_id, created_at DESC);

-- RLS
ALTER TABLE notification_event ENABLE ROW LEVEL SECURITY;
CREATE POLICY notification_event_visibility ON notification_event
  USING (fulfillment_order_id IN (
    SELECT fulfillment_order_id FROM fulfillment_order 
    WHERE restaurant_id = current_user_restaurant_id()
  ));
```

### RestaurantPOSConfig
**Purpose**: Store POS API credentials and settings per restaurant

```sql
CREATE TABLE restaurant_pos_config (
  config_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL UNIQUE REFERENCES restaurant(restaurant_id),
  
  -- POS Type
  pos_type VARCHAR(20) NOT NULL CHECK (pos_type IN ('toast', 'square', 'clover')),
  
  -- Credentials (encrypted at rest via pgcrypto or vault)
  api_credentials JSONB NOT NULL,  -- {api_key, oauth_token, refresh_token, merchant_id}
  api_base_url VARCHAR(255) NOT NULL,
  
  -- Webhooks
  webhook_url VARCHAR(255),  -- Optional: POS can send updates to Parcera
  webhook_secret VARCHAR(255),  -- For signing webhook payloads
  
  -- Settings
  settings JSONB NOT NULL DEFAULT '{}',  -- {polling_interval, prep_time_estimate, notification_prefs}
  
  -- Health
  connection_status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (connection_status IN (
    'active', 'authentication_failed', 'rate_limited', 'disabled'
  )),
  last_connection_test TIMESTAMP WITH TIME ZONE,
  last_error_message TEXT,
  
  -- Audit
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (restaurant_id) REFERENCES restaurant(restaurant_id)
);

-- Indexes
CREATE INDEX idx_restaurant_pos_config_restaurant_id 
  ON restaurant_pos_config(restaurant_id);
CREATE INDEX idx_restaurant_pos_config_connection_status 
  ON restaurant_pos_config(connection_status) WHERE connection_status != 'active';

-- RLS
ALTER TABLE restaurant_pos_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY restaurant_pos_config_visibility ON restaurant_pos_config
  USING (restaurant_id = current_user_restaurant_id());
```

### ScheduledOrderQueue
**Purpose**: Track scheduled orders pending submission

```sql
CREATE TABLE scheduled_order_queue (
  queue_entry_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fulfillment_order_id UUID NOT NULL UNIQUE REFERENCES fulfillment_order(fulfillment_order_id) ON DELETE CASCADE,
  
  -- Timing
  scheduled_time TIMESTAMP WITH TIME ZONE NOT NULL,
  submission_time TIMESTAMP WITH TIME ZONE NOT NULL,
  estimated_prep_time INTEGER NOT NULL DEFAULT 20,  -- minutes
  
  -- Status
  processed BOOLEAN NOT NULL DEFAULT FALSE,
  processed_at TIMESTAMP WITH TIME ZONE,
  
  -- Audit
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  CONSTRAINT submission_time_before_scheduled CHECK (submission_time < scheduled_time),
  CONSTRAINT submission_time_reasonable CHECK (
    submission_time > CURRENT_TIMESTAMP AND submission_time < scheduled_time + INTERVAL '1 day'
  )
);

-- Indexes
CREATE INDEX idx_scheduled_order_queue_submission_time 
  ON scheduled_order_queue(submission_time) WHERE processed = FALSE;
CREATE INDEX idx_scheduled_order_queue_processed 
  ON scheduled_order_queue(processed, submission_time);

-- RLS
ALTER TABLE scheduled_order_queue ENABLE ROW LEVEL SECURITY;
CREATE POLICY scheduled_order_queue_visibility ON scheduled_order_queue
  USING (fulfillment_order_id IN (
    SELECT fulfillment_order_id FROM fulfillment_order 
    WHERE restaurant_id = current_user_restaurant_id()
  ));
```

---

## 3. Enum Types

```sql
-- Status transitions
CREATE TYPE order_status_enum AS ENUM (
  'pending', 'scheduled', 'submitted', 'confirmed', 'preparing',
  'ready', 'completed', 'cancelled', 'failed'
);

-- Payment status
CREATE TYPE payment_status_enum AS ENUM (
  'pending', 'authorized', 'captured', 'refunded'
);

-- Channel source
CREATE TYPE order_channel_enum AS ENUM ('ivr', 'kiosk', 'mobile');

-- POS Type
CREATE TYPE pos_type_enum AS ENUM ('toast', 'square', 'clover');

-- Notification delivery
CREATE TYPE notification_delivery_enum AS ENUM (
  'queued', 'sent', 'delivered', 'failed'
);

-- Connection status
CREATE TYPE connection_status_enum AS ENUM (
  'active', 'authentication_failed', 'rate_limited', 'disabled'
);
```

---

## 4. Key Relationships

### FulfillmentOrder → OrderStatusHistory
- **Type**: One-to-many
- **Cascade**: Delete history when order deleted
- **Purpose**: Complete audit trail of status changes
- **Query Pattern**: Get all status changes for an order: `SELECT * FROM order_status_history WHERE fulfillment_order_id = ? ORDER BY timestamp DESC`

### FulfillmentOrder → POSSubmissionAttempt
- **Type**: One-to-many
- **Cascade**: Delete attempts when order deleted
- **Purpose**: Track retry attempts and error messages
- **Query Pattern**: Get last attempt: `SELECT * FROM pos_submission_attempt WHERE fulfillment_order_id = ? ORDER BY attempt_number DESC LIMIT 1`

### FulfillmentOrder → NotificationEvent
- **Type**: One-to-many
- **Cascade**: Delete notifications when order deleted
- **Purpose**: Track what customers/restaurants were notified
- **Query Pattern**: Get pending notifications: `SELECT * FROM notification_event WHERE delivery_status = 'queued' ORDER BY created_at ASC`

### FulfillmentOrder → ScheduledOrderQueue
- **Type**: One-to-one (optional)
- **Cascade**: Delete queue entry when order deleted
- **Purpose**: Only scheduled orders have queue entries
- **Query Pattern**: Get orders to submit: `SELECT * FROM scheduled_order_queue WHERE processed = FALSE AND submission_time <= NOW() ORDER BY submission_time ASC`

### RestaurantPOSConfig → FulfillmentOrder
- **Type**: One-to-many (implicit via restaurant_id)
- **Purpose**: Each restaurant has one POS config, many fulfillment orders
- **Query Pattern**: Get POS config for order: `SELECT * FROM restaurant_pos_config WHERE restaurant_id = (SELECT restaurant_id FROM fulfillment_order WHERE fulfillment_order_id = ?)`

---

## 5. Constraints & Validations

### Business Rules (Database-level)
1. **Order Number Uniqueness**: Unique (restaurant_id, order_number, date)
   - Allows restart of numbering each day per restaurant

2. **Scheduled Time Validation**: Must be in future
   - Constraint: `scheduled_time > CURRENT_TIMESTAMP`

3. **Total Amount Positive**: Must be > 0
   - Constraint: `total > 0`

4. **Submission Time Logic**: For scheduled orders, `submission_time = scheduled_time - estimated_prep_time`
   - Constraint: `submission_time < scheduled_time`

5. **Status Transition Rules** (enforced in application code):
   - pending → scheduled | submitted | cancelled
   - scheduled → submitted | cancelled
   - submitted → confirmed | failed
   - confirmed → preparing | failed
   - preparing → ready | failed
   - ready → completed | cancelled
   - failed → (awaiting admin action)

6. **Payment Authorization**: Must be 'authorized' or 'captured' before submission

---

## 6. Indexes & Query Performance

### High-Priority Queries
```sql
-- 1. Get active orders for polling (runs every 30s)
SELECT fulfillment_order_id, pos_order_id, restaurant_id, pos_type
FROM fulfillment_order
WHERE status IN ('submitted', 'confirmed', 'preparing', 'ready')
ORDER BY updated_at ASC;
-- Index: idx_fulfillment_order_status

-- 2. Get orders due for scheduled submission
SELECT fulfillment_order_id, restaurant_id
FROM scheduled_order_queue
WHERE processed = FALSE AND submission_time <= NOW()
ORDER BY submission_time ASC;
-- Index: idx_scheduled_order_queue_submission_time

-- 3. Check for duplicate order submission
SELECT pos_order_id
FROM fulfillment_order
WHERE order_id = $1 AND pos_order_id IS NOT NULL;
-- Index: idx_fulfillment_order_pos_order_id

-- 4. Get pending notifications to deliver
SELECT notification_id, recipient_id, channel, notification_content
FROM notification_event
WHERE delivery_status = 'queued'
ORDER BY created_at ASC
LIMIT 100;
-- Index: idx_notification_event_delivery_status

-- 5. Search orders by restaurant & date
SELECT fulfillment_order_id, order_number, status, created_at
FROM fulfillment_order
WHERE restaurant_id = $1 AND created_at >= $2 AND created_at < $3
ORDER BY order_number DESC;
-- Index: idx_fulfillment_order_restaurant_id, idx_fulfillment_order_created_at
```

---

## 7. Data Types & Validation

### Items JSON Schema
```json
{
  "items": [
    {
      "item_id": "uuid",
      "name": "Burger",
      "quantity": 2,
      "unit_price": 12.99,
      "modifiers": [
        {
          "modifier_id": "uuid",
          "name": "Cheese",
          "value": "Extra Cheddar",
          "price": 1.50
        }
      ]
    }
  ]
}
```

### Customer Contact JSON Schema
```json
{
  "phone": "+1-555-0100",
  "email": "customer@example.com",
  "wallet_id": "uuid"
}
```

### API Credentials JSON Schema (encrypted)
```json
{
  "pos_type": "toast",
  "api_key": "sk_live_***",
  "oauth_token": "token_***",
  "refresh_token": "refresh_***",
  "merchant_id": "merchant_123"
}
```

### Notification Content JSON Schema
```json
{
  "title": "Order Ready!",
  "body": "Your order #123 at Bob's Diner is ready for pickup",
  "action_url": "app://orders/123",
  "metadata": {
    "order_number": 123,
    "restaurant_name": "Bob's Diner",
    "status": "ready"
  }
}
```

---

## 8. Migration Strategy

### Phase 1: Initial Schema (Week 1)
- Create all core tables (FulfillmentOrder, OrderStatusHistory, POSSubmissionAttempt)
- Enable RLS policies
- Create base indexes

### Phase 2: Enhancements (Week 2)
- Add NotificationEvent table
- Add RestaurantPOSConfig table
- Add performance indexes

### Phase 3: Scheduling (Week 3)
- Add ScheduledOrderQueue table
- Add APScheduler integration
- Add scheduled order submission job

### Migration Rollback
- All migrations versioned with Alembic
- Migrations are idempotent (safe to re-run)
- Down migrations allow rollback if issues detected

---

## 9. Data Retention Policy

```sql
-- Cleanup job (runs daily)
DELETE FROM order_status_history
WHERE timestamp < CURRENT_TIMESTAMP - INTERVAL '90 days';

DELETE FROM pos_submission_attempt
WHERE timestamp < CURRENT_TIMESTAMP - INTERVAL '30 days'
  AND success = TRUE;

DELETE FROM notification_event
WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '30 days'
  AND delivery_status = 'delivered';

DELETE FROM fulfillment_order
WHERE completed_at < CURRENT_TIMESTAMP - INTERVAL '90 days'
  AND status IN ('completed', 'cancelled');
```

---

## Summary

**Data Model** is normalized, secure, and audit-friendly. Row-Level Security isolates data by restaurant. Key entities track the complete order lifecycle from submission through fulfillment, with comprehensive audit trails and retry management. Indexes optimized for high-frequency queries (polling, scheduled submission, notification delivery). Ready for implementation.

