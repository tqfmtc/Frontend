# Feature Specification: Biometric Kiosk Authentication

**Feature Branch**: `015-biometric-kiosk-auth`
**Created**: 2025-10-29
**Status**: Draft
**Input**: User description: "Biometric Kiosk Authentication - Face biometric stored in mobile wallet from ID verification (spec 012), kiosk camera captures customer face, BLE proximity detection or phone number entry establishes pairing, secure WebSocket connection between kiosk and mobile app, on-device biometric matching (privacy-first, Face ID/BiometricPrompt), payment authorization token sent from app to kiosk, automatic wallet preference loading (allergies, dietary restrictions, favorite modifications, payment method). Fallback to manual entry if biometric fails."

## User Scenarios & Testing

### User Story 1 - BLE Proximity Auto-Pairing (Priority: P1)

Customer approaches kiosk with mobile app running, BLE beacon auto-detects phone, establishes secure pairing, and displays personalized welcome without manual interaction.

**Why this priority**: Frictionless authentication differentiator. Enables "walk up and order" experience.

**Independent Test**: Customer with app walks within 3 feet of kiosk, kiosk detects phone via BLE, displays "Welcome [Name]!" with wallet preferences loaded.

**Acceptance Scenarios**:
1. **Given** customer with app approaches kiosk, **When** within BLE range (3 feet), **Then** kiosk displays "Welcome back!" and sends pairing request to app within 2 seconds
2. **Given** app receives pairing request, **When** customer approves (Face ID/fingerprint), **Then** secure WebSocket establishes and wallet loads to kiosk
3. **Given** wallet loads successfully, **When** kiosk displays menu, **Then** allergies filter items, favorites show stars, payment method pre-selected
4. **Given** multiple phones detected, **When** kiosk shows "Tap to claim this kiosk", **Then** first customer to tap continues

---

### User Story 2 - Phone Number Manual Pairing (Priority: P1)

Customer enters phone number on kiosk, receives push notification, approves connection, and kiosk loads wallet preferences for ordering.

**Why this priority**: Fallback for customers without BLE enabled or app not running in background.

**Independent Test**: Enter phone number on kiosk, receive push notification on phone, approve pairing, verify kiosk shows wallet preferences.

**Acceptance Scenarios**:
1. **Given** customer taps "Enter Phone Number" on kiosk, **When** they input number, **Then** push notification sent to phone within 3 seconds
2. **Given** push notification received, **When** customer taps "Approve Kiosk Connection", **Then** app establishes WebSocket and sends wallet data
3. **Given** customer doesn't have app installed, **When** they enter phone number, **Then** kiosk displays "Download app to enable quick checkout" with QR code
4. **Given** no response after 30 seconds, **When** timeout occurs, **Then** kiosk falls back to "Continue as Guest" manual entry

---

### User Story 3 - Face Biometric Recognition with On-Device Matching (Priority: P1)

Kiosk camera captures customer face, sends encrypted image to mobile app via WebSocket, app performs on-device biometric comparison (Face ID), returns match result and payment authorization without exposing biometric data.

**Why this priority**: Ultimate frictionless experience + privacy-first architecture. Biometric never leaves device.

**Independent Test**: Customer's face captured by kiosk camera, app receives image, performs Face ID match, sends authorization token, kiosk proceeds to order.

**Acceptance Scenarios**:
1. **Given** kiosk camera active, **When** customer looks at camera, **Then** face detected and encrypted image sent to paired app within 1 second
2. **Given** app receives face image, **When** on-device biometric SDK compares to stored template (from spec 012 ID verification), **Then** match result (true/false) returned within 2 seconds
3. **Given** biometric match succeeds, **When** app sends authorization token, **Then** kiosk displays "Verified!" and enables payment without card entry
4. **Given** biometric match fails, **When** app returns "no match", **Then** kiosk prompts "Please enter payment manually" without blocking order

---

### User Story 4 - Automatic Preference Application (Priority: P1)

Wallet preferences (allergies, dietary restrictions, favorites, payment) automatically applied to kiosk session, filtering menu items, highlighting favorites, and pre-selecting payment method.

**Why this priority**: Core value proposition - reduce ordering friction and prevent allergy errors.

**Independent Test**: Customer with stored allergies (nuts) and favorites (extra sauce) pairs with kiosk, verifies nut-containing items flagged, favorite modifications pre-selected.

**Acceptance Scenarios**:
1. **Given** customer has "peanut allergy" stored, **When** wallet loads to kiosk, **Then** all items containing peanuts show "Contains allergens - Not recommended" badge
2. **Given** customer has "vegan" dietary restriction, **When** browsing menu, **Then** non-vegan items grayed out with filter toggle "Show all items"
3. **Given** customer has favorite "extra white sauce", **When** adding eligible item, **Then** "extra white sauce" modifier pre-selected with confirmation prompt
4. **Given** customer has saved payment method, **When** reaching checkout, **Then** payment pre-selected with last 4 digits shown, requiring only CVV or biometric auth

---

### Edge Cases

- What if multiple customers with phones approach kiosk simultaneously? First-come first-served based on BLE signal strength. Others see "Kiosk in use" with wait time estimate.
- What if BLE pairing fails but customer wants biometric auth? Fallback to phone number entry, then biometric matching via WebSocket still available.
- What if biometric template doesn't exist in wallet (no ID verification completed)? Feature gracefully disabled, kiosk works normally with manual payment entry.
- What if app crashes during WebSocket session? Kiosk displays "Connection lost" and falls back to guest mode, preserving cart contents.
- What if customer privacy concern about camera? Kiosk displays "Face recognition optional - Tap here to skip" with manual payment alternative.
- What if kiosk camera quality insufficient for biometric? Minimum camera spec (1080p, 30fps) enforced. Low-quality cameras disable biometric feature automatically.

## Requirements

### Functional Requirements

#### BLE Pairing
- **FR-001**: Kiosk MUST broadcast BLE beacon (UUID specific to Parcera) detectable within 3-foot radius
- **FR-002**: Mobile app MUST scan for Parcera BLE beacons when running in background or foreground
- **FR-003**: System MUST establish secure WebSocket connection within 2 seconds of BLE pairing approval
- **FR-004**: System MUST handle multi-phone detection with "Claim Kiosk" prompt requiring tap confirmation
- **FR-005**: BLE pairing MUST timeout after 10 seconds if no app response, falling back to phone number entry

#### Phone Number Pairing
- **FR-006**: Kiosk MUST provide phone number entry keypad with validation (10-digit US format)
- **FR-007**: System MUST send push notification to entered phone number within 3 seconds via spec 010 infrastructure
- **FR-008**: Push notification MUST include kiosk location and "Approve Connection" action button
- **FR-009**: System MUST establish WebSocket connection when customer approves pairing in push notification
- **FR-010**: System MUST fall back to guest mode after 30-second no-response timeout

#### Biometric Matching
- **FR-011**: Kiosk camera MUST capture face image (1080p minimum) and encrypt before transmission
- **FR-012**: System MUST send encrypted face image to mobile app via WebSocket channel
- **FR-013**: Mobile app MUST perform on-device biometric comparison using Face ID (iOS) or BiometricPrompt (Android)
- **FR-014**: Mobile app MUST return match result (boolean) and payment authorization token without exposing biometric template
- **FR-015**: System MUST complete biometric authentication within 3 seconds total (capture + match + response)

#### Wallet Preference Loading
- **FR-016**: System MUST load wallet allergies and filter/flag menu items containing allergens on kiosk display
- **FR-017**: System MUST load dietary restrictions (vegan, vegetarian, gluten-free) and apply visual filtering to menu
- **FR-018**: System MUST pre-select favorite modifications when customer adds eligible items to cart
- **FR-019**: System MUST pre-select saved payment method at checkout with masked card number (last 4 digits)
- **FR-020**: System MUST display "Preferences loaded from wallet" confirmation banner on successful pairing

#### Privacy & Security
- **FR-021**: System MUST encrypt all WebSocket messages (TLS 1.3 minimum) between kiosk and mobile app
- **FR-022**: System MUST delete face images from mobile app immediately after biometric comparison (no storage)
- **FR-023**: Kiosk MUST never store biometric templates, only receive match result from mobile app
- **FR-024**: System MUST implement pairing session timeout (5 minutes of inactivity) to prevent unauthorized access
- **FR-025**: System MUST require biometric re-authentication if payment amount exceeds $50 (additional security)

#### Fallback & Error Handling
- **FR-026**: Kiosk MUST provide "Continue as Guest" option at all times for customers without app
- **FR-027**: System MUST gracefully degrade to manual entry if biometric fails after 2 attempts
- **FR-028**: Kiosk MUST display clear error messages ("Connection lost", "Biometric unavailable") with alternative actions
- **FR-029**: System MUST log pairing failures for debugging while preserving customer privacy (no PII in logs)
- **FR-030**: Kiosk MUST support camera-less mode (biometric disabled) if hardware unavailable

### Key Entities

- **BiometricPairingSession**: WebSocket connection with session_id, kiosk_id, wallet_id, pairing_method (ble/phone_number), biometric_status (pending/matched/failed), connection_established_time, last_activity_time, timeout (5 min)
- **BiometricTemplate**: Face biometric stored in wallet with template_id, wallet_id, created_from_id_verification (spec 012), encoded_template (encrypted), created_date, last_used_date
- **BiometricAuthorizationToken**: Payment authorization from app with token_id, session_id, payment_method_id, authorized_amount_limit ($50), expiration_time (current transaction only), digital_signature
- **KioskBLEBeacon**: Broadcast identifier with beacon_uuid, kiosk_id, broadcast_power (3-foot range), active_status, last_broadcast_time

## Success Criteria

- **SC-001**: 70% of customers with stored biometrics successfully authenticate on first attempt within 3 seconds
- **SC-002**: BLE auto-pairing drives 50% of kiosk sessions (vs 30% phone number, 20% guest)
- **SC-003**: Biometric payment authorization reduces checkout time by 50% compared to manual card entry
- **SC-004**: 0 incidents of biometric data exposure or server-side storage (privacy compliance)
- **SC-005**: Allergy preference filtering prevents 100% of orders with flagged allergens without explicit override
- **SC-006**: Favorite modification auto-application drives 80% order customization accuracy
- **SC-007**: 90% customer satisfaction with biometric kiosk experience in post-order surveys
- **SC-008**: Fallback to manual entry succeeds for 100% of biometric authentication failures (no blocked orders)
- **SC-009**: WebSocket connection remains stable for 95% of kiosk session duration
- **SC-010**: Multi-phone conflict resolution completes within 5 seconds without customer confusion

## Assumptions

1. **Biometric Storage**: Face template extracted from ID verification (spec 012) and stored encrypted in wallet. Customers must complete age verification first.
2. **BLE Hardware**: Kiosks equipped with BLE 5.0+ beacon hardware. Beacon range configured to 3-foot radius to minimize multi-kiosk interference.
3. **Camera Quality**: Kiosk camera minimum 1080p resolution, 30fps for reliable face detection. Lower quality cameras disable biometric feature.
4. **On-Device Matching**: Mobile app uses native biometric APIs (Face ID on iOS, BiometricPrompt on Android). No third-party SDKs to ensure privacy.
5. **WebSocket Security**: TLS 1.3 encryption for all kiosk-app communication. Session tokens use HMAC-SHA256 signing to prevent tampering.
6. **Payment Limits**: Biometric authorization limited to $50 per transaction. Higher amounts require manual CVV or PIN entry for security.
7. **Background App**: iOS/Android allow BLE scanning in background for limited time. App must be recently opened (within 1 hour) for BLE auto-pairing.
8. **Privacy Compliance**: Face images deleted immediately after match. GDPR/CCPA compliant with customer consent during ID verification.
9. **Network Reliability**: Kiosk has stable WiFi for WebSocket connections. Cellular data used by mobile app with fallback to guest mode on disconnection.
10. **Adoption Rate**: Assumes 60% of customers complete ID verification (spec 012) enabling biometric template storage.

## Constitution Alignment

### Principle III: Privacy-First Customer Data
- **CRITICAL**: Biometric template never leaves customer device. Kiosk receives only match result (true/false).
- Face images encrypted in transit, deleted immediately after matching on-device.
- No biometric data stored on servers or accessible to restaurants.

### Principle IV: Omnichannel by Default
- Wallet preferences (allergies, favorites) work consistently across kiosk, mobile, IVR channels.
- Biometric authentication specific to kiosk but fallback to other channels seamless.

### Principle V: Progressive Enhancement & MVP Discipline
- **P1**: BLE pairing, phone number pairing, on-device biometric, preference loading, payment authorization (FR-001 to FR-020)
- **P2**: Advanced camera features, multi-party sessions, voice activation

### Principle VI: Network Effects & Platform Thinking
- Biometric template reusable across all partner restaurant kiosks (verify once, use everywhere).

## Dependencies

### Internal Dependencies
- **Kiosk Ordering (spec 004)**: Provides kiosk interface, camera hardware, BLE beacon
- **Customer Wallet (spec 008)**: Stores biometric template, preferences, payment methods
- **Digital Identity (spec 012)**: Sources face template from ID verification photo
- **Mobile App (spec 005)**: Performs on-device biometric matching, manages WebSocket connection
- **Notification Infrastructure (spec 010)**: Sends push notifications for phone number pairing

### External Dependencies
- **BLE Hardware**: Kiosk BLE 5.0+ beacon for proximity detection
- **Kiosk Camera**: 1080p minimum resolution for face capture
- **Biometric SDK**: Face ID (iOS), BiometricPrompt (Android) for on-device matching
- **WebSocket Server**: Real-time bidirectional communication infrastructure

## Future Considerations

- **Voice Activation**: "Hey Parcera, it's me" voice command triggers biometric authentication
- **Multi-Factor Auth**: Combine biometric + PIN for high-value transactions
- **Family Sharing**: Parent biometric authorizes child's kiosk orders
- **Loyalty Integration**: Biometric authentication auto-applies loyalty points/rewards
- **Health Integration**: Store dietary restrictions from health apps (Apple Health, Google Fit)

---

**Checklist**: Create `specs/015-biometric-kiosk-auth/checklists/requirements.md` with validation status ✅ FULLY PASSED
