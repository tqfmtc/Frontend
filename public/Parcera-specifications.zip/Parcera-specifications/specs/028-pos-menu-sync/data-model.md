# Data Model: POS Menu Synchronization

**Phase**: 1 (Design & Contracts)  
**Date**: 2025-11-04  
**Status**: COMPLETE

---

## Entity Relationship Diagram

```
Restaurant (from core)
    ├── POSConnection (M)
    │   ├── SyncJob (M)
    │   │   ├── SyncChangeRecord (M)
    │   │   └── ConflictRecord (M)
    │   └── ManualReviewQueue (M)
    │
    └── SyncAuditLog (M)
```

---

## Detailed Entity Definitions

### 1. POSConnection

Restaurant's authenticated connection to incumbent POS system.

**Schema**:

```sql
CREATE TABLE pos_connections (
    -- Identifier
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    
    -- Multi-tenancy (row-level security)
    tenant_id UUID NOT NULL,
    
    -- POS Platform
    pos_platform ENUM('toast', 'square', 'clover', 'shopify', 'lightspeed', 'aloha') NOT NULL,
    external_pos_account_id VARCHAR(255),  -- Toast account ID, Square merchant ID, etc.
    
    -- Connection Status
    status ENUM('connected', 'disconnected', 'error', 'expired') DEFAULT 'connected',
    error_message TEXT,
    error_count INT DEFAULT 0,
    last_error_at TIMESTAMP,
    
    -- Authentication (encrypted)
    auth_token BYTEA,  -- Encrypted OAuth token or API key
    auth_secret BYTEA,  -- Encrypted webhook secret or additional credential
    auth_expires_at TIMESTAMP,  -- For OAuth tokens
    
    -- Sync Configuration
    sync_method ENUM('webhook', 'polling', 'manual') DEFAULT 'polling',
    polling_interval_minutes INT DEFAULT 15,  -- 5-1440 (8 hours max)
    webhook_enabled BOOLEAN DEFAULT FALSE,
    webhook_verified_at TIMESTAMP,
    
    -- Conflict Resolution Strategy
    conflict_resolution_strategy ENUM('pos_wins', 'parcera_wins', 'manual_review') DEFAULT 'pos_wins',
    auto_apply_confidence_threshold INT DEFAULT 90,  -- 0-100%
    
    -- Initial Menu Import
    initial_import_completed BOOLEAN DEFAULT FALSE,
    initial_import_item_count INT,
    initial_import_completed_at TIMESTAMP,
    
    -- Sync Tracking
    last_successful_sync_at TIMESTAMP,
    last_sync_job_id UUID REFERENCES sync_jobs(id),
    
    -- Audit
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    created_by_user_id UUID,
    
    CONSTRAINT pos_connection_unique_per_restaurant 
        UNIQUE(restaurant_id, pos_platform)
);

CREATE INDEX idx_pos_connection_restaurant_id ON pos_connections(restaurant_id);
CREATE INDEX idx_pos_connection_status ON pos_connections(status, updated_at DESC);
CREATE INDEX idx_pos_connection_webhook_verified ON pos_connections(webhook_verified_at) WHERE webhook_enabled = TRUE;
```

**Validation Rules**:
- `restaurant_id`: Cannot be NULL
- `pos_platform`: Must match supported POS platforms
- `polling_interval_minutes`: Must be 5-1440 (5 min to 24 hours)
- `auto_apply_confidence_threshold`: 0-100, validated in business logic
- `auth_token`: Encrypted at rest using KMS
- Only ONE connection per restaurant per POS platform

**State Transitions**:
```
[disconnected] ---(connect)---> [connected] ---(error)---> [error]
     ↑                                |                         |
     |________________________________|_________________________|
                    (disconnect/retry)
```

---

### 2. SyncJob

Individual menu synchronization operation instance.

**Schema**:

```sql
CREATE TABLE sync_jobs (
    -- Identifier
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pos_connection_id UUID NOT NULL REFERENCES pos_connections(id) ON DELETE CASCADE,
    restaurant_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    
    -- Sync Direction & Trigger
    direction ENUM('inbound', 'outbound') NOT NULL,  -- POS→Parcera or Parcera→POS
    trigger_type ENUM('webhook', 'scheduled_poll', 'manual', 'retry') NOT NULL,
    
    -- Status
    status ENUM('queued', 'running', 'completed', 'partial_failure', 'failed') DEFAULT 'queued',
    completion_status ENUM('success', 'partial', 'failure') DEFAULT NULL,  -- After completion
    
    -- Change Summary
    total_changes_detected INT DEFAULT 0,
    changes_auto_applied INT DEFAULT 0,  -- Confidence ≥ threshold
    changes_flagged_for_review INT DEFAULT 0,  -- Confidence < threshold
    changes_conflict_resolved INT DEFAULT 0,
    changes_failed INT DEFAULT 0,
    
    -- Timing
    triggered_at TIMESTAMP DEFAULT NOW(),
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    ai_processing_time_ms INT,  -- How long AI diff detection took
    
    -- Error Handling
    error_message TEXT,
    error_type VARCHAR(50),  -- e.g., 'pos_api_timeout', 'ai_service_unavailable'
    retry_count INT DEFAULT 0,
    next_retry_at TIMESTAMP,
    
    -- Metadata
    pos_menu_version VARCHAR(255),  -- External POS version/hash for deduplication
    parcera_menu_version VARCHAR(255),
    notes TEXT,  -- Human-readable summary
    
    -- Audit
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    CONSTRAINT sync_job_valid_direction 
        CHECK ((direction = 'inbound' AND trigger_type IN ('webhook', 'scheduled_poll', 'manual', 'retry'))
            OR (direction = 'outbound' AND trigger_type IN ('manual', 'retry')))
);

CREATE INDEX idx_sync_job_pos_connection_id ON sync_jobs(pos_connection_id);
CREATE INDEX idx_sync_job_restaurant_id ON sync_jobs(restaurant_id);
CREATE INDEX idx_sync_job_status ON sync_jobs(status, created_at DESC);
CREATE INDEX idx_sync_job_created_at ON sync_jobs(restaurant_id, created_at DESC);
CREATE INDEX idx_sync_job_retry ON sync_jobs(next_retry_at) WHERE status = 'failed';
```

**Validation Rules**:
- `pos_connection_id`: Must exist in pos_connections
- `direction`: Enum constraint enforced
- `status`: State machine rules (see below)
- `completion_status`: Can only be set when status = 'completed' or 'failed'

**State Transitions**:
```
                queued ---(start)---> running ---(complete)---> completed
                  |                       |                           |
                  |                       |---(partial fail)---> partial_failure
                  |                       |
                  |---(error)---+---------+--> failed
                                |
                            (retry)
                                |
                              [queued]
```

---

### 3. SyncChangeRecord

Detailed record of individual menu change within sync job.

**Schema**:

```sql
CREATE TABLE sync_change_records (
    -- Identifier
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sync_job_id UUID NOT NULL REFERENCES sync_jobs(id) ON DELETE CASCADE,
    restaurant_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    
    -- Item Reference
    parcera_menu_item_id UUID REFERENCES menu_items(id),  -- NULL if new item
    pos_item_id VARCHAR(255) NOT NULL,  -- External POS item ID
    item_name VARCHAR(255) NOT NULL,
    
    -- Change Classification
    change_type ENUM(
        'new_item_added',
        'item_deleted',
        'item_unavailable',
        'price_changed',
        'name_changed',
        'description_changed',
        'category_changed',
        'modifier_added',
        'modifier_removed',
        'modifier_changed',
        'availability_changed'
    ) NOT NULL,
    
    -- Change Details
    field_changed VARCHAR(100),  -- e.g., 'price', 'name', 'modifiers'
    old_value TEXT,  -- JSON-encoded if complex (modifiers)
    new_value TEXT,  -- JSON-encoded if complex (modifiers)
    
    -- AI Confidence & Resolution
    ai_confidence_score INT,  -- 0-100%
    ai_reasoning TEXT,  -- Why AI flagged for manual review (if confidence < threshold)
    
    resolution_method ENUM('auto_applied', 'manual_approved', 'manual_rejected', 'conflict_resolved', 'failed') DEFAULT NULL,
    resolution_status ENUM('pending', 'applied', 'rejected', 'failed') DEFAULT 'pending',
    
    -- If Manually Resolved
    reviewed_by_user_id UUID,
    review_notes TEXT,
    reviewed_at TIMESTAMP,
    
    -- Audit
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    CONSTRAINT change_record_valid_confidence 
        CHECK (ai_confidence_score IS NULL OR (ai_confidence_score >= 0 AND ai_confidence_score <= 100))
);

CREATE INDEX idx_sync_change_record_sync_job_id ON sync_change_records(sync_job_id);
CREATE INDEX idx_sync_change_record_change_type ON sync_change_records(change_type);
CREATE INDEX idx_sync_change_record_resolution_status ON sync_change_records(resolution_status);
CREATE INDEX idx_sync_change_record_parcera_item ON sync_change_records(parcera_menu_item_id);
```

**Validation Rules**:
- `change_type`: Must be one of predefined enums from FR-003
- `ai_confidence_score`: 0-100 or NULL (for non-AI-scored changes)
- `field_changed`: Must match the item field being changed
- `old_value`/`new_value`: Text fields can store JSON for complex types (modifiers, categories)
- State transition: pending → (applied|rejected|failed)

---

### 4. ConflictRecord

Tracks menu conflicts requiring resolution (simultaneous edits).

**Schema**:

```sql
CREATE TABLE conflict_records (
    -- Identifier
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sync_job_id UUID NOT NULL REFERENCES sync_jobs(id) ON DELETE CASCADE,
    pos_connection_id UUID NOT NULL REFERENCES pos_connections(id) ON DELETE CASCADE,
    restaurant_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    
    -- Affected Item
    parcera_menu_item_id UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
    pos_item_id VARCHAR(255) NOT NULL,
    item_name VARCHAR(255) NOT NULL,
    
    -- Conflict Type
    conflict_type ENUM(
        'simultaneous_edit',      -- Both systems modified between syncs
        'structural_mismatch',    -- Modifier/category structure conflict
        'deletion_conflict',      -- Deleted in one system, modified in other
        'field_value_conflict'    -- Different values for same field
    ) NOT NULL,
    
    -- Version Storage (JSON snapshots)
    parcera_version JSONB NOT NULL,  -- { name, price, description, modifiers, availability }
    pos_version JSONB NOT NULL,
    parcera_modified_at TIMESTAMP NOT NULL,
    pos_modified_at TIMESTAMP NOT NULL,
    
    -- Resolution
    resolution_strategy ENUM('pos_wins', 'parcera_wins', 'manual_review'),
    resolution_status ENUM('pending', 'resolved', 'unresolvable') DEFAULT 'pending',
    resolved_by_user_id UUID,
    resolved_at TIMESTAMP,
    resolved_version JSONB,  -- The final merged/chosen version
    resolution_notes TEXT,
    
    -- Auto-Resolution Details (if resolved automatically)
    auto_resolved BOOLEAN DEFAULT FALSE,
    resolution_reason TEXT,  -- Why POS Wins was chosen (newer timestamp, etc.)
    
    -- Audit
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    CONSTRAINT conflict_record_modified_times_valid
        CHECK (parcera_modified_at IS NOT NULL AND pos_modified_at IS NOT NULL)
);

CREATE INDEX idx_conflict_record_pos_connection_id ON conflict_records(pos_connection_id);
CREATE INDEX idx_conflict_record_resolution_status ON conflict_records(resolution_status, updated_at DESC);
CREATE INDEX idx_conflict_record_restaurant_id ON conflict_records(restaurant_id, created_at DESC);
```

**Validation Rules**:
- `parcera_version`/`pos_version`: Must be valid JSON snapshots of menu item state
- `resolution_strategy`: Must match pos_connection's configured strategy OR be overridden for manual review
- `resolved_version`: Only populated after resolution, must match either parcera_version or pos_version (or merged)

---

### 5. ManualReviewQueue

Queue of changes flagged for owner approval (low-confidence changes).

**Schema**:

```sql
CREATE TABLE manual_review_queue (
    -- Identifier
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sync_job_id UUID NOT NULL REFERENCES sync_jobs(id) ON DELETE CASCADE,
    sync_change_record_id UUID NOT NULL REFERENCES sync_change_records(id) ON DELETE CASCADE,
    restaurant_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    
    -- Change Details
    item_name VARCHAR(255) NOT NULL,
    change_summary TEXT NOT NULL,  -- Human-readable: "Caesar Salad possibly renamed to Classic Caesar Salad"
    change_type VARCHAR(100),
    
    -- AI Analysis
    ai_confidence_score INT,
    ai_reasoning TEXT,  -- Why this change is ambiguous
    
    -- Version Comparison (for UI display)
    pos_version_data JSONB,
    parcera_version_data JSONB,
    differences JSONB,  -- Highlighted differences for UI
    
    -- Owner Action
    suggested_action VARCHAR(100),  -- 'approve', 'rename_existing', 'create_new', 'merge', 'ignore'
    owner_action ENUM('approved', 'rejected', 'modified', 'ignored') DEFAULT NULL,
    owner_notes TEXT,
    
    -- Status
    review_status ENUM('pending', 'approved', 'rejected', 'modified', 'expired') DEFAULT 'pending',
    
    -- Audit
    reviewed_by_user_id UUID,
    reviewed_at TIMESTAMP,
    expires_at TIMESTAMP DEFAULT (NOW() + INTERVAL '7 days'),  -- Auto-expire after 7 days
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    CONSTRAINT review_must_be_before_expiry
        CHECK (reviewed_at IS NULL OR reviewed_at < expires_at)
);

CREATE INDEX idx_manual_review_restaurant_id ON manual_review_queue(restaurant_id);
CREATE INDEX idx_manual_review_review_status ON manual_review_queue(review_status, created_at DESC);
CREATE INDEX idx_manual_review_expires_at ON manual_review_queue(expires_at) WHERE review_status = 'pending';
```

**Validation Rules**:
- `sync_change_record_id`: Must exist and correspond to the sync_job
- `review_status`: State machine (pending → approved|rejected|modified|expired)
- `expires_at`: Auto-set to 7 days; flagged changes older than this are considered ignored

---

### 6. SyncAuditLog

Comprehensive audit trail for compliance and troubleshooting.

**Schema**:

```sql
CREATE TABLE sync_audit_logs (
    -- Identifier
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sync_job_id UUID REFERENCES sync_jobs(id) ON DELETE SET NULL,
    restaurant_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    pos_connection_id UUID REFERENCES pos_connections(id) ON DELETE SET NULL,
    
    -- Event Details
    event_type ENUM(
        'sync_started',
        'sync_completed',
        'sync_failed',
        'conflict_detected',
        'manual_review_flagged',
        'manual_review_approved',
        'manual_review_rejected',
        'change_applied',
        'change_failed',
        'error_occurred',
        'webhook_received',
        'webhook_validation_failed',
        'api_call_succeeded',
        'api_call_failed',
        'rollback_executed'
    ) NOT NULL,
    
    event_details JSONB,  -- Flexible structure for different event types
    
    -- Context
    sync_direction ENUM('inbound', 'outbound'),  -- NULL for non-sync events
    changes_summary TEXT,  -- e.g., "3 items added, 2 prices updated"
    affected_item_names TEXT[],  -- Array of item names affected
    
    -- User Action (if applicable)
    user_id UUID,
    action_taken VARCHAR(255),
    
    -- Result
    outcome ENUM('success', 'partial', 'failed'),
    error_message TEXT,
    
    -- Retention & Compliance
    retention_days INT DEFAULT 365,  -- 365 (1 year) by default, configurable per restaurant
    can_be_deleted_at TIMESTAMP,  -- Auto-calculated for compliance
    
    -- Timestamp
    created_at TIMESTAMP DEFAULT NOW(),
    
    CONSTRAINT audit_log_retention_valid
        CHECK (retention_days >= 30 AND retention_days <= 2555)  -- Min 30 days, max 7 years
);

CREATE INDEX idx_sync_audit_log_restaurant_id ON sync_audit_logs(restaurant_id, created_at DESC);
CREATE INDEX idx_sync_audit_log_event_type ON sync_audit_logs(event_type, created_at DESC);
CREATE INDEX idx_sync_audit_log_can_be_deleted ON sync_audit_logs(can_be_deleted_at) WHERE can_be_deleted_at IS NOT NULL;
CREATE INDEX idx_sync_audit_log_sync_job_id ON sync_audit_logs(sync_job_id);
```

**Validation Rules**:
- `retention_days`: 30-2555 (30 days to 7 years)
- `can_be_deleted_at`: Auto-calculated as created_at + (retention_days days)
- `event_type`: Predefined enumeration
- `event_details`: JSON structure varies by event type

**Event Detail Examples**:
```json
// sync_started
{
  "trigger_type": "webhook",
  "estimated_item_count": 150
}

// conflict_detected
{
  "item_id": "uuid",
  "item_name": "Burger",
  "field": "price",
  "pos_value": 11.00,
  "parcera_value": 10.00,
  "strategy": "pos_wins"
}

// api_call_failed
{
  "api": "toast",
  "endpoint": "GET /api/v1/menus",
  "status_code": 429,
  "retry_after": 60
}
```

---

## Multi-Tenant Data Isolation

All entities include `tenant_id` for row-level security (RLS).

**PostgreSQL RLS Policy** (example):

```sql
CREATE POLICY sync_job_isolation ON sync_jobs
    USING (tenant_id = current_setting('app.current_tenant_id')::uuid);

ALTER TABLE sync_jobs ENABLE ROW LEVEL SECURITY;
```

**Application Responsibility**:
- Set `current_setting('app.current_tenant_id')` in each request
- Validate tenant_id matches authenticated user's tenant
- Never query without WHERE tenant_id = $1

---

## Cascade & Referential Integrity

| Parent | Child | Delete Behavior |
|--------|-------|-----------------|
| POSConnection | SyncJob | CASCADE |
| SyncJob | SyncChangeRecord | CASCADE |
| SyncJob | ConflictRecord | CASCADE |
| SyncJob | ManualReviewQueue | CASCADE (via sync_change_record) |

**Rationale**: Deleting POS connection → archive all related sync history (via CASCADE) for clean removal.

---

## JSON Fields Strategy

**Fields Using JSONB**:
- `conflict_records.parcera_version` - Full menu item state
- `conflict_records.pos_version` - Full menu item state
- `manual_review_queue.pos_version_data` - For UI comparison
- `manual_review_queue.parcera_version_data` - For UI comparison
- `sync_audit_logs.event_details` - Flexible event metadata

**Storage Rationale**: Menu item structures vary by POS platform; JSONB allows flexibility without schema migration.

**Example JSONB Structure** (menu item):
```json
{
  "name": "Burger",
  "price": 10.99,
  "description": "1/3 lb beef patty",
  "category": "Entrees",
  "availability": "available",
  "modifiers": [
    {
      "id": "mod-1",
      "name": "Toppings",
      "options": [
        { "name": "Bacon", "price_add": 0.50 },
        { "name": "Cheese", "price_add": 0.25 }
      ]
    }
  ],
  "external_ids": {
    "toast_id": "item-12345",
    "pos_timestamp": "2025-11-04T14:30:00Z"
  }
}
```

---

## Change Detection Algorithm

**Input**: Old JSONB (Parcera), New JSONB (POS)  
**Output**: List of SyncChangeRecord

```python
def detect_changes(old_item, new_item, ai_detector):
    changes = []
    
    # Field-by-field comparison
    COMPARABLE_FIELDS = ['name', 'price', 'description', 'category', 'availability']
    for field in COMPARABLE_FIELDS:
        old_val = old_item.get(field)
        new_val = new_item.get(field)
        
        if old_val != new_val:
            if field == 'name':
                # Use AI semantic similarity
                confidence = ai_detector.name_similarity(old_val, new_val)
                change_type = 'name_changed' if confidence > 85 else 'ambiguous_rename'
            elif field == 'price':
                # Exact match, 100% confidence
                confidence = 100
                change_type = 'price_changed'
            else:
                # Other simple fields
                confidence = 100
                change_type = f'{field}_changed'
            
            changes.append(SyncChangeRecord(
                change_type=change_type,
                field_changed=field,
                old_value=old_val,
                new_value=new_val,
                ai_confidence_score=confidence
            ))
    
    # Modifier comparison (complex structure)
    old_mods = old_item.get('modifiers', [])
    new_mods = new_item.get('modifiers', [])
    if old_mods != new_mods:
        confidence = ai_detector.modifier_similarity(old_mods, new_mods)
        changes.append(SyncChangeRecord(
            change_type='modifier_changed',
            old_value=json.dumps(old_mods),
            new_value=json.dumps(new_mods),
            ai_confidence_score=confidence
        ))
    
    return changes
```

---

## Summary

**Entity Count**: 6 core tables  
**Relationships**: 1-to-Many across all entities  
**Multi-Tenancy**: Row-level security via tenant_id + RLS policies  
**Compliance**: Audit logging with configurable retention (30 days - 7 years)  
**Scalability**: Indexed on frequently queried fields; JSONB for flexible menu structures  

---

**Version**: 1.0.0 | **Completed**: 2025-11-04 | **Next**: contracts/*.yaml
