# Implementation Plan: POS Menu Synchronization

**Branch**: `028-pos-menu-sync` | **Date**: 2025-11-04 | **Spec**: [spec.md](spec.md)
**Input**: Feature specification from `/specs/028-pos-menu-sync/spec.md`

## Summary

POS Menu Sync enables bidirectional menu synchronization between Parcera and incumbent POS systems (Toast, Square, Clover, etc.) using AI-powered diff detection. The system monitors POS menu changes in real-time (via webhooks) or periodically (via polling), detects modifications with AI confidence scoring, auto-applies high-confidence changes (≥90%), flags ambiguous changes for manual review, and supports reverse sync (Parcera→POS) when write APIs available. MVP focuses on Toast + Square integration with AI-driven change detection, conflict resolution strategies, and comprehensive audit logging.

## Technical Context

**Language/Version**: Python 3.11+ (FastAPI backend recommended per constitution)

**Primary Dependencies**: 
- FastAPI + Pydantic for API/validation
- SQLAlchemy + PostgreSQL for data persistence
- Celery + Redis for async sync jobs
- OpenAI API for semantic similarity & change categorization (AI diff detection)
- Toast/Square SDK libraries for POS platform integration
- APScheduler for scheduled polling

**Storage**: PostgreSQL 14+ with row-level security (multi-tenant design)

**Testing**: pytest + pytest-asyncio for async endpoints, mock libraries for POS API mocking

**Target Platform**: Linux server (Docker-deployed)

**Project Type**: Single backend service with API contracts

**Performance Goals**:
- Webhook-triggered syncs: <10 seconds (webhook receipt → menu update)
- Polling syncs (≤500 items): <2 minutes
- AI confidence scoring: <5 seconds per change batch
- Propagation to ordering channels: <30 seconds

**Constraints**:
- <200ms p95 for sync API endpoints
- Support menus up to 1000 items
- Handle POS API rate limits + downtime gracefully
- Zero data loss on conflicts (preserve both versions until resolution)
- Multi-tenant isolation via row-level security

**Scale/Scope**: 
- MVP: 10-50 restaurants, ~500 items/restaurant avg
- Phase 2: 500+ restaurants, 1000+ items/restaurant possible

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Status | Justification |
|-----------|--------|---------------|
| **I. AI-First Architecture** | ✅ PASS | AI-powered diff detection + semantic matching for change categorization is core to feature |
| **II. Multi-Tenancy by Design** | ✅ PASS | Row-level security on POSConnection, SyncJob, SyncChangeRecord, ManualReviewQueue, ConflictRecord |
| **III. Privacy-First Customer Data** | ✅ PASS | Sync focuses on menu data only; no customer PII involved |
| **IV. Omnichannel by Default** | ✅ PASS | Synced menu changes propagate to all ordering channels (IVR, Kiosk, Mobile) within 30s |
| **V. Progressive Enhancement & MVP Discipline** | ✅ PASS | P0 = POS→Parcera auto-sync; P1 = Reverse sync + Multi-POS; P2 = History dashboard |
| **VI. Network Effects & Platform Thinking** | ✅ PASS | Aggregated menu change patterns enable future cost optimization insights |
| **VII. Integration-Friendly Architecture** | ✅ PASS | Platform adapters for Toast, Square, Clover; respects POS data models + APIs |

**Pre-Phase 0 Gates**: All PASS. No blocking violations detected.

---

## Project Structure

### Documentation (this feature)

```text
specs/028-pos-menu-sync/
├── spec.md                   # Feature specification (COMPLETED)
├── plan.md                   # This file (IN PROGRESS)
├── research.md               # Phase 0 output (PENDING)
├── data-model.md             # Phase 1 output (PENDING)
├── quickstart.md             # Phase 1 output (PENDING)
├── contracts/                # Phase 1 output (PENDING)
│   ├── webhook-payload.yaml  # Toast webhook schema (DRAFT)
│   ├── pos-connection-api.yaml
│   ├── sync-job-api.yaml
│   ├── manual-review-api.yaml
│   └── sync-history-api.yaml
└── tasks.md                  # Phase 2 output (/speckit.tasks command)
```

### Source Code (repository root)

```text
# Single backend service model
src/
├── models/
│   ├── pos_connection.py       # POSConnection entity + queries
│   ├── sync_job.py             # SyncJob + SyncChangeRecord
│   ├── conflict_record.py       # ConflictRecord + resolution logic
│   ├── manual_review_queue.py   # ManualReviewQueue + approval workflow
│   └── sync_audit_log.py        # SyncAuditLog for compliance
│
├── services/
│   ├── pos_adapters/           # Platform-specific integrations
│   │   ├── base_adapter.py      # Abstract POS adapter interface
│   │   ├── toast_adapter.py     # Toast Menu API + webhooks
│   │   ├── square_adapter.py    # Square Catalog API + polling
│   │   └── clover_adapter.py    # Clover REST API
│   │
│   ├── sync_engine.py          # Orchestrates POS→Parcera sync
│   ├── reverse_sync_engine.py  # Orchestrates Parcera→POS sync
│   ├── ai_diff_detector.py     # AI-powered change categorization + confidence scoring
│   ├── conflict_resolver.py    # Applies conflict resolution strategies
│   ├── audit_logger.py         # Logs all sync events
│   └── webhook_handler.py      # Webhook signature validation + receipt
│
├── api/
│   ├── pos_connections.py      # POST/GET /pos-connections (connect/disconnect)
│   ├── sync_jobs.py            # GET /sync-jobs, POST /sync-jobs/{id}/retry
│   ├── manual_reviews.py       # GET /manual-reviews, POST /manual-reviews/{id}/approve
│   ├── sync_history.py         # GET /sync-history (with filters, export)
│   └── webhooks.py             # POST /webhooks/pos (Toast, Square, Clover)
│
└── cli/
    └── admin_commands.py       # Testing: manual sync triggers, data reset

tests/
├── unit/
│   ├── test_ai_diff_detector.py        # AI confidence scoring logic
│   ├── test_conflict_resolver.py       # Conflict resolution strategies
│   └── test_sync_audit_log.py          # Audit logging correctness
│
├── integration/
│   ├── test_pos_adapters.py            # Mock POS API responses
│   ├── test_sync_engine.py             # End-to-end inbound sync flow
│   ├── test_reverse_sync_engine.py     # End-to-end outbound sync flow
│   └── test_webhook_handler.py         # Webhook validation + processing
│
└── contract/
    ├── test_webhook_contract.yaml      # Toast webhook payload validation
    ├── test_pos_api_contracts.yaml     # POS adapter API responses
    └── test_manual_review_contract.yaml# Manual review payload structure
```

**Structure Decision**: Single backend service model. POS Menu Sync is a sub-service of the Parcera platform (sits alongside Order Management, KDS, Payment services). Embedded within main FastAPI app with dedicated database tables and Celery tasks. No separate microservice needed at MVP scale.

---

## Phase 0: Research & Clarification

### Research Tasks (TO COMPLETE)

1. **AI Diff Detection Best Practices**
   - Task: Find optimal semantic similarity thresholds (87%? 92%?) for change categorization
   - Task: Evaluate OpenAI API costs vs custom ML models for confidence scoring
   - Task: Research change detection patterns for menu-specific data (prices, modifiers, availability)

2. **POS Platform Integration Patterns**
   - Task: Document Toast webhook authentication (API keys, signatures, retries)
   - Task: Document Square OAuth flow + Catalog API rate limits
   - Task: Research Clover REST API authentication + field mappings
   - Task: Compare webhook vs polling performance trade-offs

3. **Conflict Resolution Strategies**
   - Task: Find best practices for timestamp-based conflict detection (what's "simultaneous"?)
   - Task: Research data reconciliation patterns for menu sync across platforms
   - Task: Document POS API constraints affecting reverse sync (rate limits, field sizes)

4. **Audit & Compliance**
   - Task: Research 12-month retention requirements for SaaS platforms
   - Task: Document CSV export format for regulatory compliance

### Phase 0 Output: research.md

Will consolidate findings on:
- AI confidence scoring algorithm + threshold tuning
- Toast/Square/Clover integration documentation
- Conflict resolution algorithm + edge cases
- Compliance + audit logging patterns

**Gate for Phase 1**: research.md complete with no "NEEDS CLARIFICATION" remaining.

---

## Phase 1: Design & Contracts

### 1. Data Model (data-model.md) - TO COMPLETE

Extract from spec Section "Key Entities":

- **POSConnection**: restaurant ↔ POS mapping, auth credentials, sync config
- **SyncJob**: individual sync operation (POS→Parcera or Parcera→POS)
- **SyncChangeRecord**: detail of single menu change (new item, price update, etc.)
- **ConflictRecord**: tracks simultaneous edits requiring resolution
- **ManualReviewQueue**: flags ambiguous changes for owner approval
- **SyncAuditLog**: compliance log of all sync events

Include:
- Entity relationships (foreign keys)
- Validation rules from FR-* requirements
- State transitions (SyncJob: queued → running → completed/failed)
- Multi-tenant scoping (all rows scoped to restaurant_id)

### 2. API Contracts (contracts/*.yaml) - TO COMPLETE

**RESTful endpoints** from functional requirements:

```text
contracts/
├── webhook-payload.yaml
│   POST /webhooks/pos/toast - Toast fires menu change event
│   POST /webhooks/pos/square - Square fires menu change event
│
├── pos-connection-api.yaml
│   POST /pos-connections - Connect to POS (start OAuth/API key entry)
│   GET /pos-connections - List all connections for restaurant
│   DELETE /pos-connections/{id} - Disconnect POS
│   GET /pos-connections/{id}/test - Test connection health
│
├── sync-job-api.yaml
│   GET /sync-jobs - List recent syncs (paginated, filterable)
│   POST /sync-jobs/{id}/retry - Manual retry of failed sync
│   GET /sync-jobs/{id} - Detail view of sync (all changes, timestamps)
│
├── manual-review-api.yaml
│   GET /manual-reviews - Queue of pending changes
│   POST /manual-reviews/{id}/approve - Owner approves AI suggestion
│   POST /manual-reviews/{id}/reject - Owner rejects change
│   POST /manual-reviews/{id}/modify - Owner overrides AI suggestion
│
└── sync-history-api.yaml
    GET /sync-history - Chronological log with filters (date, type, direction, status)
    GET /sync-history/export.csv - Export for compliance
```

Include:
- Request/response schemas (Pydantic models)
- Error codes + messages (e.g., "Invalid Toast API key", "Conflict detected")
- Rate limit guidance
- Pagination for large result sets

### 3. Quickstart (quickstart.md) - TO COMPLETE

End-to-end walkthrough:
1. Restaurant owner connects to Toast via OAuth
2. System imports initial menu (5-10 items)
3. Owner makes change in Toast (price update)
4. System detects change via webhook within 5 seconds
5. AI analyzes confidence (95% → auto-apply)
6. Owner sees updated menu in Parcera
7. Owner checks Sync History Dashboard for audit trail

### 4. Update Agent Context - TO COMPLETE

Run `.specify/scripts/bash/update-agent-context.sh claude` to update agent knowledge base with:
- FastAPI + Celery async patterns for sync jobs
- SQLAlchemy multi-tenant row-level security
- OpenAI API integration for AI diff detection
- Toast/Square/Clover API patterns + error handling

---

## Complexity Tracking

> No violations detected in Constitution Check. All principles aligned.

---

## Next Steps

**Immediate (Phase 0 - Research)**:
1. ✓ Constitution Check: PASS
2. Execute Phase 0 research tasks (AI diff detection, POS APIs, conflict resolution)
3. Generate research.md with findings

**Phase 1 (Design)**:
1. Generate data-model.md with entity definitions
2. Generate contracts/*.yaml with REST API schemas
3. Generate quickstart.md with end-to-end walkthrough
4. Run update-agent-context.sh to sync AI knowledge base

**Phase 2 (Implementation - /speckit.tasks)**:
1. Generate tasks.md with dependency-ordered work items
2. Begin implementation based on task priority

---

**Version**: 1.0.0 (DRAFT) | **Created**: 2025-11-04 | **Status**: Phase 0 In Progress
