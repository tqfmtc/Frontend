# Quickstart: POS Menu Sync

**Phase**: 1 (Design & Contracts)  
**Date**: 2025-11-04

---

## End-to-End Workflow

This quickstart demonstrates the core POS Menu Sync flow using Toast as the example POS platform.

### Step 1: Restaurant Owner Connects Toast POS

**User Action**: Restaurant owner navigates to Parcera Business Dashboard → Settings → Integrations

**Owner clicks**: "Connect POS System"

```json
POST /v1/pos-connections
{
  "pos_platform": "toast"
}

Response 200:
{
  "connection_id": "conn-uuid-12345",
  "oauth_url": "https://toast.com/oauth/authorize?client_id=...",
  "status": "pending",
  "next_step": "Click the link above to authorize Parcera access to your Toast menu"
}
```

**Owner is redirected to Toast OAuth login**, authorizes Parcera, returns with OAuth token

**Parcera system**: 
- Stores encrypted OAuth token
- Calls `GET /api/v1/menus` on Toast to fetch initial menu
- Imports 50 items into Parcera menu (stored in `menu_items` table)
- Registers webhook: `POST /api/v1/webhooks` → `https://api.parcera.com/v1/webhooks/pos/toast`

**Owner sees**: "Toast connected! Sync enabled (real-time)"

---

### Step 2: Owner Updates Menu in Toast

**2:00:00 PM** - Owner logs into Toast POS, makes 3 changes:

1. **New Item**: Adds "Buffalo Wings" - $12.99, Appetizers category
2. **Price Update**: Changes "Burger" price from $10.00 to $11.00
3. **Availability**: Marks "Fish Tacos" as "Sold Out" (unavailable)

---

### Step 3: Webhook Triggers Sync (Real-Time)

**2:00:01 PM** - Toast fires webhook to Parcera:

```json
POST /v1/webhooks/pos/toast
X-Toast-Signature: <HMAC-SHA256 signature>

{
  "event_type": "menu.item.updated",
  "timestamp": "2025-11-04T14:00:01Z",
  "items": [
    {
      "id": "toast-item-001",
      "name": "Buffalo Wings",
      "price": 1299,  // cents
      "category": "Appetizers",
      "availability": "available",
      "modifiers": []
    },
    {
      "id": "toast-item-002",
      "name": "Burger",
      "price": 1100,  // changed from 1000
      "availability": "available"
    },
    {
      "id": "toast-item-003",
      "name": "Fish Tacos",
      "availability": "unavailable"  // changed
    }
  ]
}
```

**Parcera receives webhook**:
1. Validates HMAC-SHA256 signature ✓
2. Creates SyncJob record (status: queued, direction: inbound, trigger_type: webhook)
3. Queues Celery task for processing

---

### Step 4: AI Diff Detection (5-8 seconds)

**2:00:06 PM** - Celery task executes:

**Task**: `sync_engine.process_inbound_sync(sync_job_id)`

1. **Fetch current Parcera menu state** for comparison
2. **Detect changes** using AI diff detector:

```
Change 1: Buffalo Wings
- Type: new_item_added
- Confidence: 95% (new name, price, all fields present)
- Resolution: AUTO-APPLY (≥90%)

Change 2: Burger price $10→$11
- Type: price_changed
- Confidence: 100% (exact numeric match)
- Resolution: AUTO-APPLY

Change 3: Fish Tacos availability
- Type: availability_changed
- Confidence: 100% (explicit status field)
- Resolution: AUTO-APPLY
```

3. **Insert SyncChangeRecord** rows for each change

---

### Step 5: Apply Changes to Parcera Menu

**2:00:07 PM** - Apply auto-approved changes:

```sql
-- Insert new item
INSERT INTO menu_items (restaurant_id, name, price, category, ...)
VALUES (rest-uuid, 'Buffalo Wings', 12.99, 'Appetizers', ...);

-- Update price
UPDATE menu_items SET price = 11.00 
WHERE restaurant_id = rest-uuid AND name = 'Burger';

-- Mark unavailable
UPDATE menu_items SET availability = 'unavailable'
WHERE restaurant_id = rest-uuid AND name = 'Fish Tacos';

-- Log audit trail
INSERT INTO sync_audit_logs (event_type, event_details, ...)
VALUES ('change_applied', {item_name: 'Buffalo Wings', ...}, ...);
```

---

### Step 6: Propagate to All Ordering Channels

**2:00:30 PM** - Within 30 seconds, menu changes propagate:

**IVR Channel**: 
- "Welcome to Joe's Pizza! Say 'Buffalo Wings' to order our new appetizer..."

**Kiosk Channel**:
- Burger price updates from $10 to $11
- Fish Tacos grayed out with "Currently Unavailable"

**Mobile App**:
- Push notification: "1 new item added to menu: Buffalo Wings"
- Menu UI refreshes showing updated prices and availability

---

### Step 7: Owner Reviews Sync History

**2:01:00 PM** - Owner opens Parcera Dashboard → Sync History

**API Call**:
```json
GET /v1/sync-history?limit=10&direction=inbound

Response 200:
{
  "sync_events": [
    {
      "timestamp": "2025-11-04T14:00:06Z",
      "direction": "POS→Parcera",
      "summary": "3 changes from Toast: 1 item added, 1 price updated, 1 availability changed",
      "status": "Success",
      "details": [
        {
          "item": "Buffalo Wings",
          "change_type": "New Item Added",
          "old_value": null,
          "new_value": {price: 12.99, category: "Appetizers"},
          "ai_confidence": "95%",
          "applied_at": "2025-11-04T14:00:07Z"
        },
        {
          "item": "Burger",
          "change_type": "Price Updated",
          "old_value": 10.00,
          "new_value": 11.00,
          "ai_confidence": "100%",
          "applied_at": "2025-11-04T14:00:07Z"
        },
        {
          "item": "Fish Tacos",
          "change_type": "Availability Changed",
          "old_value": "available",
          "new_value": "unavailable",
          "ai_confidence": "100%",
          "applied_at": "2025-11-04T14:00:07Z"
        }
      ]
    }
  ]
}
```

Owner sees: "All changes synced automatically. Confidence scores all ≥90%."

---

## Scenario 2: Ambiguous Change (Manual Review)

**User Action**: Owner in Toast renames "Caesar Salad" → "Classic Caesar Salad"

**AI Analysis** (confidence: 87%):
- Name similarity: 87% (not quite certain if rename or new item)
- Price/modifiers/category: unchanged
- Decision: **FLAG FOR MANUAL REVIEW** (<90% threshold)

**API Response**:
```json
GET /v1/manual-reviews

{
  "pending_reviews": [
    {
      "id": "review-uuid",
      "sync_job_id": "job-uuid",
      "item_name": "Caesar Salad",
      "change_summary": "Item name changed: 'Caesar Salad' → 'Classic Caesar Salad'",
      "ai_confidence": 87,
      "ai_reasoning": "Name similarity 87% - could be rename or new item with similar name",
      "pos_version": {name: "Classic Caesar Salad", price: 14.99},
      "parcera_version": {name: "Caesar Salad", price: 14.99},
      "suggested_action": "rename_existing",
      "expires_at": "2025-11-11T14:00:00Z"
    }
  ]
}
```

**Owner Action**: Clicks "Rename existing item" in dashboard

```json
POST /v1/manual-reviews/review-uuid/approve
{
  "action": "approved",
  "notes": "This is a menu refresh - same item, just updated name"
}
```

**System Response**:
1. Updates menu_item name from "Caesar Salad" → "Classic Caesar Salad"
2. Creates SyncChangeRecord with resolution_method = "manual_approved"
3. Propagates to all channels
4. Audit log: "Manual review approved by owner@rest.com"

---

## Scenario 3: Conflict Detection (POS vs Parcera)

**Setup**: 
- Same owner updates Burger price in BOTH systems before sync cycle completes
- Toast: Changes price $10 → $11 at 2:00 PM
- Parcera: Owner changes price $10 → $10.50 at 2:01 PM (via Business Dashboard)

**2:15 PM** - Scheduled sync runs:

**Conflict Detection**:
```
Burger item:
- POS version: price $11 (modified 2:00 PM)
- Parcera version: price $10.50 (modified 2:01 PM)
- Last sync: 1:45 PM
- Status: CONFLICT DETECTED

Configured resolution: "POS Wins" (default)
```

**System Response**:
1. Creates ConflictRecord (stores both versions)
2. Applies "POS Wins" strategy: Parcera price reverts to $11
3. Logs conflict: "Conflict on Burger: POS version ($11) applied over Parcera version ($10.50)"
4. Notifies owner: "Menu conflict resolved - Burger price set to $11 (POS version)"
5. Audit log records conflict + resolution method

**Owner can override** via manual review if needed (set strategy to "Manual Review")

---

## Summary

| Step | Duration | Actor | System Action |
|------|----------|-------|---------------|
| 1 | - | Owner | Connects Toast via OAuth |
| 2 | - | Owner | Makes menu changes in Toast (3 items) |
| 3 | 1 sec | Toast | Fires webhook to Parcera |
| 4 | 5-8 sec | Parcera | AI detects 3 changes, scores confidence |
| 5 | 1 sec | Parcera | Applies auto-approved changes to DB |
| 6 | 30 sec | Parcera | Propagates changes to IVR/Kiosk/Mobile |
| 7 | - | Owner | Views sync history dashboard |

**Total Time to Live Menu Update**: ~30 seconds  
**Owner Effort**: 0 (fully automated)  
**Confidence in Changes**: 95-100% (all auto-applied)

---

## Related Documentation

- `plan.md` - Implementation plan, project structure
- `research.md` - AI diff detection, POS integration patterns
- `data-model.md` - Database schema, entity relationships
- `contracts/pos-connection-api.yaml` - POS connection endpoints
- `contracts/sync-job-api.yaml` - Sync job tracking endpoints

---

**Version**: 1.0.0 | **Completed**: 2025-11-04 | **Next**: /speckit.tasks (implementation tasks)
