# Quickstart: Mobile App Ordering Development

**Phase**: 1 Ready | **Date**: 2025-11-04 | **Status**: Development Ready

## Prerequisites

- Node.js 18+
- Python 3.11+ (for backend)
- Xcode 14+ (for iOS development)
- Android Studio (for Android development)
- Git + GitHub access
- Parcera Platform API credentials (from Feature 008)

## Project Setup

### 1. Clone Repository

```bash
git clone https://github.com/parcera/platform.git
cd platform

# Create feature branch
git checkout -b 005-mobile-app-ordering
```

### 2. Install Dependencies

#### Backend (FastAPI)

```bash
cd backend
python -m venv venv
source venv/bin/activate  # or: venv\Scripts\activate on Windows
pip install -r requirements.txt
```

**Key Dependencies**:
- `fastapi` - Web framework
- `sqlalchemy` - ORM for database models
- `psycopg2-binary` - PostgreSQL adapter
- `pydantic` - Data validation
- `python-jose[cryptography]` - JWT authentication
- `requests` - HTTP client for Olivia.io and POS APIs

#### Mobile App (React Native)

```bash
cd apps/mobile-app

# Install dependencies
npm install
# or
yarn install

# Install CocoaPods (iOS dependencies)
cd ios
pod install
cd ..
```

**Key Dependencies** (in package.json):
- `react-native` - Mobile framework
- `expo` - Managed React Native
- `react-navigation` - Navigation
- `react-native-gesture-handler` - Touch handling
- `react-native-reanimated` - Animations
- `redux` - State management
- `react-native-firebase` - Push notifications
- `react-native-stripe-sdk` or equivalent for payments

#### Web App (React)

```bash
cd apps/web-app

npm install
# or
yarn install
```

**Key Dependencies**:
- `react` 18+
- `react-router-dom` - Routing
- `axios` - HTTP client
- `zustand` or `redux` - State management
- `tailwindcss` or `material-ui` - UI components

### 3. Environment Setup

#### Backend (.env)

```plaintext
DATABASE_URL=postgresql://user:password@localhost:5432/parcera_mobile
OLIVIA_IO_API_KEY=your_api_key_here
OLIVIA_IO_API_URL=https://api.olivia.io/v1
PAYMENT_GATEWAY=authorize_net
AUTHORIZE_NET_LOGIN_ID=your_login_id
AUTHORIZE_NET_TRANSACTION_KEY=your_transaction_key
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRATION_HOURS=24
FIREBASE_PROJECT_ID=your_firebase_project
FIREBASE_PRIVATE_KEY=your_firebase_key
FIREBASE_CLIENT_EMAIL=your_firebase_email
```

#### Mobile App (.env or app.json)

```json
{
  "expo": {
    "name": "Parcera Mobile",
    "slug": "parcera-mobile",
    "version": "0.1.0",
    "extra": {
      "apiUrl": "https://api.parcera.io/v1",
      "oliviaIoApiKey": "your_key_here",
      "firebaseConfig": {
        "apiKey": "YOUR_API_KEY",
        "authDomain": "YOUR_AUTH_DOMAIN",
        "projectId": "YOUR_PROJECT_ID",
        "messagingSenderId": "YOUR_MESSAGING_SENDER_ID",
        "appId": "YOUR_APP_ID"
      }
    }
  }
}
```

### 4. Database Setup

```bash
# Create PostgreSQL database
createdb parcera_mobile

# Run migrations
cd backend
alembic upgrade head

# Seed test data (restaurants, menus)
python scripts/seed_test_data.py
```

**Migration Script** (alembic):
```bash
# Create new migration
alembic revision --autogenerate -m "Add customer_wallets table"

# Apply migrations
alembic upgrade head
```

## Local Development

### Backend Server

```bash
cd backend

# Install development dependencies
pip install -r requirements-dev.txt

# Run with auto-reload
uvicorn src.main:app --reload --host 0.0.0.0 --port 8000
```

API will be available at http://localhost:8000
Swagger docs at http://localhost:8000/docs

### Mobile App (iOS)

```bash
cd apps/mobile-app

# Run iOS simulator
npx react-native run-ios

# or with Expo
expo start --ios
```

### Mobile App (Android)

```bash
cd apps/mobile-app

# Run Android emulator (must be running first)
npx react-native run-android

# or with Expo
expo start --android
```

### Web App

```bash
cd apps/web-app

# Development server
npm start

# or
yarn start
```

Web app will be available at http://localhost:3000

## Testing

### Backend Tests

```bash
cd backend

# Run all tests
pytest

# Run specific test file
pytest tests/test_wallets.py

# Run with coverage
pytest --cov=src tests/
```

**Test Structure**:
```
backend/tests/
├── unit/
│   ├── test_models.py
│   ├── test_services.py
│   └── test_validators.py
├── integration/
│   ├── test_wallet_api.py
│   ├── test_ordering_api.py
│   └── test_payment_processing.py
└── contract/
    ├── test_wallet_api_contract.py
    └── test_ordering_api_contract.py
```

### Mobile Tests

```bash
cd apps/mobile-app

# Jest tests
npm test

# Run specific test
npm test -- OrderScreen.test.js

# Watch mode
npm test -- --watch
```

### Web Tests

```bash
cd apps/web-app

npm test

# E2E tests (Cypress)
npm run cypress:open
```

## Key API Endpoints to Test

### Wallet API

```bash
# Create wallet
curl -X POST http://localhost:8000/v1/wallets \
  -H "Content-Type: application/json" \
  -d '{"phone_number": "+14155552671"}'

# Verify phone
curl -X POST http://localhost:8000/v1/wallets/{wallet_id}/verify \
  -H "Content-Type: application/json" \
  -d '{"verification_code": "123456"}'

# Get wallet
curl -X GET http://localhost:8000/v1/wallets/me \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Ordering API

```bash
# Search restaurants
curl "http://localhost:8000/v1/restaurants?latitude=37.7749&longitude=-122.4194&radius_miles=5"

# Get menu
curl http://localhost:8000/v1/restaurants/{restaurant_id}/menu

# Create order
curl -X POST http://localhost:8000/v1/orders \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "restaurant_id": "...",
    "order_type": "pickup",
    "items": [
      {"menu_item_id": "...", "quantity": 1, "modifiers": {}}
    ],
    "payment_method_id": "...",
    "pickup_time": "2025-11-04T14:30:00Z"
  }'
```

## Key Files to Review

### Backend

- `backend/src/models/wallets.py` - CustomerWallet ORM model
- `backend/src/models/orders.py` - MobileOrder ORM model
- `backend/src/api/wallets.py` - Wallet endpoints
- `backend/src/api/ordering.py` - Ordering endpoints
- `backend/src/services/olivia.py` - Olivia.io integration
- `backend/src/services/payment.py` - Payment processing
- `backend/src/db/migrations/` - Database migrations

### Mobile App

- `apps/mobile-app/src/screens/RestaurantSearchScreen.js` - Restaurant discovery
- `apps/mobile-app/src/screens/MenuScreen.js` - Menu browsing
- `apps/mobile-app/src/screens/VoiceOrderingScreen.js` - Voice interface
- `apps/mobile-app/src/screens/CartScreen.js` - Cart management
- `apps/mobile-app/src/screens/CheckoutScreen.js` - Payment & order submission
- `apps/mobile-app/src/services/olivia.js` - Olivia.io client
- `apps/mobile-app/src/state/slices/` - Redux slices (cart, orders, wallet)

### Web App

- `apps/web-app/src/pages/HomePage.js` - Restaurant search & discovery
- `apps/web-app/src/pages/MenuPage.js` - Menu browsing
- `apps/web-app/src/pages/CheckoutPage.js` - Checkout flow
- `apps/web-app/src/components/` - Reusable components
- `apps/web-app/src/services/api.js` - API client

## Architecture Decisions

### 1. Monorepo Structure

All three apps (mobile, web, backend) in single repo under `apps/` directory. Enables:
- Coordinated releases
- Shared API contracts
- Unified dependency management

### 2. State Management

**Mobile**: Redux for cart, orders, wallet state
**Web**: Zustand for lighter state management
**Backend**: SQLAlchemy ORM for database state

### 3. Authentication

JWT-based with refresh tokens. Wallet creation via phone verification (OTP), no password required.

### 4. Data Privacy

All customer data (phone, email, addresses, payments) owned by Parcera. Restaurants access only order details and aggregated metrics.

### 5. Real-Time Updates

- Order status polling every 30 seconds
- Push notifications via Firebase Cloud Messaging
- WebSocket support (future P1 enhancement)

## Debugging Tips

### Backend

- Enable debug logging: `LOG_LEVEL=DEBUG`
- Check database state: `psql -U user -d parcera_mobile`
- Inspect JWT tokens: jwt.io
- Test POS APIs with Postman collection (in `/docs/postman/`)

### Mobile

- React Native Inspector: `Cmd+D` (iOS) or `Cmd+M` (Android)
- Xcode Console for iOS logs
- Android Studio Logcat for Android logs
- Redux DevTools extension for state debugging

### Web

- Browser DevTools (F12)
- React DevTools extension
- Redux DevTools extension
- Network tab for API debugging

## Next Steps After Setup

1. Implement Wallet API endpoints (Phase 1)
2. Implement Ordering API endpoints (Phase 1)
3. Build mobile UI for restaurant search (Phase 2)
4. Integrate Olivia.io voice AI (Phase 2)
5. Implement payment processing (Phase 2)
6. Add push notifications (Phase 2)
7. Implement voice-to-text handoff (Phase 3)

## Support & Documentation

- **API Docs**: http://localhost:8000/docs (Swagger)
- **Contributing**: See `CONTRIBUTING.md`
- **Architecture**: See `data-model.md` and `research.md`
- **API Contracts**: See `contracts/` directory

## Troubleshooting

### Database Connection Failed

```bash
# Check PostgreSQL is running
psql --version

# Create database if missing
createdb parcera_mobile

# Check credentials in .env
```

### Node Modules Issues

```bash
# Clear node_modules and reinstall
rm -rf node_modules
npm install

# or for Expo
rm -rf node_modules
npx expo start --clear
```

### React Native Build Issues

```bash
# Clear build cache (iOS)
cd ios && xcodebuild clean && cd ..

# Clear build cache (Android)
cd android && ./gradlew clean && cd ..

# Rebuild
npx react-native run-ios
npx react-native run-android
```

## Performance Targets

- App launch <2 seconds
- Menu load <1 second (cached)
- Order submission <5 seconds
- Voice response 800ms-1.5s
- Push notification delivery <30 seconds
