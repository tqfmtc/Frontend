# Research & Analysis: Mobile App Ordering

**Phase**: 0 Research | **Date**: 2025-11-04 | **Status**: Complete

## Executive Summary

Mobile/web app ordering is a P0 MVP feature enabling iOS/Android customers and web users to place orders via voice (Olivia.io), text chat, or visual menu browsing. Shares architecture with IVR/kiosk channels (Feature 001-004) and leverages existing POS integration patterns (Feature 007). Privacy-first wallet model (Feature 008) differentiates from competitors.

**Tech Stack Decision:**
- **Mobile**: React Native (cross-platform MVP)
- **Web**: React 18+
- **Backend**: FastAPI (Python 3.11+)
- **Database**: PostgreSQL 14+ with RLS
- **Integrations**: Olivia.io, Toast/Square/Clover POS APIs, payment gateway

## Technology Research

### 1. Cross-Platform Mobile Framework Analysis

**Evaluated Options:**
- React Native (chosen)
- Flutter
- Native iOS/Android
- Kotlin Multiplatform Mobile (KMM)

**Decision**: React Native (React Native)
- **Rationale**: Single codebase reduces MVP timeline by 30-40%, 80-90% code reuse between iOS/Android
- **Trade-off**: Slightly reduced native performance vs massive time savings for MVP
- **Success Metric**: iOS 14+ (95% coverage), Android 8.0+ API 26 (90% coverage)

**Key Libraries**:
- `react-native` (v0.73.x) - Core framework
- `expo` (v50.x) - Rapid development, managed updates, OTA capabilities
- `react-navigation` (v6.x) - Cross-platform routing
- `react-native-gesture-handler` - Touch interactions
- `react-native-reanimated` - Smooth animations for voice UI
- `react-native-sound` - Audio playback/recording for Olivia.io

### 2. Voice AI Integration: Olivia.io

**Current State**:
- Olivia.io provides proven 800ms-1.5s latency for voice ordering
- IVR/kiosk channels use block-based, context-aware orchestration
- Mobile SDK must provide same conversation engine

**Integration Points**:
1. **Voice Recording**: Native iOS `AVAudioEngine`, Android `MediaRecorder`
2. **Audio Upload**: HTTPS to Olivia.io API with auth token
3. **Conversation Context**: Session management with cart state, restaurant selection
4. **Response Playback**: TTS rendering through device audio

**Unknown Factors** (blocking):
- Does Olivia.io provide native mobile SDK or REST API only?
- What are latency characteristics for mobile network (WiFi vs cellular)?
- How to handle voice confidence thresholds <70%?

**Research Actions**:
- [ ] Request Olivia.io mobile SDK documentation
- [ ] Prototype voice session with test API key
- [ ] Measure latency on iOS/Android from 4G network

### 3. Payment Gateway Integration

**Candidates** (Decision pending per constitution):
- Authorize.Net (traditional, broad support)
- Stacks (blockchain, crypto payments)
- Adyen (premium, global coverage)

**Mobile Payment Standards**:
- Apple Pay (iOS) via `react-native-stripe-sdk`
- Google Pay (Android) via native Payment Request API
- Web: Stripe, Authorize.Net hosted forms

**Implementation Approach**:
- Tokenization: Store payment method tokens in Parcera wallet, not raw card data
- PCI Compliance: Payment gateway handles card data, Parcera passes token to POS API
- Mobile SDKs: Each gateway provides platform-specific SDK (Authorize.Net Mobile, Adyen Mobile)

**Risk**: Payment gateway selection impacts SDK availability; recommend Authorize.Net or Adyen for fastest mobile integration.

### 4. POS Integration API Patterns

**Verified Third-Party APIs**:
- **Toast**: Mobile order submission endpoint, real-time order status webhooks
- **Square**: Orders API v2 with device tracking
- **Clover**: Custom Tender support for third-party orders

**Key Integration Pattern** (from Feature 007):
```
Mobile App → Order Service (Parcera) → POS API → Restaurant
   └─ Order ID, items, payment token ──→
                              ┌──── Webhook ← Order status updates
```

**Success Criteria**: Order submission <5 seconds, status polling every 30 seconds when order active.

### 5. Push Notification Infrastructure

**Options**:
- Firebase Cloud Messaging (FCM) for Android, APNs for iOS (recommended)
- AWS SNS with cross-platform support
- Dedicated service: OneSignal, Braze, Pusher

**Architecture**:
1. Mobile app registers device token with Parcera backend
2. POS status webhook triggers Parcera notification service
3. Notification service sends via FCM/APNs without exposing restaurant API
4. Privacy-first: Restaurants never see customer device tokens

**Implementation**: Firebase Cloud Messaging SDKs for React Native (`react-native-firebase`)

### 6. Database Schema & Multi-Tenancy

**Tenant Isolation** (per constitution Principle II):
- Row-level security (RLS) policies in PostgreSQL
- All customer wallets scoped to Parcera-controlled namespace (no restaurant access)
- Order data includes `wallet_id` + `restaurant_id` for tenant-scoped queries

**Key Tables**:
- `customer_wallets` - Parcera-owned, per-customer (never shared with restaurants)
- `payment_methods` - Tokenized data only, never raw card info
- `addresses` - Customer delivery addresses, never shared with restaurants
- `mobile_orders` - Order details with status tracking
- `conversation_sessions` - Olivia.io context, voice/text history

**Scaling Consideration**: Prepare sharding strategy for 10,000+ restaurants (future post-MVP)

### 7. Offline Mode & Network Resilience

**Scope** (P1 - deferred from P0):
- Cart persisted locally (SQLite on device)
- Menu data cached for recently viewed restaurants
- Order submission queues locally, retries with exponential backoff (3 attempts)

**Implementation**:
- `realm` or `sqlite` for local device storage
- Redux Persist for state hydration
- Network status monitoring via `react-native-netinfo`

## Architecture Decisions

### Layout Decision: Mobile + Web + Backend

**Project Structure**:
```
apps/
├── mobile-app/           # React Native (iOS/Android)
│   ├── src/
│   │   ├── screens/      # Voice, visual menu, cart, checkout
│   │   ├── components/   # Reusable UI components
│   │   ├── services/     # Olivia.io, POS, payment integration
│   │   └── state/        # Redux slices (cart, orders, wallet)
│   └── ios/, android/    # Platform-specific configurations
│
├── web-app/              # React web interface
│   ├── src/
│   │   ├── pages/        # Restaurant search, menu, checkout
│   │   ├── components/
│   │   └── services/
│   └── public/
│
└── backend/              # FastAPI (Python)
    ├── src/
    │   ├── models/       # SQLAlchemy ORM (CustomerWallet, MobileOrder, etc.)
    │   ├── api/          # REST endpoints
    │   ├── services/     # Business logic (Olivia.io, POS, payment)
    │   └── db/           # Database migrations, RLS policies
    └── tests/
```

**Rationale**: 
- Single monorepo enables coordinated development
- Mobile and web share business logic via backend APIs
- Backend owns all customer data (privacy-first)

### State Management & Context Flow

**Mobile State** (Redux + Context):
- `cart` slice: Restaurant, items, modifiers, totals
- `orders` slice: Order history, real-time status updates
- `wallet` slice: Payment methods, addresses, authentication
- `conversation` slice: Olivia.io session context (voice/text history)

**Real-Time Updates**:
- Order status polling every 30s via API
- Push notifications trigger cart refresh
- Conversation context preserved during modality switching (voice → text)

## Open Technical Questions (Blocking)

1. **Olivia.io Mobile SDK**: Does mobile SDK exist, or integrate via REST API only? (Impacts voice latency/reliability)
2. **Payment Gateway**: Final selection (Authorize.Net, Stacks, Adyen)? Impacts SDK integration timeline.
3. **Delivery Integration**: MVP assumes restaurant handles delivery. Integrate DoorDash Drive, Uber Direct post-MVP?
4. **Analytics Platform**: Firebase Analytics, Mixpanel, or custom? (Affects telemetry instrumentation)
5. **App Store Signing**: iOS developer account + certificate management process documented?
6. **Android App Signing**: Keystore management for production builds?

## Dependency Verification

**Upstream Dependencies (MUST EXIST)**:
- ✅ Feature 001 (Restaurant Management): Restaurant data available via API
- ✅ Feature 002 (Menu Management): Menu endpoints with item photos, categories
- ✅ Feature 007 (POS Integration): Toast/Square/Clover order submission tested
- ✅ Feature 008 (Customer Wallet): Wallet creation, authentication endpoints ready
- ✅ Olivia.io: Mobile SDK or API endpoint available

**Status**: All upstream dependencies confirmed or in progress.

## Non-Functional Requirements Research

### Performance Targets

| Metric | Target | Justification |
|--------|--------|---------------|
| App Launch → Home Screen | <2s | Mid-range devices (iPhone 12, Galaxy S21) |
| Menu Load (cached) | <1s | Network bandwidth varies |
| Order Submission | <5s | POS API latency + payment processing |
| Voice Response | 800ms-1.5s | Olivia.io SLA |
| Push Notification Delivery | <30s | Order status webhook latency |
| Cart Sync (voice↔text) | <1s | Modal switching lag tolerance |

### Accessibility Requirements

**iOS VoiceOver** + **Android TalkBack**:
- All interactive elements have meaningful labels
- Voice ordering interface fully screenreader-compatible
- Text-to-speech for all confirmations (built-in iOS/Android support)
- High contrast mode for visual ordering

### Localization (MVP: English + Spanish)

**Scope**:
- App UI strings (language selection in settings)
- Voice prompts via Olivia.io (language parameter)
- Menu item names/descriptions (translated by Menu Management feature)
- Push notification content (translated at backend)

## Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|-----------|
| Olivia.io mobile latency >1.5s | Medium | High | Early prototype, latency testing on real networks |
| Payment gateway SDK delays | Low | High | Evaluate Authorize.Net + Adyen in parallel |
| React Native platform gaps | Low | Medium | Test camera, push notifications early |
| POS API status webhook failures | Medium | Medium | Polling fallback (30s interval) as backup |
| Cart loss during app crash | Low | Medium | Local persistence + cloud state recovery |

## Success Metrics (Phase 0 Completion)

- ✅ Tech stack finalized (React Native, FastAPI, PostgreSQL confirmed)
- ✅ Architecture pattern validated (mobile + web + backend monorepo)
- ✅ Integration points identified (Olivia.io, POS APIs, payment gateway)
- ✅ Data model drafted (8 key entities documented in spec)
- ✅ Blocking questions identified (Olivia.io SDK, payment gateway selection)

**Next Phase**: Phase 1 - Data Model & API Contracts
