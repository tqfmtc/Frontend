# Data Model: Mobile App Ordering

**Phase**: 1 Design | **Date**: 2025-11-04 | **Status**: Complete

## Overview

The mobile app ordering data model extends Feature 008 (Customer Wallet) and integrates with Features 001, 002, 007 for restaurant, menu, and POS data. Privacy-first architecture ensures Parcera owns customer identity; restaurants access only aggregated metrics and order status.

## Database Schema (PostgreSQL)

### Core Tables

#### 1. customer_wallets
Parcera-owned customer identity and preferences (never shared with restaurants).

```sql
CREATE TABLE customer_wallets (
  wallet_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_number VARCHAR(20) UNIQUE NOT NULL,  -- E.164 format: +1234567890
  email VARCHAR(255) UNIQUE,
  name VARCHAR(255),
  dietary_preferences JSONB DEFAULT '[]',  -- ["vegetarian", "vegan", "gluten-free"]
  default_payment_method_id UUID,
  default_delivery_address_id UUID,
  marketing_opt_in BOOLEAN DEFAULT FALSE,
  last_login_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT fk_default_payment FOREIGN KEY (default_payment_method_id) 
    REFERENCES payment_methods(payment_method_id),
  CONSTRAINT fk_default_address FOREIGN KEY (default_delivery_address_id)
    REFERENCES addresses(address_id)
);

CREATE UNIQUE INDEX idx_wallet_phone ON customer_wallets(phone_number);
CREATE INDEX idx_wallet_created ON customer_wallets(created_at DESC);
```

#### 2. payment_methods
Tokenized payment data (PCI-compliant, no raw card numbers).

```sql
CREATE TABLE payment_methods (
  payment_method_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id UUID NOT NULL,
  type VARCHAR(20) NOT NULL,  -- 'card', 'apple_pay', 'google_pay'
  card_last_four VARCHAR(4),
  card_brand VARCHAR(20),  -- 'Visa', 'Mastercard', 'Amex'
  expiry_month INTEGER,
  expiry_year INTEGER,
  billing_address_id UUID,
  payment_gateway_token VARCHAR(255) NOT NULL,  -- Tokenized ID from payment gateway
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT fk_wallet FOREIGN KEY (wallet_id) REFERENCES customer_wallets(wallet_id),
  CONSTRAINT fk_billing_address FOREIGN KEY (billing_address_id) REFERENCES addresses(address_id),
  CONSTRAINT chk_expiry CHECK (expiry_month BETWEEN 1 AND 12 AND expiry_year >= 2025)
);

CREATE INDEX idx_payment_wallet ON payment_methods(wallet_id);
CREATE UNIQUE INDEX idx_payment_default ON payment_methods(wallet_id) 
  WHERE is_default = TRUE;
```

#### 3. addresses
Customer delivery addresses and billing addresses (never shared with restaurants).

```sql
CREATE TABLE addresses (
  address_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id UUID NOT NULL,
  label VARCHAR(50) NOT NULL,  -- "Home", "Work", "Mom's House"
  street_address VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state VARCHAR(2) NOT NULL,  -- State code: "CA", "NY"
  zip_code VARCHAR(10) NOT NULL,
  latitude DECIMAL(10, 8),  -- For delivery radius validation
  longitude DECIMAL(11, 8),
  delivery_instructions TEXT,
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT fk_wallet FOREIGN KEY (wallet_id) REFERENCES customer_wallets(wallet_id)
);

CREATE INDEX idx_address_wallet ON addresses(wallet_id);
CREATE UNIQUE INDEX idx_address_default ON addresses(wallet_id) 
  WHERE is_default = TRUE;
CREATE INDEX idx_address_location ON addresses USING GIST(
  ll_to_earth(latitude, longitude)
);
```

#### 4. mobile_orders
Order details submitted from mobile app to POS system.

```sql
CREATE TABLE mobile_orders (
  order_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id UUID NOT NULL,
  restaurant_id UUID NOT NULL,
  order_number INTEGER NOT NULL,  -- Unique per restaurant per day
  order_type VARCHAR(20) NOT NULL CHECK (order_type IN ('pickup', 'delivery')),
  items JSONB NOT NULL,  -- Array of {item_id, name, quantity, modifiers, price}
  subtotal DECIMAL(10, 2) NOT NULL,
  tax DECIMAL(10, 2) NOT NULL,
  delivery_fee DECIMAL(10, 2) DEFAULT 0,
  tip DECIMAL(10, 2) DEFAULT 0,
  total DECIMAL(10, 2) NOT NULL,
  pickup_time TIMESTAMP,  -- NULL for ASAP orders
  delivery_address_id UUID,
  special_instructions TEXT,
  payment_method_id UUID NOT NULL,
  payment_transaction_id VARCHAR(255),  -- From payment gateway
  payment_status VARCHAR(20) DEFAULT 'pending' 
    CHECK (payment_status IN ('pending', 'approved', 'declined', 'refunded')),
  pos_order_id VARCHAR(255),  -- Third-party POS order ID
  order_status VARCHAR(20) DEFAULT 'pending'
    CHECK (order_status IN ('pending', 'confirmed', 'preparing', 'ready', 'out_for_delivery', 'completed', 'cancelled')),
  channel VARCHAR(20) DEFAULT 'mixed'  -- 'voice', 'text_chat', 'visual', 'mixed' (analytics)
  submitted_to_pos_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT fk_wallet FOREIGN KEY (wallet_id) REFERENCES customer_wallets(wallet_id),
  CONSTRAINT fk_payment_method FOREIGN KEY (payment_method_id) REFERENCES payment_methods(payment_method_id),
  CONSTRAINT fk_delivery_address FOREIGN KEY (delivery_address_id) REFERENCES addresses(address_id),
  CONSTRAINT chk_delivery_addr CHECK (
    (order_type = 'delivery' AND delivery_address_id IS NOT NULL) OR 
    (order_type = 'pickup' AND delivery_address_id IS NULL)
  )
);

CREATE INDEX idx_order_wallet ON mobile_orders(wallet_id);
CREATE INDEX idx_order_restaurant ON mobile_orders(restaurant_id);
CREATE INDEX idx_order_status ON mobile_orders(order_status) WHERE order_status != 'completed';
CREATE INDEX idx_order_created ON mobile_orders(created_at DESC);
CREATE UNIQUE INDEX idx_order_number ON mobile_orders(restaurant_id, DATE(created_at), order_number);
```

#### 5. conversation_sessions
Olivia.io voice/text conversation context for session continuity.

```sql
CREATE TABLE conversation_sessions (
  session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id UUID NOT NULL,
  restaurant_id UUID,  -- NULL if restaurant not yet selected
  modality VARCHAR(20) NOT NULL,  -- 'voice', 'text', 'mixed'
  conversation_log JSONB NOT NULL DEFAULT '[]',  -- Array of {role, message, timestamp}
  cart_snapshot JSONB,  -- Cart state at session start
  olivia_context JSONB,  -- Olivia.io conversation state for resumption
  started_at TIMESTAMP DEFAULT NOW(),
  ended_at TIMESTAMP,
  resulted_in_order BOOLEAN DEFAULT FALSE,
  order_id UUID,  -- Foreign key to mobile_orders if conversation led to order
  
  CONSTRAINT fk_wallet FOREIGN KEY (wallet_id) REFERENCES customer_wallets(wallet_id),
  CONSTRAINT fk_order FOREIGN KEY (order_id) REFERENCES mobile_orders(order_id)
);

CREATE INDEX idx_conversation_wallet ON conversation_sessions(wallet_id);
CREATE INDEX idx_conversation_active ON conversation_sessions(wallet_id) 
  WHERE ended_at IS NULL;
```

#### 6. favorite_items
Customer's favorite menu items across restaurants.

```sql
CREATE TABLE favorite_items (
  favorite_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id UUID NOT NULL,
  restaurant_id UUID NOT NULL,
  menu_item_id UUID NOT NULL,  -- References Feature 002 menu data
  modifiers JSONB,  -- Saved customizations: {option_id, value}
  nickname VARCHAR(100),  -- "My usual burger"
  created_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT fk_wallet FOREIGN KEY (wallet_id) REFERENCES customer_wallets(wallet_id),
  CONSTRAINT unique_favorite UNIQUE (wallet_id, restaurant_id, menu_item_id)
);

CREATE INDEX idx_favorite_wallet ON favorite_items(wallet_id);
CREATE INDEX idx_favorite_restaurant ON favorite_items(restaurant_id);
```

#### 7. favorite_restaurants
Customer's favorite restaurants for quick access.

```sql
CREATE TABLE favorite_restaurants (
  favorite_restaurant_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id UUID NOT NULL,
  restaurant_id UUID NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT fk_wallet FOREIGN KEY (wallet_id) REFERENCES customer_wallets(wallet_id),
  CONSTRAINT unique_favorite UNIQUE (wallet_id, restaurant_id)
);

CREATE INDEX idx_fav_rest_wallet ON favorite_restaurants(wallet_id);
```

#### 8. push_notifications
Device push notification tokens and delivery tracking.

```sql
CREATE TABLE push_notifications (
  notification_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id UUID NOT NULL,
  order_id UUID,  -- NULL for non-order notifications (promotions, etc.)
  type VARCHAR(30) NOT NULL,
    CHECK (type IN ('order_confirmed', 'order_preparing', 'order_ready', 'order_out_for_delivery', 'order_delivered', 'promotional')),
  title VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  device_token VARCHAR(255),  -- Push service token (FCM, APNs)
  sent_at TIMESTAMP DEFAULT NOW(),
  read_at TIMESTAMP,
  
  CONSTRAINT fk_wallet FOREIGN KEY (wallet_id) REFERENCES customer_wallets(wallet_id),
  CONSTRAINT fk_order FOREIGN KEY (order_id) REFERENCES mobile_orders(order_id)
);

CREATE INDEX idx_notif_wallet ON push_notifications(wallet_id);
CREATE INDEX idx_notif_order ON push_notifications(order_id);
CREATE INDEX idx_notif_unread ON push_notifications(wallet_id, read_at) 
  WHERE read_at IS NULL;
```

#### 9. device_tokens
Store push notification device tokens securely.

```sql
CREATE TABLE device_tokens (
  device_token_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id UUID NOT NULL,
  token VARCHAR(255) NOT NULL UNIQUE,  -- FCM or APNs token
  platform VARCHAR(20) NOT NULL CHECK (platform IN ('ios', 'android', 'web')),
  app_version VARCHAR(20),
  os_version VARCHAR(20),
  is_active BOOLEAN DEFAULT TRUE,
  last_verified_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT fk_wallet FOREIGN KEY (wallet_id) REFERENCES customer_wallets(wallet_id)
);

CREATE INDEX idx_device_wallet ON device_tokens(wallet_id);
CREATE INDEX idx_device_active ON device_tokens(wallet_id) WHERE is_active = TRUE;
```

## Row-Level Security (RLS) Policies

All tables use wallet_id as tenant key. Policies enforce customer can only access their own data.

```sql
-- Example RLS policy for mobile_orders
ALTER TABLE mobile_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY wallet_isolation ON mobile_orders
  USING (wallet_id = current_user_id())
  WITH CHECK (wallet_id = current_user_id());

-- Restaurants can query aggregated data only (view, not direct table access)
CREATE VIEW restaurant_order_summary AS
  SELECT 
    restaurant_id,
    DATE(created_at) as order_date,
    COUNT(*) as total_orders,
    SUM(total) as revenue,
    AVG(total) as avg_order_value
  FROM mobile_orders
  GROUP BY restaurant_id, DATE(created_at);
```

## Data Flow Diagrams

### Order Creation Flow
```
Customer App                 Parcera Backend              Third-Party POS
    │                             │                              │
    │─ Voice/Text/Visual ────────▶│                              │
    │  (Restaurant, Items)        │                              │
    │                     ┌───────▼────────────┐                │
    │                     │ 1. Create cart     │                │
    │                     │ 2. Validate items  │                │
    │                     │ 3. Calculate fees  │                │
    │                     └───────┬────────────┘                │
    │◀────────────────────────────│ Cart summary                │
    │                             │                              │
    │─ Confirm + Payment Token ──▶│                              │
    │                     ┌───────▼────────────┐                │
    │                     │ 4. Process payment │                │
    │                     │ 5. Create order    │                │
    │                     │ 6. Generate Order  │                │
    │                     │    ID              │                │
    │                     └───────┬────────────┘                │
    │                             │─ Order Details ────────────▶│
    │                             │ + POS Location              │
    │                             │                             │
    │                             │◀─ POS Order ID ────────────│
    │                     ┌───────▼────────────┐                │
    │                     │ 7. Store POS Order │                │
    │                     │    ID + Status     │                │
    │                     └───────┬────────────┘                │
    │◀────────────────────────────│ Confirmation              │
    │ (Order #, ETA, etc.)        │                              │
```

### Order Status Update Flow
```
Third-Party POS          Parcera Backend           Customer App
       │                      │                            │
       │─ Webhook: Status ───▶│                            │
       │  (order_id, status)  │                            │
       │              ┌──────▼──────┐                       │
       │              │ 1. Update    │                       │
       │              │    order_    │                       │
       │              │    status    │                       │
       │              │ 2. Query     │                       │
       │              │    device    │                       │
       │              │    tokens    │                       │
       │              └──────┬──────┘                       │
       │                     │─ Push Notification ────────▶│
       │                     │ (FCM/APNs via platform)    │
       │                     │                            │
       │                     │◀── Device fetches ────────│
       │                     │    order status           │
       │              ┌──────▼──────┐                       │
       │              │ Serve order  │                       │
       │              │ status via   │                       │
       │              │ REST API     │                       │
       │              └──────────────┘                       │
       │                              │ Order details      │
       │                              │ visible in app     │
```

## Voice Session Context Management

Voice/text switching preserves cart and order context via `conversation_sessions`.

```json
{
  "session_id": "uuid",
  "wallet_id": "uuid",
  "restaurant_id": "uuid",
  "modality": "mixed",
  "conversation_log": [
    {
      "role": "user",
      "message": "I want a cheeseburger",
      "timestamp": "2025-11-04T10:00:00Z"
    },
    {
      "role": "olivia",
      "message": "Great! Adding cheeseburger to cart. Anything else?",
      "timestamp": "2025-11-04T10:00:01Z"
    }
  ],
  "cart_snapshot": {
    "restaurant_id": "uuid",
    "items": [
      {
        "menu_item_id": "uuid",
        "name": "Cheeseburger",
        "quantity": 1,
        "modifiers": {"cheese": "extra"},
        "price": 12.99
      }
    ],
    "subtotal": 12.99,
    "tax": 1.04,
    "total": 14.03
  },
  "olivia_context": {
    "current_state": "awaiting_checkout",
    "selected_restaurant": "uuid",
    "conversation_turns": 3
  }
}
```

## Privacy & Tenancy Enforcement

### Principle: Zero Customer Data to Restaurants

| Data | Stored Location | Accessible By | Access Method |
|------|-----------------|---------------|----------------|
| Phone, Email | customer_wallets (Parcera) | Parcera only | Direct table |
| Payment Methods | payment_methods (Parcera) | Parcera only | Tokenized |
| Delivery Addresses | addresses (Parcera) | Parcera only | For order fulfillment |
| Order Details | mobile_orders (Parcera) | Parcera + Restaurant via POS | POS API only (order_id based) |
| Customer Preferences | dietary_preferences, favorites | Parcera only | Not shared with restaurants |

**Implementation**: RLS policies + view-based aggregation for restaurant analytics.

## Scaling Strategy (Post-MVP)

For 5000+ restaurants (3-year goal):
- **Sharding key**: restaurant_id + wallet_id hash
- **Hot tables**: mobile_orders, conversation_sessions (time-series partitioning)
- **Archive**: Orders >90 days to cold storage (S3)
- **Read replicas**: For analytics queries (restaurant_order_summary view)

## Indexing Strategy

**High-traffic queries**:
```sql
-- Find customer's active orders
SELECT * FROM mobile_orders 
WHERE wallet_id = ? AND order_status IN ('confirmed', 'preparing', 'ready', 'out_for_delivery')
ORDER BY created_at DESC;
-- Index: idx_order_wallet, idx_order_status

-- Poll for order status updates
SELECT order_id, order_status, updated_at 
FROM mobile_orders 
WHERE wallet_id = ? AND order_id = ?;
-- Index: idx_order_wallet

-- Fetch customer's recent restaurants
SELECT DISTINCT restaurant_id 
FROM mobile_orders 
WHERE wallet_id = ? 
ORDER BY created_at DESC LIMIT 10;
-- Index: idx_order_wallet, idx_order_created
```

## Constraints & Validation

1. **Delivery Address Validation**: 
   - Must be within restaurant's delivery radius (geocoding check in app)
   - Latitude/longitude required for pickup time estimates

2. **Order Minimum**: 
   - Enforce minimum order subtotal per restaurant
   - Stored in restaurant metadata (Feature 001), validated at checkout

3. **Item Availability**:
   - Check against menu_items.is_available from Feature 002
   - Cache validity: 5 minutes (refresh on cart change)

4. **Payment Method Expiry**:
   - Validate expiry_month/expiry_year before submission
   - Prompt customer to update if expired

5. **Wallet Phone Number**:
   - E.164 format validated at creation
   - Must be unique (prevent duplicate wallets)
   - Supports phone number changes (reverification required)

## Next Steps (Phase 1 Complete)

- ✅ 9 core tables designed with RLS policies
- ✅ Data flow diagrams for order creation/updates
- ✅ Privacy enforcement verified (zero customer data to restaurants)
- ✅ Scaling strategy outlined for post-MVP
- ✅ Indexing and query patterns optimized

**Next**: API Contracts (contracts/*.yaml)
