# Implementation Plan: Mobile App Ordering (SPEC 005)

**Branch**: `005-mobile-app-ordering` | **Date**: 2025-11-04 | **Spec**: [spec.md](spec.md)
**Input**: Feature specification from `/specs/005-mobile-app-ordering/spec.md`

## Summary

Cross-platform mobile and web app ordering for iOS, Android, and web customers enabling voice (Olivia.io), text chat, and visual menu-based ordering. Privacy-first wallet stores customer data (Parcera-owned, never shared with restaurants). Integrates with third-party POS systems (Toast, Square, Clover) for order submission and tracking.

**Tech Stack**:
- **Mobile**: React Native (cross-platform MVP, 30-40% faster timeline)
- **Web**: React 18+
- **Backend**: FastAPI (Python 3.11+)
- **Database**: PostgreSQL 14+ with RLS for multi-tenancy
- **Integrations**: Olivia.io (voice/chat), Toast/Square/Clover (POS), Payment Gateway (Authorize.Net/Adyen), Firebase (push notifications)

## Technical Context

**Language/Version**: Python 3.11 (backend), Node.js 18+ (mobile/web), React 18+
**Primary Dependencies**: FastAPI, React Native, Expo, PostgreSQL, SQLAlchemy, Redux
**Storage**: PostgreSQL (customer data, orders, wallets, payment methods, addresses)
**Testing**: pytest (backend), Jest (mobile/web), Contract tests (OpenAPI)
**Target Platform**: iOS 14+, Android 8.0+ (API 26), Web (modern browsers)
**Project Type**: Mobile + Web + Backend (monorepo structure)
**Performance Goals**: 
  - App launch <2s
  - Order submission <5s
  - Voice response 800ms-1.5s (Olivia.io)
  - Push notification delivery <30s

**Constraints**:
- <200ms p95 API response time
- Voice confidence threshold 70%+ required for action
- PCI compliance (payment gateway tokenization only)
- Offline cart persistence, online order submission

**Scale/Scope**: 
  - MVP: 50-100 restaurants, 1000-5000 orders/day
  - Phase 2: 500 restaurants, 25k orders/day
  - 3-year: 5000+ restaurants, 500k+ orders/day

## Constitution Check

GATE: Must pass before Phase 0 research (PASSED).

**Principle I (AI-First)**: ✅
- Olivia.io voice AI integrated as primary ordering modality
- Text chat powered by same AI conversation engine
- Voice-to-text handoff demonstrates context-aware AI

**Principle II (Multi-Tenancy)**: ✅
- Row-level security enforces wallet_id isolation
- Customer data never exposed to restaurant tenants
- Order data includes restaurant_id for tenant scoping

**Principle III (Privacy-First)**: ✅
- Customer wallet (phone, email, addresses, payments) owned by Parcera
- Restaurants access only order details via POS API, not customer contact info
- Push notifications sent by Parcera on behalf of restaurants
- Order-ID-based notification routing prevents merchant spam

**Principle IV (Omnichannel)**: ✅
- Mobile app independent ordering channel
- Shares menu data and order submission with IVR, web portal, kiosk
- No requirement for Parcera POS hardware

**Principle V (MVP Discipline)**: ✅
- P0 (MVP): Voice, visual browsing, wallet, order history, push notifications
- P1 (post-MVP): Text chat, favorites, voice-to-text handoff, offline mode
- P2 (long-term): Social features, loyalty, advanced analytics

## Project Structure

### Documentation (this feature)

```text
specs/005-mobile-app-ordering/
├── plan.md              # THIS FILE - Phase 1 implementation roadmap
├── spec.md              # Phase 0 - Complete specification (34KB)
├── research.md          # Phase 0 - Technology research & decisions
├── data-model.md        # Phase 1 - Database schema, ERD, data flows
├── quickstart.md        # Phase 1 - Development setup & local environment
├── contracts/           # Phase 1 - OpenAPI specifications
│   ├── wallet-api.yaml  # Customer wallet endpoints
│   ├── ordering-api.yaml # Menu browsing, orders, favorites
│   └── README.md        # Contract testing guide
└── tasks.md             # Phase 2 OUTPUT (from /speckit.tasks command)
```

### Source Code (repository root)

```text
# Mobile + Web + Backend monorepo
apps/
├── backend/             # FastAPI backend (Python 3.11+)
│   ├── src/
│   │   ├── models/      # SQLAlchemy ORM (wallets, orders, payments, addresses)
│   │   ├── api/         # FastAPI routers (wallets, ordering, push)
│   │   ├── services/    # Business logic (Olivia.io, POS integration, payments)
│   │   ├── db/          # Database config, migrations, RLS policies
│   │   ├── auth/        # JWT authentication, phone verification
│   │   └── main.py      # FastAPI app initialization
│   ├── tests/
│   │   ├── unit/        # Unit tests (models, services, validators)
│   │   ├── integration/ # Integration tests (API, payment, POS)
│   │   └── contract/    # OpenAPI contract tests
│   ├── requirements.txt  # Python dependencies
│   └── Dockerfile       # Container image for deployment
│
├── mobile-app/          # React Native (iOS + Android)
│   ├── src/
│   │   ├── screens/     # Screen components (RestaurantSearch, Menu, Voice, Cart, Checkout)
│   │   ├── components/  # Reusable UI components (MenuCard, OrderItem, etc.)
│   │   ├── services/    # API clients (wallet, ordering, Olivia.io, payment)
│   │   ├── state/       # Redux slices (cart, orders, wallet, conversation)
│   │   ├── utils/       # Utilities (formatting, validation, geolocation)
│   │   └── App.js       # Root component, navigation setup
│   ├── ios/             # iOS-specific configuration (Podfile, Info.plist)
│   ├── android/         # Android-specific configuration (build.gradle, AndroidManifest.xml)
│   ├── package.json     # Dependencies (react-native, redux, firebase, etc.)
│   ├── app.json         # Expo config
│   └── jest.config.js   # Test configuration
│
├── web-app/             # React web interface
│   ├── src/
│   │   ├── pages/       # Page components (HomePage, MenuPage, CheckoutPage)
│   │   ├── components/  # Reusable components (Header, Footer, etc.)
│   │   ├── services/    # API client, auth service
│   │   ├── state/       # Zustand store (simpler than Redux for web)
│   │   └── App.js       # Root component
│   ├── public/          # Static assets (logo, favicon)
│   └── package.json     # Dependencies
│
└── docs/                # Project documentation
    ├── CONTRIBUTING.md  # Contribution guidelines
    ├── ARCHITECTURE.md  # System architecture overview
    └── postman/         # Postman collections for API testing
```

**Structure Decision Rationale**:
- **Monorepo**: Single git repository enables coordinated releases, shared API contracts, unified dependency management
- **apps/ separation**: Clear boundary between frontend (mobile/web) and backend, enabling independent scaling and deployment
- **Backend-first data ownership**: All customer data (wallet, orders, payments) owned by backend (Parcera), never directly exposed to restaurants
- **State isolation**: Mobile uses Redux (more complex state), web uses Zustand (simpler), both consume same REST APIs from backend

## Complexity Tracking

No Constitution violations. Architecture aligns fully with Principles I-V.

| Decision | Rationale |
|----------|-----------|
| React Native over Flutter | Existing React expertise in team, 80-90% code reuse iOS/Android, proven for MVP timeline |
| Monorepo over separate repos | Coordinated releases, shared API contracts, easier cross-team development |
| FastAPI over Node.js backend | Python preference from stakeholder, proven async performance, strong ORM ecosystem |
| PostgreSQL + RLS over separate databases | Single database, row-level security enforces multi-tenancy, simpler ops vs sharded databases |
| Voice-first UX over visual-first | AI-first principle (Principle I), hands-free ordering key differentiator vs DoorDash/UberEats |

## Phase Breakdown

### Phase 0: Research & Design (COMPLETE - 2025-11-04)

**Deliverables**:
- ✅ spec.md (34KB, 7 user stories, 15 functional requirements, 8 data entities)
- ✅ research.md (Technology evaluation, architecture decisions, risk assessment)
- ✅ data-model.md (9 PostgreSQL tables, RLS policies, data flow diagrams)
- ✅ API contracts (wallet-api.yaml, ordering-api.yaml with OpenAPI 3.0)
- ✅ quickstart.md (Development setup, local environment, testing guide)

**Key Decisions Made**:
- React Native for cross-platform MVP
- FastAPI + PostgreSQL for backend
- Privacy-first wallet architecture (Parcera-owned customer data)
- Firebase Cloud Messaging for push notifications
- Order polling every 30s + webhook fallback for status updates

### Phase 1: Backend & API Implementation (NEXT)

**Deliverables**:
- Wallet service (create wallet, phone verification, OTP login)
- Wallet API endpoints (CRUD payment methods, addresses)
- Ordering service (restaurant search, menu fetch, order submission to POS)
- Ordering API endpoints (checkout, order history, favorites)
- Payment service (gateway integration, tokenization)
- Push notification service (device token registration, order status notifications)
- Database migrations (9 tables + RLS policies)
- Unit tests (models, services, validators)
- Integration tests (API endpoints, payment processing, POS integration)
- Contract tests (OpenAPI validation)

**Est. Timeline**: 4-6 weeks (1 backend engineer + 1 DevOps for deployment)

### Phase 2: Mobile App Implementation (PARALLEL)

**Deliverables**:
- Restaurant search screen (map view, list view, filters)
- Menu browsing screens (categories, item details, modifiers)
- Cart management (add/remove items, modify quantities)
- Voice ordering integration (Olivia.io SDK integration)
- Checkout screen (address selection, payment, order submission)
- Order history screen (past orders, reorder functionality)
- Push notification handling (Firebase, device token registration)
- Local state management (Redux slices for cart, orders, wallet)
- Mobile UI components (consistent iOS/Android design)
- Unit tests (component, service, state management)
- E2E tests (critical user journeys)

**Est. Timeline**: 6-8 weeks (1-2 React Native engineers)

### Phase 3: Web App Implementation (PARALLEL)

**Deliverables**:
- Web UI for restaurant search, menu, checkout
- Responsive design (mobile, tablet, desktop)
- Same API integration as mobile (reuses backend)
- Basic analytics (order metrics, user engagement)
- Admin dashboard (order management, customer history)

**Est. Timeline**: 4-6 weeks (1 React engineer)

### Phase 4: Integration & Testing (SEQUENTIAL)

**Deliverables**:
- E2E tests (full ordering flow: wallet creation → order submission → status tracking)
- Performance testing (load testing for 1000+ concurrent orders)
- Security testing (penetration test for API, payment processing)
- Olivia.io integration testing (voice quality, latency, confidence thresholds)
- POS API testing (Toast, Square, Clover integration verification)
- Firebase push notification testing (delivery rates, performance)
- App store submission preparation (iOS TestFlight, Android Beta)

**Est. Timeline**: 2-3 weeks

### Phase 5: MVP Launch (TARGET: January 15, 2025)

**Deliverables**:
- iOS app on App Store
- Android app on Google Play Store
- Web app deployed to production
- Backend running on AWS/Azure with monitoring
- Customer support documentation
- Post-launch monitoring & bug fixes

**Est. Timeline**: 1 week (release management + monitoring)

## Dependency Management

### Upstream Dependencies (MUST EXIST FIRST)

- ✅ Feature 001 (Restaurant Management): Restaurant database, API endpoints
- ✅ Feature 002 (Menu Management): Menu data structure, image storage, OCR extraction
- ✅ Feature 007 (POS Integration): Toast/Square/Clover API integration, order submission endpoints
- ✅ Feature 008 (Customer Wallet): Wallet creation, authentication infrastructure
- ✅ Olivia.io Partnership: Mobile SDK or API access for voice/text ordering

**Status**: All dependencies confirmed or in progress.

### Downstream Dependencies (WILL USE THIS FEATURE)

- Feature 006 (Order Fulfillment): Mobile orders flow through same fulfillment pipeline
- Feature 010 (Analytics): Mobile app metrics feed into business intelligence platform (P2)
- Future Loyalty Program: Mobile wallet enables cross-merchant rewards (P2)

## Key Milestones

| Milestone | Target Date | Gate Criteria |
|-----------|-------------|---------------|
| Phase 0 Complete | 2025-11-04 | ✅ All research docs, API contracts ready |
| Backend Wallet API | 2025-11-18 | Wallet creation, payment methods, addresses |
| Backend Ordering API | 2025-12-02 | Restaurant search, menu, order submission |
| Mobile UI Framework | 2025-12-09 | Navigation, core screens, Redux setup |
| Voice Integration | 2025-12-16 | Olivia.io integrated, voice ordering E2E |
| Payment Integration | 2025-12-23 | Payment gateway tokenization, checkout |
| MVP Complete | 2025-01-15 | All P0 features, >80% test coverage |

## Risk Mitigation

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|-----------|
| Olivia.io SDK delays | Medium | High | Early prototype, latency testing, REST API fallback |
| Payment gateway SDK integration | Low | High | Parallel evaluation of Authorize.Net + Adyen |
| React Native platform gaps (camera, push) | Low | Medium | Early integration testing, native module fallback |
| POS API reliability | Medium | High | Polling fallback (30s) + webhook validation |
| Database performance at scale | Low | Medium | Prepared sharding strategy, read replicas for analytics |

## Success Criteria

**Phase 0 (COMPLETE)**:
- ✅ Tech stack finalized and documented
- ✅ Architecture pattern validated (monorepo, privacy-first)
- ✅ Data model designed (9 tables, RLS policies)
- ✅ API contracts defined (OpenAPI)
- ✅ Development environment documented

**Phase 1 (MVP)**:
- Order completion rate ≥80%
- Voice ordering adoption ≥30% of orders
- App load time <2 seconds
- Order submission <5 seconds
- Voice accuracy ≥75% first-attempt
- Push notification delivery ≥95% within 30s
- Test coverage ≥70% for P0 features

**Post-MVP**:
- Reorder usage ≥40% repeat customers
- Average order time <4 minutes (returning customers)
- App Store rating ≥4.5 stars
- Customer retention ≥50% second order within 30 days

## Next Steps

1. ✅ Phase 0: Research & Design (COMPLETE)
2. ⏭️ Phase 1: Backend API Implementation (START 2025-11-06)
3. ⏭️ Phase 2: Mobile App Development (START 2025-11-13, PARALLEL)
4. ⏭️ Phase 3: Web App Development (START 2025-12-01, PARALLEL)
5. ⏭️ Phase 4: Integration Testing (START 2025-12-16)
6. ⏭️ Phase 5: MVP Launch (2025-01-15)

---

## Files Completed

- ✅ spec.md (Feature specification)
- ✅ research.md (Technology research & decisions)
- ✅ data-model.md (Database schema & architecture)
- ✅ plan.md (THIS FILE - Implementation plan)
- ✅ contracts/wallet-api.yaml (OpenAPI for wallet endpoints)
- ✅ contracts/ordering-api.yaml (OpenAPI for ordering endpoints)
- ✅ quickstart.md (Development setup guide)

**Remaining** (via /speckit.tasks command):
- tasks.md (Detailed implementation tasks with story points)

---

**STATUS**: ✅ PHASE 0 COMPLETE - READY FOR PHASE 1

Generated: 2025-11-04 | Schema Version: 1.0 | Constitution Alignment: 100%
