# Feature Specification: Mobile App Ordering

**Feature Branch**: `005-mobile-app-ordering`
**Created**: 2025-10-29
**Status**: Draft
**Constitution Alignment**: Principles I (AI-First), III (Privacy-First), IV (Omnichannel), V (MVP Discipline)

---

## Overview

Native or cross-platform mobile application for iOS and Android enabling customers to order from restaurants using voice (Olivia.io integration), text-based chat, or traditional visual menu browsing. Features privacy-first customer wallet for identity management, order history, favorites, push notifications, and seamless handoff between voice and text interactions. Supports both pickup and delivery orders via third-party POS integration.

---

## User Scenarios & Testing

### User Story 1 - Quick Voice Order with Olivia (Priority: P0)

**As a** busy customer on-the-go
**I want to** place an order using voice commands without looking at my phone
**So that** I can order while driving, walking, or multitasking safely

**Why this priority**: Voice ordering is the core AI differentiator. Enables hands-free, eyes-free ordering that competitors (DoorDash, Uber Eats, Grubhub) don't offer at this level of sophistication.

**Independent Test**: Can be fully tested by opening app, tapping voice button, speaking full order ("I want a burger and fries from Joe's Diner for pickup in 20 minutes"), confirming order, and receiving order confirmation. Delivers immediate value for hands-free convenience.

**Acceptance Scenarios**:

1. **Given** Customer has app installed and is logged into their wallet, **When** Customer opens app and taps voice button, **Then** Olivia greets customer and asks what they'd like to order
2. **Given** Voice session is active, **When** Customer says "I want a cheeseburger and fries from Main Street Pizza", **Then** App recognizes restaurant name, shows menu items, adds to cart with voice confirmation
3. **Given** Items are in cart, **When** Customer says "Order for pickup in 30 minutes", **Then** App sets pickup time, shows order summary, and asks for confirmation
4. **Given** Order summary is displayed, **When** Customer says "Yes, place the order", **Then** Order is submitted to restaurant POS, payment is processed, and confirmation screen appears with order number

---

### User Story 2 - Visual Menu Browsing and Ordering (Priority: P0)

**As a** customer who prefers to browse visually
**I want to** see menu items with photos and descriptions and tap to order
**So that** I can explore options and make informed decisions without voice interaction

**Why this priority**: Foundation for traditional mobile ordering. Many customers prefer visual browsing, especially for discovering new items or complex customization.

**Independent Test**: Can be fully tested by searching for restaurant, browsing menu categories, viewing item details with photos, adding items to cart with modifiers, and completing checkout. Delivers standard mobile ordering experience.

**Acceptance Scenarios**:

1. **Given** Customer opens app, **When** Customer searches for "pizza near me", **Then** App displays list of nearby restaurants with ratings, distance, and estimated delivery/pickup time
2. **Given** Customer selects a restaurant, **When** Menu loads, **Then** Categories are displayed with item cards showing photos, names, prices, and dietary icons
3. **Given** Customer taps on menu item, **When** Item detail screen appears, **Then** Full description, ingredients, modifiers, and "Add to Cart" button are shown
4. **Given** Customer adds item with modifiers, **When** Customer proceeds to checkout, **Then** Cart shows all items with correct pricing and allows order type selection (pickup/delivery)

---

### User Story 3 - Text Chat Ordering with AI Assistant (Priority: P1)

**As a** customer in a quiet environment or with hearing/speech challenges
**I want to** order using text chat with the AI assistant
**So that** I can get conversational guidance without voice interaction

**Why this priority**: Provides accessibility alternative to voice and adds conversational convenience to traditional menu browsing. Differentiates from competitors' static menu interfaces.

**Independent Test**: Can be fully tested by opening chat interface, typing order request in natural language ("Can I get a vegetarian pizza with extra cheese?"), receiving AI suggestions and clarifications, confirming order via chat, and completing checkout. Delivers conversational ordering without voice.

**Acceptance Scenarios**:

1. **Given** Customer is viewing restaurant menu, **When** Customer opens chat interface, **Then** Olivia greets via text: "Hi! What would you like to order from [Restaurant Name]?"
2. **Given** Chat is active, **When** Customer types "vegetarian options?", **Then** Olivia suggests vegetarian items with descriptions and asks which to add to cart
3. **Given** Customer types item request with modifications, **When** Olivia confirms understanding ("Got it! Veggie pizza with extra cheese, anything else?"), **Then** Item is added to cart and chat continues
4. **Given** Customer types "that's all", **When** Olivia asks about pickup or delivery, **Then** Customer selects option via text or quick reply buttons and proceeds to checkout

---

### User Story 4 - Customer Wallet and Privacy-First Identity (Priority: P0)

**As a** customer concerned about privacy
**I want to** create a wallet that stores my preferences and order history without sharing my contact info with restaurants
**So that** I can enjoy personalized experience without risking spam or data misuse

**Why this priority**: Privacy-first architecture is constitutional requirement (Principle III). Wallet enables cross-restaurant personalization and loyalty without compromising customer data.

**Independent Test**: Can be fully tested by creating wallet with phone/email verification, placing orders at multiple restaurants, viewing unified order history, and verifying that restaurants cannot access customer contact info directly (only Parcera can send notifications). Delivers privacy guarantee.

**Acceptance Scenarios**:

1. **Given** New customer opens app, **When** Customer taps "Create Wallet", **Then** App requests phone number, sends verification code, and creates wallet without password requirement
2. **Given** Wallet is created, **When** Customer completes first order, **Then** Payment method and delivery address are saved to wallet for future use
3. **Given** Customer has ordered from multiple restaurants, **When** Customer views order history, **Then** All orders from all restaurants appear in unified timeline with reorder capability
4. **Given** Restaurant wants to notify customer, **When** Order status changes, **Then** Parcera sends push notification on behalf of restaurant without exposing customer contact info to merchant

---

### User Story 5 - Favorites and Reordering (Priority: P1)

**As a** repeat customer with regular orders
**I want to** save favorite items and restaurants for quick reordering
**So that** I can place my usual order in seconds without browsing

**Why this priority**: Drives repeat business and reduces friction for loyal customers. Common feature in competitor apps but enhanced with AI voice reordering.

**Independent Test**: Can be fully tested by favoriting items and restaurants, using "Reorder" button from order history, voice command "Reorder my usual from Joe's Diner", and completing checkout with saved preferences. Delivers convenience for repeat customers.

**Acceptance Scenarios**:

1. **Given** Customer is viewing menu item, **When** Customer taps heart icon, **Then** Item is added to favorites list with restaurant association
2. **Given** Customer has favorites saved, **When** Customer opens favorites tab, **Then** All favorited items and restaurants are displayed for quick access
3. **Given** Customer views past order, **When** Customer taps "Reorder", **Then** All items from that order are added to cart with original modifiers
4. **Given** Customer uses voice, **When** Customer says "Reorder my last order from Pizza Place", **Then** Olivia retrieves most recent order, confirms items, and adds to cart

---

### User Story 6 - Push Notifications for Order Status (Priority: P0)

**As a** customer waiting for my order
**I want to** receive real-time notifications about order progress
**So that** I know when to pick up or when delivery is arriving

**Why this priority**: Essential for order tracking and customer satisfaction. Reduces "where is my order?" support requests.

**Independent Test**: Can be fully tested by placing order, simulating order status changes in POS system, and verifying that app displays push notifications (order confirmed, preparing, ready for pickup, out for delivery). Delivers transparency and reduces anxiety.

**Acceptance Scenarios**:

1. **Given** Customer places order, **When** Restaurant accepts order in POS, **Then** Customer receives push notification: "Your order from [Restaurant] has been confirmed"
2. **Given** Order is being prepared, **When** Status changes to "In Progress", **Then** Customer receives notification: "Your order is being prepared. Estimated ready time: [X] minutes"
3. **Given** Order is ready for pickup, **When** Status changes to "Ready", **Then** Customer receives notification with order number and pickup instructions
4. **Given** Order is out for delivery, **When** Status changes to "Out for Delivery", **Then** Customer receives notification with estimated delivery time (if available from POS API)

---

### User Story 7 - Seamless Voice-to-Text Handoff (Priority: P1)

**As a** customer using voice ordering
**I want to** switch to text or visual confirmation at any point
**So that** I can verify complex orders or make adjustments visually

**Why this priority**: Enhances voice ordering reliability and user confidence. Allows customers to combine voice speed with visual accuracy.

**Independent Test**: Can be fully tested by starting order with voice, switching to text chat mid-order to clarify modifier, then returning to voice to complete order. Verifies context is preserved across modalities. Delivers flexible interaction model.

**Acceptance Scenarios**:

1. **Given** Customer is placing voice order, **When** Customer taps "Show me the menu" during voice session, **Then** App displays visual menu while preserving voice session context
2. **Given** Voice order is in progress, **When** Customer types a question in chat, **Then** Olivia responds via text while maintaining cart contents from voice interaction
3. **Given** Customer started with text chat, **When** Customer taps microphone button, **Then** Voice input activates and Olivia continues conversation seamlessly
4. **Given** Complex order with modifiers, **When** Customer switches from voice to visual cart review, **Then** All voice-added items appear correctly with modifiers and customer can edit visually

---

### Edge Cases

1. **Voice Recognition Fails in Noisy Environment**: App detects low confidence (<50%), automatically suggests switching to text chat or visual browsing, preserves partial order
2. **Network Drops During Order Submission**: App queues order locally, retries submission when connection restored, notifies customer of submission status
3. **Restaurant Closed or Out of Stock Item**: App checks restaurant hours before order submission, displays "Currently Closed" or "Item Unavailable" with alternative suggestions
4. **Customer Wallet Phone Number Changes**: App requires reverification of new number, transfers order history and wallet data to new number after verification
5. **Multiple Restaurants with Same Name**: Voice recognition disambiguates by location ("Which Main Street Pizza? The one on 5th Avenue or Elm Street?")
6. **Push Notification Permission Denied**: App displays in-app order status updates, shows banner prompting user to enable notifications for better experience
7. **Payment Method Expired**: App detects expired card before checkout, prompts customer to update payment method, saves new method to wallet
8. **Delivery Address Outside Restaurant Range**: App validates delivery radius before order submission, suggests pickup or alternative nearby restaurants
9. **Customer Says "Cancel Order" Mid-Voice Session**: Olivia asks for confirmation, clears cart if confirmed, or returns to order if declined
10. **App Crashes During Checkout**: App persists cart contents locally, restores cart when app reopens, confirms with customer before resubmitting
11. **Voice Command Ambiguous ("Large Pizza")**: Olivia asks clarifying questions ("Which type of pizza? We have Margherita, Pepperoni, and Vegetarian")
12. **Customer Has Multiple Active Orders**: Order history shows status for each order separately, push notifications include restaurant name for clarity

---

## Functional Requirements

### FR-M1: Voice Ordering with Olivia.io (P0)
- **FR-M1.1**: Integrate Olivia.io conversation engine for voice ordering with same block-based, context-aware orchestration as IVR channel
- **FR-M1.2**: Voice input activates via button tap or "Hey Olivia" wake word (configurable in settings)
- **FR-M1.3**: Support natural language commands for: restaurant selection, item addition, modifiers, order type (pickup/delivery), checkout
- **FR-M1.4**: Voice confidence threshold of 70%+ required for action execution; below threshold triggers clarification or text fallback
- **FR-M1.5**: Voice feedback with text-to-speech confirmation of actions and order summary

### FR-M2: Text Chat Ordering (P1)
- **FR-M2.1**: Text-based chat interface powered by Olivia.io for conversational ordering
- **FR-M2.2**: Natural language processing for menu queries, item requests, and order modifications
- **FR-M2.3**: AI-generated suggestions based on context (dietary preferences, order history, popular items)
- **FR-M2.4**: Quick reply buttons for common responses ("Yes", "No", "Show me more", "Checkout")
- **FR-M2.5**: Chat history preserved within session for reference

### FR-M3: Visual Menu Browsing (P0)
- **FR-M3.1**: Display restaurant menu with categories, item cards (photo, name, price, description)
- **FR-M3.2**: Item detail view with full description, ingredients, nutritional info (if available), modifiers
- **FR-M3.3**: Search functionality within restaurant menu (filter by name, category, dietary restrictions)
- **FR-M3.4**: Visual indicators for dietary options (vegetarian, vegan, gluten-free, etc.)
- **FR-M3.5**: Real-time availability updates (if POS API provides inventory status)

### FR-M4: Restaurant Discovery (P0)
- **FR-M4.1**: Search restaurants by name, cuisine type, or location
- **FR-M4.2**: "Restaurants near me" with GPS location permission (fallback to manual address entry)
- **FR-M4.3**: Restaurant cards display: name, cuisine, rating, distance, estimated delivery time, open/closed status
- **FR-M4.4**: Filter options: cuisine type, delivery/pickup availability, open now, price range
- **FR-M4.5**: Sort options: distance, rating, estimated delivery time, popularity

### FR-M5: Cart Management (P0)
- **FR-M5.1**: Persistent cart per restaurant (switching restaurants prompts save/discard current cart)
- **FR-M5.2**: Cart displays items with modifiers, quantities, subtotal, tax, delivery fee (if applicable), total
- **FR-M5.3**: Item editing (modify, remove, adjust quantity) directly from cart
- **FR-M5.4**: Minimum order requirements displayed and enforced before checkout
- **FR-M5.5**: Cart synced across voice, text, and visual interfaces in real-time

### FR-M6: Customer Wallet and Privacy-First Identity (P0)
- **FR-M6.1**: Wallet creation with phone number verification (SMS code)
- **FR-M6.2**: Passwordless authentication using phone number + OTP for subsequent logins
- **FR-M6.3**: Wallet stores: payment methods, delivery addresses, dietary preferences, order history
- **FR-M6.4**: Customer contact info (phone, email) stored in Parcera-controlled database, not shared with restaurants
- **FR-M6.5**: Opt-in marketing preferences managed at wallet level (not per-restaurant)

### FR-M7: Order Placement (P0)
- **FR-M7.1**: Order type selection: pickup or delivery (if restaurant supports delivery)
- **FR-M7.2**: Pickup time selection: ASAP or scheduled time (within restaurant hours)
- **FR-M7.3**: Delivery address validation against restaurant delivery radius
- **FR-M7.4**: Special instructions field for entire order (e.g., "Ring doorbell", "Office building entrance")
- **FR-M7.5**: Order submitted to third-party POS API (Toast, Square, Clover) with all details

### FR-M8: Payment Processing (P0)
- **FR-M8.1**: Payment method management in wallet (add, remove, set default)
- **FR-M8.2**: Support credit/debit cards, mobile wallets (Apple Pay, Google Pay)
- **FR-M8.3**: Payment processing via integrated payment gateway (Authorize.Net, Stacks, or Adyen)
- **FR-M8.4**: Tip selection for delivery orders (percentage or custom amount)
- **FR-M8.5**: Payment confirmation screen with receipt accessible from order history
- **FR-M8.6**: Payment method and promo code data passed to POS system API; app supports features that POS API supports (no additional implementation required on Parcera side)

### FR-M9: Order History and Tracking (P0)
- **FR-M9.1**: Unified order history across all restaurants in wallet
- **FR-M9.2**: Order detail view with: items, restaurant, timestamp, total, order status
- **FR-M9.3**: Real-time order status updates from POS API (if supported): confirmed, preparing, ready, completed
- **FR-M9.4**: Reorder functionality from past orders (one-tap to add same items to cart)
- **FR-M9.5**: Order status polling frequency: every 30 seconds when order is active

### FR-M10: Favorites and Personalization (P1)
- **FR-M10.1**: Favorite restaurants (quick access from home screen)
- **FR-M10.2**: Favorite menu items (accessible across voice, text, and visual interfaces)
- **FR-M10.3**: "Reorder" voice command recognizes "my usual" or "last order from [Restaurant]"
- **FR-M10.4**: AI-powered recommendations based on order history and preferences
- **FR-M10.5**: Dietary preference filtering (set once in wallet, applied across all restaurants)

### FR-M11: Push Notifications (P0)
- **FR-M11.1**: Push notifications for order status changes (confirmed, preparing, ready, out for delivery)
- **FR-M11.2**: Notification sent by Parcera on behalf of restaurant (privacy-first model)
- **FR-M11.3**: Notification permission request at optimal time (after first order placed)
- **FR-M11.4**: In-app notification center for users who decline push permissions
- **FR-M11.5**: Notification settings customizable per event type (order updates, promotions, etc.)

### FR-M12: Voice-to-Text Handoff (P1)
- **FR-M12.1**: Seamless context preservation when switching from voice to text chat
- **FR-M12.2**: Voice session can be paused to view visual menu, then resumed
- **FR-M12.3**: Cart contents synchronized regardless of input modality
- **FR-M12.4**: Customer can start with text, switch to voice, and back without losing progress
- **FR-M12.5**: Visual confirmation prompt for voice orders before final submission

### FR-M13: Offline Mode and Network Handling (P1)
- **FR-M13.1**: Menu data cached locally for recently viewed restaurants
- **FR-M13.2**: Cart persisted locally if app crashes or network drops
- **FR-M13.3**: Order submission retries automatically when network restored (3 attempts, exponential backoff)
- **FR-M13.4**: Clear messaging when network unavailable: "You're offline. Order will be submitted when connection restores."
- **FR-M13.5**: Force refresh option to manually sync menu data and order status

### FR-M14: Platform Requirements (P0)
- **FR-M14.1**: React Native cross-platform development for MVP (single codebase, 30-40% faster time-to-market, 80-90% code reuse)
- **FR-M14.2**: iOS support: iOS 14+ (covers 95% of active devices)
- **FR-M14.3**: Android support: Android 8.0+ (API level 26, covers 90% of active devices)
- **FR-M14.4**: Responsive design for various screen sizes (phones and tablets)
- **FR-M14.5**: Accessibility: VoiceOver (iOS) and TalkBack (Android) support, high contrast mode
- **FR-M14.6**: Platform-specific optimizations applied where necessary (camera, push notifications, native payment SDKs)

### FR-M15: Multi-Language Support (P0)
- **FR-M15.1**: English and Spanish supported for MVP
- **FR-M15.2**: Language selection in settings (applies to UI, voice prompts, and chat)
- **FR-M15.3**: Menu item names and descriptions displayed in selected language (if translation available from Menu Management)
- **FR-M15.4**: Voice recognition and TTS in selected language
- **FR-M15.5**: Future support for additional languages (P2)

---

## Key Entities

### 1. **CustomerWallet**
- `wallet_id` (UUID, primary key)
- `phone_number` (string, unique, E.164 format)
- `email` (string, nullable, unique)
- `name` (string, nullable, customer chooses to provide or not)
- `dietary_preferences` (JSON array: vegetarian, vegan, gluten-free, etc.)
- `default_payment_method_id` (UUID, foreign key to PaymentMethod)
- `default_delivery_address_id` (UUID, foreign key to Address)
- `marketing_opt_in` (boolean, default false)
- `created_at`, `updated_at` (timestamps)

### 2. **PaymentMethod**
- `payment_method_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key)
- `type` (enum: 'card', 'apple_pay', 'google_pay')
- `card_last_four` (string, nullable)
- `card_brand` (string: 'Visa', 'Mastercard', etc., nullable)
- `expiry_month`, `expiry_year` (integers, nullable)
- `billing_address_id` (UUID, foreign key to Address, nullable)
- `payment_gateway_token` (string, tokenized payment method ID from gateway)
- `is_default` (boolean)
- `created_at` (timestamp)

### 3. **Address**
- `address_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key)
- `label` (string: "Home", "Work", "Mom's House")
- `street_address` (string)
- `city`, `state`, `zip_code` (strings)
- `latitude`, `longitude` (floats, for delivery radius calculation)
- `delivery_instructions` (string, nullable, e.g., "Ring doorbell")
- `is_default` (boolean)
- `created_at` (timestamp)

### 4. **MobileOrder**
- `order_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key to CustomerWallet)
- `restaurant_id` (UUID, foreign key to Restaurant)
- `order_number` (integer, unique per restaurant per day)
- `order_type` (enum: 'pickup', 'delivery')
- `items` (JSON array of OrderItem objects with modifiers)
- `subtotal`, `tax`, `delivery_fee`, `tip`, `total` (decimals)
- `pickup_time` (timestamp, nullable for ASAP orders)
- `delivery_address_id` (UUID, foreign key to Address, nullable for pickup)
- `special_instructions` (string, nullable)
- `payment_method_id` (UUID, foreign key)
- `payment_transaction_id` (string, from payment gateway)
- `payment_status` (enum: 'pending', 'approved', 'declined', 'refunded')
- `pos_order_id` (string, from third-party POS API)
- `order_status` (enum: 'pending', 'confirmed', 'preparing', 'ready', 'out_for_delivery', 'completed', 'cancelled')
- `submitted_to_pos_at`, `created_at`, `updated_at` (timestamps)
- `channel` (enum: 'voice', 'text_chat', 'visual', 'mixed' - for analytics)

### 5. **ConversationSession**
- `session_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key)
- `restaurant_id` (UUID, foreign key, nullable if not yet selected)
- `modality` (enum: 'voice', 'text', 'mixed')
- `conversation_log` (JSON array of messages with timestamps and speaker)
- `cart_snapshot` (JSON, cart contents at any point in conversation)
- `olivia_context` (JSON, Olivia.io conversation context for continuity)
- `started_at`, `ended_at` (timestamps)
- `resulted_in_order` (boolean, analytics flag)

### 6. **FavoriteItem**
- `favorite_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key)
- `restaurant_id` (UUID, foreign key)
- `menu_item_id` (UUID, foreign key to MenuItem from Menu Management)
- `modifiers` (JSON, saved customizations for this favorite)
- `nickname` (string, nullable, customer's name for this favorite: "My usual burger")
- `created_at` (timestamp)

### 7. **FavoriteRestaurant**
- `favorite_restaurant_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key)
- `restaurant_id` (UUID, foreign key)
- `created_at` (timestamp)

### 8. **PushNotification**
- `notification_id` (UUID, primary key)
- `wallet_id` (UUID, foreign key)
- `order_id` (UUID, foreign key, nullable for non-order notifications)
- `type` (enum: 'order_confirmed', 'order_preparing', 'order_ready', 'order_delivered', 'promotional')
- `title`, `body` (strings, notification content)
- `sent_at` (timestamp)
- `read_at` (timestamp, nullable)
- `push_token` (string, device-specific push notification token)

---

## Success Criteria

### Measurable Outcomes

1. **Order Completion Rate**: ≥80% of customers who add items to cart complete checkout (industry standard: 60-70%)
2. **Voice Ordering Adoption**: ≥30% of orders placed use voice input at some point in the ordering flow
3. **App Load Time**: <2 seconds from app launch to home screen on mid-range devices (iPhone 12, Samsung Galaxy S21)
4. **Order Submission Speed**: <5 seconds from "Place Order" tap to POS submission confirmation
5. **Voice Recognition Accuracy**: ≥75% first-attempt success rate for common menu items and commands
6. **Push Notification Delivery**: ≥95% of order status notifications delivered within 30 seconds of POS status change
7. **Reorder Usage**: ≥40% of repeat customers use reorder or favorites feature within first month
8. **Cart Abandonment Recovery**: <20% cart abandonment rate (lower than industry average of 30-40%)
9. **Average Order Time**: <4 minutes from app open to order confirmation for returning customers with saved payment/address
10. **Customer Retention**: ≥50% of first-time users place second order within 30 days
11. **Voice-to-Text Handoff**: <1 second lag when switching modalities, with 100% cart data preservation
12. **App Store Rating**: Target ≥4.5 stars on both iOS App Store and Google Play Store within 3 months of launch

### Key Performance Indicators (KPIs)
- **Orders per Active User per Month**: Target 4-6 orders (indicates high engagement)
- **Average Order Value**: Track to compare with IVR and kiosk channels
- **Voice vs Text vs Visual**: Monitor channel preference for UX optimization
- **Wallet Creation Rate**: ≥90% of users create wallet after first order
- **Push Notification Opt-In**: ≥70% of users enable push notifications
- **Favorites Saved**: Track how many items/restaurants users favorite (engagement signal)

---

## Assumptions

1. **Cross-Platform Development**: React Native chosen for MVP to maximize speed-to-market and code reuse (confirmed decision)
2. **Olivia.io Mobile SDK**: Olivia.io provides SDK or API for mobile app integration with same capabilities as IVR
3. **GPS Permissions**: Majority of users grant location permission for "restaurants near me" feature (fallback to manual address entry)
4. **Payment Gateway Mobile SDK**: Selected payment gateway (Authorize.Net, Stacks, Adyen) provides mobile SDK for tokenized payments
5. **Third-Party POS APIs**: Toast, Square, Clover APIs support mobile-originated orders with same contract as IVR/kiosk channels
6. **Push Notification Infrastructure**: AWS SNS, Firebase Cloud Messaging, or similar service used for cross-platform push notifications
7. **No Native Login Required**: Wallet creation with phone verification is sufficient; no traditional username/password login
8. **Single Restaurant Per Order**: MVP does not support multi-restaurant orders (DoorDash-style marketplace feature deferred to P2)
9. **English and Spanish Only**: MVP launches with two languages; additional languages added post-MVP based on market demand
10. **No In-App Social Features**: MVP does not include order sharing, group ordering, or social recommendations (P2 features)
11. **Delivery Handled by Restaurant**: App does not integrate with third-party delivery services (DoorDash Drive, etc.); restaurants handle own delivery
12. **Customer Wallet is Universal**: Single wallet works across all restaurants using Parcera platform
13. **Internet Connectivity Required**: App requires internet for order submission; offline mode caches data but cannot complete orders without network

---

## Open Questions

1. ~~**Native vs Cross-Platform**~~ - **RESOLVED**: React Native chosen for MVP
2. ~~**Split Payments and Promo Codes**~~ - **RESOLVED**: Payment features passed through to POS API (no additional Parcera implementation)
3. **Delivery Integration**: Will MVP integrate with third-party delivery services (DoorDash Drive, Uber Direct) or assume restaurants handle delivery? (Impacts feature scope significantly)
4. **Social Features**: Should MVP include any social features (sharing orders, group ordering, following friends)? (Deferred to P2 but affects data model)
5. **Loyalty Program**: Should MVP include basic loyalty points system or defer to P2? (Mentioned in constitution as cross-merchant opportunity)
6. **App Store ASO**: What are keyword targets for App Store Optimization (restaurant ordering, food delivery, voice ordering)? (Impacts app description and marketing)
7. **Analytics Tracking**: Which analytics platform for mobile (Firebase Analytics, Mixpanel, Amplitude, custom)? (Impacts SDK integration)
8. **Customer Support**: Should app include in-app customer support chat or direct users to phone support? (Affects support infrastructure)
9. **Rating and Reviews**: Should customers be able to rate restaurants and orders within the app? (Common feature but requires moderation)
10. **Tablet Optimization**: Should MVP optimize UI for tablets or focus on phone-first design? (Impacts UI complexity)

---

## Dependencies

### Upstream Dependencies (Must Exist First)
- **Feature 001 (Restaurant Management)**: App displays restaurants from Restaurant Management database
- **Feature 002 (Menu Management)**: App fetches menu data from Menu Management API
- **Feature 007 (POS Integration)**: App submits orders to third-party POS APIs
- **Feature 008 (Customer Identity & Wallet)**: Mobile app is primary interface for customer wallet creation and management
- **Olivia.io Mobile SDK/API**: Voice and text chat powered by Olivia.io
- **Payment Gateway Mobile SDK**: Payment processing for mobile transactions

### Downstream Dependencies (Will Use This Feature)
- **Feature 006 (Order Fulfillment)**: Mobile orders flow through same fulfillment workflow as other channels
- **Future Analytics Dashboard**: Mobile app usage metrics feed into business intelligence platform (P2)
- **Future Loyalty Program**: Mobile wallet enables cross-merchant loyalty points (P2)

### Infrastructure Dependencies
- Push notification service (Firebase Cloud Messaging, AWS SNS, etc.)
- App Store and Google Play Store accounts for distribution
- Mobile analytics platform (Firebase Analytics, Mixpanel, etc.)
- CDN for menu images and app assets (CloudFront, Cloudflare)
- Olivia.io API/SDK for mobile
- Payment gateway mobile SDK

---

## Constitution Alignment

This feature aligns with the Parcera Constitution as follows:

### Principle I: AI-First Architecture ✅
- Olivia.io voice AI is primary ordering modality, not an add-on
- Text chat ordering powered by same AI conversation engine
- AI-driven recommendations based on order history and preferences
- Seamless voice-to-text handoff demonstrates AI-first design

### Principle III: Privacy-First Customer Data ✅
- Customer wallet architecture ensures Parcera owns customer data
- Restaurants cannot access customer contact info (phone, email) directly
- Push notifications sent by Parcera on behalf of restaurants
- Order-ID-based notification routing prevents merchant spam
- Privacy-first model enables cross-restaurant loyalty without data leakage

### Principle IV: Omnichannel by Default ✅
- Mobile app is independent ordering channel working with third-party POS
- Shares menu data, order submission, and fulfillment with IVR and kiosk channels
- No requirement for Parcera POS hardware
- Customer wallet works across all channels seamlessly

### Principle V: Progressive Enhancement & MVP Discipline ✅
- P0 features: Voice ordering, visual browsing, wallet, order history, push notifications
- P1 features: Text chat, favorites, voice-to-text handoff, offline mode
- P2 features: Social features, loyalty program, advanced analytics, multi-restaurant orders
- Clear prioritization prevents scope creep during MVP development

---

## Validation Checklist

- [x] **User Stories**: 7 user stories defined with clear acceptance criteria and test scenarios
- [x] **Priorities**: All user stories marked P0 (MVP) or P1 (post-MVP)
- [x] **Functional Requirements**: 15 requirement groups covering all aspects
- [x] **Key Entities**: 8 entities defined with attributes
- [x] **Success Criteria**: 12 measurable outcomes with specific targets
- [x] **Edge Cases**: 12 edge cases documented with handling strategies
- [x] **Assumptions**: 13 assumptions documented covering platform, APIs, features
- [x] **Open Questions**: 10 questions flagged for stakeholder decision
- [x] **Dependencies**: Upstream (features 001, 002, 007, 008, Olivia.io, payment gateway) and downstream (feature 006, analytics, loyalty) mapped
- [x] **Constitution Alignment**: Explicitly mapped to principles I, III, IV, V with justification
- [x] **Privacy-First**: Customer wallet with Parcera-controlled data, no merchant access to PII
- [x] **Multi-Language**: English and Spanish for MVP (P0)
- [x] **Integration Contracts**: Third-party POS API, payment gateway, Olivia.io API
- [x] **Omnichannel**: Mobile app works independently with existing POS systems
- [x] **Clarifications Resolved**: All critical clarifications addressed (React Native platform, payment passthrough to POS)

---

**STATUS**: ✅ SPECIFICATION COMPLETE - Ready for `/speckit.plan` and `/speckit.tasks`

**Clarifications Resolved**:
1. ✅ **Platform Choice**: React Native cross-platform for MVP (30-40% faster time-to-market, single codebase)
2. ✅ **Payment Features**: Payment methods and promo codes passed through to POS API; Parcera supports what POS supports (no additional implementation)

**Next Steps**:
1. Create implementation plan with `/speckit.plan`
2. Generate tasks with `/speckit.tasks`
3. Coordinate with features 001, 002, 007, 008 for API contracts
4. Begin React Native project setup and Olivia.io SDK integration
