# Quickstart Guide: Multi-tenant Restaurant Management

**Feature**: 001-restaurant-management
**Target**: Backend developers onboarding to Parcera platform
**Time to Complete**: ~30 minutes

---

## Prerequisites

Before starting, ensure you have the following installed:

- **Python 3.11+** (verify: `python --version`)
- **PostgreSQL 14+** (verify: `psql --version`)
- **Redis 6+** (verify: `redis-cli --version`)
- **Git** (for repository clone)
- **curl or httpie** (for API testing)
- **Poetry** (Python dependency management): `pip install poetry`

---

## Quick Start (5 Minutes to Running Service)

### Step 1: Clone and Setup

```bash
# Clone repository
git clone https://github.com/parcera/restaurant-management.git
cd restaurant-management

# Install dependencies with Poetry
poetry install

# Activate virtual environment
poetry shell
```

### Step 2: Configure Environment

Create `.env` file in project root:

```bash
# Database Configuration
DATABASE_URL=postgresql://parcera_app:password@localhost:5432/parcera_dev

# Redis Configuration (for caching)
REDIS_URL=redis://localhost:6379/0

# JWT Configuration
JWT_SECRET_KEY=your-secret-key-change-in-production
JWT_ALGORITHM=HS256
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=30

# Application Settings
APP_ENV=development
DEBUG=true
LOG_LEVEL=INFO

# File Upload Settings
MAX_UPLOAD_SIZE_MB=2
UPLOAD_BUCKET=parcera-uploads-dev
```

**Security Note**: Never commit `.env` to version control. Use `.env.example` as template.

### Step 3: Initialize Database

```bash
# Create database
createdb parcera_dev

# Run migrations (creates all tables, RLS policies, indexes)
alembic upgrade head

# Seed test data (optional, creates sample tenants)
python scripts/seed_test_data.py
```

**Expected Output**:
```plaintext
INFO  [alembic.runtime.migration] Running upgrade -> 001_create_base_schema
INFO  [alembic.runtime.migration] Running upgrade 001 -> 002_create_rls_policies
INFO  [alembic.runtime.migration] Running upgrade 002 -> 003_create_indexes
✓ Database schema created
✓ RLS policies enabled on 6 tables
✓ 15 indexes created
✓ Test data seeded (2 tenants, 3 restaurants, 5 locations)
```

### Step 4: Start Development Server

```bash
# Start FastAPI server with hot reload
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**Expected Output**:
```plaintext
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     Started reloader process [12345] using StatReload
INFO:     Started server process [12346]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
```

### Step 5: Verify Installation

Open browser to http://localhost:8000/docs (Swagger UI).

You should see auto-generated API documentation with endpoints:
- `/v1/activation-codes/validate`
- `/v1/onboarding/wizard`
- `/v1/restaurants`
- `/v1/locations`

**Health Check**:
```bash
curl http://localhost:8000/health
```

**Expected Response**:
```json
{
  "status": "healthy",
  "database": "connected",
  "redis": "connected",
  "version": "1.0.0"
}
```

---

## Testing Tenant Isolation (Critical)

Row-Level Security (RLS) is the foundation of multi-tenancy. **Always test tenant isolation** before deploying.

### Automated RLS Tests

```bash
# Run RLS isolation test suite
pytest tests/test_tenant_isolation.py -v

# Expected output:
# test_tenant_cannot_see_other_tenant_restaurants PASSED
# test_tenant_cannot_update_other_tenant_locations PASSED
# test_tenant_cannot_delete_other_tenant_data PASSED
# test_rls_policy_enforcement PASSED
```

### Manual RLS Testing

**Step 1: Create Two Test Tenants**

```bash
# Create Tenant 1
curl -X POST http://localhost:8000/v1/admin/provisioning/requests \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "tenant_slug": "test-tenant-1",
    "tenant_name": "Test Tenant 1",
    "deployment_type": "shared"
  }'

# Create Tenant 2
curl -X POST http://localhost:8000/v1/admin/provisioning/requests \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -d '{
    "tenant_slug": "test-tenant-2",
    "tenant_name": "Test Tenant 2",
    "deployment_type": "shared"
  }'
```

**Step 2: Generate Activation Codes**

```bash
# Generate code for Tenant 1
curl -X POST http://localhost:8000/v1/admin/activation-codes \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -d '{
    "count": 1,
    "deployment_type": "shared",
    "emails": ["tenant1@example.com"]
  }'

# Save the returned code (e.g., ABCD-EF12-GH34)
```

**Step 3: Onboard Tenant 1**

```bash
# Validate activation code
curl -X POST http://localhost:8000/v1/activation-codes/validate \
  -H "Content-Type: application/json" \
  -d '{"code": "ABCD-EF12-GH34"}'

# Start onboarding wizard
curl -X POST http://localhost:8000/v1/onboarding/wizard \
  -H "Content-Type: application/json" \
  -d '{
    "activation_code": "ABCD-EF12-GH34",
    "restaurant_name": "Tenant 1 Restaurant",
    "contact_email": "contact@tenant1.com",
    "cuisine_type": "Italian"
  }'

# Save session_id from response
```

**Step 4: Complete Onboarding**

```bash
# Add location data
curl -X PATCH http://localhost:8000/v1/onboarding/wizard/{session_id} \
  -H "Content-Type: application/json" \
  -d '{
    "step": "location",
    "data": {
      "location_name": "Downtown",
      "street_address": "123 Main St",
      "city": "Boston",
      "state_province": "MA",
      "postal_code": "02108",
      "timezone": "America/New_York"
    }
  }'

# Set operating hours
curl -X PATCH http://localhost:8000/v1/onboarding/wizard/{session_id} \
  -H "Content-Type: application/json" \
  -d '{
    "step": "hours",
    "data": {
      "operating_hours": [
        {"day_of_week": 1, "opening_time": "11:00", "closing_time": "22:00"},
        {"day_of_week": 2, "opening_time": "11:00", "closing_time": "22:00"},
        {"day_of_week": 0, "is_closed": true}
      ]
    }
  }'

# Complete onboarding
curl -X POST http://localhost:8000/v1/onboarding/complete \
  -H "Content-Type: application/json" \
  -d '{"session_id": "{session_id}"}'

# Save access_token and tenant_id from response
```

**Step 5: Test Tenant Isolation**

```bash
# Set Tenant 1 token
TENANT1_TOKEN="<access_token_from_onboarding>"

# Create restaurant for Tenant 1
TENANT1_RESTAURANT_ID=$(curl -X POST http://localhost:8000/v1/restaurants \
  -H "Authorization: Bearer $TENANT1_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Tenant 1 Pizza",
    "contact_email": "pizza@tenant1.com"
  }' | jq -r '.id')

# Repeat onboarding for Tenant 2 (get TENANT2_TOKEN)

# Try to access Tenant 1's restaurant with Tenant 2's token (should fail)
curl -X GET http://localhost:8000/v1/restaurants/$TENANT1_RESTAURANT_ID \
  -H "Authorization: Bearer $TENANT2_TOKEN"

# Expected: 403 Forbidden or 404 Not Found (RLS blocks access)
```

**✓ Success Criteria**: Tenant 2 cannot see, update, or delete Tenant 1's data.

---

## Example API Calls

### Authentication Flow

**1. Validate Activation Code**

```bash
curl -X POST http://localhost:8000/v1/activation-codes/validate \
  -H "Content-Type: application/json" \
  -d '{"code": "ABCD-EF12-GH34"}'
```

**Response**:
```json
{
  "valid": true,
  "code": "ABCD-EF12-GH34",
  "deployment_type": "shared",
  "expiration_date": "2025-12-31T23:59:59Z",
  "intended_email": "owner@joespizza.com"
}
```

**2. Complete Onboarding (Get Access Token)**

```bash
curl -X POST http://localhost:8000/v1/onboarding/complete \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "7f3e8b2a-4c91-4d8e-9f1a-2b3c4d5e6f7g"
  }'
```

**Response**:
```json
{
  "tenant_id": "550e8400-e29b-41d4-a716-446655440000",
  "tenant_slug": "joes-pizza-grill",
  "restaurant_id": "7f3e8b2a-4c91-4d8e-9f1a-2b3c4d5e6f7g",
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "dashboard_url": "https://business.parcera.com/joes-pizza-grill/dashboard"
}
```

### Restaurant Management

**3. List Restaurants (Tenant-Scoped)**

```bash
curl -X GET http://localhost:8000/v1/restaurants \
  -H "Authorization: Bearer <access_token>"
```

**Response**:
```json
{
  "data": [
    {
      "id": "7f3e8b2a-4c91-4d8e-9f1a-2b3c4d5e6f7g",
      "tenant_id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "Joe's Pizza & Grill",
      "cuisine_type": "Italian",
      "status": "active",
      "branding_config": {
        "logo_url": null,
        "primary_color": "#FF6B00",
        "secondary_color": "#333333"
      },
      "created_at": "2025-11-03T10:00:00Z"
    }
  ],
  "pagination": {
    "total": 1,
    "limit": 20,
    "offset": 0,
    "has_more": false
  }
}
```

**4. Update Restaurant Branding**

```bash
curl -X PUT http://localhost:8000/v1/restaurants/{restaurant_id}/branding \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "primary_color": "#FF6B00",
    "secondary_color": "#333333",
    "welcome_message": "Welcome to Joe'\''s Pizza!"
  }'
```

### Location Management

**5. Add New Location**

```bash
curl -X POST http://localhost:8000/v1/restaurants/{restaurant_id}/locations \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Cambridge Location",
    "slug": "cambridge",
    "street_address": "456 Mass Ave",
    "city": "Cambridge",
    "state_province": "MA",
    "postal_code": "02139",
    "timezone": "America/New_York",
    "phone": "+16175552345"
  }'
```

**6. Update Operating Hours**

```bash
curl -X PUT http://localhost:8000/v1/locations/{location_id}/hours \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "hours": [
      {"day_of_week": 0, "is_closed": true},
      {"day_of_week": 1, "opening_time": "11:00", "closing_time": "22:00"},
      {"day_of_week": 2, "opening_time": "11:00", "closing_time": "22:00"},
      {"day_of_week": 3, "opening_time": "11:00", "closing_time": "22:00"},
      {"day_of_week": 4, "opening_time": "11:00", "closing_time": "22:00"},
      {"day_of_week": 5, "opening_time": "11:00", "closing_time": "23:00"},
      {"day_of_week": 6, "opening_time": "11:00", "closing_time": "23:00"}
    ]
  }'
```

**7. Add Special Hours (Holiday Closure)**

```bash
curl -X POST http://localhost:8000/v1/locations/{location_id}/special-hours \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "date": "2025-12-25",
    "is_closed": true,
    "reason": "Christmas Day - Closed",
    "override_type": "holiday"
  }'
```

**8. Check if Location is Open**

```bash
curl -X GET "http://localhost:8000/v1/locations/{location_id}/hours/check" \
  -H "Authorization: Bearer <access_token>"
```

**Response**:
```json
{
  "location_id": "abc123...",
  "is_open": true,
  "current_time": "2025-11-03T14:30:00-05:00",
  "status_message": "Open until 10:00 PM",
  "next_opening": null,
  "special_hours_active": false
}
```

---

## Common Troubleshooting

### Database Connection Errors

**Issue**: `psycopg2.OperationalError: could not connect to server`

**Solution**:
```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# If not running, start it
sudo systemctl start postgresql

# Verify connection
psql -U parcera_app -d parcera_dev -h localhost
```

### RLS Policy Not Enforcing

**Issue**: Tenant A can see Tenant B's data

**Diagnosis**:
```sql
-- Check if RLS is enabled
SELECT tablename, rowsecurity
FROM pg_tables
WHERE schemaname = 'public'
  AND tablename = 'restaurants';

-- Should return: rowsecurity = true
```

**Solution**:
```bash
# Re-run RLS migration
alembic downgrade -1
alembic upgrade head

# Verify RLS policies exist
psql parcera_dev -c "\d restaurants"
# Should show policies: tenant_isolation_policy
```

### JWT Token Expired

**Issue**: `401 Unauthorized` with message "Token expired"

**Solution**:
```bash
# Use refresh token to get new access token
curl -X POST http://localhost:8000/v1/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{"refresh_token": "<refresh_token>"}'
```

### Activation Code Already Used

**Issue**: `410 Gone` with message "Activation code has already been used"

**Solution**:
```bash
# Request new activation code (admin endpoint)
curl -X POST http://localhost:8000/v1/admin/activation-codes \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -d '{
    "count": 1,
    "deployment_type": "shared",
    "emails": ["newuser@example.com"]
  }'

# Or resend existing code to email
curl -X POST http://localhost:8000/v1/activation-codes/resend \
  -d '{"email": "owner@joespizza.com"}'
```

### Migration Failures

**Issue**: `alembic.util.exc.CommandError: Target database is not up to date`

**Solution**:
```bash
# Check current migration version
alembic current

# Check pending migrations
alembic history

# Force migration to specific version (use cautiously)
alembic upgrade <revision_id>

# If completely broken, reset (DEVELOPMENT ONLY)
alembic downgrade base
alembic upgrade head
```

---

## Development Workflow

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage report
pytest --cov=app --cov-report=html

# Run specific test file
pytest tests/test_restaurants.py -v

# Run tests matching pattern
pytest -k "test_tenant_isolation"
```

### Database Migrations

```bash
# Create new migration (auto-detect changes)
alembic revision --autogenerate -m "Add new column to restaurants"

# Review generated migration in alembic/versions/

# Apply migration
alembic upgrade head

# Rollback last migration
alembic downgrade -1
```

### Code Quality

```bash
# Format code with Black
black app/ tests/

# Lint with Ruff
ruff check app/ tests/

# Type checking with mypy
mypy app/

# Pre-commit hooks (auto-format on commit)
pre-commit install
```

### Debugging

**Enable SQL Logging**:

In `.env`, set:
```bash
DATABASE_ECHO=true
```

This logs all SQL queries to console (useful for debugging RLS policies).

**Interactive Debugging**:

Add breakpoint in code:
```python
import pdb; pdb.set_trace()
```

Or use VS Code debugger:
```json
// .vscode/launch.json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "FastAPI",
      "type": "python",
      "request": "launch",
      "module": "uvicorn",
      "args": ["app.main:app", "--reload"],
      "jinja": true
    }
  ]
}
```

---

## Production Deployment Checklist

Before deploying to production:

- [ ] Change `JWT_SECRET_KEY` to cryptographically secure random string
- [ ] Set `DEBUG=false` in `.env`
- [ ] Configure production database connection (not localhost)
- [ ] Enable HTTPS (TLS certificates)
- [ ] Set up database backups (daily minimum)
- [ ] Configure log aggregation (CloudWatch, Datadog, etc.)
- [ ] Enable rate limiting on public endpoints
- [ ] Run RLS isolation tests on production database (read-only)
- [ ] Set up monitoring alerts (Prometheus, Grafana)
- [ ] Configure CDN for static assets (logo uploads)
- [ ] Review security headers (CORS, CSP, HSTS)
- [ ] Enable database connection pooling (PgBouncer)

---

## Additional Resources

### Documentation

- **API Reference**: http://localhost:8000/docs (Swagger UI)
- **Data Model**: `specs/001-restaurant-management/data-model.md`
- **Architecture Decisions**: `specs/001-restaurant-management/research.md`

### Database Tools

**PgAdmin** (GUI for PostgreSQL):
```bash
# Install
sudo apt install pgadmin4  # Linux
brew install --cask pgadmin4  # macOS

# Connect to parcera_dev database
# Host: localhost, Port: 5432, User: parcera_app
```

**psql Commands**:
```bash
# List all tables
\dt

# Describe table structure
\d restaurants

# Show RLS policies
\d+ restaurants

# Run query
SELECT * FROM tenants;
```

### Helpful Scripts

**Generate Activation Code (Development)**:
```python
# scripts/generate_dev_code.py
import random
import string

def generate_code():
    chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'  # No ambiguous chars
    parts = [''.join(random.choices(chars, k=4)) for _ in range(3)]
    return '-'.join(parts)

print(generate_code())  # e.g., ABCD-EF12-GH34
```

**Inspect JWT Token**:
```bash
# Decode JWT (without verification, for debugging)
echo "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." | base64 -d
```

**Reset Development Database**:
```bash
# WARNING: Deletes all data
dropdb parcera_dev
createdb parcera_dev
alembic upgrade head
python scripts/seed_test_data.py
```

---

## Next Steps

Now that you have the service running:

1. **Explore the API**: Use Swagger UI at http://localhost:8000/docs to test endpoints
2. **Review Data Model**: Read `data-model.md` to understand database schema
3. **Study RLS Policies**: Examine `alembic/versions/002_create_rls_policies.py`
4. **Implement Features**: Refer to `spec.md` for functional requirements
5. **Write Tests**: Add tests for your features in `tests/`

**Questions?** Contact the Parcera Platform Team or check the project Wiki.

---

**End of Quickstart Guide**
