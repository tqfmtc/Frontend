# Feature Specification: Sales Portal & Pre-Sale Provisioning

**Feature Branch**: `016-sales-portal`
**Created**: 2025-10-29
**Status**: Draft
**Input**: User description: "Sales Portal & Pre-Sale Provisioning - Web-based portal for sales team (salesperson and dispatcher personas) to provision new restaurant tenants before on-site visit. Automated web scraping of restaurant website for business info, menu, hours, and contact details. One-click tenant or branch creation (detect if restaurant chain is existing customer). Automatic provisioning of IVR number, kiosk configuration, and mobile app demo instance. Contract signing workflow with e-signature and 30-day risk-free trial activation. Email-based order delivery fallback until POS integration token obtained. Sales pipeline management with lead tracking, demo scheduling, and conversion analytics. Role-based access for sales team with territory management."

## User Scenarios & Testing

### User Story 1 - Automated Restaurant Data Import (Priority: P0)

Salesperson enters restaurant name or website URL, system automatically scrapes public information (menu, hours, contact info, location, photos) and pre-populates tenant creation form, allowing quick review and one-click provisioning.

**Why this priority**: Core value proposition. Without automated import, manual data entry takes hours and is error-prone. This enables rapid pre-sales provisioning and immediate demo readiness.

**Independent Test**: Enter restaurant URL, verify system extracts menu items, business hours, contact info, and location. Edit any incorrect data, click "Create Tenant", verify tenant created with IVR number assigned.

**Acceptance Scenarios**:
1. **Given** salesperson enters restaurant website URL, **When** scraping completes, **Then** form pre-populates with business name, address, phone, hours, and menu items with 80%+ accuracy
2. **Given** restaurant has menu PDF on website, **When** OCR processes PDF, **Then** menu items extracted with categories, prices, and descriptions
3. **Given** scraped data is incomplete, **When** salesperson reviews, **Then** missing fields highlighted with prompts to manually enter before provisioning
4. **Given** restaurant website uses JavaScript-heavy menu display, **When** scraper accesses page, **Then** system renders JavaScript and extracts dynamic content successfully

---

### User Story 2 - Tenant vs Branch Detection & Creation (Priority: P0)

System detects if restaurant is part of existing chain (by business name, domain, or parent company), offers to create as new branch under existing tenant or new standalone tenant, automatically inherits chain-level settings if branch.

**Why this priority**: Critical for correct data model. Wrong tenant structure breaks billing, analytics, and multi-location management. Must get this right at provisioning.

**Independent Test**: Search for "McDonald's - Downtown" when "McDonald's Corporation" already exists as tenant, verify system suggests branch creation, create branch and confirm inherits chain menu and branding.

**Acceptance Scenarios**:
1. **Given** restaurant name matches existing tenant name pattern (e.g., "Pizza Hut - Location"), **When** salesperson clicks "Create", **Then** system prompts "Add as branch to existing Pizza Hut tenant?"
2. **Given** salesperson creates branch, **When** branch is provisioned, **Then** branch inherits parent tenant's menu template, loyalty program, and branding with option to customize
3. **Given** restaurant is new standalone business, **When** no tenant match found, **Then** system creates new tenant with unique tenant_id and full configuration
4. **Given** salesperson manually overrides detection, **When** they select "Create as new tenant", **Then** system allows override with confirmation prompt

---

### User Story 3 - Automated Demo Environment Provisioning (Priority: P0)

One-click button provisions complete demo environment: IVR phone number with voice menu, kiosk configuration with QR code, mobile app preview instance, all pre-configured with restaurant's menu and branding before salesperson arrives on-site.

**Why this priority**: Demo-ready environment is sales team's #1 need. Without this, no effective on-site demonstration. Enables "show, not tell" selling.

**Independent Test**: Click "Provision Demo", verify IVR number assigned and callable with restaurant's menu, kiosk QR code generated and functional, mobile app accessible via link with restaurant branding.

**Acceptance Scenarios**:
1. **Given** tenant created, **When** salesperson clicks "Provision Demo Environment", **Then** system assigns toll-free IVR number, configures Olivia.io voice menu with restaurant's menu items, and displays number within 30 seconds
2. **Given** IVR provisioned, **When** salesperson calls IVR number, **Then** voice greeting uses restaurant name and menu items are orderable via voice
3. **Given** kiosk provisioning requested, **When** system generates configuration, **Then** QR code created linking to web-based kiosk demo with restaurant menu and branding
4. **Given** mobile app provisioned, **When** salesperson accesses app demo link, **Then** app displays restaurant in marketplace with full menu, ordering enabled in demo mode (no payment processing)

---

### User Story 4 - Contract Signing & Trial Activation (Priority: P1)

Salesperson sends e-signature contract link to restaurant owner via email or SMS during on-site meeting, owner signs on tablet or phone, system automatically activates 30-day risk-free trial with countdown clock and billing hold.

**Why this priority**: Closes the sale on-site. E-signature removes friction, 30-day trial removes risk. Critical for conversion but can be done manually initially.

**Independent Test**: Send contract to test email, sign on mobile device, verify trial activated with "Trial ends on [date]" banner in restaurant portal.

**Acceptance Scenarios**:
1. **Given** salesperson completes tenant setup, **When** they click "Send Contract", **Then** email with e-signature link sent to restaurant owner with contract terms and 30-day free trial details
2. **Given** owner receives email, **When** they open link and review contract, **Then** contract displays with terms, pricing, trial period, and signature field
3. **Given** owner signs contract, **When** signature submitted, **Then** trial activates immediately, restaurant portal access granted, countdown timer shows days remaining
4. **Given** trial expires without cancellation, **When** 30 days pass, **Then** system automatically converts to paid subscription and processes first billing

---

### User Story 5 - Email-Based Order Delivery Fallback (Priority: P1)

For restaurants without immediate POS integration token, system sends order details to restaurant's public email address with order summary, customer info, and fulfillment instructions until POS integration completed.

**Why this priority**: Allows restaurant to receive orders immediately during trial, even before POS token obtained. Removes blocker for trial activation.

**Independent Test**: Place test order via IVR, verify email sent to restaurant with order details, customer contact, items ordered, total, and pickup/delivery instructions.

**Acceptance Scenarios**:
1. **Given** restaurant has no POS token configured, **When** customer places order, **Then** order details emailed to restaurant's configured email address within 30 seconds
2. **Given** order email sent, **When** restaurant opens email, **Then** displays order #, customer name/phone, items with modifications, total amount, pickup time, and "Reply to accept" instruction
3. **Given** restaurant receives email order, **When** POS integration later configured, **Then** system automatically switches from email to POS order delivery
4. **Given** email delivery fails, **When** email bounces, **Then** salesperson notified via portal alert to verify restaurant email address

---

### User Story 6 - Sales Pipeline & Territory Management (Priority: P1)

Sales manager views pipeline dashboard showing all leads by stage (prospecting, demo scheduled, contract sent, trial active, converted), assigns territories to salespeople, tracks conversion metrics and revenue forecasts.

**Why this priority**: Sales team management and accountability. Required for scaling sales org but not needed for individual salesperson function.

**Independent Test**: Create 3 leads at different stages, assign to salesperson, verify manager sees pipeline with stages, conversion rates, and territory assignments.

**Acceptance Scenarios**:
1. **Given** sales manager accesses dashboard, **When** they view pipeline, **Then** sees all leads grouped by stage with counts, conversion percentages, and average time-in-stage
2. **Given** manager assigns territory (ZIP codes or regions), **When** new lead created in territory, **Then** automatically assigned to territory owner with notification
3. **Given** salesperson has assigned leads, **When** they log in, **Then** sees only their leads filtered by territory with action items (schedule demo, send contract, check-in)
4. **Given** trial converts to paid, **When** billing activates, **Then** lead marked "Converted" and appears in salesperson's commission report

---

### Edge Cases

- What if restaurant website has no menu (brick-and-mortar only)? Scraper extracts basic business info, prompts salesperson to manually enter menu or schedule menu photography appointment.
- What if chain detection creates false positive (e.g., "Broadway Pizza" matches "Pizza Hut")? Salesperson can override detection and manually select "Create new tenant" with confirmation.
- What if IVR provisioning fails due to phone number pool exhaustion? System queues provisioning request, notifies salesperson via email when number assigned (typically within 1 hour).
- What if restaurant owner doesn't sign contract within 7 days? Automated reminder emails sent at day 3, 5, 7 with escalation to salesperson. Demo environment remains active for 14 days.
- What if POS token is obtained mid-trial? System automatically switches from email delivery to POS integration, retroactively sends order history to POS if supported.
- What if salesperson provisions duplicate tenant by mistake? Admin portal allows tenant merge with conflict resolution for orders, menu items, and customer data.

## Requirements

### Functional Requirements

#### Restaurant Data Import & Web Scraping
- **FR-001**: Portal MUST accept restaurant website URL or business name as input for automated data extraction
- **FR-002**: Web scraper MUST extract business name, address, phone, hours of operation, and menu items from restaurant website HTML/PDF
- **FR-003**: System MUST use OCR service (Tesseract-based custom solution or Microsoft Azure Cognitive Services Document Intelligence) to extract menu data from PDF files or menu images on website
- **FR-003a**: System MUST use GenAI (GPT-4 or similar) to clean and enhance extracted menu data including structuring items into categories, identifying modifiers/toppings/options, linking related items, and correcting OCR errors
- **FR-004**: Portal MUST display scraped data in review form with editable fields for salesperson correction before provisioning
- **FR-005**: System MUST flag incomplete or low-confidence data (below 80% accuracy threshold) with visual indicators requiring manual review
- **FR-006**: Scraper MUST handle JavaScript-rendered websites by executing JavaScript before extraction (headless browser capability)

#### Tenant vs Branch Detection
- **FR-007**: System MUST search existing tenants by business name, domain, and parent company when new restaurant entered
- **FR-008**: System MUST suggest branch creation when name pattern matches existing tenant (e.g., "Brand - Location" pattern)
- **FR-009**: Branch creation MUST inherit parent tenant's menu template, loyalty program settings, and branding configuration
- **FR-010**: System MUST allow salesperson to override detection and force new tenant creation with confirmation prompt
- **FR-011**: Portal MUST display tenant hierarchy (parent → branches) in tree view for multi-location chains

#### Demo Environment Provisioning
- **FR-012**: System MUST provision toll-free IVR number from available pool and assign to restaurant within 30 seconds of request
- **FR-013**: IVR provisioning MUST configure Olivia.io voice menu with restaurant's name, menu items, and ordering flow
- **FR-014**: System MUST generate kiosk configuration with QR code linking to web-based kiosk demo pre-loaded with restaurant menu
- **FR-015**: Mobile app provisioning MUST create restaurant instance in marketplace with full menu and demo-mode ordering (no payment processing)
- **FR-016**: Portal MUST display "Demo Environment" status panel showing IVR number, kiosk QR code, and mobile app link after provisioning
- **FR-017**: Demo environment MUST remain active for 14 days after provisioning with automatic deactivation if trial not started

#### Contract Signing & Trial Activation
- **FR-018**: Portal MUST generate e-signature contract with restaurant name, pricing terms, trial period (30 days), and legal terms
- **FR-019**: System MUST send contract link via email or SMS to restaurant owner with signing instructions
- **FR-020**: E-signature interface MUST support signature capture on mobile devices (touch/stylus) and desktop (mouse)
- **FR-021**: System MUST activate trial immediately upon contract signature with trial_end_date = signature_date + 30 days
- **FR-022**: Restaurant portal MUST display trial status banner with countdown ("X days remaining in free trial")
- **FR-023**: System MUST send trial reminder emails at 7 days remaining, 3 days remaining, and day of expiration
- **FR-024**: System MUST automatically convert trial to paid subscription on day 31 if not cancelled, processing first billing

#### Email-Based Order Delivery
- **FR-025**: System MUST send order details to restaurant's configured email address when POS integration token not available
- **FR-026**: Order email MUST include order number, customer name/phone, items with modifications, total amount, pickup/delivery time, and fulfillment instructions
- **FR-027**: System MUST track email delivery status and retry up to 3 times if delivery fails
- **FR-028**: Portal MUST alert salesperson if email delivery fails after 3 attempts with prompt to verify email address
- **FR-029**: System MUST automatically switch from email delivery to POS integration when token configured during trial
- **FR-030**: System MUST provide order history export (CSV) for restaurant to manually enter into POS if needed

#### Sales Pipeline & Territory Management
- **FR-031**: Portal MUST track lead stages: Prospecting, Demo Scheduled, Demo Complete, Contract Sent, Trial Active, Converted, Lost
- **FR-032**: Sales manager MUST be able to assign territories (ZIP codes, cities, or regions) to salespeople
- **FR-033**: System MUST auto-assign new leads to salesperson based on restaurant location matching territory
- **FR-034**: Dashboard MUST display pipeline metrics: leads by stage, conversion rates, average time-in-stage, and revenue forecast
- **FR-035**: Salespeople MUST see only their assigned leads and territories with action items and next steps
- **FR-036**: System MUST track salesperson commission based on converted trials with revenue attribution

#### Personas & Role-Based Access
- **FR-037**: Portal MUST support two sales team personas: Salesperson (provisions tenants) and Dispatcher (supports salesperson remotely)
- **FR-038**: Dispatcher MUST have same provisioning permissions as Salesperson plus ability to assist multiple salespeople simultaneously
- **FR-039**: Sales Manager MUST have read access to all leads and territories plus ability to reassign leads and manage team
- **FR-040**: Admin MUST have full access including tenant merge, contract override, and billing configuration

### Key Entities

- **Lead**: Sales opportunity with lead_id, restaurant_name, website_url, contact_name, contact_email, contact_phone, stage (enum), assigned_salesperson_id, territory_id, created_date, last_activity_date, demo_scheduled_date, contract_sent_date, trial_start_date, converted_date, lost_reason
- **ScrapedRestaurantData**: Imported data with scrape_id, lead_id, source_url, business_name, address, phone, hours_of_operation (JSON), menu_items (array), photos (array), confidence_score (0-100), requires_review (boolean), scraped_date
- **DemoEnvironment**: Provisioned resources with demo_id, lead_id, ivr_phone_number, ivr_provisioned_date, kiosk_qr_code_url, mobile_app_demo_url, status (active/expired), expiration_date (14 days from provision)
- **Contract**: E-signature document with contract_id, lead_id, sent_date, signed_date, signer_name, signer_email, signature_data (base64), trial_end_date, contract_status (pending/signed/expired), contract_pdf_url
- **Territory**: Sales assignment with territory_id, name, zip_codes (array), cities (array), assigned_salesperson_id, lead_count, conversion_rate, monthly_revenue
- **SalesMetrics**: Performance tracking with metric_id, salesperson_id, period (month), leads_created, demos_scheduled, demos_completed, contracts_sent, trials_started, conversions, revenue, commission_amount

## Success Criteria

- **SC-001**: Salesperson can provision demo-ready restaurant tenant in under 10 minutes from URL entry to IVR callable
- **SC-002**: Web scraper achieves 80%+ accuracy for menu extraction requiring minimal manual correction
- **SC-003**: 70% of restaurant owners sign contract during on-site meeting (same day as demo)
- **SC-004**: Trial-to-paid conversion rate reaches 40% within first 3 months of launch
- **SC-005**: Email order delivery fallback enables 100% of trial restaurants to receive orders immediately without POS token
- **SC-006**: Sales pipeline dashboard reduces manager time spent tracking leads by 50% (vs manual spreadsheets)
- **SC-007**: Automated provisioning eliminates 95% of post-sale technical onboarding support tickets
- **SC-008**: Territory auto-assignment ensures new leads get salesperson contact within 24 hours
- **SC-009**: Chain detection accuracy prevents 90% of duplicate tenant creation errors
- **SC-010**: Demo environment provisioning success rate exceeds 98% (less than 2% require manual intervention)

## Assumptions

1. **Web Scraping Legality**: Restaurant websites are public and scraping for business purposes is legally permissible. Assumption: Scraping limited to publicly available business information (no authentication bypass).
2. **IVR Number Availability**: Toll-free number pool has sufficient capacity for expected provisioning volume. Assumption: 100+ numbers available per month minimum.
3. **E-Signature Compliance**: Digital signatures meet legal requirements in target jurisdictions. Assumption: Using established e-signature provider (DocuSign, Adobe Sign) meeting ESIGN Act requirements.
4. **Email Delivery Reliability**: Restaurant email addresses are valid and monitored. Assumption: 90%+ delivery success rate, restaurants check email at least daily.
5. **Trial Cancellation Process**: 30-day trial cancellation requires explicit action (not automatic). Assumption: Restaurant must actively cancel, otherwise converts to paid.
6. **Menu Data Accuracy**: OCR (Tesseract or Azure Cognitive Services) combined with GenAI post-processing achieves 80%+ accuracy for menu extraction. Assumption: Manual correction by salesperson acceptable for remaining 20%, GenAI cleanup significantly reduces manual work.
7. **POS Token Timeline**: Most restaurants provide POS integration token within 7-14 days of trial start. Assumption: Email fallback sufficient for first 2 weeks.
8. **Salesperson Training**: Sales team trained on portal within 2 hours. Assumption: UI intuitive enough for non-technical users.
9. **Chain Detection Accuracy**: Business name pattern matching achieves 85%+ accuracy. Assumption: Manual override available for edge cases.
10. **Demo Environment Lifespan**: 14-day demo expiration sufficient for sales cycle. Assumption: Most contracts signed within 7 days of demo.

## Constitution Alignment

### Principle I: AI-First Architecture
- Olivia.io IVR automatically provisioned with restaurant's menu for immediate voice ordering demo
- Menu extraction uses OCR/ML for automated data import from PDFs and images

### Principle II: Multi-Tenancy by Design
- Branch vs tenant detection ensures correct multi-tenancy structure from day one
- Chain-level settings inherited by branches automatically

### Principle III: Privacy-First Customer Data
- Pre-sales provisioning does not involve customer PII (restaurant business data only)
- Demo orders use test data, no real customer information exposed

### Principle V: Progressive Enhancement & MVP Discipline
- **P0**: Automated import, tenant creation, demo provisioning, email order fallback (FR-001 to FR-030)
- **P1**: Contract signing, trial activation, sales pipeline, territory management (FR-031 to FR-040)
- **P2**: Advanced analytics, revenue forecasting, commission automation

### Principle VI: Network Effects & Platform Thinking
- Sales portal accelerates restaurant onboarding, growing platform supply side
- Faster provisioning → more restaurants → more customer choice → network flywheel

## Dependencies

### Internal Dependencies
- **Restaurant Management (spec 001)**: Tenant and branch creation APIs
- **Menu Management (spec 002)**: Menu import and OCR integration for scraped data
- **IVR Voice Ordering (spec 003)**: IVR number provisioning and Olivia.io configuration
- **Kiosk Ordering (spec 004)**: Kiosk configuration and QR code generation
- **Mobile App (spec 005)**: Restaurant marketplace demo instance
- **POS Integration (spec 007)**: POS token configuration and email-to-POS migration
- **Admin Dashboard (spec 009)**: Restaurant portal access for trial restaurants

### External Dependencies
- **Web Scraping Service**: Third-party scraper or headless browser (Puppeteer, Playwright) for website data extraction
- **OCR Service**: Menu text extraction from PDF/images (custom Tesseract-based solution or Microsoft Azure Cognitive Services Document Intelligence)
- **GenAI Service**: Menu data cleaning, structuring, and enhancement (OpenAI GPT-4, Azure OpenAI, or similar LLM for item categorization, modifier detection, and relationship mapping)
- **Phone Number Provider**: Toll-free number provisioning API (Twilio, Bandwidth)
- **E-Signature Platform**: Contract signing service (DocuSign, Adobe Sign, HelloSign)
- **Email Delivery Service**: Transactional email for contract links and order notifications (SendGrid, AWS SES)

## Future Considerations

- **Automated Lead Generation**: Scrape business directories (Yelp, Google Maps) to auto-create leads for outreach
- **Video Demo Recording**: Record IVR and kiosk demos for email follow-up with restaurant owners
- **Multi-Language Support**: Provision demo environments in restaurant's primary language (Spanish, Chinese, etc.)
- **Restaurant Analytics Preview**: Show restaurant their potential order volume based on similar restaurants in platform
- **Mobile Sales App**: Native iOS/Android app for salespeople with offline provisioning capability
- **Integration Marketplace**: Pre-built connectors for 50+ POS systems to streamline token configuration
- **Automated Contract Negotiation**: Dynamic pricing based on restaurant size, volume projections, and competitive analysis

---

**Validation Checklist**: See [checklists/requirements.md](checklists/requirements.md)
