# Feature Specification: Extension Marketplace & Feature Toggles

**Feature Branch**: `020-extension-marketplace`
**Created**: 2025-10-30
**Status**: Draft
**Constitution Alignment**: Principles V (MVP Discipline), VI (Platform Thinking)

---

## Overview

Restaurant owner marketplace for discovering, enabling, and managing premium features through one-click activation. Provides upsell opportunities for KDS, Inventory, Loyalty, Delivery, Analytics, and Table Management extensions. Supports instant feature toggles, automatic billing integration with prorated charges, dependency validation, per-location configuration, and free trial periods. Core SaaS monetization mechanism enabling tiered pricing (Basic/Pro/Enterprise) and feature-based revenue growth.

**Core Value**: Enables platform revenue expansion through feature upsells while giving restaurants flexibility to pay only for features they need. Reduces sales friction with self-service activation and free trials.

---

## User Scenarios & Testing

### User Story 1 - Browse and Enable Premium Feature (Priority: P0)

**As a** restaurant owner on Basic plan
**I want to** browse available premium features and enable one with a click
**So that** I can add capabilities as my business grows without sales calls

**Why this priority**: Core monetization mechanism. Without marketplace, no upsell path exists.

**Independent Test**: Can be fully tested by: (1) owner accesses Extensions marketplace, (2) views KDS feature with pricing, (3) clicks "Enable", (4) confirms billing, (5) feature activates immediately. Delivers standalone revenue generation value.

**Acceptance Scenarios**:

1. **Given** owner on Basic plan views Extensions marketplace, **When** page loads, **Then** displays available extensions: KDS ($49/mo), Inventory ($29/mo), Loyalty ($39/mo), Delivery ($59/mo), Advanced Analytics ($19/mo), Table Management ($25/mo) - each with description, features list, pricing
2. **Given** owner clicks on KDS extension, **When** detail page opens, **Then** shows: full feature description, pricing ($49/month prorated), what's included (unlimited displays, order routing, prep time tracking), "Start Free Trial" button (14 days), dependency check (none for KDS)
3. **Given** owner clicks "Start Free Trial", **When** confirmation dialog displays, **Then** shows: "14-day free trial starts today, billing begins [date] at $49/month. Cancel anytime." with "Confirm" and "Cancel" buttons
4. **Given** owner confirms activation, **When** system processes, **Then** enables KDS feature instantly, displays success message "KDS activated! Set up your first display in Settings", sends confirmation email, schedules billing for end of trial
5. **Given** KDS enabled, **When** owner navigates to Settings, **Then** KDS configuration options now visible with setup wizard

---

### User Story 2 - Validate Feature Dependencies (Priority: P0)

**As a** restaurant owner trying to enable Loyalty feature
**I want** the system to check if required features are enabled
**So that** I don't enable features that won't work without dependencies

**Why this priority**: Prevents customer frustration and support issues from enabling incompatible features.

**Independent Test**: Can be fully tested by: (1) owner without Customer Identity enabled tries to enable Loyalty, (2) system detects missing dependency, (3) displays warning with option to enable both, (4) owner enables both in one action. Delivers value through error prevention.

**Acceptance Scenarios**:

1. **Given** owner clicks "Enable" on Loyalty & Rewards extension, **When** system checks dependencies, **Then** validates that Customer Identity feature (Spec 008) is enabled as prerequisite
2. **Given** Customer Identity is NOT enabled, **When** dependency check fails, **Then** system displays: "Loyalty requires Customer Identity to track customer accounts. Enable both features? Customer Identity: included in Basic plan (free). Loyalty: $39/month after 14-day trial."
3. **Given** owner confirms enabling both, **When** activation proceeds, **Then** system enables Customer Identity first, then Loyalty, displays success for both, configures integration between features
4. **Given** owner has Customer Identity enabled, **When** they enable Loyalty, **Then** dependency check passes, activation proceeds without additional prompts
5. **Given** owner tries to disable Customer Identity, **When** Loyalty is enabled, **Then** system blocks with error: "Cannot disable Customer Identity while Loyalty is active. Disable Loyalty first."

---

### User Story 3 - Manage Free Trial and Billing (Priority: P1)

**As a** restaurant owner using feature trial
**I want to** see trial status and billing start date
**So that** I can cancel before charges if feature doesn't meet needs

**Why this priority**: Transparent billing builds trust. Important for customer satisfaction but not blocking for feature enable/disable.

**Independent Test**: Can be fully tested by: (1) owner starts KDS trial, (2) views "My Extensions" page showing trial countdown, (3) cancels before trial ends, (4) no charge occurs. Delivers value through billing transparency.

**Acceptance Scenarios**:

1. **Given** owner has active KDS trial, **When** they view "My Extensions" page, **Then** displays: KDS card with "Trial - 10 days remaining", trial end date, "Cancel Trial" button, "Billing starts [date] at $49/mo"
2. **Given** trial period ends, **When** 14 days elapse, **Then** system automatically: starts billing at $49/month, updates status to "Active - Paid", sends invoice email, charges payment method on file
3. **Given** owner clicks "Cancel Trial" on day 5, **When** confirmation dialog appears, **Then** shows: "Cancel KDS trial? You'll lose access immediately. Data will be retained for 30 days if you reactivate.", owner confirms, system disables feature, stops trial, no charges occur
4. **Given** trial cancelled, **When** owner views cancelled feature, **Then** shows: "Trial Cancelled", "Reactivate" button (starts new trial if available or begins paid subscription)
5. **Given** owner starts second trial (if allowed per business rules), **When** they activate same feature again, **Then** system determines if second trial permitted or requires paid activation immediately

---

### User Story 4 - Configure Features Per Location (Priority: P1)

**As a** multi-location restaurant owner
**I want to** enable different features for different branches
**So that** I only pay for features each location needs

**Why this priority**: Cost optimization for multi-location businesses but not essential for single-location operators.

**Independent Test**: Can be fully tested by: (1) owner with 3 locations enables KDS for Location A only, (2) KDS appears in Location A settings, (3) not available at Location B or C, (4) billing reflects 1 location only. Delivers value through flexible feature allocation.

**Acceptance Scenarios**:

1. **Given** owner with multiple locations views extension details, **When** KDS detail page opens, **Then** pricing shows: "$49/month for first location, $29/month per additional location" with location selector
2. **Given** owner enables KDS, **When** activation screen displays, **Then** shows checkboxes for each location: "Main St" (checked by default), "Downtown" (unchecked), "Airport" (unchecked) with individual pricing, total: $49/mo
3. **Given** owner enables KDS for Main St only, **When** activation completes, **Then** KDS available in Main St settings/operations, disabled message shown at other locations: "KDS not enabled for this location. Enable in Extensions?"
4. **Given** owner later enables KDS for Downtown, **When** adding second location, **Then** system calculates prorated charge for current month, displays: "KDS at Downtown: $29/month (prorated $15 for remainder of current billing cycle)", adds to subscription
5. **Given** owner disables KDS at Main St but keeps at Downtown, **When** disabling, **Then** pricing adjusts: Downtown becomes $49/mo (first location pricing), prorated credit applied for Main St unused days

---

### User Story 5 - Downgrade with Data Retention (Priority: P1)

**As a** restaurant owner reducing costs
**I want to** disable premium feature and understand data impact
**So that** I don't lose important historical data

**Why this priority**: Customer retention - making downgrade clear and safe encourages trial adoption.

**Independent Test**: Can be fully tested by: (1) owner with active Advanced Analytics disables feature, (2) system warns about data retention, (3) owner confirms understanding, (4) feature disabled with 30-day grace period for data access. Delivers value through safe downgrade path.

**Acceptance Scenarios**:

1. **Given** owner clicks "Disable" on active paid feature, **When** confirmation dialog opens, **Then** displays warning: "Disabling Advanced Analytics will: Stop access to custom reports, Archive existing reports (viewable for 30 days), Stop billing on next cycle. Historical order data retained. Continue?"
2. **Given** owner confirms disable, **When** processing, **Then** system: marks feature inactive effective immediately, schedules billing stop at end of current month (already paid for), retains feature data for 30 days, sends confirmation email
3. **Given** 30-day grace period active, **When** owner accesses disabled feature, **Then** shows read-only access with message: "Advanced Analytics disabled. Reactivate to create new reports. Data retained until [date]."
4. **Given** owner reactivates within 30 days, **When** reactivation occurs, **Then** system: restores full access, retrieves archived data, restarts billing at next cycle, no data loss
5. **Given** 30 days elapse without reactivation, **When** grace period ends, **Then** system archives feature-specific data to cold storage, removes from active access, owner receives final notification before permanent archive

---

### Edge Cases

- What happens when payment fails for feature billing?
  - Feature remains active for 7-day grace period, owner receives payment failure notifications, system retries billing 3 times, after grace period feature suspends until payment resolved

- How does system handle when owner downgrades plan tier with active individual extensions?
  - System evaluates included features in new tier, keeps additional paid extensions active, adjusts billing to reflect new base price + extensions

- What happens to feature data when tenant subscription expires completely?
  - All feature data moves to 90-day retention per platform policy, owner can export before expiration, permanent deletion after retention period

- How does system handle mid-billing-cycle feature enable/disable?
  - Proration calculation: (feature price / days in month) × remaining days, credit applied as account balance for future billings

- What happens when "Coming Soon" feature becomes available?
  - Owner receives notification if previously expressed interest, feature appears as available in marketplace, early adopters may receive discount

- How does system prevent feature dependency circular loops?
  - Dependency validation prevents circular references during feature configuration, displays error if admin attempts to create circular dependency

---

## Requirements

### Functional Requirements

**Marketplace Display**

- **FR-001**: System MUST display Extensions marketplace accessible from restaurant owner dashboard Settings menu
- **FR-002**: System MUST list available extensions with: name, short description, monthly price, "View Details" button, status (Available, Enabled, Trial, Coming Soon)
- **FR-003**: System MUST display extension pricing clearly showing: per-month cost, per-location cost (if applicable), whether included in plan or premium add-on
- **FR-004**: System MUST show "Coming Soon" badge on features under development with "Notify Me" option for launch updates
- **FR-005**: System MUST provide search/filter for extensions by category (Operations, Customer Engagement, Analytics, Delivery), price range, plan inclusion

**Extension Details**

- **FR-006**: System MUST display detailed extension page with: full description, complete features list, pricing breakdown, customer testimonials/use cases, "Start Free Trial" or "Enable Now" button
- **FR-007**: System MUST show what's included in extension (specific capabilities, limits if any, setup requirements)
- **FR-008**: System MUST display billing information: trial period length (14-30 days), monthly cost after trial, proration for current month, next billing date
- **FR-009**: System MUST show plan tier information indicating if extension included in Pro/Enterprise plans

**Feature Activation**

- **FR-010**: System MUST provide one-click activation via "Start Free Trial" or "Enable Now" button
- **FR-011**: System MUST display confirmation dialog before activation showing: billing terms, trial length (if applicable), what happens at trial end, data implications
- **FR-012**: System MUST validate feature dependencies before activation, displaying required features if missing
- **FR-013**: System MUST allow batch activation of feature + dependencies in single transaction
- **FR-014**: System MUST enable feature instantly upon confirmation (no manual provisioning delay)
- **FR-015**: System MUST send confirmation email after activation with: feature details, trial end date (if applicable), getting started guide, support contact

**Feature Toggles**

- **FR-016**: System MUST provide feature toggle mechanism changing feature availability immediately without service restart
- **FR-017**: System MUST update UI instantly showing/hiding feature-specific menu items, settings, and functionality based on toggle state
- **FR-018**: System MUST enforce feature access at operation level preventing use of disabled features even if UI circumvented
- **FR-019**: System MUST log all feature enable/disable actions with: timestamp, user who made change, feature affected, previous state, new state

**Dependency Management**

- **FR-020**: System MUST maintain feature dependency graph defining prerequisites for each extension
- **FR-021**: System MUST validate dependencies before enabling feature, blocking activation if unmet
- **FR-022**: System MUST prevent disabling features that other enabled features depend on with clear error message
- **FR-023**: System MUST offer to enable dependent features during activation showing combined pricing
- **FR-024**: System MUST track dependency relationships: Customer Identity required for Loyalty, Inventory required for Advanced Analytics (stock insights)

**Per-Location Configuration**

- **FR-025**: System MUST allow multi-location tenants to enable/disable features per individual location
- **FR-026**: System MUST display location selector during activation with pricing per location
- **FR-027**: System MUST calculate per-location pricing: first location at full price ($X/mo), additional locations at reduced price ($Y/mo typically 60% of full)
- **FR-028**: System MUST bill based on enabled location count updating automatically when locations added/removed
- **FR-029**: System MUST prevent feature use at locations where disabled showing "Not enabled for this location" message

**Free Trials**

- **FR-030**: System MUST provide 14-day free trial for first-time feature activation (per feature, per tenant)
- **FR-031**: System MUST display trial status prominently showing: days remaining, trial end date, billing start date, monthly cost after trial
- **FR-032**: System MUST allow trial cancellation anytime before end with immediate feature deactivation and no charges
- **FR-033**: System MUST automatically convert trial to paid subscription at trial end charging payment method on file
- **FR-034**: System MUST send trial reminder emails: 7 days before end, 3 days before end, 1 day before end with cancellation option

**Billing Integration**

- **FR-035**: System MUST integrate with Spec 021 (Payment Processing) and Spec 022 (Subscription & Billing) for automatic charges
- **FR-036**: System MUST calculate prorated charges when enabling mid-billing-cycle: (monthly cost / days in month) × remaining days
- **FR-037**: System MUST add extension charges to next invoice showing: extension name, location count, proration if applicable, total addition
- **FR-038**: System MUST apply prorated credits when disabling mid-cycle using same calculation
- **FR-039**: System MUST handle payment failures by maintaining feature access during 7-day grace period while retrying billing

**Feature Usage Analytics**

- **FR-040**: System MUST track usage metrics for each enabled feature to demonstrate value
- **FR-041**: System MUST display usage metrics in "My Extensions" page: KDS orders processed, Loyalty customers enrolled, Inventory items tracked, etc.
- **FR-042**: System MUST provide "Value Report" showing ROI or usage stats for enabled premium features

**Downgrades and Deactivation**

- **FR-043**: System MUST allow feature deactivation via "Disable" button on active features
- **FR-044**: System MUST warn about data implications during deactivation: what data is retained, how long, what's deleted, reactivation options
- **FR-045**: System MUST provide 30-day grace period after deactivation with read-only access to feature data
- **FR-046**: System MUST stop billing for disabled features at end of current billing cycle (not mid-cycle unless requested)
- **FR-047**: System MUST allow reactivation within grace period restoring full access with no data loss

**Platform Analytics**

- **FR-048**: System MUST track feature adoption rate per tenant plan tier for platform analytics (used by Spec 019 Platform Admin)
- **FR-049**: System MUST track trial conversion rate (trials that become paid subscriptions)
- **FR-050**: System MUST track average features per tenant for revenue forecasting

---

### Key Entities

- **Extension**: Represents premium feature available in marketplace. Contains extension_id, name, description, category, base_monthly_price, per_additional_location_price, trial_period_days, included_in_plans (array: Pro, Enterprise), dependencies (array of required extension IDs), status (available, coming_soon). Defines product offerings.

- **Tenant Extension Subscription**: Records tenant's enabled features. Contains subscription_id, tenant_id, extension_id, status (trial, active, suspended, cancelled), enabled_locations (array of location IDs), trial_start_date, trial_end_date, billing_start_date, next_billing_date, monthly_charge, created_at. Tracks active subscriptions.

- **Feature Toggle**: Controls feature availability per tenant. Contains toggle_id, tenant_id, feature_key (string identifier), enabled (boolean), enabled_locations (array), effective_date, updated_at, updated_by_user_id. Enforces feature access.

- **Feature Dependency**: Defines prerequisite relationships. Contains dependency_id, feature_id, requires_feature_id, dependency_type (hard/soft). Hard dependencies block activation, soft dependencies show warnings.

- **Extension Usage Metrics**: Tracks feature utilization. Contains metric_id, tenant_id, extension_id, metric_type (orders_processed, customers_enrolled, reports_generated), metric_value, measured_at. Demonstrates value for upsells.

- **Trial Activity Log**: Records trial lifecycle events. Contains log_id, tenant_id, extension_id, event_type (trial_started, trial_ended, trial_cancelled, converted_to_paid), event_date, auto_converted (boolean). Platform analytics data source.

---

## Success Criteria

### Measurable Outcomes

- Extension activation completes in under 30 seconds from click to feature availability
- Trial conversion rate of 40%+ (trials becoming paid subscriptions)
- Average 2.5 premium extensions per paid tenant within 6 months
- Extension browsing to activation rate of 25% (quarter of browsers enable something)
- Zero dependency-related support tickets (validation prevents issues)
- Feature downgrade with reactivation rate of 60% within grace period
- Trial cancellation rate below 30% (70%+ convert or continue trial to end)
- Per-location pricing drives 15% higher adoption among multi-location tenants

### Qualitative Measures

- Restaurant owners report feature discovery is easy and pricing is clear
- Trial period builds confidence before financial commitment
- Transparent billing prevents surprise charges and builds trust
- Dependency validation prevents frustration from enabling incompatible features
- Downgrade process feels safe encouraging initial trial adoption

---

## Dependencies and Assumptions

### Dependencies

- Spec 019 (Platform Admin) provides tenant and subscription management foundation
- Spec 021 (Payment Processing) handles payment method and charging
- Spec 022 (Subscription & Billing) manages subscription lifecycle and invoicing
- All feature specs (024 KDS, 011 Loyalty, etc.) must support toggle-based enable/disable

### Assumptions

- Restaurant owners have authority to enable features and approve billing (not requiring corporate approval for SMBs)
- Payment method on file before premium features can be enabled (required during tenant onboarding)
- Most tenants start on Basic plan and upsell over time as business grows
- Free trials are loss leader worth the risk for conversion rate achieved
- Feature usage metrics are meaningful indicators of value to customers
- Per-location pricing model is financially viable at 60% discount for additional locations

### Out of Scope

- Custom feature bundles negotiated per tenant (standard catalog only in MVP)
- Volume discounts for large enterprise multi-location deals (flat per-location pricing in MVP)
- Affiliate or referral commissions for recommending extensions (future partnership program)
- Third-party extension developers publishing to marketplace (first-party extensions only)
- A/B testing different pricing strategies per tenant segment (static pricing MVP)
- Feature usage-based billing (flat monthly, not metered/usage-based)

---

**Status**: ✅ Ready for validation and `/speckit.plan` command
