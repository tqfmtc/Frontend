# Research: IVR Voice Ordering with Olivia.io Integration

**Feature**: 003-ivr-voice-ordering
**Created**: 2025-11-03
**Status**: Research & Recommendations

---

## Executive Summary

This document provides architectural research and design recommendations for implementing the Parcera voice ordering channel using Olivia.io voice AI platform. The analysis covers five critical areas: Olivia.io integration patterns, voice AI conversation design, telephony fundamentals, state management architecture, and PCI-compliant payment handling.

**Key Recommendations**:
1. **Olivia Integration**: Use Olivia.io REST API with callback webhooks for asynchronous event handling; implement conversation state in Parcera backend
2. **Conversation Engine**: Implement goal-oriented state machine with explicit intents (order-item, customization, confirmation, payment)
3. **State Storage**: Redis for active sessions (sub-second lookup), PostgreSQL for audit trail and conversation history
4. **Payment**: Tokenize card data via Stripe/Adyen; never store card numbers in Parcera backend (PCI DSS Level 1 requirement)
5. **Telephony**: Use Olivia.io's built-in handling for call management, DTMF fallback, and call recording compliance

---

## Decision 1: Olivia.io Integration Architecture

### Architecture: Webhook-Driven Event Processing with Conversation State in Parcera Backend

Olivia.io provides two integration patterns for voice applications:

### Pattern 1: Olivia-Hosted State Management (Simplest)
- Olivia maintains conversation state and bot logic
- Parcera acts as webhook endpoint (receives events + order data)
- Pros: Lower latency (Olivia's infrastructure optimized), less operational complexity
- Cons: Less control over conversation flow, vendor lock-in risk, harder to customize responses

### Pattern 2: Parcera-Hosted State Management (Recommended) ✅
- Parcera implements conversation state machine
- Olivia.io handles speech-to-text, text-to-speech, call management
- Parcera drives dialog flow, manages context, creates orders
- Pros: Full control over conversation logic, omnichannel conversation consistency, portable to other voice providers
- Cons: Responsible for handling state recovery, network failure resilience, concurrency

**Recommendation: Pattern 2** (Parcera-Hosted State)

**Rationale:**
- Constitution Principle I demands AI-First architecture; owning the conversation engine enables competitive differentiation
- Enables cross-channel conversation context (start order on web, complete on voice)
- Provides audit trail and conversation analytics owned by Parcera
- Allows pluggable voice AI providers (future migration opportunity)

---

### Integration Flow

```plaintext
Customer -> Call -> Olivia.io Infrastructure -> POST /voice/events -> Parcera Backend
                                                         ↓
                                         [Conversation Engine State Machine]
                                                         ↓
                                         PostgreSQL (history) + Redis (active)
                                                         ↓
                                           Callback: SSML response back to Olivia.io
                                                         ↓
                                                 Olivia TTS -> Customer
```

**Key Events Handled by Parcera Backend:**
- `call.initiated` - Initialize conversation context, fetch restaurant config
- `speech.transcribed` - Process customer input, update dialog state
- `intent.detected` - Route to conversation handlers (order-item, customization, etc.)
- `call.completed` - Finalize order, trigger payment, close conversation
- `call.failed` - Clean up session, enable call recovery

---

### Olivia.io API Contract (Expected Patterns)

Based on typical voice AI platforms and Olivia.io partnership details:

```plaintext
REST Endpoints:
  POST /api/calls              # Initiate outbound call (for post-order confirmation)
  POST /api/messages           # Send SSML/TTS to active call
  POST /api/transfer           # Transfer call to human agent (future)
  GET  /api/calls/{callId}     # Retrieve call details + transcript

Webhooks (Parcera implements these):
  POST /voice/events/initiated       # Call started
  POST /voice/events/transcribed     # Speech-to-text result
  POST /voice/events/completed       # Call ended
  POST /voice/events/failed          # Call error or timeout
  POST /voice/events/transferred     # Call transferred to agent (future)

Request/Response Format (JSON):
  {
    "event_id": "evt_abc123",
    "call_id": "call_xyz789",
    "timestamp": "2025-11-03T14:30:00Z",
    "restaurant_id": "rest_acme123",
    "phone_number": "+1-555-0100",
    "transcript": "I want a large pizza",
    "confidence": 0.95,
    "audio_url": "https://olivia.io/audio/call_xyz789.wav"  # For quality monitoring
  }
```

---

## Decision 2: Conversation State Machine Design

### Architecture: Goal-Oriented State Machine with Block-Based Orchestration

Voice ordering conversation follows predictable stages with explicit intents:

### Conversation Stages (State Machine)

```plaintext
┌─────────────────────────────────────────────────────────────────┐
│ GREETING                                                        │
│ - Play restaurant's custom welcome message                      │
│ - Establish customer identity (phone number lookup)             │
└──────────────┬──────────────────────────────────────────────────┘
               ↓
┌─────────────────────────────────────────────────────────────────┐
│ MENU_BROWSING                                                   │
│ - Listen for order intent: "I want a pizza", "What's popular?"  │
│ - Can clarify: "Which size?", "Any toppings?"                   │
│ - Can recommend: "Our best sellers are..."                      │
└──────────────┬──────────────────────────────────────────────────┘
               ↓
┌─────────────────────────────────────────────────────────────────┐
│ ITEM_SELECTION                                                  │
│ - Confirm item + size + modifiers                               │
│ - Parse customizations from speech                              │
│ - Add to cart (state: [item, quantity, modifiers])              │
└──────────────┬──────────────────────────────────────────────────┘
               ↓ (Customer: "That's all" or silence timeout)
┌─────────────────────────────────────────────────────────────────┐
│ CART_REVIEW                                                     │
│ - Summarize order: "You have: 1x Large Pepperoni, 1x Coke"     │
│ - Confirm total price with tax                                  │
│ - Ask: "Anything else?" (loop back to MENU_BROWSING)            │
└──────────────┬──────────────────────────────────────────────────┘
               ↓
┌─────────────────────────────────────────────────────────────────┐
│ CONTACT_INFO                                                    │
│ - Capture/confirm customer phone number                         │
│ - Attempt lookup for returning customer                         │
│ - Ask: "Best delivery address?" (future)                        │
└──────────────┬──────────────────────────────────────────────────┘
               ↓
┌─────────────────────────────────────────────────────────────────┐
│ PAYMENT                                                         │
│ - Ask payment method: "Credit or debit card?"                   │
│ - Collect card via DTMF (tokenized, never stored)              │
│ - Process payment via payment gateway                           │
│ - Handle failure: offer alternatives or payment on pickup      │
└──────────────┬──────────────────────────────────────────────────┘
               ↓
┌─────────────────────────────────────────────────────────────────┐
│ CONFIRMATION                                                    │
│ - Announce order number: "Your order is #1234"                  │
│ - Quote preparation time: "Ready in 20 minutes"                 │
│ - Offer SMS confirmation: "Texting confirmation to..."          │
└──────────────┬──────────────────────────────────────────────────┘
               ↓
┌─────────────────────────────────────────────────────────────────┐
│ CLOSED                                                          │
│ - End call gracefully                                           │
│ - Finalize conversation log                                     │
│ - Persist order to order management system                      │
└─────────────────────────────────────────────────────────────────┘
```

### Intent Classification (Parcera Backend Responsibility)

Each customer speech input must be classified into explicit intents:

```plaintext
Intent: ORDER_ITEM
  Pattern: "I want [item]", "Can I get [item]?", "Add [item]"
  Extraction: Item name, quantity, implicit size/modifiers
  Example: "I want a large pepperoni pizza" 
    -> item="Pepperoni Pizza", size="Large", quantity=1

Intent: CUSTOMIZE
  Pattern: "No [topping]", "Extra [topping]", "Make it [modifier]"
  Extraction: Item index, topping name, modifier type (add/remove)
  Example: "Remove the pepperoni" -> action=remove, topping=pepperoni

Intent: CLARIFY
  Pattern: "Which size?", "What toppings?"
  Response: Read menu options for pending item

Intent: CONFIRM
  Pattern: "Yes", "That's all", "Sounds good"
  Action: Move to next stage

Intent: NEGATE
  Pattern: "No", "Not that", "Cancel order"
  Action: Remove item from cart or restart conversation

Intent: RECOMMEND_REQUEST
  Pattern: "What do you recommend?", "What's popular?"
  Response: Return 2-3 top items from restaurant config

Intent: CORRECT
  Pattern: "Actually...", "Change that to...", "Make it small instead"
  Action: Update previous item in cart
```

### State Recovery (Network Resilience)

If network interruption occurs:
1. Save conversation state to Redis (every state transition)
2. Save to PostgreSQL (async, eventual consistency)
3. If call resumes: reload from Redis, prompt customer to confirm (avoid duplicate orders)
4. If call completes after timeout: mark partial order for recovery (customer can resume if calling back)

---

## Decision 3: Telephony Fundamentals & Call Handling

### Architecture: Leverage Olivia.io for Telephony, Implement Fallback to DTMF

### Call Flow

1. **Inbound Call Received by Olivia.io**
   - Olivia terminates the SIP call
   - Routes to Olivia.io cloud infrastructure
   - Begins speech-to-text transcription in real-time

2. **Speech Recognition → Intent**
   - Olivia sends transcribed text + confidence score to Parcera webhook
   - Parcera classifies intent, updates conversation state
   - Parcera responds with SSML (Speech Synthesis Markup Language) or DTMF prompts

3. **Speech-to-Action Loop**
   - Olivia generates TTS (Text-To-Speech) from SSML response
   - Plays audio to customer
   - Listens for next customer input
   - Repeats until conversation closed

### DTMF Fallback (When Speech Recognition Fails)

If Olivia detects low confidence (<70%) or repeated speech recognition failures:

```plaintext
Olivia says: "I didn't understand. Press 1 for menu, 2 for recommendations, 3 to repeat."
Customer presses: 2 (keypad input)
Parcera receives: DTMF_2
Parcera action: Return menu recommendations (same logic as voice intent)
```

Implementation:
- Use Olivia.io's built-in DTMF collection
- Keypad input mapped to menu options (1-9 for top menu items)
- Natural escalation for complex customizations (fallback to agent or SMS)

### Noise Cancellation & Speaker Diarization

**Iris Technology** (Olivia partnership):
- Real-time noise suppression during transcription
- Maintains speech intelligibility in noisy environments (car, street, restaurant)
- Transparent to Parcera backend (handled by Olivia)

**Speechmatics** (Speaker Diarization):
- Identifies multiple speakers on single call
- Labels customer vs background voices
- Parcera backend receives speaker tags with confidence
- Alert when non-customer voice detected (e.g., family member interrupting)

---

## Decision 4: Session State Storage Architecture

### Architecture: Redis (Active) + PostgreSQL (Audit Trail)

Two-tier storage strategy:

### Redis (Primary - Active Sessions)

**Purpose**: Sub-second conversation context lookup during active call

**Data Structure**:
```plaintext
conversation:{call_id}
  {
    "call_id": "call_xyz789",
    "restaurant_id": "rest_acme123",
    "phone_number": "+1-555-0100",
    "stage": "ITEM_SELECTION",
    "cart": [
      {"item_id": "item_123", "name": "Pepperoni Pizza", "size": "Large", "qty": 1, "price": 14.99},
      {"item_id": "item_456", "name": "Coke", "size": "Large", "qty": 1, "price": 2.99}
    ],
    "total_price": 18.98,
    "tax": 2.02,
    "grand_total": 21.00,
    "customer_id": "cust_abc123",  # NULL until identified
    "transcript": ["Customer: I want a large pepperoni pizza", "Olivia: Got it..."],
    "intent_history": [
      {"intent": "ORDER_ITEM", "confidence": 0.95, "timestamp": "2025-11-03T14:30:00Z"}
    ],
    "created_at": "2025-11-03T14:25:00Z",
    "last_activity": "2025-11-03T14:30:15Z"
  }
```

**TTL (Time-To-Live)**: 1 hour (calls typically complete in 2-3 minutes; 1 hour allows recovery if customer calls back)

**Concurrency**: Use Redis transactions (WATCH/MULTI/EXEC) to prevent lost updates during rapid state changes

### PostgreSQL (Secondary - Audit Trail + History)

**Purpose**: Persistent conversation logs, order history, analytics, compliance auditing

**Tables**:
- `voice_calls` - Call metadata (caller, duration, status)
- `conversation_logs` - Detailed transcript, intent classification, confidence scores
- `voice_orders` - Order created from voice session
- `call_analytics` - Aggregated metrics per restaurant

**Persistence Strategy**:
- Synchronous write: Save conversation state to PostgreSQL after payment confirmation (order finalized)
- Asynchronous write: Background job publishes events to PostgreSQL every 30 seconds (eventual consistency)
- Guarantees: No order data lost if Redis crashes (PostgreSQL is source of truth for completed orders)

---

## Decision 5: PCI-Compliant Payment Capture

### Architecture: Tokenized Payment via Stripe/Adyen, Never Store Card Numbers

Parcera MUST achieve PCI DSS Level 1 compliance (strictest standard). Key requirement: **Never store full credit card numbers**.

### Payment Flow

```plaintext
Customer Voice Input:
  Olivia: "What's your card number?"
  Customer: "4111 1111 1111 1111"  (spoken digit by digit)

Olivia DTMF Collection:
  Olivia collects card digits as DTMF input (secure)
  Does NOT send card number to Parcera backend
  Sends secured token or delegates to payment processor

Stripe Integration (Recommended):
  1. Olivia redirects customer to Stripe Payment Element (voice prompt: "Go to this URL")
  2. OR Olivia collects card + CVC, sends to Stripe tokenization endpoint
  3. Stripe returns token (e.g., "tok_4242...")
  4. Parcera receives only token, no card number exposed

Payment Processing:
  Parcera: POST /stripe/charges {amount: 21.00, token: "tok_4242..."}
  Stripe: Processes payment, returns charge status
  Parcera: Records payment status, updates order

PCI Compliance Checklist:
  ✅ No card numbers stored in Parcera database
  ✅ Card entry handled by Olivia/Stripe (PCI-compliant providers)
  ✅ Parcera only handles tokens (low-risk data)
  ✅ Audit logs track all payment attempts
  ✅ Compliance audit by third-party annually
```

### Alternative: Adyen for Global Support

If Parcera targets international restaurants:
- Adyen handles PCI compliance in 190+ countries
- Supports voice-based payments (Adyen Conversational Payments)
- Higher fee (2.5% vs Stripe's 2.2%) but reduced compliance burden

**Recommendation: Stripe for MVP** (lower cost, easier integration), evaluate Adyen for Phase 2 (international scaling)

---

## Decision 6: Error Handling & Fallback Patterns

### Architecture: Graceful Degradation with Multiple Fallback Levels

```plaintext
Level 1: Speech Recognition Failure
  Problem: Olivia confidence < 70% or timeout
  Fallback: Offer DTMF menu ("Press 1 for menu, 2 for recommendations...")
  
Level 2: DTMF Entry Failure (Multiple Mistakes)
  Problem: Customer enters wrong digits 3+ times
  Fallback: Offer SMS alternative ("Text your order to 555-0123")
           OR transfer to human agent
  
Level 3: Payment Processing Failure
  Problem: Card declined, network timeout, etc.
  Fallback: Offer alternative payment methods
           - Different credit card
           - Cash on pickup
           - Debit card
           - Digital wallet (Apple Pay via DTMF code entry)
  
Level 4: Complete Call Failure (Network Outage)
  Problem: Olivia call drops mid-order
  Fallback: Save partial order to Redis/PostgreSQL
           - Customer can resume if calling back within 24 hours
           - Confirm no duplicate charge applied
           - Email partial order receipt for recovery
```

### Timeout Strategy

```plaintext
Silent Timeout (No speech for 8 seconds):
  Olivia: "Are you still there? Please say your order."
  Wait: 8 more seconds
  Fallback: Offer DTMF menu or transfer to agent

Inactivity Timeout (No activity for 5+ minutes):
  Likely abandoned call
  Save conversation state (order can be resumed)
  Offer SMS: "Your order is saved. Text RESUME to complete..."

Network Timeout (No response from Parcera backend for 5 seconds):
  Olivia: "Having trouble processing. Please hold..."
  Retry: Exponential backoff (500ms, 1s, 2s, 4s)
  Max attempts: 3
  Fallback: "I'm having connectivity issues. Please try again in a moment."
```

---

## Decision 7: Conversation Analytics & Quality Monitoring

### Architecture: Sentiment Analysis + Intent Extraction for Insights

**Metrics Captured per Call**:
1. **Operational**:
   - Call duration, silence duration, speech duration
   - Number of clarification loops
   - Correction rate (% of items corrected mid-order)
   - Abandonment point (if call dropped, where in the flow?)

2. **Quality**:
   - Speech recognition confidence (avg)
   - Intent classification accuracy
   - Sentiment analysis (satisfaction estimate)
   - Noise level detection

3. **Business**:
   - Order value, items ordered, customization complexity
   - Recommendation acceptance rate
   - Payment method chosen
   - Repeat customer rate

**Storage**: Aggregated in `call_analytics` table per restaurant per day

**Visualization**: Restaurant dashboard shows:
- "Call volume last 7 days: 42 calls, 35 completed (83%)"
- "Avg order value: $18.50 (up 5% from last week)"
- "Recommended items accepted: 28% (target: 30%)"
- "Most-abandoned stage: Payment (8% of calls)"

**Quality Assurance**: Sample 5% of calls for human review (spot-check transcript accuracy)

---

## Recommendations Summary

| Decision | Recommendation | Rationale |
|----------|----------------|-----------|
| Olivia Integration | Parcera-hosted state machine | Full control, competitive differentiation, cross-channel consistency |
| Conversation Engine | Goal-oriented state machine with explicit intents | Reliable NLU, easy to debug, scales across restaurants |
| Telephony | Olivia.io + DTMF fallback | Proven scale, noise cancellation, speaker diarization included |
| Session Storage | Redis (active) + PostgreSQL (audit) | Sub-second lookup, durability, compliance audit trail |
| Payment | Stripe tokenization (MVP), Adyen evaluation (Phase 2) | PCI compliance, lower cost, global support path |
| Error Handling | Graceful degradation with SMS/agent fallback | Improves UX, reduces abandonment, handles edge cases |
| Analytics | Sentiment + intent extraction + business metrics | Actionable insights, quality monitoring, competitive advantage |

---

## Open Questions for Phase 1 Design

1. **Olivia.io SLA & Rate Limits**: What's the guaranteed latency distribution? Rate limits per restaurant?
2. **Call Recording Storage**: Olivia or Parcera? Retention policy? Compliance implications (state-specific laws)?
3. **International Support**: Are Iris/Speechmatics available in target languages? Voice input in Spanish/Mandarin?
4. **Agent Transfer**: Can calls be transferred to human staff? Queueing mechanics? Handoff protocol?
5. **Conversation Mining**: Can Parcera extract structured menu insights from conversation logs (e.g., "customers ask about vegan options")?
6. **A/B Testing**: Can welcome message be A/B tested? Recommendation ranking optimized per restaurant?

---

**Next Steps (Phase 1 - Design)**:
- Obtain Olivia.io API documentation and sandbox access
- Design database schema for voice calls, conversation logs, analytics
- Implement conversation state machine in Python + FastAPI
- Create OpenAPI contracts for voice session and call routing APIs
- Build end-to-end integration test with mocked Olivia responses

