# Quickstart: IVR Voice Ordering

**Feature**: 003-ivr-voice-ordering
**Created**: 2025-11-03
**Status**: Developer Onboarding Guide

---

## Overview

This guide gets developers up and running with the IVR Voice Ordering feature. It covers:
1. Local development setup
2. Olivia.io sandbox integration
3. Running end-to-end tests
4. Testing voice order flows
5. Debugging common issues

**Time to first voice call**: ~30 minutes (assuming Olivia.io sandbox credentials available)

---

## Prerequisites

- Python 3.11+
- PostgreSQL 14+ (local or Docker)
- Redis (for session state)
- Olivia.io sandbox account with API credentials
- Stripe test account (for payment tokenization)

---

## Part 1: Local Development Setup

### 1.1 Clone & Environment Setup

```bash
# Clone the repository
git clone https://github.com/parcera/parcera-platform.git
cd parcera-platform

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt  # Testing, debugging tools
```

### 1.2 Environment Variables

Create `.env.local` in project root:

```plaintext
# Database
DATABASE_URL=postgresql://postgres:password@localhost:5432/parcera_dev
DATABASE_TEST_URL=postgresql://postgres:password@localhost:5432/parcera_test

# Redis
REDIS_URL=redis://localhost:6379/0

# Olivia.io
OLIVIA_API_KEY=sandbox_key_xxxxx
OLIVIA_API_SECRET=sandbox_secret_xxxxx
OLIVIA_WEBHOOK_SECRET=webhook_secret_xxxxx
OLIVIA_BASE_URL=https://sandbox-api.olivia.io

# Stripe (Test)
STRIPE_API_KEY=sk_test_xxxxx
STRIPE_PUBLISHABLE_KEY=pk_test_xxxxx

# App
APP_ENV=development
LOG_LEVEL=DEBUG
```

### 1.3 Database Setup

```bash
# Create databases
createdb parcera_dev
createdb parcera_test

# Run migrations
python -m alembic upgrade head

# Seed test data
python scripts/seed_dev_data.py

# Verify schema
psql parcera_dev -c "\dt"  # List all tables
```

### 1.4 Start Services

```bash
# Terminal 1: PostgreSQL (if using Docker)
docker run -d \
  --name postgres-dev \
  -e POSTGRES_PASSWORD=password \
  -p 5432:5432 \
  postgres:14

# Terminal 2: Redis
docker run -d \
  --name redis-dev \
  -p 6379:6379 \
  redis:7

# Terminal 3: Parcera backend
python -m uvicorn app.main:app --reload --port 8000

# Terminal 4: Ngrok tunnel (for Olivia webhooks)
ngrok http 8000
# Note: Copy ngrok URL for webhook configuration
```

---

## Part 2: Olivia.io Sandbox Integration

### 2.1 Get Sandbox Credentials

1. Login to Olivia.io partner dashboard
2. Create sandbox app
3. Copy API Key, Secret, Webhook Secret
4. Add to `.env.local`

### 2.2 Configure Webhook Endpoint

In Olivia.io dashboard:
1. Settings → Webhooks
2. Endpoint: `https://YOUR-NGROK-URL/v1/voice/events`
3. Events to subscribe: all voice events
4. Secret: Your `OLIVIA_WEBHOOK_SECRET`

### 2.3 Test Olivia Connection

```bash
# Run connection test
python scripts/test_olivia_connection.py

# Expected output:
# ✓ Olivia API reachable
# ✓ Webhook endpoint registered
# ✓ Test call initiated (will call your test phone)
```

---

## Part 3: Running End-to-End Tests

### 3.1 Unit Tests

```bash
# Run all unit tests
pytest tests/unit -v

# Run specific test file
pytest tests/unit/test_conversation_engine.py -v

# Run with coverage
pytest tests/unit --cov=app --cov-report=html
```

### 3.2 Integration Tests

```bash
# Integration tests (with mocked Olivia)
pytest tests/integration -v

# Run specific integration test
pytest tests/integration/test_call_flow.py::test_simple_order_placement -v
```

### 3.3 Contract Tests

```bash
# Validate API contracts
pytest tests/contract -v

# Validate OpenAPI schemas
python scripts/validate_openapi_schemas.py

# Expected output:
# ✓ voice-session-api.yaml valid
# ✓ call-routing-api.yaml valid
# ✓ order-creation-api.yaml valid
```

### 3.4 End-to-End Test Simulation

```bash
# Simulate full voice order flow (no actual call required)
python scripts/test_e2e_voice_flow.py

# Output:
# [1] Call initiated: call_xyz789
# [2] Customer speech: "I want a large pepperoni pizza"
# [3] Intent detected: ORDER_ITEM (confidence: 0.95)
# [4] State updated: ITEM_SELECTION
# [5] Confirmation: "Got it, one large pepperoni pizza. Anything else?"
# [6] Customer: "That's all"
# [7] Stage updated: CART_REVIEW
# [8] Order created: order_abc123 (confirmation: ABC123)
# [9] Call completed: duration 2m 15s
```

---

## Part 4: Testing Voice Order Flows

### 4.1 Manual Testing (Real Olivia Call)

**Option A: Call from Your Phone**

1. Request Olivia sandbox number from partner team
2. Call the number
3. Hear custom restaurant greeting (test message)
4. Say your order: "I want a large pepperoni pizza"
5. Confirm: "Yes"
6. Confirm phone number: "555-0100"
7. Confirm payment: "Credit card"
8. Receive confirmation number and prep time

**Option B: Automated Test Call**

```bash
# Initiate test call to your phone
python scripts/test_call_myself.py --phone "+1-555-0100"

# Or call Olivia sandbox number (if available)
# Dial: [SANDBOX_NUMBER]
```

### 4.2 Monitoring Live Calls

```bash
# Watch call events in real-time
python scripts/watch_call_events.py

# Output:
# 14:30:00 | call.initiated    | call_xyz789   | +1-555-0100
# 14:30:05 | speech.transcribed | I want pizza  | confidence: 0.95
# 14:30:07 | intent.detected   | ORDER_ITEM    | confidence: 0.92
# ...
```

### 4.3 Debugging Conversation State

```bash
# Inspect active session state
python scripts/debug_session.py --call-id "call_xyz789"

# Output:
# Call ID: call_xyz789
# Stage: ITEM_SELECTION
# Cart:
#   - Pepperoni Pizza (Large) x1 [$14.99]
# Total: $14.99 + $1.02 tax = $16.01
# Transcript:
#   Customer: "I want a large pepperoni pizza"
#   Olivia: "Got it, one large pepperoni pizza. Anything else?"
# Intents:
#   - ORDER_ITEM (0.95) @ 14:30:05
```

---

## Part 5: Test Scenarios

### Scenario 1: Simple Order (P0)

**Goal**: Customer places simple 1-item order

**Setup**:
```bash
# Create test restaurant
python scripts/create_test_restaurant.py --name "Pizza Palace"

# Get test phone number
TEST_PHONE="+1-555-0100"
```

**Steps**:
1. Call Olivia sandbox number
2. Say: "I want a large pepperoni pizza"
3. Confirm: "Yes"
4. Provide phone: "555-0100"
5. Pay: "Credit card"
6. Receive confirmation

**Assertion**:
- Order created in database
- Order appears in KDS (kitchen display system)
- Confirmation number sent to customer

---

### Scenario 2: Complex Order with Customizations (P0)

**Setup**: Same as Scenario 1

**Steps**:
1. "Medium pizza, extra cheese, no pepperoni, add mushrooms"
2. Olivia confirms: "One medium pizza with extra cheese, no pepperoni, mushrooms?"
3. Confirm: "Yes"
4. Proceed to payment
5. Get confirmation

**Assertion**:
- All customizations captured correctly
- Price reflects modifiers (extra cheese +$1, etc.)
- Order in KDS shows all modifiers clearly

---

### Scenario 3: Error Handling (P0)

**Setup**: Enable low confidence detection in test config

**Steps**:
1. Speak unclear order (simulated low confidence)
2. Olivia offers DTMF: "Press 1 for menu, 2 for recommendations"
3. Press 2 (DTMF)
4. Receive recommendations
5. Say item name

**Assertion**:
- Fallback to DTMF triggered correctly
- Order completed successfully via DTMF input

---

## Part 6: Common Issues & Debugging

### Issue 1: Webhook Not Receiving Events

**Symptoms**: Test calls don't create sessions in database

**Debug**:
```bash
# Check webhook is publicly accessible
curl -X POST https://YOUR-NGROK-URL/v1/voice/events \
  -H "Content-Type: application/json" \
  -H "X-Olivia-Signature: test" \
  -d '{"event_id":"test","event_type":"call.initiated"}'

# Check logs
tail -f logs/app.log | grep "voice/events"

# Verify webhook signature validation
python scripts/test_webhook_signature.py
```

**Solution**:
- Ensure ngrok tunnel is running
- Check firewall rules allow inbound webhook
- Verify webhook secret matches in Olivia dashboard

### Issue 2: Call Hangs Up Immediately

**Symptoms**: Call drops after greeting

**Debug**:
```bash
# Check Olivia logs
python scripts/query_olivia_call_log.py --call-id "call_xyz789"

# Check backend logs for errors
grep -A 5 "call_xyz789" logs/app.log

# Verify restaurant config
python scripts/debug_restaurant_config.py --restaurant-id "rest_acme123"
```

**Solution**:
- Ensure welcome message exists for restaurant
- Check payment gateway credentials
- Verify database connection working

### Issue 3: Orders Not Appearing in KDS

**Symptoms**: Voice orders created but kitchen can't see them

**Debug**:
```bash
# Check order in database
psql parcera_dev -c "SELECT * FROM voice_orders WHERE id='order_abc123';"

# Check KDS integration
python scripts/test_kds_integration.py --restaurant-id "rest_acme123"

# Verify order routing to correct location
psql parcera_dev -c "SELECT * FROM orders WHERE source_channel='voice';"
```

**Solution**:
- Ensure KDS integration is enabled for restaurant
- Check order routing configuration
- Verify order event published to order management system

---

## Part 7: Performance Profiling

### Latency Measurement

```bash
# Run latency benchmark
python scripts/benchmark_latency.py

# Output:
# Latency percentiles:
#   p50: 450ms (speech-to-response)
#   p95: 950ms (target: <1500ms)
#   p99: 1200ms
#
# Breakdown:
#   Olivia STT: 300ms (avg)
#   Intent classification: 100ms (avg)
#   Database update: 50ms (avg)
#   TTS generation: 100ms (avg)
```

### Load Testing

```bash
# Simulate 100 concurrent calls
python scripts/load_test_voice.py --concurrent-calls 100 --duration 5m

# Output:
# Started: 100 concurrent calls
# Completed: 98 orders (98% success rate)
# Failed: 2 (2% error rate)
# Peak latency: 1800ms
# Avg response time: 850ms
```

---

## Part 8: Deployment Checklist

Before deploying to production:

- [ ] All tests passing (unit, integration, contract, E2E)
- [ ] Load test passed (1000+ concurrent calls supported)
- [ ] Latency benchmark passed (p95 < 1500ms)
- [ ] Security audit passed (PCI compliance, secrets not in code)
- [ ] Database migrations tested + rollback plan documented
- [ ] Olivia.io production credentials configured
- [ ] Stripe production account ready
- [ ] Error logging and monitoring configured
- [ ] Runbook created for operational team
- [ ] Customer documentation reviewed

---

## Next Steps

1. **Phase 1**: Complete data-model.md schema design, implement conversation state machine
2. **Phase 2**: Build voice session API endpoints, integrate Olivia.io webhooks
3. **Phase 3**: Implement payment processing with PCI compliance
4. **Phase 4**: Add analytics and quality monitoring dashboard
5. **Phase 5**: Production launch with gradual rollout (10% → 50% → 100%)

---

**Support**: Reach out to `#voice-ordering` Slack channel for help

