# Data Model: IVR Voice Ordering

**Feature**: 003-ivr-voice-ordering
**Created**: 2025-11-03
**Status**: Technical Specification
**PostgreSQL Version**: 14+

---

## Overview

This document defines the complete data model for the IVR Voice Ordering feature, including PostgreSQL schema definitions, entity relationships, Row-Level Security (RLS) policies, indexes, validation rules, and state transitions.

**Architecture Pattern**: Multi-Tenant Voice Call Orchestration
- **All voice data scoped by restaurant_id** (tenant isolation via RLS)
- **Redis-backed conversation state** (active calls)
- **PostgreSQL audit trail** (history, compliance, analytics)

---

## Entity Relationship Diagram

```plaintext
┌──────────────────────────┐
│ Restaurants (from 001)   │ ← Tenant context
└────────────┬─────────────┘
             │
             │ 1:N
             │
┌────────────▼───────────────────┐      ┌──────────────────┐
│ VoiceCall                      │      │ ConversationLog  │
│ ──────────────────────────     │◄─────│ ──────────────── │
│ id (UUID, PK)                  │ 1:1  │ id (UUID, PK)    │
│ restaurant_id (FK, RLS)        │      │ call_id (FK)     │
│ phone_number                   │      │ transcript       │
│ call_status                    │      │ sentiment        │
│ duration_seconds               │      │ intent_history   │
│ start_time, end_time           │      └──────────────────┘
│ noise_level, confidence_avg    │
└────────────┬──────────────────┘
             │
             │ 1:N (multiple orderings per call)
             │
┌────────────▼──────────────────┐      ┌──────────────────┐
│ VoiceOrder                     │      │ ConversationCtx  │
│ ──────────────────────────     │      │ ──────────────── │
│ id (UUID, PK)                  │      │ call_id (FK, PK) │
│ call_id (FK)                   │      │ stage            │
│ restaurant_id (FK, RLS)        │      │ cart_items       │
│ customer_phone                 │      │ total_price      │
│ order_items (JSON)             │      │ customer_id      │
│ total_amount                   │      │ transcript (JSONB)
│ payment_status                 │      └──────────────────┘
│ confirmation_code              │
│ prep_time_minutes              │
└────────────┬──────────────────┘
             │
             │ 1:N
             │
┌────────────▼──────────────────┐
│ AIRecommendation              │
│ ──────────────────────────     │
│ id (UUID, PK)                  │
│ restaurant_id (FK, RLS)        │
│ item_ids (UUID array)          │
│ recommendation_type            │
│ acceptance_count               │
│ total_impressions              │
└────────────────────────────────┘

┌──────────────────────────────┐
│ CallAnalytics                 │
│ ──────────────────────────    │
│ id (UUID, PK)                 │
│ restaurant_id (FK, RLS)       │
│ date (DATE, indexed)          │
│ total_calls, completed_calls  │
│ avg_duration, avg_order_value │
│ abandonment_rate              │
│ avg_latency_ms                │
└──────────────────────────────┘
```

---

## Schema Definitions

### 1. VoiceCall Table

**Purpose**: Record metadata for each inbound voice call

```sql
CREATE TABLE voice_calls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL,
    phone_number VARCHAR(20) NOT NULL,  -- E.164 format: +1-555-0100
    customer_id UUID,  -- NULL until customer identified (returning customer lookup)
    call_status VARCHAR(20) NOT NULL DEFAULT 'in_progress'
        CHECK (call_status IN ('in_progress', 'completed', 'abandoned', 'failed')),
    
    -- Timing
    start_time TIMESTAMPTZ NOT NULL DEFAULT now(),
    end_time TIMESTAMPTZ,
    duration_seconds INT,
    
    -- Quality metrics
    speech_recognition_confidence NUMERIC(3,2),  -- 0.00-1.00
    avg_confidence NUMERIC(3,2),  -- Average across all utterances
    noise_level VARCHAR(20) CHECK (noise_level IN ('quiet', 'moderate', 'loud')),
    speaker_count INT DEFAULT 1,  -- Detected speakers (speaker diarization)
    
    -- Olivia.io integration
    olivia_call_id VARCHAR(100),  -- External call ID from Olivia
    audio_url VARCHAR(500),  -- Recording URL (if stored)
    
    -- Order reference
    voice_order_id UUID,  -- FK to voice_orders (may be NULL if order not completed)
    
    -- Metadata
    user_agent VARCHAR(500),  -- Device/network info
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    
    -- Constraints
    CONSTRAINT restaurant_exists 
        FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    CONSTRAINT customer_exists_if_identified
        FOREIGN KEY (customer_id) REFERENCES customers(id),
    CONSTRAINT duration_matches_timestamps
        CHECK (end_time IS NULL OR duration_seconds = EXTRACT(EPOCH FROM (end_time - start_time))),
    CONSTRAINT confidence_valid_range
        CHECK (avg_confidence IS NULL OR (avg_confidence >= 0 AND avg_confidence <= 1))
);

-- Indexes for tenant isolation + query performance
CREATE INDEX idx_voice_calls_restaurant_id ON voice_calls(restaurant_id);
CREATE INDEX idx_voice_calls_restaurant_date ON voice_calls(restaurant_id, start_time DESC);
CREATE INDEX idx_voice_calls_phone_number ON voice_calls(phone_number);
CREATE INDEX idx_voice_calls_customer_id ON voice_calls(customer_id) WHERE customer_id IS NOT NULL;
CREATE INDEX idx_voice_calls_status ON voice_calls(call_status);

-- RLS Policy: Only restaurant staff can view their own calls
CREATE POLICY voice_calls_tenant_isolation ON voice_calls
    FOR ALL USING (restaurant_id = current_setting('app.current_restaurant_id')::uuid);
ALTER TABLE voice_calls ENABLE ROW LEVEL SECURITY;

-- Trigger: Update updated_at on modification
CREATE TRIGGER update_voice_calls_updated_at
    BEFORE UPDATE ON voice_calls
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

---

### 2. ConversationContext Table

**Purpose**: Maintain state during active voice conversation (ephemeral, short-lived)

**Note**: Primary storage is Redis during active call. PostgreSQL stores completed/abandoned conversations for audit trail.

```sql
CREATE TABLE conversation_contexts (
    call_id UUID PRIMARY KEY,
    restaurant_id UUID NOT NULL,
    
    -- Conversation stage
    stage VARCHAR(50) NOT NULL DEFAULT 'greeting'
        CHECK (stage IN (
            'greeting', 'menu_browsing', 'item_selection', 'cart_review',
            'contact_info', 'payment', 'confirmation', 'closed', 'error'
        )),
    
    -- Cart state (JSON for flexibility)
    cart_items JSONB NOT NULL DEFAULT '[]'::jsonb,  -- [{item_id, qty, size, modifiers}]
    total_price NUMERIC(8,2),  -- Calculated from items
    tax_amount NUMERIC(8,2),
    grand_total NUMERIC(8,2),
    
    -- Customer context
    customer_id UUID,  -- NULL until identified
    customer_phone VARCHAR(20),
    
    -- Conversation history
    transcript JSONB NOT NULL DEFAULT '[]'::jsonb,  -- [{role: 'customer'|'olivia', text, timestamp, confidence}]
    intent_history JSONB NOT NULL DEFAULT '[]'::jsonb,  -- [{intent, confidence, timestamp}]
    
    -- Session metadata
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_activity TIMESTAMPTZ NOT NULL DEFAULT now(),
    
    -- Constraints
    CONSTRAINT restaurant_exists 
        FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    CONSTRAINT customer_exists_if_set
        FOREIGN KEY (customer_id) REFERENCES customers(id),
    CONSTRAINT call_exists 
        FOREIGN KEY (call_id) REFERENCES voice_calls(id),
    CONSTRAINT total_matches_items
        CHECK (cart_items != '[]'::jsonb OR total_price IS NULL)
);

-- Indexes
CREATE INDEX idx_conversation_contexts_restaurant_id ON conversation_contexts(restaurant_id);
CREATE INDEX idx_conversation_contexts_customer_id ON conversation_contexts(customer_id) 
    WHERE customer_id IS NOT NULL;

-- RLS: Only restaurant staff can view context for their calls
CREATE POLICY conversation_contexts_tenant_isolation ON conversation_contexts
    FOR ALL USING (restaurant_id = current_setting('app.current_restaurant_id')::uuid);
ALTER TABLE conversation_contexts ENABLE ROW LEVEL SECURITY;
```

---

### 3. VoiceOrder Table

**Purpose**: Order created from voice call (immutable record)

```sql
CREATE TABLE voice_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    call_id UUID NOT NULL,
    restaurant_id UUID NOT NULL,
    
    -- Customer info
    customer_phone VARCHAR(20) NOT NULL,
    customer_id UUID,  -- NULL if new customer
    
    -- Order items
    order_items JSONB NOT NULL,  -- [{item_id, name, size, qty, modifiers, price}]
    
    -- Pricing
    subtotal NUMERIC(8,2) NOT NULL,
    tax NUMERIC(8,2) NOT NULL,
    total_amount NUMERIC(8,2) NOT NULL,
    
    -- Payment
    payment_method VARCHAR(20) CHECK (payment_method IN ('credit_card', 'debit_card', 'digital_wallet', 'cash')),
    payment_token VARCHAR(255),  -- Stripe/Adyen token (NOT card number)
    payment_status VARCHAR(20) NOT NULL DEFAULT 'pending'
        CHECK (payment_status IN ('pending', 'authorized', 'completed', 'failed', 'refunded')),
    payment_processed_at TIMESTAMPTZ,
    
    -- Order fulfillment
    confirmation_code VARCHAR(20) NOT NULL UNIQUE,  -- e.g., "ABC123"
    prep_time_minutes INT,  -- Estimated time to ready
    order_status VARCHAR(20) NOT NULL DEFAULT 'confirmed'
        CHECK (order_status IN ('confirmed', 'preparing', 'ready', 'completed', 'cancelled')),
    
    -- Metadata
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    
    -- Constraints
    CONSTRAINT restaurant_exists 
        FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    CONSTRAINT call_exists 
        FOREIGN KEY (call_id) REFERENCES voice_calls(id),
    CONSTRAINT customer_exists_if_set
        FOREIGN KEY (customer_id) REFERENCES customers(id),
    CONSTRAINT total_matches_subtotal_tax
        CHECK (total_amount = subtotal + tax),
    CONSTRAINT payment_token_required_if_completed
        CHECK (payment_status != 'completed' OR payment_token IS NOT NULL)
);

-- Indexes
CREATE INDEX idx_voice_orders_restaurant_id ON voice_orders(restaurant_id);
CREATE INDEX idx_voice_orders_call_id ON voice_orders(call_id);
CREATE INDEX idx_voice_orders_customer_id ON voice_orders(customer_id) WHERE customer_id IS NOT NULL;
CREATE INDEX idx_voice_orders_confirmation_code ON voice_orders(confirmation_code);
CREATE INDEX idx_voice_orders_created_at ON voice_orders(created_at DESC);

-- RLS: Only restaurant staff can view/modify their orders
CREATE POLICY voice_orders_tenant_isolation ON voice_orders
    FOR ALL USING (restaurant_id = current_setting('app.current_restaurant_id')::uuid);
ALTER TABLE voice_orders ENABLE ROW LEVEL SECURITY;

-- Trigger: Update updated_at on modification
CREATE TRIGGER update_voice_orders_updated_at
    BEFORE UPDATE ON voice_orders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

---

### 4. ConversationLog Table

**Purpose**: Detailed audit trail of conversation for quality monitoring, dispute resolution, and conversation mining

```sql
CREATE TABLE conversation_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    call_id UUID NOT NULL,
    restaurant_id UUID NOT NULL,
    
    -- Full transcript
    transcript TEXT NOT NULL,  -- Concatenated conversation
    transcript_json JSONB,  -- Structured: [{speaker, text, timestamp, confidence}]
    
    -- Analysis
    sentiment VARCHAR(20) CHECK (sentiment IN ('positive', 'neutral', 'negative', 'unknown')),
    sentiment_score NUMERIC(3,2),  -- 0.00-1.00
    customer_satisfaction_estimate VARCHAR(20) 
        CHECK (customer_satisfaction_estimate IN ('very_satisfied', 'satisfied', 'neutral', 'dissatisfied', 'very_dissatisfied')),
    
    -- Intent extraction
    intents_detected JSONB,  -- [{intent, confidence, timestamp}]
    extracted_entities JSONB,  -- [{type: 'item'|'size'|'modifier', value, confidence}]
    
    -- Quality metrics
    avg_confidence NUMERIC(3,2),
    clarification_loops INT DEFAULT 0,  -- How many times "did you mean...?" asked
    correction_count INT DEFAULT 0,  -- How many times customer corrected order
    
    -- Speaker info (if diarization enabled)
    speaker_diarization JSONB,  -- [{speaker_id, confidence, speech_segments}]
    
    -- Metadata
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    
    -- Constraints
    CONSTRAINT restaurant_exists 
        FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    CONSTRAINT call_exists 
        FOREIGN KEY (call_id) REFERENCES voice_calls(id)
);

-- Indexes
CREATE INDEX idx_conversation_logs_restaurant_id ON conversation_logs(restaurant_id);
CREATE INDEX idx_conversation_logs_call_id ON conversation_logs(call_id);
CREATE INDEX idx_conversation_logs_sentiment ON conversation_logs(sentiment);
CREATE INDEX idx_conversation_logs_created_at ON conversation_logs(restaurant_id, created_at DESC);

-- RLS: Only restaurant staff can view transcripts for their calls
CREATE POLICY conversation_logs_tenant_isolation ON conversation_logs
    FOR ALL USING (restaurant_id = current_setting('app.current_restaurant_id')::uuid);
ALTER TABLE conversation_logs ENABLE ROW LEVEL SECURITY;

-- Partitioning by date (for large volumes)
-- CREATE TABLE conversation_logs_2025_11 PARTITION OF conversation_logs
--     FOR VALUES FROM ('2025-11-01') TO ('2025-12-01');
```

---

### 5. AIRecommendation Table

**Purpose**: Track AI-generated menu recommendations and their effectiveness

```sql
CREATE TABLE ai_recommendations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL,
    
    -- Recommendation config
    item_ids UUID[] NOT NULL,  -- [item_1, item_2, item_3] (top N recommendations)
    recommendation_type VARCHAR(50) NOT NULL
        CHECK (recommendation_type IN ('popular', 'personalized', 'seasonal', 'trending')),
    
    -- Effectiveness tracking
    total_impressions INT DEFAULT 0,  -- How many times recommended to customers
    acceptance_count INT DEFAULT 0,  -- How many times customer ordered after recommendation
    acceptance_rate NUMERIC(3,2) DEFAULT 0,  -- acceptance_count / total_impressions
    revenue_from_recommendations NUMERIC(10,2) DEFAULT 0,  -- Total $ from recommended items
    
    -- Metadata
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    
    -- Constraints
    CONSTRAINT restaurant_exists 
        FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    CONSTRAINT acceptance_rate_valid
        CHECK (acceptance_rate >= 0 AND acceptance_rate <= 1)
);

-- Indexes
CREATE INDEX idx_ai_recommendations_restaurant_id ON ai_recommendations(restaurant_id);
CREATE INDEX idx_ai_recommendations_type ON ai_recommendations(recommendation_type);

-- RLS: Only restaurant staff can view/manage their recommendations
CREATE POLICY ai_recommendations_tenant_isolation ON ai_recommendations
    FOR ALL USING (restaurant_id = current_setting('app.current_restaurant_id')::uuid);
ALTER TABLE ai_recommendations ENABLE ROW LEVEL SECURITY;

-- Trigger: Update updated_at
CREATE TRIGGER update_ai_recommendations_updated_at
    BEFORE UPDATE ON ai_recommendations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

---

### 6. CallAnalytics Table

**Purpose**: Aggregated metrics for dashboard and reporting (per restaurant, per day)

```sql
CREATE TABLE call_analytics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL,
    date DATE NOT NULL,  -- Aggregation date
    
    -- Call volume
    total_calls INT DEFAULT 0,
    completed_calls INT DEFAULT 0,
    abandoned_calls INT DEFAULT 0,
    failed_calls INT DEFAULT 0,
    
    -- Timing metrics
    avg_call_duration_seconds INT,
    avg_speech_duration_seconds INT,
    avg_silence_duration_seconds INT,
    p95_call_duration_seconds INT,  -- 95th percentile
    
    -- Quality metrics
    avg_confidence NUMERIC(3,2),
    avg_sentiment_score NUMERIC(3,2),
    calls_with_clarifications INT DEFAULT 0,
    calls_with_corrections INT DEFAULT 0,
    
    -- Business metrics
    orders_created INT DEFAULT 0,
    completed_payment_rate NUMERIC(3,2),  -- orders_created / completed_calls
    avg_order_value NUMERIC(8,2),
    total_order_value NUMERIC(12,2),
    
    -- Recommendations
    recommendations_shown INT DEFAULT 0,
    recommendations_accepted INT DEFAULT 0,
    recommendation_acceptance_rate NUMERIC(3,2),
    
    -- Noise
    quiet_calls INT DEFAULT 0,
    moderate_noise_calls INT DEFAULT 0,
    loud_calls INT DEFAULT 0,
    
    -- Latency (milliseconds)
    avg_response_latency_ms INT,
    p95_response_latency_ms INT,
    
    -- Metadata
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    
    -- Constraints
    CONSTRAINT restaurant_exists 
        FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    CONSTRAINT unique_restaurant_date
        UNIQUE (restaurant_id, date),
    CONSTRAINT completion_rate_valid
        CHECK (completed_payment_rate IS NULL OR (completed_payment_rate >= 0 AND completed_payment_rate <= 1))
);

-- Indexes
CREATE INDEX idx_call_analytics_restaurant_id ON call_analytics(restaurant_id);
CREATE INDEX idx_call_analytics_date ON call_analytics(date DESC);
CREATE INDEX idx_call_analytics_restaurant_date ON call_analytics(restaurant_id, date DESC);

-- RLS: Only restaurant staff can view their analytics
CREATE POLICY call_analytics_tenant_isolation ON call_analytics
    FOR ALL USING (restaurant_id = current_setting('app.current_restaurant_id')::uuid);
ALTER TABLE call_analytics ENABLE ROW LEVEL SECURITY;

-- Trigger: Update updated_at
CREATE TRIGGER update_call_analytics_updated_at
    BEFORE UPDATE ON call_analytics
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

---

## State Machines

### VoiceCall State Transitions

```plaintext
[in_progress] --→ [completed]
      ↓              (normal flow: call ended, order confirmed)
      ├→ [abandoned]
      │  (customer hung up mid-call, no order completed)
      │
      └→ [failed]
         (system error: Olivia disconnect, payment failure, etc.)
```

### VoiceOrder.order_status Transitions

```plaintext
[confirmed] --→ [preparing] --→ [ready] --→ [completed]
    ↓
    └→ [cancelled] (customer cancels before prep starts)
```

### ConversationContext.stage Transitions

```plaintext
[greeting] → [menu_browsing] → [item_selection] → [cart_review]
                     ↑__________________|
                     (loop: customer adds more items)
                                ↓
                         [contact_info] → [payment] → [confirmation] → [closed]
                                ↓
                         [error] → [closed] (if unrecoverable error)
```

---

## Validation Rules

### VoiceCall Validation

- `phone_number`: Must be valid E.164 format (+1-555-0100)
- `duration_seconds`: Must match (end_time - start_time) when call is completed
- `avg_confidence`: Must be between 0.00 and 1.00
- `call_status`: Must reflect actual state (completed calls must have end_time)

### VoiceOrder Validation

- `total_amount`: Must equal subtotal + tax (prevents price manipulation)
- `confirmation_code`: Must be unique and non-empty
- `payment_status`: "completed" requires valid payment_token
- `order_items`: Must not be empty (at least 1 item)

### CallAnalytics Aggregation

- `completed_payment_rate`: Must equal orders_created / completed_calls
- `recommendation_acceptance_rate`: Must equal recommendations_accepted / recommendations_shown

---

## Data Retention Policy

| Table | Retention | Reason |
|-------|-----------|--------|
| voice_calls | 90 days | Compliance, dispute resolution, chargeback defense |
| conversation_logs | 90 days | Quality monitoring, customer service feedback, conversation mining |
| voice_orders | 7 years | Tax audit, PCI compliance, order history |
| call_analytics | Forever | Historical trending, performance benchmarking |
| ai_recommendations | Forever | Recommendation effectiveness tracking |
| conversation_contexts | 24 hours | Volatile session state (auto-deleted after 24h inactivity) |

---

## Indexing Strategy

**Query Patterns**:
1. "Show all calls for restaurant X today" → `idx_voice_calls_restaurant_date`
2. "Find returning customer by phone" → `idx_voice_calls_phone_number`
3. "List orders for restaurant X between dates" → `idx_voice_orders_restaurant_id` + `created_at`
4. "Get analytics dashboard for restaurant X" → `idx_call_analytics_restaurant_date`

**Missing Indexes** (to be added if new query patterns emerge):
- None anticipated in MVP phase

---

## Migration Strategy

1. **Phase 1**: Create base schema (VoiceCall, ConversationContext, VoiceOrder)
2. **Phase 2**: Add analytics tables (CallAnalytics) + RLS policies
3. **Phase 3**: Add conversation logging (ConversationLog) + partitioning
4. **Phase 4**: Add recommendation tracking (AIRecommendation)

**Rollback Plan**: Each migration includes rollback DDL script in `/db/migrations/rollback/`

