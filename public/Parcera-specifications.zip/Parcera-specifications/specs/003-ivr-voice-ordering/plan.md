# Implementation Plan: IVR Voice Ordering Channel (Olivia.io Integration)

**Branch**: `003-ivr-voice-ordering` | **Date**: 2025-11-03 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `/specs/003-ivr-voice-ordering/spec.md`

**Note**: This template is filled in by the `/speckit.plan` command. See `.specify/templates/commands/plan.md` for the execution workflow.

## Summary

AI-powered voice ordering channel integrating Olivia.io voice AI platform with Parcera restaurant management system. Enables customers to place orders via phone with natural language understanding, flexible conversation management, menu item recommendations, secure payment capture, and order confirmation with estimated preparation time. Supports 1000+ concurrent calls with 800ms-1.5s response latency. Fully complies with Constitution Principle I (AI-First Architecture) and represents core omnichannel ordering capability.

## Technical Context

**Language/Version**: Python 3.11+ (FastAPI) - aligns with 001-restaurant-management and Constitution recommendation
**Primary Dependencies**: Olivia.io REST API client, FastAPI, PostgreSQL 14+ with RLS, Redis for session state, Speechmatics (speaker diarization), Iris (noise cancellation - via Olivia partnership)
**Storage**: PostgreSQL 14+ for conversation logs, call analytics, order state; Redis for active session cache (sub-second lookups)
**Testing**: pytest for unit/integration, contract tests via OpenAPI schema validation for voice session and call routing APIs
**Target Platform**: Linux server (Docker + Kubernetes), cloud-hosted voice AI integration, RESTful API backend
**Project Type**: Web application (backend API for call orchestration + optional frontend dashboard)
**Performance Goals**: 800ms-1.5s latency for 95% of Olivia interactions (P0), <200ms p95 for order creation endpoints, support 1000+ concurrent calls without degradation
**Constraints**: PCI compliance (tokenized payment, no card storage), DTMF fallback when speech fails, conversation state must survive network interruption, noise cancellation effective in 90% of real-world environments
**Scale/Scope**: MVP: 50-100 restaurants, Phase 2: 500 restaurants, 3-Year: 5000+ restaurants each handling 100+ concurrent calls

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

### Principle I: AI-First Architecture ✅ CRITICAL

**Requirements from Constitution:**
- MUST integrate Olivia.io voice AI for omnichannel ordering with 800ms-1.5s latency target
- MUST implement goal-oriented conversation engine with block-based, context-aware orchestration
- SHOULD support AI-driven features: menu extraction, cost optimization, predictive analytics

**Alignment with Spec:**
- ✅ FR-001, FR-002: Olivia.io integration via REST API for inbound call handling
- ✅ FR-006, FR-007, FR-008: Goal-oriented conversation flow with natural language understanding, flexible corrections, confirmation patterns
- ✅ FR-020: 800ms-1.5s latency target explicitly specified and measurable (SC-002)
- ✅ FR-012: AI-driven menu recommendations (P1 feature)
- ✅ SC-001, SC-002: Success criteria directly measure latency and conversation accuracy
- ✅ User Story 2 & 4: Complex customizations and error handling demonstrate goal-oriented engine capability
- ✅ User Story 3: Personalized recommendations based on conversation context

**Gate Status:** ✅ PASS - This feature IS the implementation of Constitution Principle I (AI-First) for ordering channel

**Blocking Decisions:** 
1. Olivia.io API contract finalization (speech-to-intent, SSML generation, session state management)
2. Iris/Speechmatics integration partnership terms and latency impact
3. Payment tokenization provider selection (PCI compliance strategy)

---

### Principle II: Multi-Tenancy by Design ✅

**Requirements from Constitution:**
- MUST implement row-level security with tenant isolation at database layer
- MUST use tenant slugs/unique identifiers for all multi-tenant resources
- MUST design APIs with tenant context in all requests

**Alignment with Spec:**
- ✅ FR-003: Custom welcome message per restaurant (tenant-specific)
- ✅ FR-012: Restaurant-configured recommendations (tenant-specific)
- ✅ FR-016: Estimated preparation time based on restaurant configuration
- ✅ FR-024: Restaurant-specific hours enforcement
- ✅ All conversation logs scoped to restaurant_id (tenant isolation)
- ✅ Call analytics aggregated per restaurant (SC-008)

**Gate Status:** ✅ PASS - All voice ordering data scoped by tenant_id with RLS enforcement

---

### Principle III: Privacy-First Customer Data ✅

**Requirements from Constitution:**
- MUST store all customer data (phone, email, preferences) in Parcera-controlled tables
- MUST use order ID-based notification routing (merchants cannot spam customers)
- MUST NOT expose customer contact information to merchant dashboards

**Alignment with Spec:**
- ✅ FR-010: Customer phone number captured by Olivia, stored in Parcera (not merchant-visible in raw form)
- ✅ FR-022: Conversation logs retained for quality monitoring, not shared with merchants
- ✅ Returning customer recognition via phone number (FR-011) - Parcera owns this data
- ✅ Order confirmation delivered to customer via Olivia (not merchant email)

**Gate Status:** ✅ PASS - Customer data remains Parcera-controlled, order notifications route via Parcera

---

### Principle IV: Omnichannel by Default ⚠️ PARTIAL

**Requirements from Constitution:**
- MUST provide all ordering channels independently of POS: IVR, web portal, mobile app, text chat
- MUST maintain order state and customer context across all channels seamlessly

**Alignment with Spec:**
- ✅ FR-025: Integration with order management system creates confirmed orders (shared state)
- ✅ FR-026: Third-party POS integration via integration gateway (omnichannel order routing)
- ✅ Orders created by voice channel visible in KDS (kitchen display system - channel-agnostic)
- ⚠️ Web/mobile channel details not specified in this spec (delegated to 002-online-ordering)
- ⚠️ Cross-channel conversation context (e.g., start order on web, complete on voice) not defined yet

**Gate Status:** ✅ PASS - Voice ordering integrates with shared order management layer; other channels defer to spec 002

---

### Principle V: Progressive Enhancement & MVP Discipline ✅

**Requirements from Constitution:**
- MUST define P0/P1/P2/P3 priorities for all features
- MUST ship P0 features within 3-month MVP timeline
- MUST design features as independently testable user stories

**Alignment with Spec:**
- ✅ User Story 1: P0 - Simple voice order placement (independent test, delivers immediate value)
- ✅ User Story 2: P0 - Complex orders with customizations (core AI capability)
- ✅ User Story 3: P1 - Menu recommendations (enhances AOV but not critical for MVP)
- ✅ User Story 4: P0 - Natural language error handling (user satisfaction critical)
- ✅ User Story 5: P1 - Noise cancellation (MVP works in quiet environments initially)
- ✅ All user stories have independent acceptance scenarios and test criteria
- ✅ Edge cases documented with sensible defaults

**Gate Status:** ✅ PASS - Proper P0/P1 prioritization with MVP-critical features identified

---

### Principle VII: Integration-Friendly Architecture ✅

**Requirements from Constitution:**
- MUST provide RESTful APIs with clear contracts for all core services
- MUST support third-party POS API integration (Toast, Square, Clover)
- SHOULD follow OpenAPI/Swagger standards for API documentation

**Alignment with Spec:**
- ✅ FR-026: Integration gateway for third-party POS systems
- ✅ Testing specifies contract tests via OpenAPI schema validation
- ✅ Voice session API and call routing API contracts will be generated in Phase 1
- ✓ Olivia.io integration via published REST API (not proprietary)

**Gate Status:** ✅ PASS - APIs designed for integration; contracts will be formalized in Phase 1

---

### Overall Gate Assessment

**STATUS: ✅ PROCEED TO PHASE 0**

**Critical Decisions Needed (Phase 0 Research):**
1. Olivia.io API contract specification (speech-to-intent formats, SSML generation, session state)
2. Iris/Speechmatics noise cancellation and speaker diarization integration approach
3. Payment tokenization strategy (PCI-compliant voice card entry)
4. Latency budget breakdown: Olivia API (target 400-600ms), Parcera backend (target 200-300ms), network (50-300ms)
5. Conversation state storage: Redis vs PostgreSQL vs hybrid approach
6. Error handling fallback strategy (DTMF keypad input implementation)
7. Call recording and retention policy (compliance implications, storage cost)

## Project Structure

### Documentation (this feature)

```text
specs/003-ivr-voice-ordering/
├── plan.md              # This file (/speckit.plan command output)
├── research.md          # Phase 0 output - Olivia integration patterns, voice AI architecture, telephony fundamentals
├── data-model.md        # Phase 1 output - VoiceCall, ConversationContext, VoiceOrder, ConversationLog schemas
├── quickstart.md        # Phase 1 output - Developer onboarding, Olivia sandbox setup, end-to-end test flow
├── contracts/           # Phase 1 output - OpenAPI specs for voice session API, call routing API, order creation
└── tasks.md             # Phase 2 output (/speckit.tasks command - NOT created by /speckit.plan)
```

### Source Code (repository root)

```text
backend/
├── src/
│   ├── models/
│   │   ├── voice_call.py              # VoiceCall entity, call lifecycle
│   │   ├── conversation_context.py    # ConversationContext, dialog state machine
│   │   ├── voice_order.py             # VoiceOrder, order capture + customizations
│   │   ├── conversation_log.py        # ConversationLog, transcript + sentiment analysis
│   │   ├── ai_recommendation.py       # AIRecommendation, menu suggestions + effectiveness
│   │   └── call_analytics.py          # CallAnalytics, aggregated metrics per restaurant
│   ├── services/
│   │   ├── olivia_service.py          # Olivia.io API client, speech-to-intent, SSML generation
│   │   ├── conversation_engine.py     # Goal-oriented dialog orchestration, state transitions
│   │   ├── order_service.py           # Order creation from conversation context
│   │   ├── payment_service.py         # Tokenized payment handling, PCI compliance
│   │   ├── recommendation_service.py  # Menu recommendations, personalization logic
│   │   ├── call_routing_service.py    # Inbound call handling, tenant routing
│   │   └── analytics_service.py       # Call metrics aggregation, quality monitoring
│   ├── api/
│   │   ├── v1/
│   │   │   ├── voice_sessions.py      # POST /voice/sessions (inbound call handling)
│   │   │   ├── call_events.py         # POST /voice/events (Olivia event callbacks)
│   │   │   ├── orders.py              # POST /orders (create order from voice session)
│   │   │   └── analytics.py           # GET /analytics/calls (call metrics per restaurant)
│   │   └── middleware/
│   │       ├── tenant_context.py      # Inject tenant_id from Olivia call context
│   │       └── call_validation.py     # Validate Olivia webhook signatures
│   └── db/
│       ├── migrations/                 # Database schema migrations
│       └── rls_policies.sql           # Row-level security policies for voice tables
└── tests/
    ├── contract/
    │   ├── voice_sessions_api_test.py # Validate voice session endpoints
    │   └── call_routing_api_test.py   # Validate call routing contracts
    ├── integration/
    │   ├── test_call_flow.py          # End-to-end voice call flow (mocked Olivia)
    │   ├── test_order_capture.py      # Order creation from conversation context
    │   ├── test_payment_handling.py   # Tokenized payment processing
    │   └── test_recommendation_engine.py  # Recommendation logic
    └── unit/
        ├── test_conversation_engine.py
        ├── test_order_service.py
        ├── test_payment_service.py
        └── test_analytics_service.py

frontend/ (optional - voice analytics dashboard)
├── src/
│   ├── components/
│   │   ├── CallAnalyticsDashboard/    # Call volume, completion rate, AOV
│   │   ├── ConversationMonitor/       # Transcript review for quality assurance
│   │   └── WelcomeMessageEditor/      # Restaurant configurable greeting
│   ├── pages/
│   │   ├── VoiceOrderingPage.tsx      # Configuration and metrics
│   │   └── ConversationReplayPage.tsx # Quality monitoring UI
│   └── services/
│       └── voiceOrderingApi.ts        # API client for voice analytics
└── tests/
    └── e2e/
        └── voice_ordering_config.spec.ts  # Restaurant configuration UI tests
```

**Structure Decision**: Web application (Option 2) - Backend API orchestrates voice calls via Olivia.io, captures orders in Parcera backend, routes to order management system. Optional React dashboard for restaurant owners to review call metrics, edit welcome message, manage recommendations. Voice AI logic delegated to Olivia.io (partnership integration), Parcera backend handles conversation state, order capture, and integration with core platform.

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

No constitution violations detected. All gates passed. Voice ordering is a direct implementation of Constitution Principle I (AI-First Architecture) with full multi-tenant support.

---

**Recommendations for Phase 0 Research:**
- Study Olivia.io API patterns and conversation state management (requires partner documentation review)
- Analyze latency budget constraints: identify bottlenecks between Olivia, Parcera backend, and database
- Research PCI-compliant voice payment capture patterns (DTMF encryption, tokenization)
- Design conversation state recovery for network failures (Redis persistence strategy)
- Document fallback patterns for speech recognition failures (DTMF keypad, SMS clarification)

