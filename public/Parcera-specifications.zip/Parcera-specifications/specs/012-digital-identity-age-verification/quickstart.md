# Quickstart: Digital Identity & Age Verification

**Feature**: `012-digital-identity-age-verification`  
**Date**: 2025-11-04  
**Status**: Phase 1 Complete

This guide demonstrates the core workflows for implementing age verification in your Parcera integration.

---

## Table of Contents

1. [Setup & Prerequisites](#setup--prerequisites)
2. [Workflow 1: Driver's License OCR Verification](#workflow-1-drivers-license-ocr-verification)
3. [Workflow 2: Third-Party IDV (ID.me) Integration](#workflow-2-third-party-idv-idme-integration)
4. [Workflow 3: Checkout Integration](#workflow-3-checkout-integration)
5. [Workflow 4: Manual Review Handling](#workflow-4-manual-review-handling)
6. [Configuration Examples](#configuration-examples)
7. [Testing Scenarios](#testing-scenarios)

---

## Setup & Prerequisites

### Installation

```bash
# Backend dependencies (FastAPI + async processing)
pip install fastapi uvicorn boto3 google-cloud-vision cryptography celery redis

# External service setup
export AWS_TEXTRACT_REGION=us-east-1
export IDME_CLIENT_ID=your-id-me-oauth-client-id
export YOTI_CLIENT_ID=your-yoti-oauth-client-id
```

### Database Setup

```sql
-- Create age verification schema (PostgreSQL 14+)
CREATE TABLE verification_credentials (
    credential_id UUID PRIMARY KEY,
    wallet_id UUID NOT NULL REFERENCES wallets(wallet_id),
    verification_method VARCHAR(50) NOT NULL,
    issued_at TIMESTAMP NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    verified_age_threshold INT DEFAULT 21,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    issuer_signature TEXT NOT NULL,
    issuer_public_key_id UUID NOT NULL,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX ON verification_credentials(wallet_id, status, expires_at);
CREATE INDEX ON verification_credentials(credential_id);

-- Verification attempt audit log
CREATE TABLE verification_attempts (
    attempt_id UUID PRIMARY KEY,
    wallet_id UUID NOT NULL,
    verification_method VARCHAR(50) NOT NULL,
    document_type VARCHAR(50),
    submitted_at TIMESTAMP NOT NULL,
    completed_at TIMESTAMP,
    extracted_birthdate DATE ENCRYPTED,
    extracted_name TEXT ENCRYPTED,
    ocr_confidence_score FLOAT,
    status VARCHAR(50) NOT NULL,
    failure_reason VARCHAR(100),
    age_calculated INT,
    device_fingerprint TEXT,
    ip_address INET,
    manual_reviewer_id UUID,
    manual_reviewer_notes TEXT,
    credential_created BOOLEAN DEFAULT FALSE,
    credential_id UUID REFERENCES verification_credentials(credential_id),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX ON verification_attempts(wallet_id, submitted_at);
CREATE INDEX ON verification_attempts(status, created_at);
CREATE INDEX ON verification_attempts(device_fingerprint, submitted_at DESC);

-- Manual review queue
CREATE TABLE manual_verification_requests (
    request_id UUID PRIMARY KEY,
    attempt_id UUID NOT NULL REFERENCES verification_attempts(attempt_id),
    wallet_id UUID NOT NULL,
    reason VARCHAR(50) NOT NULL,
    customer_notes TEXT,
    priority VARCHAR(20) DEFAULT 'standard',
    status VARCHAR(50) NOT NULL,
    reviewer_id UUID,
    reviewer_notes TEXT,
    resolution_decision VARCHAR(50),
    target_review_completion TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX ON manual_verification_requests(status, target_review_completion);
```

### RSA Key Setup

```bash
# Generate RSA key pair (store in AWS Secrets Manager)
openssl genrsa -out private_key.pem 2048
openssl rsa -in private_key.pem -pubout -out public_key.pem

# Store in AWS Secrets Manager
aws secretsmanager create-secret \
  --name parcera/age-verification/rsa-private-key \
  --secret-string file://private_key.pem
```

---

## Workflow 1: Driver's License OCR Verification

### Step 1: Initiate Verification

Customer selects "Verify with Driver's License" in mobile app.

```bash
curl -X POST https://api.parcera.local/v1/verification/initiate \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "wallet_id": "550e8400-e29b-41d4-a716-446655440000",
    "verification_method": "ocr_license"
  }'
```

**Response**:

```json
{
  "attempt_id": "660e8400-e29b-41d4-a716-446655440001",
  "wallet_id": "550e8400-e29b-41d4-a716-446655440000",
  "verification_method": "ocr_license",
  "status": "pending",
  "expires_at": "2025-11-05T22:37:00Z",
  "next_steps": {
    "action": "upload_document",
    "message": "Photograph front of your driver's license"
  }
}
```

### Step 2: Upload ID Document

Customer photographs front and back of license.

```bash
curl -X POST https://api.parcera.local/v1/verification/upload-document \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -F "attempt_id=660e8400-e29b-41d4-a716-446655440001" \
  -F "document_side=front" \
  -F "image_file=@front_license.jpg"

curl -X POST https://api.parcera.local/v1/verification/upload-document \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -F "attempt_id=660e8400-e29b-41d4-a716-446655440001" \
  -F "document_side=back" \
  -F "image_file=@back_license.jpg"
```

**Response** (202 Accepted):

```json
{
  "attempt_id": "660e8400-e29b-41d4-a716-446655440001",
  "status": "pending",
  "estimated_completion_seconds": 30
}
```

### Step 3: Poll for Result

Mobile app polls status until completion.

```bash
curl https://api.parcera.local/v1/verification/status/660e8400-e29b-41d4-a716-446655440001 \
  -H "Authorization: Bearer $JWT_TOKEN"
```

**Response** (Success):

```json
{
  "attempt_id": "660e8400-e29b-41d4-a716-446655440001",
  "wallet_id": "550e8400-e29b-41d4-a716-446655440000",
  "verification_method": "ocr_license",
  "status": "success",
  "submitted_at": "2025-11-04T22:37:00Z",
  "completed_at": "2025-11-04T22:37:28Z",
  "credential_id": "770e8400-e29b-41d4-a716-446655440002",
  "next_steps": "Your identity is verified! You can now order age-restricted items."
}
```

### Backend Implementation (Python/FastAPI)

```python
from fastapi import FastAPI, File, UploadFile, HTTPException
from celery import Celery
import boto3
from datetime import datetime, timedelta
import uuid
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
import json

app = FastAPI()
celery_app = Celery('age_verification')
textract = boto3.client('textract', region_name='us-east-1')

@app.post('/verification/initiate')
async def initiate_verification(wallet_id: str, verification_method: str):
    attempt_id = str(uuid.uuid4())
    
    # Create verification attempt record
    db_session.execute("""
        INSERT INTO verification_attempts 
        (attempt_id, wallet_id, verification_method, submitted_at, status)
        VALUES (%s, %s, %s, NOW(), 'pending')
    """, (attempt_id, wallet_id, verification_method))
    
    return {
        "attempt_id": attempt_id,
        "wallet_id": wallet_id,
        "verification_method": verification_method,
        "status": "pending",
        "expires_at": (datetime.utcnow() + timedelta(hours=24)).isoformat(),
        "next_steps": {"action": "upload_document"}
    }

@app.post('/verification/upload-document')
async def upload_document(
    attempt_id: str,
    document_side: str,
    image_file: UploadFile = File(...)
):
    # Save image temporarily
    image_path = f"/tmp/{attempt_id}_{document_side}.jpg"
    with open(image_path, 'wb') as f:
        f.write(await image_file.read())
    
    # Queue async OCR task
    process_ocr.delay(attempt_id, image_path, document_side)
    
    return {
        "attempt_id": attempt_id,
        "status": "pending",
        "estimated_completion_seconds": 30
    }

@celery_app.task
def process_ocr(attempt_id: str, image_path: str, document_side: str):
    """Async OCR processing via AWS Textract"""
    try:
        with open(image_path, 'rb') as image_file:
            response = textract.detect_document_text(
                Document={'Bytes': image_file.read()}
            )
        
        # Extract text
        extracted_text = {}
        for block in response['Blocks']:
            if block['BlockType'] == 'LINE':
                extracted_text[block['Text']] = block['Confidence']
        
        # Parse OCR results (simplified)
        birthdate, confidence = extract_birthdate(extracted_text)
        age = calculate_age(birthdate)
        
        # Validate age
        if age < 21:
            db_session.execute("""
                UPDATE verification_attempts
                SET status = 'failed', failure_reason = 'underage'
                WHERE attempt_id = %s
            """, (attempt_id,))
            return
        
        if confidence < 0.70:
            # Flag for manual review
            db_session.execute("""
                UPDATE verification_attempts
                SET status = 'manual_review_required', ocr_confidence_score = %s
                WHERE attempt_id = %s
            """, (confidence, attempt_id))
            
            # Create manual review request
            request_id = str(uuid.uuid4())
            db_session.execute("""
                INSERT INTO manual_verification_requests
                (request_id, attempt_id, wallet_id, reason, priority, status, target_review_completion)
                SELECT %s, %s, wallet_id, 'low_ocr_confidence', 'standard', 'pending',
                       NOW() + INTERVAL '24 hours'
                FROM verification_attempts WHERE attempt_id = %s
            """, (request_id, attempt_id, attempt_id))
            return
        
        # Create credential
        create_verification_credential(attempt_id, birthdate)
        
    except Exception as e:
        db_session.execute("""
            UPDATE verification_attempts
            SET status = 'failed', failure_reason = 'ocr_error'
            WHERE attempt_id = %s
        """, (attempt_id,))

def create_verification_credential(attempt_id: str, birthdate: str):
    """Generate and sign age verification credential"""
    credential_id = str(uuid.uuid4())
    issued_at = datetime.utcnow()
    expires_at = issued_at + timedelta(days=365*5)  # 5-year validity
    
    # Create credential payload
    credential_payload = {
        "credential_id": credential_id,
        "issued_at": issued_at.isoformat(),
        "expires_at": expires_at.isoformat(),
        "verified_age_threshold": 21
    }
    
    # Sign credential
    private_key = get_private_key_from_secrets()
    signature = private_key.sign(
        json.dumps(credential_payload).encode(),
        padding.PKCS1v15(),
        hashes.SHA256()
    )
    
    # Store credential
    db_session.execute("""
        INSERT INTO verification_credentials
        (credential_id, wallet_id, verification_method, issued_at, expires_at,
         verified_age_threshold, status, issuer_signature, issuer_public_key_id)
        SELECT %s, wallet_id, 'ocr_license', %s, %s, 21, 'active', %s, %s
        FROM verification_attempts WHERE attempt_id = %s
    """, (credential_id, issued_at, expires_at, signature.hex(), 'current_key_id', attempt_id))
    
    # Mark attempt as successful
    db_session.execute("""
        UPDATE verification_attempts
        SET status = 'success', credential_created = true, 
            credential_id = %s, completed_at = NOW()
        WHERE attempt_id = %s
    """, (credential_id, attempt_id))
```

---

## Workflow 2: Third-Party IDV (ID.me) Integration

### Step 1: Initiate ID.me Flow

```bash
curl -X POST https://api.parcera.local/v1/verification/initiate \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "wallet_id": "550e8400-e29b-41d4-a716-446655440000",
    "verification_method": "idv_id_me"
  }'
```

**Response**:

```json
{
  "attempt_id": "880e8400-e29b-41d4-a716-446655440003",
  "verification_method": "idv_id_me",
  "status": "pending",
  "next_steps": {
    "action": "redirect_to_provider",
    "redirect_url": "https://api.id.me/oauth/authorize?client_id=...&redirect_uri=https://api.parcera.local/v1/idv-callback/id-me&state=..."
  }
}
```

### Step 2: Handle OAuth Callback

ID.me redirects customer back to Parcera after verification.

```python
@app.get('/idv-callback/id-me')
async def id_me_callback(code: str, state: str):
    """OAuth callback from ID.me"""
    try:
        # Verify state parameter (CSRF protection)
        stored_state = redis.get(f"idv_state:{state}")
        if not stored_state:
            raise HTTPException(status_code=400, detail="Invalid state")
        
        attempt_id = stored_state.decode()
        
        # Exchange code for token
        token_response = requests.post('https://api.id.me/oauth/token', data={
            'client_id': IDME_CLIENT_ID,
            'client_secret': IDME_CLIENT_SECRET,
            'code': code,
            'redirect_uri': 'https://api.parcera.local/v1/idv-callback/id-me'
        })
        
        access_token = token_response.json()['access_token']
        
        # Get age assertion from ID.me
        userinfo = requests.get('https://api.id.me/oauth/userinfo',
            headers={'Authorization': f'Bearer {access_token}'})
        
        age_assertion = userinfo.json().get('age_21_plus')  # Binary: true/false
        
        if not age_assertion:
            db_session.execute("""
                UPDATE verification_attempts
                SET status = 'failed', failure_reason = 'underage'
                WHERE attempt_id = %s
            """, (attempt_id,))
        else:
            # Create credential
            create_verification_credential(attempt_id, None)  # No birthdate stored
        
        # Redirect to mobile app with result
        return RedirectResponse(f"parcera://verification/callback?attempt_id={attempt_id}")
        
    except Exception as e:
        return RedirectResponse("parcera://verification/error")
```

---

## Workflow 3: Checkout Integration

When customer adds age-restricted item to cart, system validates credential.

### Frontend (Mobile App)

```swift
// Check if user has valid age credential before checkout
let credential = try await verificationService.validateCredential(
    credentialId: order.customer.ageCredentialId,
    restaurantId: order.restaurantId
)

if credential.isValid && credential.verified_age_threshold >= 21 {
    // Proceed with checkout
    await checkoutService.processPayment(order)
} else {
    // Prompt for verification
    present(AgeVerificationViewController())
}
```

### Backend (Order Fulfillment - spec 006 integration)

```python
@app.post('/orders/{order_id}/validate-age-restricted')
async def validate_age_restricted_items(order_id: str):
    """Called by spec 006 (Order Fulfillment) during checkout"""
    
    order = db_session.query(Order).get(order_id)
    
    # Check if order contains age-restricted items
    age_restricted = db_session.execute("""
        SELECT DISTINCT ari.age_requirement
        FROM order_items oi
        JOIN age_restricted_items ari ON oi.menu_item_id = ari.menu_item_id
        WHERE oi.order_id = %s AND ari.is_active = true
    """, (order_id,)).fetchall()
    
    if not age_restricted:
        return {"requires_verification": False}
    
    # Get customer's valid credential
    credential = db_session.execute("""
        SELECT * FROM verification_credentials
        WHERE wallet_id = %s AND status = 'active' AND expires_at > NOW()
        LIMIT 1
    """, (order.wallet_id,)).fetchone()
    
    if not credential:
        return {
            "requires_verification": True,
            "age_requirement": max(ar.age_requirement for ar in age_restricted),
            "message": "You must verify your age to order this item"
        }
    
    # Validate credential signature
    public_key = get_public_key(credential.issuer_public_key_id)
    is_valid = verify_signature(credential.issuer_signature, credential, public_key)
    
    if not is_valid:
        return {"requires_verification": True, "message": "Age verification credential is invalid"}
    
    # Log access for compliance audit
    audit_logger.log({
        "action": "credential_validated",
        "wallet_id": order.wallet_id,
        "restaurant_id": order.restaurant_id,
        "credential_id": credential.credential_id,
        "timestamp": datetime.utcnow()
    })
    
    return {"requires_verification": False}
```

---

## Workflow 4: Manual Review Handling

### For Support Staff

```bash
# Get pending manual reviews
curl https://api.parcera.local/v1/admin/manual-reviews?status=pending \
  -H "Authorization: Bearer $ADMIN_JWT_TOKEN"
```

**Response**:

```json
{
  "total_pending": 15,
  "overdue_count": 2,
  "requests": [
    {
      "request_id": "990e8400-e29b-41d4-a716-446655440004",
      "wallet_id": "550e8400-e29b-41d4-a716-446655440000",
      "reason": "low_ocr_confidence",
      "priority": "standard",
      "submitted_at": "2025-11-04T20:00:00Z",
      "target_review_completion": "2025-11-05T20:00:00Z",
      "status": "pending",
      "is_overdue": false
    }
  ]
}
```

### Approve Verification

```bash
curl -X POST https://api.parcera.local/v1/admin/manual-reviews/990e8400-e29b-41d4-a716-446655440004/approve \
  -H "Authorization: Bearer $ADMIN_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "reviewer_notes": "Driver license clearly visible, birthdate confirms 21+"
  }'
```

**Response**:

```json
{
  "credential_id": "aa0e8400-e29b-41d4-a716-446655440005",
  "status": "approved"
}
```

### Deny Verification

```bash
curl -X POST https://api.parcera.local/v1/admin/manual-reviews/990e8400-e29b-41d4-a716-446655440004/deny \
  -H "Authorization: Bearer $ADMIN_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "reason": "identity_mismatch",
    "reviewer_notes": "Birthdate on license shows customer is 20 years old"
  }'
```

---

## Configuration Examples

### AWS Textract Setup

```python
# .env or AWS Secrets Manager
AWS_REGION = us-east-1
AWS_TEXTRACT_CONFIDENCE_THRESHOLD = 0.70
AWS_TEXTRACT_TIMEOUT = 30  # seconds

# Textract request
response = textract.detect_document_text(
    Document={
        'S3Object': {
            'Bucket': 'parcera-documents',
            'Name': f'{attempt_id}/front.jpg'
        }
    }
)
```

### ID.me Configuration

```python
IDME_CLIENT_ID = "your-client-id"
IDME_CLIENT_SECRET = "stored-in-aws-secrets-manager"
IDME_AUTHORIZE_URL = "https://api.id.me/oauth/authorize"
IDME_TOKEN_URL = "https://api.id.me/oauth/token"
IDME_USERINFO_URL = "https://api.id.me/oauth/userinfo"

# Scopes: age verification only (no full identity)
IDME_SCOPES = ["openid", "age"]
```

### Yoti Configuration

```python
YOTI_CLIENT_ID = "your-yoti-client-id"
YOTI_KEY = "stored-in-aws-secrets-manager"
YOTI_SDK = YotiClient(client_id=YOTI_CLIENT_ID)

# Yoti returns verified age attributes
YOTI_AGE_REQUIREMENT = 21
```

### Celery Task Queue

```python
# celery_config.py
broker_url = 'redis://localhost:6379/0'
result_backend = 'redis://localhost:6379/0'
task_serializer = 'json'
accept_content = ['json']
timezone = 'UTC'
enable_utc = True

# Task retry policy
task_autoretry_for = (Exception,)
task_max_retries = 3
task_default_retry_delay = 60  # seconds
```

---

## Testing Scenarios

### Test Case 1: Successful License OCR Verification

```python
def test_successful_license_ocr():
    """Happy path: Valid driver's license, age 21+"""
    # Setup
    wallet_id = str(uuid.uuid4())
    
    # Step 1: Initiate
    attempt_response = client.post('/verification/initiate', json={
        'wallet_id': wallet_id,
        'verification_method': 'ocr_license'
    })
    assert attempt_response.status_code == 200
    attempt_id = attempt_response.json()['attempt_id']
    
    # Step 2: Upload mock image
    with open('test_license_valid.jpg', 'rb') as f:
        upload_response = client.post('/verification/upload-document',
            files={'image_file': f},
            data={'attempt_id': attempt_id, 'document_side': 'front'}
        )
    assert upload_response.status_code == 202
    
    # Step 3: Poll status
    import time
    for _ in range(5):
        status_response = client.get(f'/verification/status/{attempt_id}')
        if status_response.json()['status'] == 'success':
            break
        time.sleep(1)
    
    assert status_response.json()['status'] == 'success'
    assert 'credential_id' in status_response.json()
```

### Test Case 2: Low Confidence OCR (Manual Review)

```python
def test_low_confidence_ocr_flags_manual_review():
    """Edge case: Blurry image, <70% confidence"""
    wallet_id = str(uuid.uuid4())
    
    # Upload blurry image (simulated <70% confidence in mock)
    attempt_id = initiate_verification(wallet_id, 'ocr_license')
    upload_and_wait(attempt_id, 'test_license_blurry.jpg')
    
    status = client.get(f'/verification/status/{attempt_id}').json()
    assert status['status'] == 'manual_review_required'
    
    # Verify manual review request created
    reviews = client.get('/admin/manual-reviews').json()
    assert any(r['reason'] == 'low_ocr_confidence' for r in reviews['requests'])
```

### Test Case 3: Age-Restricted Checkout Validation

```python
def test_checkout_blocks_underage_without_credential():
    """Integration: Order blocking for unverified customers"""
    wallet_id = str(uuid.uuid4())
    restaurant_id = str(uuid.uuid4())
    
    # Create order with age-restricted item
    order = create_order(wallet_id=wallet_id, items=[BEER_ID])
    
    # Validate age restriction
    validation = client.post(f'/orders/{order.id}/validate-age-restricted')
    
    assert validation.json()['requires_verification'] == True
    assert validation.status_code == 403
```

### Test Case 4: Credential Expiration Reminder (spec 010 Integration)

```python
def test_expiration_reminder_notification():
    """Integration: Notification service sends reminder 30 days before expiry"""
    # Create credential expiring in 25 days
    credential_id = create_test_credential(expires_in_days=25)
    
    # Trigger daily check (or schedule via Celery beat)
    check_upcoming_expirations()
    
    # Verify notification sent
    notifications = db.query(Notification).filter_by(
        wallet_id=credential.wallet_id,
        type='credential_expiration_reminder'
    ).all()
    
    assert len(notifications) > 0
```

---

## Phase 1 Status: COMPLETE

All workflows documented. API contracts finalized. Ready for Phase 2 (task generation and implementation).

