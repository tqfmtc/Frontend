# Feature Specification: Digital Identity & Age Verification

**Feature Branch**: `012-digital-identity-age-verification`
**Created**: 2025-10-29
**Status**: Draft
**Input**: User description: "Digital Identity & Age Verification - Reusable digital identity system for age-restricted orders (alcohol, tobacco) with support for restaurant-issued digital credentials and third-party identity verification (IDV) providers. Customers verify identity once via government ID scan or third-party IDV service, receive digitally signed credential stored in wallet, and present for age-restricted purchases across all partner restaurants. Supports multiple verification methods (driver license OCR, passport scan, ID.me, Yoti), verification status tracking (pending, verified, expired), automatic credential refresh reminders, and privacy-preserving verification (restaurants see 'verified 21+' status without viewing full birthdate or ID). Integrates with order fulfillment to block age-restricted items for unverified customers."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - One-Time Age Verification (Priority: P1)

Customers complete age verification once by scanning government-issued ID (driver's license, passport) or using third-party IDV service, receiving reusable digital credential for all future age-restricted purchases.

**Why this priority**: Legal requirement for alcohol/tobacco sales. Without verification, restaurants cannot fulfill age-restricted orders, blocking significant revenue stream.

**Independent Test**: Can be fully tested by initiating verification flow in mobile app, submitting ID photo, receiving verified credential in wallet, and successfully placing age-restricted order.

**Acceptance Scenarios**:

1. **Given** customer attempts to order alcohol without verified credential, **When** they add beer to cart, **Then** system prompts "Age verification required" with option to start verification
2. **Given** customer uploads driver's license photo, **When** OCR extraction completes, **Then** birthdate is extracted, age is verified as 21+, and digitally signed credential is stored in wallet within 30 seconds
3. **Given** customer has verified credential, **When** they order alcohol at any partner restaurant, **Then** order proceeds without re-verification and restaurant sees "Verified 21+" status only
4. **Given** credential expires (5 years from issue), **When** expiration approaches (30 days prior), **Then** customer receives reminder notification to re-verify

---

### User Story 2 - Privacy-Preserving Verification (Priority: P1)

Restaurants receive age verification confirmation ("Verified 21+") without accessing customer's full birthdate, ID photo, or personal details, protecting customer privacy.

**Why this priority**: Constitutional requirement (Principle III: Privacy-First). Prevents restaurant access to sensitive PII while meeting legal verification obligations.

**Independent Test**: Can be fully tested by placing age-restricted order, confirming restaurant operator sees "Verified 21+" badge in order details, and verifying operator cannot access birthdate or ID images.

**Acceptance Scenarios**:

1. **Given** customer has verified credential, **When** restaurant views order details, **Then** age verification badge displays "Verified 21+" without showing birthdate or ID document
2. **Given** order requires age verification, **When** delivery driver requests proof, **Then** customer can show verification QR code in app that driver scans to confirm "21+ Verified" status
3. **Given** verification credential is digitally signed, **When** system validates credential, **Then** cryptographic signature confirms authenticity without exposing underlying ID data
4. **Given** restaurant attempts API call for customer birthdate, **When** request is made, **Then** system returns 403 Forbidden with "Access to customer birthdate not permitted"

---

### User Story 3 - Multiple Verification Methods (Priority: P1)

System supports multiple verification paths: in-app ID scanning (driver's license, passport OCR), third-party IDV providers (ID.me, Yoti), and restaurant-issued credentials for trusted customers.

**Why this priority**: Flexibility reduces verification friction. Customers without smartphone cameras or expired IDs can use alternative methods.

**Independent Test**: Can be fully tested by attempting verification via each method (ID scan, ID.me integration, restaurant-issued) and confirming all paths result in valid credential.

**Acceptance Scenarios**:

1. **Given** customer chooses "Scan Driver's License", **When** they photograph front and back of license, **Then** OCR extracts name, birthdate, expiration, and creates credential if age requirement met
2. **Given** customer selects "Verify with ID.me", **When** they complete ID.me OAuth flow, **Then** ID.me provides age assertion (21+) and Parcera creates credential without storing ID images
3. **Given** restaurant wants to issue credential to regular customer, **When** operator manually verifies ID in-person and approves in dashboard, **Then** customer receives restaurant-issued credential valid for 1 year
4. **Given** passport is uploaded instead of driver's license, **When** OCR processing completes, **Then** system extracts birthdate from passport format and creates credential with passport as document type

---

### User Story 4 - Verification Status Tracking (Priority: P2)

Customers and operators track verification status (pending, verified, expired, rejected) with transparency into verification progress and resolution path for failures.

**Why this priority**: Important for user experience but not blocking for MVP. Manual review can substitute initially for edge cases.

**Independent Test**: Can be fully tested by submitting ID with various issues (blurry, expired, underage), verifying system reflects appropriate status, and confirming customer receives actionable guidance.

**Acceptance Scenarios**:

1. **Given** customer submits ID photo, **When** OCR processing is underway, **Then** wallet shows status "Verification Pending" with estimated completion time (30 seconds)
2. **Given** ID photo is blurry or unreadable, **When** OCR fails, **Then** status changes to "Verification Failed - Please retake photo" with tips for better photo quality
3. **Given** extracted birthdate shows customer is under 21, **When** verification check completes, **Then** status shows "Age Verification Denied - Must be 21+" and age-restricted items remain blocked
4. **Given** credential expiration date is reached, **When** customer opens wallet, **Then** status shows "Credential Expired - Renew Now" with shortcut to re-verification flow

---

### Edge Cases

- What happens when ID photo shows birthdate making customer exactly 21 years old today? System calculates exact age in days and approves if customer is 21 years + 0 days (inclusive).
- How does system handle international IDs (non-US driver's licenses, foreign passports)? OCR supports common international formats or fallback to manual review queue. International IDs may require third-party IDV integration.
- What happens when customer's ID expires after credential is issued? Credential remains valid for its own 5-year term independent of underlying ID expiration. Re-verification uses current valid ID.
- How does system prevent fake ID usage? OCR includes security feature detection (holograms, microprinting). High-confidence rejections auto-deny; low-confidence flags for manual review.
- What happens when customer disputes verification denial? Customer can request manual review via support, uploading additional documentation. Review SLA is 24 hours.
- How does system handle verification for pickup vs delivery? Same credential works for both. For delivery, driver app scans customer QR code at handoff to confirm age verification.

## Requirements *(mandatory)*

### Functional Requirements

#### Verification Methods
- **FR-001**: System MUST support driver's license OCR verification by extracting name, birthdate, expiration date, and state from front/back photos
- **FR-002**: System MUST support passport OCR verification by extracting name, birthdate, nationality, and expiration date from passport photo page
- **FR-003**: System MUST integrate with third-party IDV providers (ID.me, Yoti) via OAuth for age assertion without storing ID images
- **FR-004**: System MUST allow restaurant operators to issue manual verification credentials after in-person ID check with 1-year validity
- **FR-005**: System MUST complete OCR-based verification within 30 seconds for 95% of submissions with readable photos

#### Credential Management
- **FR-006**: System MUST generate digitally signed credential with issuer signature, issue date, expiration date (5 years from issue), verification method used
- **FR-007**: System MUST store credential in customer wallet (spec 008) with encrypted birthdate and verification metadata
- **FR-008**: System MUST validate credential cryptographic signature on each age-restricted order to prevent tampering
- **FR-009**: System MUST send expiration reminder notification 30 days before credential expires
- **FR-010**: System MUST automatically mark expired credentials as invalid and block age-restricted orders until re-verification

#### Privacy-Preserving Verification
- **FR-011**: System MUST display "Verified 21+" badge to restaurants without exposing customer birthdate, ID images, or document details
- **FR-012**: System MUST prevent restaurant API access to customer birthdate, ID photos, or verification metadata beyond age confirmation
- **FR-013**: System MUST generate privacy-preserving QR code for delivery driver age verification that reveals only "21+ Verified" status when scanned
- **FR-014**: System MUST audit log all verification status checks by restaurants for compliance monitoring
- **FR-015**: System MUST delete uploaded ID photos after credential creation (retain only extracted birthdate and metadata)

#### Order Integration
- **FR-016**: System MUST block checkout for orders containing age-restricted items when customer lacks valid verification credential
- **FR-017**: System MUST display age verification requirement messaging when customer adds age-restricted item to cart
- **FR-018**: System MUST allow operators to mark menu items as age-restricted (21+) in menu management system (spec 002)
- **FR-019**: System MUST sync verification status across all ordering channels (IVR, kiosk, mobile) in real-time
- **FR-020**: System MUST provide verification prompt shortcut during checkout flow (initiate verification without leaving cart)

#### Verification Status & Failure Handling
- **FR-021**: System MUST track verification status: pending, verified, expired, rejected, manual_review_required
- **FR-022**: System MUST provide actionable error messages for verification failures (blurry photo, underage, expired ID, unreadable)
- **FR-023**: System MUST route low-confidence OCR results to manual review queue with 24-hour SLA
- **FR-024**: System MUST allow customers to request manual review for disputed rejections with support ticket creation
- **FR-025**: System MUST implement fraud detection for multiple verification attempts from same device with different IDs

### Key Entities

- **VerificationCredential**: Digital credential with wallet_id, credential_id, verification_method (ocr_license, ocr_passport, idv_provider, restaurant_issued), issue_date, expiration_date, verified_age_threshold (21+), digital_signature, status (active/expired/revoked)
- **VerificationAttempt**: Record of verification request with attempt_id, wallet_id, verification_method, uploaded_document_type, extracted_birthdate, confidence_score, status (pending/success/failed/manual_review), failure_reason, timestamp
- **IDVProviderIntegration**: Third-party IDV connection with provider_name (ID.me, Yoti), OAuth credentials, age_assertion_endpoint, active status, supported_verification_types
- **AgeRestrictedItem**: Menu item flagged for age verification with item_id, restaurant_id, age_requirement (21+), restricted_substance_type (alcohol/tobacco)
- **ManualVerificationRequest**: Support ticket for disputed verifications with request_id, wallet_id, reason, uploaded_evidence, reviewer_notes, resolution (approved/denied), reviewed_date

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 90% of customers complete age verification successfully on first attempt within 2 minutes
- **SC-002**: 95% of OCR verifications complete within 30 seconds for readable ID photos
- **SC-003**: Credential reuse rate of 100% (customers verify once, use credential across all restaurants)
- **SC-004**: 0 incidents of customer birthdate or ID photo exposure to restaurants in first 6 months (privacy compliance)
- **SC-005**: Manual review queue processes 95% of flagged verifications within 24 hours
- **SC-006**: Age-restricted order completion rate increases by 40% compared to manual ID check at delivery
- **SC-007**: Fraud detection prevents 95% of fake ID attempts while flagging <2% of legitimate verifications
- **SC-008**: Customer complaints about verification difficulty <5% of total verification attempts
- **SC-009**: Restaurant compliance with age verification laws achieves 100% for orders through Parcera platform
- **SC-010**: Credential expiration reminder drives 80% renewal rate within 30-day window before expiration

## Assumptions *(mandatory)*

1. **Age Threshold**: 21+ is standard age requirement for alcohol/tobacco in US. System supports configurable thresholds for future international expansion.
2. **Credential Validity**: 5-year credential validity balances security (periodic re-verification) with user convenience (infrequent re-verification burden).
3. **OCR Accuracy**: Commercial OCR services (Google Vision, AWS Textract) provide 90%+ accuracy for US driver's licenses. Manual review handles edge cases.
4. **Legal Compliance**: Digital age verification meets state/local alcohol delivery laws. Legal counsel confirms approach per jurisdiction.
5. **ID Photo Storage**: Uploaded ID photos deleted after credential creation for privacy. Only extracted birthdate and metadata retained.
6. **Third-Party IDV**: ID.me, Yoti integrations use OAuth age assertion (binary 21+ result) without exposing full verification details to Parcera.
7. **Delivery Verification**: Delivery drivers use Parcera driver app to scan customer QR code for age confirmation at handoff (future driver app feature).
8. **Restaurant-Issued Credentials**: Restaurants can issue credentials only for in-person verification. Liability for improper issuance rests with restaurant.
9. **International IDs**: MVP focuses on US IDs. International ID support (Canada, Mexico, UK) is P2 enhancement requiring localized OCR models.
10. **Audit Retention**: Verification attempt logs and credential history retained for 7 years for legal/compliance requirements.

## Constitution Alignment *(mandatory)*

### Principle III: Privacy-First Customer Data
- **CRITICAL ALIGNMENT**: Restaurants see only "Verified 21+" status, never birthdate or ID images
- Verification metadata stored in customer wallet (Parcera-controlled), not accessible to restaurants
- ID photos deleted post-verification; only extracted birthdate retained (encrypted)

### Principle IV: Omnichannel by Default
- Verification credential works across all channels (IVR, kiosk, mobile) without re-verification
- Age-restricted item blocking enforced consistently regardless of ordering channel

### Principle V: Progressive Enhancement & MVP Discipline
- **P1 Features**: OCR verification (license/passport), credential storage, privacy-preserving verification, order blocking
- **P2 Features**: Third-party IDV integration, restaurant-issued credentials, manual review queue, fraud detection

### Principle VI: Network Effects & Platform Thinking
- One-time verification enables orders across all partner restaurants (network credential portability)
- Aggregated verification success rates improve OCR models and fraud detection over time

### Principle VII: Integration-Friendly Architecture
- RESTful API for third-party IDV provider integrations (ID.me, Yoti OAuth)
- Webhook support for verification status callbacks to notify customer wallet of completion

## Dependencies *(mandatory)*

### Internal Dependencies
- **Customer Identity (spec 008)**: Stores verification credential in wallet with encrypted birthdate
- **Menu Management (spec 002)**: Flags menu items as age-restricted requiring verification
- **Order Fulfillment (spec 006)**: Blocks checkout for age-restricted orders without valid credential
- **Mobile App (spec 005)**: Provides verification flow UI (ID photo capture, third-party IDV OAuth, credential display)
- **Notification Infrastructure (spec 010)**: Sends credential expiration reminders and verification status updates

### External Dependencies
- **OCR Service**: Google Vision API, AWS Textract, or Azure Computer Vision for ID document text extraction
- **Third-Party IDV Providers**: ID.me, Yoti OAuth integration for age assertions
- **Cryptographic Signing**: Public/private key infrastructure for credential digital signatures (platform-managed keys)

## Future Considerations *(optional)*

### Post-MVP Enhancements (P2/P3)
- **Biometric Linking**: Link facial photo from ID to customer wallet for biometric authentication at kiosk (see spec 015 placeholder)
- **International ID Support**: OCR models for Canadian, UK, Mexican IDs with localized age thresholds
- **Blockchain Credentials**: Issue verifiable credentials using W3C standard for decentralized identity (DID)
- **Real-Time Age Verification API**: Sync with state DMV databases for instant license validation (if partnerships established)
- **Delivery Driver App Integration**: Driver-facing QR scanner for age verification at handoff
- **Family Account Sharing**: Parent verification extends to authorized family members (with consent)
- **Subscription Verification**: Annual verification subscription with auto-renewal and premium support
