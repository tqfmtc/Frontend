# Research: Digital Identity & Age Verification

**Feature**: `012-digital-identity-age-verification`  
**Date**: 2025-11-04  
**Status**: Phase 0 Complete

## Research Questions Resolved

### 1. OCR Service Selection

**Decision**: AWS Textract or Google Vision API  
**Rationale**: Both services provide 90%+ accuracy for US driver's licenses. AWS Textract offers superior document-specific OCR with form detection. Google Vision provides robust backup with faster implementation.  
**Alternatives Considered**:
- Microsoft Azure Computer Vision: Viable but less document-specialized; already used for menu OCR in spec 002
- Tesseract (open-source): <85% accuracy for complex documents; insufficient for compliance

**Implementation Approach**:
- Primary: AWS Textract with boto3 client
- Fallback: Google Vision API via google-cloud-vision SDK
- Extraction fields: Full name, DOB, expiration, license number, state, class

### 2. Cryptographic Credential Signing

**Decision**: RSA-2048 with PKCS#1 v1.5 padding for signature generation  
**Rationale**: Industry-standard for digital credentials; compatible with JWT libraries for easy validation; 2048-bit provides 112-bit security equivalent sufficient for compliance.  
**Alternatives Considered**:
- ECDSA (P-256): Smaller signatures but more complex implementation; overkill for credential lifetime
- EdDSA (Ed25519): Modern but less widely supported in compliance frameworks

**Implementation Approach**:
- Private key: Stored in AWS Secrets Manager (not in code)
- Signature method: `signature = sign_data(credential_json, private_key)`
- Validation: Public key embedded in credential, verified before accepting payment orders
- Rotation: Annual key rotation with 90-day overlap for credential validation

### 3. Third-Party IDV Integration Pattern

**Decision**: OAuth 2.0 with provider-specific age assertion endpoint  
**Rationale**: Industry-standard for identity verification (ID.me, Yoti use OAuth); providers return binary age assertion (21+/under 21) without exposing full identity details; reduces PII exposure.  
**Alternatives Considered**:
- SAML 2.0: Enterprise-focused; overkill for consumer IDV
- Direct API calls with shared secrets: Less secure; no standardized protocol

**Implementation Approach**:
- ID.me: OAuth with `openid email` scopes; returns age assertion via ID token
- Yoti: OAuth with age verification scope; returns structured age verification claim
- Flow: Redirect to provider → OAuth callback → Extract age assertion → Create credential

### 4. Credential Storage in Wallet (spec 008)

**Decision**: Encrypted JSON blob stored in customer_credentials table (spec 008)  
**Rationale**: Wallet system (spec 008) provides secure, customer-controlled storage with encryption at rest. Avoids duplicate PII storage across systems.  
**Alternatives Considered**:
- Separate verification service database: Unnecessary duplication
- Browser local storage: Insufficient for server-side age validation

**Implementation Approach**:
- Credential structure: `{credential_id, issuer_sig, issue_date, expiration, verified_age_threshold, verification_method}`
- Storage: Customer wallet via spec 008 API with `credential_type: "age_verification"`
- Encryption: AES-256-GCM at rest via spec 008
- Retrieval: On checkout, fetch credential from wallet, validate signature, check expiration

### 5. Privacy-Preserving QR Code for Delivery

**Decision**: JWT-encoded QR code containing only age assertion and expiration  
**Rationale**: Minimal data exposure; QR code easily revoked after delivery; driver doesn't see customer name/birthdate/document details.  
**Alternatives Considered**:
- Barcode with credential ID: Requires backend lookup (privacy risk if logs exposed)
- NFT-based credential: Overkill; blockchain unnecessary for single-chain verification

**Implementation Approach**:
- Payload: `{age_status: "21_verified", expiration: TIMESTAMP, credential_id: UUID, iss: "parcera"}`
- Encoding: JWT signed with Parcera private key; QR encodes JWT string
- Driver validation: Scan QR → Verify JWT signature → Extract age_status
- Expiration: QR valid for 24 hours after order placement

### 6. OCR Processing Pipeline

**Decision**: Async task queue (Celery with PostgreSQL) for reliability and monitoring  
**Rationale**: OCR processing takes 3-5 seconds; async prevents blocking UI; task queue provides retry logic and audit trail.  
**Alternatives Considered**:
- Synchronous API call: Blocks user; poor UX for 30-second p95 latency
- AWS Lambda: Vendor lock-in; less audit trail control

**Implementation Approach**:
- Task submission: Mobile app uploads image → API creates verification_attempt record → Celery task queued
- Processing: Worker calls Textract → Extracts birthdate → Validates age → Creates credential
- Callback: Webhook to mobile app notifies user of completion
- Audit: All attempts logged with timestamps, confidence scores, extraction results

### 7. Fraud Detection Strategy

**Decision**: Rule-based with machine learning readiness  
**Rationale**: Initial MVP uses heuristics (multiple attempts same device, age mismatch patterns); ML models added in P2 after sufficient training data.  
**Alternatives Considered**:
- Full ML from day one: Insufficient training data; high false positive rate
- No fraud detection: Unacceptable compliance risk

**Implementation Approach**:
- Phase 1 (MVP): Device fingerprinting + attempt counting + ID quality checks
  - Flag: >3 failed attempts from same device in 24 hours
  - Flag: Confidence score <70% for OCR extraction
  - Flag: Extracted age off by >2 years from submitted birthdate
- Phase 2: ML model trained on verification patterns to detect anomalies
- Manual review queue: All flagged verifications routed to support with 24-hour SLA

### 8. International ID Support (P2)

**Decision**: Phase 2 enhancement; P1 focuses on US driver's licenses only  
**Rationale**: MVP timeline constraints; US market priority; international requires localized OCR models and legal compliance research.  
**Alternatives Considered**:
- Support all international IDs in P1: Delays MVP; legal liability for unsupported jurisdictions

**Implementation Approach**:
- P1: US driver's licenses + US passports only
- P2: Add Canadian, Mexican, UK IDs with localized age thresholds
- P3: Real-time DMV database integration (if partnerships available)

### 9. Audit Logging & Compliance

**Decision**: Immutable audit log table with 7-year retention  
**Rationale**: Legal requirement for alcohol/tobacco verification audit trails; immutable prevents tampering; 7-year aligns with state recordkeeping laws.  
**Alternatives Considered**:
- Transient logs: Non-compliant; no audit trail for regulatory review
- Permanent retention: GDPR/privacy concerns; unnecessary beyond 7 years

**Implementation Approach**:
- Audit table: `{attempt_id, timestamp, user_id, action, result, ocr_confidence, reviewer_notes}`
- No deletion: Records marked as "sensitive" but never deleted for 7 years
- Access control: Only compliance officer + legal team can view audit logs
- Monitoring: Automated alerts for manual review queue backlog >24 hours

### 10. Manual Review Queue Implementation

**Decision**: PostgreSQL queue table with priority scoring  
**Rationale**: Low-confidence OCR results need human review; priority queue ensures fairest SLA achievement.  
**Alternatives Considered**:
- Fifo queue: Doesn't account for verification urgency (user waiting vs background batch)

**Implementation Approach**:
- Queue schema: `{request_id, wallet_id, reason, confidence_score, submitted_at, priority}`
- Priority: Express (in-app user waiting) > Batch (background verification)
- Reviewer UX: Dashboard showing OCR result, extracted birthdate, confidence score, manual decision UI
- SLA: 24-hour target; alerts escalate after 18 hours

---

## Technical Stack Confirmed

### Backend Services
- **Language**: Python 3.11+ (aligns with spec 010)
- **Framework**: FastAPI (async-capable for OCR callbacks)
- **Async Processing**: Celery + Redis (from constitution)
- **Database**: PostgreSQL 14+ (existing spec infrastructure)
- **Authentication**: JWT tokens (spec 008)

### External Services
- **OCR**: AWS Textract (primary) + Google Vision API (fallback)
- **IDV Providers**: ID.me + Yoti (OAuth 2.0)
- **Cryptography**: RSA-2048 via cryptography package
- **Secret Management**: AWS Secrets Manager for RSA private key

### Testing
- **Unit Tests**: pytest with fixture-based mock OCR responses
- **Integration Tests**: Mock Textract + real database transactions
- **Contract Tests**: OpenAPI validation of IDV callback endpoints
- **E2E Tests**: Simulated user workflows (ID upload → credential creation → checkout)

---

## Dependencies Validated

### Internal Spec Dependencies
- **spec 008 (Customer Identity)**: Credential storage in wallet ✓
- **spec 002 (Menu Management)**: Age-restricted item flags ✓
- **spec 006 (Order Fulfillment)**: Checkout blocking for age-restricted orders ✓
- **spec 005 (Mobile App)**: Verification flow UI + camera access ✓
- **spec 010 (Notification Infrastructure)**: Expiration reminders ✓

### External Dependencies
- AWS Textract API (boto3 SDK)
- Google Vision API (google-cloud-vision SDK)
- ID.me OAuth endpoints (https://api.id.me/oauth/authorize)
- Yoti SDK (yoti_python_sdk)
- PostgreSQL JSON functions for credential storage
- Redis for Celery task queue

---

## Assumptions Validated

1. **Age Threshold**: 21+ universal; configurable in database for future localization
2. **Credential Validity**: 5 years balances security + UX; aligns with license expiration patterns
3. **OCR Accuracy**: 90%+ accuracy confirmed by AWS Textract documentation; manual review SLA handles edge cases
4. **Legal Compliance**: US alcohol/tobacco laws require age verification; digital credential meets state delivery requirements
5. **PII Deletion**: ID photos deleted immediately post-OCR; encrypted birthdate retained only
6. **Third-party IDV**: ID.me + Yoti confirmed to return binary age assertion without full identity exposure
7. **Delivery Verification**: QR code validation assumes driver app with camera (spec 025 - POS Tablet, future capability)
8. **Restaurant Liability**: Terms of Service place credential issuance liability on restaurants
9. **International IDs**: Deferred to P2; MVP US-only
10. **Audit Retention**: 7-year retention aligns with state alcohol licensing audit requirements

---

## Phase 0 Status: COMPLETE

All research questions resolved. Technical stack confirmed. Dependencies validated. Ready for Phase 1 design.

### Clarifications Achieved
- OCR service selected (AWS Textract primary)
- Cryptographic approach finalized (RSA-2048)
- IDV integration pattern established (OAuth)
- Privacy-preserving architecture designed (wallet + QR)
- Fraud detection strategy outlined (Phase 1 heuristics, Phase 2 ML)
- International support deferred to P2

### Next Steps (Phase 1)
1. Generate data-model.md with entity definitions
2. Create API contracts in OpenAPI format
3. Write quickstart.md with example flows
4. Update agent context with confirmed technologies
