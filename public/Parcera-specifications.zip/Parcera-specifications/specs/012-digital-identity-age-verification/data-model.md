# Data Model: Digital Identity & Age Verification

**Feature**: `012-digital-identity-age-verification`  
**Date**: 2025-11-04  
**Status**: Phase 1 Complete

---

## Entity Definitions

### 1. VerificationCredential

**Purpose**: Digital credential representing successful age verification, stored in customer wallet (spec 008).

**Fields**:

| Field | Type | Constraint | Description |
|-------|------|-----------|-------------|
| credential_id | UUID | PRIMARY KEY | Unique credential identifier |
| wallet_id | UUID | FOREIGN KEY (spec 008) | Reference to customer wallet |
| verification_method | ENUM | NOT NULL | Method used: `ocr_license`, `ocr_passport`, `idv_id_me`, `idv_yoti`, `restaurant_issued` |
| issued_at | TIMESTAMP | NOT NULL | UTC timestamp of credential creation |
| expires_at | TIMESTAMP | NOT NULL | UTC timestamp of expiration (5 years for OCR/IDV, 1 year for restaurant-issued) |
| verified_age_threshold | INT | NOT NULL | Age verified as 21+ (constant; reserved for future thresholds) |
| status | ENUM | NOT NULL | `active`, `expired`, `revoked`, `disputed` |
| issuer_signature | TEXT | NOT NULL | RSA-2048 PKCS#1 v1.5 signature of credential_id + issued_at + expires_at |
| issuer_public_key_id | UUID | NOT NULL | Reference to key version used for signing (enables key rotation) |
| metadata | JSONB | NULL | Additional context: `{document_type: "DL", state: "CA", last_4_ssn: "1234"}` (last_4_ssn only for manual review) |
| created_at | TIMESTAMP | DEFAULT NOW() | Record creation timestamp |

**Indexes**:
- `(wallet_id, status, expires_at)` - Query credentials by wallet + status + validity
- `(credential_id)` - Validation lookups during checkout

**Access Control**:
- Customer: Can read own credentials via spec 008 wallet API
- Restaurant operator: Cannot access credential details; only sees "21+ Verified" status during order display
- Compliance officer: Can view all credentials for audit purposes with access logging

**Lifecycle**:
1. Created: After successful verification
2. Active: 5 years (OCR/IDV) or 1 year (restaurant-issued)
3. Expires: Auto-marked `expired` on `expires_at` timestamp
4. Revoked: If fraud detected or customer disputes; manual intervention
5. Disputed: If customer contests verification rejection

---

### 2. VerificationAttempt

**Purpose**: Immutable audit record of each age verification attempt; retained for 7 years for compliance.

**Fields**:

| Field | Type | Constraint | Description |
|-------|------|-----------|-------------|
| attempt_id | UUID | PRIMARY KEY | Unique attempt identifier |
| wallet_id | UUID | NOT NULL | Reference to customer wallet |
| verification_method | ENUM | NOT NULL | Method: `ocr_license`, `ocr_passport`, `idv_id_me`, `idv_yoti`, `restaurant_issued` |
| document_type | ENUM | NULL | `driver_license`, `passport`, `id_me_result`, `yoti_result`, `manual` |
| submitted_at | TIMESTAMP | NOT NULL | When customer initiated verification |
| completed_at | TIMESTAMP | NULL | When verification result finalized |
| extracted_birthdate | DATE | NULL | Extracted via OCR (encrypted at rest; deleted after credential creation) |
| extracted_name | TEXT | NULL | Extracted via OCR (deleted post-verification) |
| ocr_confidence_score | FLOAT | NULL | 0.0-1.0 confidence for OCR extraction accuracy |
| status | ENUM | NOT NULL | `pending`, `success`, `failed`, `manual_review_required`, `manual_review_approved`, `manual_review_denied` |
| failure_reason | TEXT | NULL | If status=`failed`: `blurry_image`, `unreadable_text`, `underage`, `expired_id`, `security_feature_not_detected`, `idv_provider_error` |
| age_calculated | INT | NULL | Calculated age in years at submission time (used for audit) |
| device_fingerprint | TEXT | NULL | Hash of device identification for fraud detection (IP + user-agent hash) |
| ip_address | INET | NULL | IPv4/IPv6 address of submission (masked to /24 for privacy) |
| manual_reviewer_id | UUID | NULL | Staff member who reviewed flagged attempt |
| manual_reviewer_notes | TEXT | NULL | Reviewer commentary on decision |
| credential_created | BOOLEAN | DEFAULT FALSE | True if credential_id was generated |
| credential_id | UUID | NULL | Reference to created credential (if success) |
| created_at | TIMESTAMP | DEFAULT NOW() | Record creation timestamp |

**Indexes**:
- `(wallet_id, submitted_at)` - Query verification history for customer
- `(status, created_at)` - Find pending/flagged attempts for queue management
- `(device_fingerprint, submitted_at DESC)` - Fraud detection (multiple attempts per device)

**Immutability**:
- No UPDATE operations after creation
- DELETE blocked until 7-year retention expires (business logic enforces)
- Encrypted fields: `extracted_birthdate`, `extracted_name` deleted after 30 days via scheduled cleanup

**Retention Policy**:
- 7-year immutable storage (regulatory requirement)
- Sensitive fields auto-purged after 30 days: `extracted_birthdate`, `extracted_name`, `device_fingerprint`
- Aggregated metrics retained indefinitely for compliance dashboards

---

### 3. IDVProviderIntegration

**Purpose**: Configuration for third-party IDV provider connections (ID.me, Yoti).

**Fields**:

| Field | Type | Constraint | Description |
|-------|------|-----------|-------------|
| provider_id | UUID | PRIMARY KEY | Unique provider configuration ID |
| provider_name | ENUM | NOT NULL | `id_me`, `yoti` |
| oauth_client_id | TEXT | NOT NULL | Provider-issued OAuth client ID (stored in AWS Secrets Manager) |
| oauth_client_secret_id | TEXT | NOT NULL | Reference to AWS Secrets Manager secret ARN |
| authorization_endpoint | TEXT | NOT NULL | Provider OAuth authorize URL |
| token_endpoint | TEXT | NOT NULL | Provider token endpoint |
| userinfo_endpoint | TEXT | NOT NULL | Provider identity endpoint |
| age_assertion_endpoint | TEXT | NOT NULL | Provider endpoint returning age verification claim |
| supported_verification_types | TEXT[] | NOT NULL | Array: `["age_21_plus", "age_18_plus"]` |
| is_active | BOOLEAN | DEFAULT TRUE | Enable/disable provider at runtime |
| rate_limit_per_hour | INT | DEFAULT 1000 | API rate limit for this provider |
| metadata | JSONB | NULL | Provider-specific config: `{idv_level: "two_factor", nist_level: "ial2"}` |
| created_at | TIMESTAMP | DEFAULT NOW() | Configuration creation date |
| updated_at | TIMESTAMP | DEFAULT NOW() ON UPDATE NOW() | Last modification timestamp |

**Indexes**:
- `(provider_name, is_active)` - Query active provider configurations

**Access Control**:
- Backend services only (no API exposure)
- Secrets stored in AWS Secrets Manager
- Configuration changes require admin approval + audit log

---

### 4. AgeRestrictedItem

**Purpose**: Menu items flagged as requiring age verification (managed via spec 002 - Menu Management).

**Fields**:

| Field | Type | Constraint | Description |
|-------|------|-----------|-------------|
| restricted_item_id | UUID | PRIMARY KEY | Unique ID for this restriction record |
| menu_item_id | UUID | NOT NULL | Reference to spec 002 menu_item table |
| restaurant_id | UUID | NOT NULL | Reference to restaurant (tenant isolation) |
| age_requirement | INT | NOT NULL | Required minimum age; typically 21 |
| restricted_substance_type | ENUM | NOT NULL | `alcohol_beverage`, `tobacco`, `both` |
| requires_verification | BOOLEAN | DEFAULT TRUE | Force age verification check (always TRUE in MVP) |
| is_active | BOOLEAN | DEFAULT TRUE | Temporarily disable age restriction |
| created_at | TIMESTAMP | DEFAULT NOW() | When restriction created |
| created_by | UUID | NOT NULL | Restaurant staff member who added restriction |
| updated_at | TIMESTAMP | DEFAULT NOW() ON UPDATE NOW() | Last modification timestamp |

**Indexes**:
- `(restaurant_id, is_active)` - Query age-restricted items for restaurant
- `(menu_item_id)` - Lookup restrictions for menu item during checkout

**Access Control**:
- Restaurant operator: Can view/modify own restaurant's restrictions
- Customer: Cannot view; system enforces at checkout
- Compliance: Can view all restrictions for audit

---

### 5. ManualVerificationRequest

**Purpose**: Support tickets for disputed verification denials or low-confidence OCR results.

**Fields**:

| Field | Type | Constraint | Description |
|-------|------|-----------|-------------|
| request_id | UUID | PRIMARY KEY | Unique manual review request ID |
| attempt_id | UUID | NOT NULL | Reference to original verification_attempt |
| wallet_id | UUID | NOT NULL | Customer requesting review |
| reason | ENUM | NOT NULL | `customer_dispute`, `low_ocr_confidence`, `identity_mismatch`, `other` |
| customer_notes | TEXT | NULL | Customer explanation for dispute |
| uploaded_evidence | JSONB | NULL | Array of uploaded document URLs: `[{document_type: "passport", url: "s3://..."}]` |
| priority | ENUM | DEFAULT "standard" | `express` (user waiting), `standard` (batch) |
| status | ENUM | NOT NULL | `pending`, `in_review`, `approved`, `denied`, `escalated` |
| reviewer_id | UUID | NULL | Staff member conducting review |
| reviewer_notes | TEXT | NULL | Internal review findings |
| resolution_decision | ENUM | NULL | `approved`, `denied`, `escalated` |
| resolution_date | TIMESTAMP | NULL | When review completed |
| target_review_completion | TIMESTAMP | NOT NULL | SLA deadline (24 hours from submission) |
| created_at | TIMESTAMP | DEFAULT NOW() | Request submission timestamp |
| updated_at | TIMESTAMP | DEFAULT NOW() ON UPDATE NOW() | Last status change |

**Indexes**:
- `(status, target_review_completion)` - Find overdue reviews for escalation
- `(wallet_id, created_at DESC)` - Query customer's review history
- `(reviewer_id, status)` - Workload assignment

**SLA Tracking**:
- Standard: 24-hour target resolution
- Express: 2-hour target (customer in-app waiting)
- Escalation alert: If 18+ hours without resolution

---

### 6. VerificationCredentialPublicKey

**Purpose**: Key rotation tracking for RSA signature verification.

**Fields**:

| Field | Type | Constraint | Description |
|-------|------|-----------|-------------|
| key_id | UUID | PRIMARY KEY | Unique key version identifier |
| public_key | TEXT | NOT NULL | PEM-encoded RSA public key (2048-bit) |
| valid_from | TIMESTAMP | NOT NULL | When key became active |
| valid_until | TIMESTAMP | NULL | When key rotated out (null = current) |
| is_current | BOOLEAN | DEFAULT TRUE | Only one key is_current at any time |
| created_at | TIMESTAMP | DEFAULT NOW() | Key generation timestamp |

**Indexes**:
- `(is_current)` - Get current public key for verification
- `(valid_from, valid_until)` - Determine key version for historical credentials

**Key Rotation Strategy**:
- Annual rotation (validity window: 1 year per key)
- 90-day overlap: Old key accepted for 90 days post-rotation
- All credentials signed with issuer_public_key_id for version tracking

---

## Relationships Diagram

```
Customer (spec 008)
    |
    +-- Wallet (spec 008)
            |
            +-- VerificationCredential (active/expired)
                    |
                    +-- created by VerificationAttempt
                    |
                    +-- validated via VerificationCredentialPublicKey

Menu Item (spec 002)
    |
    +-- AgeRestrictedItem (21+ requirement)

VerificationAttempt (immutable audit)
    |
    +-- queued to ManualVerificationRequest (if low confidence)
    |
    +-- resolved by IDVProviderIntegration (if third-party method)
```

---

## State Transitions

### VerificationCredential Lifecycle

```
[Created]
    |
    +-- if issued_at + 5 years < now(): [Expired]
    |
    +-- if fraud detected: [Revoked]
    |
    +-- if customer disputes: [Disputed] → manual review → [Active] or [Revoked]
```

### VerificationAttempt Lifecycle

```
[Submitted]
    |
    +-- OCR processing...
    |
    +-- if confidence >= 0.70 and age >= 21: [Success] → VerificationCredential created
    |
    +-- if confidence < 0.70: [ManualReviewRequired] → ManualVerificationRequest
    |
    +-- if OCR fails: [Failed] (customer retries)
    |
    +-- if low confidence: [ManualReviewRequired] → [ManualReviewApproved] or [ManualReviewDenied]
```

### ManualVerificationRequest Lifecycle

```
[Pending]
    |
    +-- reviewer assigned...
    |
    +-- if > 18 hours: [Escalated]
    |
    +-- if reviewed: [InReview]
    |
    +-- if approved: [Approved] → VerificationCredential created
    |
    +-- if denied: [Denied] (customer notified, can retry)
    |
    +-- if escalated: [Escalated] → manager review
```

---

## Validation Rules

### VerificationCredential Validation
- Credential signature must be valid per issuer_public_key_id
- expires_at must be in future (or credential status = expired)
- wallet_id must reference existing customer wallet
- verified_age_threshold must be 21 (constant in MVP)

### VerificationAttempt Validation
- extracted_birthdate, if present, must indicate age >= 21
- ocr_confidence_score between 0.0 and 1.0
- status must be one of allowed values
- device_fingerprint, if present, must be valid hash format

### AgeRestrictedItem Validation
- age_requirement typically 21 (or 18 for tobacco in some jurisdictions)
- menu_item_id must exist in spec 002
- restaurant_id must exist and be tenant of requestor

### ManualVerificationRequest Validation
- attempt_id must reference existing VerificationAttempt
- reviewer_id, if set, must be valid staff user
- resolution_date can only be set if status = approved/denied/escalated
- target_review_completion must be 24 hours after created_at

---

## Privacy & Security Annotations

### PII Fields (Sensitive)

| Field | Table | Handling |
|-------|-------|----------|
| extracted_birthdate | VerificationAttempt | Encrypted at rest; deleted after 30 days |
| extracted_name | VerificationAttempt | Encrypted at rest; deleted after 30 days |
| device_fingerprint | VerificationAttempt | Hash (not plaintext); deleted after 30 days |
| metadata.last_4_ssn | VerificationCredential | Only for manual review scenarios; access logged |
| ip_address | VerificationAttempt | Masked to /24 CIDR for privacy |

### Audit Logging

All access to sensitive fields must be logged:
- Who accessed (user_id)
- When (timestamp)
- Why (purpose: audit, manual_review, dispute_resolution)
- What (field names accessed)

---

## Indexes Summary

| Table | Index | Purpose |
|-------|-------|---------|
| VerificationCredential | (wallet_id, status, expires_at) | Fetch active credentials |
| VerificationAttempt | (wallet_id, submitted_at) | Customer verification history |
| VerificationAttempt | (status, created_at) | Queue management |
| VerificationAttempt | (device_fingerprint, submitted_at DESC) | Fraud detection |
| AgeRestrictedItem | (restaurant_id, is_active) | Menu filtering |
| ManualVerificationRequest | (status, target_review_completion) | SLA tracking |

---

## Phase 1 Status: COMPLETE

Data model finalized with full schema definitions, relationships, state transitions, and validation rules. Ready for API contracts generation.

