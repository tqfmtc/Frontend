# Feature Specification: Second Screen IVR Experience

**Feature Branch**: `014-second-screen-ivr`
**Created**: 2025-10-29
**Status**: Draft
**Input**: User description: "Second Screen IVR Experience - SMS link sent during IVR call launches mobile app with real-time WebSocket sync showing items being discussed, shopping cart contents, and running total. Dual-mode interaction allows voice (IVR) + visual (mobile app) simultaneously. Seamless handoff enables customer to complete order in app after starting on phone. Visual confirmation of voice-recognized items before adding to cart. Handles connection loss gracefully with independent app operation."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - SMS Link & App Launch During IVR Call (Priority: P1)

Customer receives SMS with app deep link during IVR call that launches mobile app directly to second-screen experience, enabling visual confirmation while continuing voice conversation.

**Why this priority**: Core feature enabling dual-mode interaction. Without SMS link, customers cannot access second screen, blocking entire feature value.

**Independent Test**: Can be fully tested by calling IVR number, receiving SMS with link, tapping link to launch app, and verifying app opens to second-screen session synchronized with IVR call.

**Acceptance Scenarios**:

1. **Given** customer calls IVR number from mobile phone, **When** IVR greeting completes, **Then** SMS is sent within 5 seconds with message "View your order on screen: [link]"
2. **Given** customer receives SMS link, **When** they tap link, **Then** mobile app launches (or installs prompt appears) directly to second-screen view showing current IVR session
3. **Given** customer taps SMS link while not logged in, **When** app launches, **Then** passwordless authentication using phone number from caller ID creates/logs into account automatically
4. **Given** customer calls from landline (non-mobile number), **When** IVR detects landline, **Then** IVR prompts "Enter your mobile number to see your order on screen" and sends SMS to entered number

---

### User Story 2 - Real-Time Cart Synchronization (Priority: P1)

Mobile app displays shopping cart, running total, and current item discussion synchronized in real-time with IVR conversation via WebSocket connection.

**Why this priority**: Essential for second-screen value proposition. Without real-time sync, app becomes stale information instead of live companion experience.

**Independent Test**: Can be fully tested by conducting IVR ordering session with app open, verifying items discussed appear instantly in app, cart updates reflect IVR additions, and total updates in real-time.

**Acceptance Scenarios**:

1. **Given** customer has app open on second screen, **When** IVR adds item to cart via voice, **Then** app displays new item within 1 second with image, name, price, selected modifiers
2. **Given** IVR discusses item details (size, toppings), **When** customer reviews options, **Then** app shows current item being configured with available choices highlighted
3. **Given** cart contains 3 items, **When** customer removes item via IVR voice command, **Then** app removes item from cart display within 1 second and updates total
4. **Given** running total is $24.50, **When** item with $8.99 price is added, **Then** app updates total to $33.49 within 1 second including tax calculation

---

### User Story 3 - Visual Confirmation Before Adding to Cart (Priority: P1)

App displays voice-recognized items with visual confirmation prompt before finalizing addition to cart, reducing order errors from voice misrecognition.

**Why this priority**: Critical for order accuracy. Voice recognition errors (e.g., "cheese pizza" vs "chicken pizza") require visual confirmation to prevent wrong orders.

**Independent Test**: Can be fully tested by saying ambiguous item name on IVR, verifying app shows recognition result with "Confirm to add" button, testing both confirmation and correction flows.

**Acceptance Scenarios**:

1. **Given** customer says "I want a large pepperoni pizza" on IVR, **When** voice recognition completes, **Then** app displays "Large Pepperoni Pizza - $15.99" with "✓ Confirm" and "✗ Not This" buttons
2. **Given** app shows confirmation prompt, **When** customer taps "✓ Confirm", **Then** item is added to cart, IVR proceeds to next step ("Added! Anything else?"), and prompt dismisses
3. **Given** app shows incorrect recognition (wanted "chicken" but heard "cheese"), **When** customer taps "✗ Not This", **Then** IVR prompts "Sorry, let me try again. What would you like?" and clears pending item
4. **Given** customer ignores confirmation for 15 seconds, **When** timeout occurs, **Then** IVR auto-confirms with "I've added that to your order" and item is added to cart

---

### User Story 4 - Seamless Handoff from IVR to App (Priority: P1)

Customer can complete order in mobile app after starting on IVR, preserving cart contents and order state for seamless transition without restarting.

**Why this priority**: Enables flexibility for customers interrupted during IVR call or preferring to finish visually. Key differentiator for user experience.

**Independent Test**: Can be fully tested by adding items via IVR, hanging up phone, reopening app, and verifying cart persists with ability to complete checkout in app.

**Acceptance Scenarios**:

1. **Given** customer adds 3 items to cart via IVR then hangs up, **When** they reopen app within 30 minutes, **Then** cart contents are preserved with banner "Continue your order from phone call?"
2. **Given** IVR session ends mid-order, **When** customer opens app, **Then** they can add more items, modify existing items, and proceed to checkout without calling back
3. **Given** customer completes order in app after IVR handoff, **When** checkout succeeds, **Then** order is processed identically to IVR-completed orders with same fulfillment flow
4. **Given** customer abandons cart (no activity for 2 hours), **When** they reopen app, **Then** cart is cleared and "Previous session expired" message displays with option to start new order

---

### Edge Cases

- What happens when customer doesn't have mobile app installed? SMS link directs to app store with install prompt, after install app opens to session using session token from link.
- How does system handle WebSocket connection loss during IVR call? App displays "Connection lost - Reconnecting..." and attempts reconnection every 5 seconds. IVR continues independently; app syncs state when reconnected.
- What happens when customer taps SMS link after IVR call ends? App opens to cart view with items from completed call, allowing review and modification before checkout.
- How does system handle multiple IVR sessions from same customer? Most recent session takes precedence; app switches to latest session with notification "Switched to new phone order".
- What happens when customer uses second screen on different phone than caller ID? After tapping SMS link, app prompts for verification code sent to caller ID number to prevent unauthorized access.
- How does system handle simultaneous voice + app interactions? App changes take precedence (customer tapped button in app overrides pending IVR voice command) with IVR acknowledging "I see you updated that in the app."

## Requirements *(mandatory)*

### Functional Requirements

#### SMS Link & Session Establishment
- **FR-001**: System MUST send SMS with app deep link within 5 seconds of IVR call start, using caller ID as recipient number
- **FR-002**: System MUST generate unique session token embedded in deep link for secure IVR-app session pairing
- **FR-003**: System MUST support universal deep links that launch app (if installed) or redirect to app store (if not installed)
- **FR-004**: System MUST authenticate customer using phone number from caller ID, creating account automatically if first-time caller
- **FR-005**: System MUST prompt for mobile number via IVR when caller ID is landline or blocked, sending SMS to entered number

#### Real-Time Synchronization
- **FR-006**: System MUST establish WebSocket connection between mobile app and IVR backend using session token from deep link
- **FR-007**: System MUST sync cart state (items, modifiers, quantities, total) from IVR to app within 1 second of changes
- **FR-008**: System MUST sync current item discussion state (item being configured, available options) in real-time
- **FR-009**: System MUST handle bidirectional sync: app modifications (add/remove/edit items) reflect in IVR state immediately
- **FR-010**: System MUST maintain connection heartbeat every 10 seconds, reconnecting automatically on connection loss

#### Visual Confirmation Flow
- **FR-011**: System MUST display voice-recognized item with visual confirmation prompt showing item image, name, price, modifiers
- **FR-012**: System MUST provide "Confirm" and "Not This" action buttons for customer to validate or reject recognized item
- **FR-013**: System MUST notify IVR of confirmation result within 500ms (proceed if confirmed, retry if rejected)
- **FR-014**: System MUST auto-confirm after 15-second timeout if customer doesn't interact, notifying IVR to proceed
- **FR-015**: System MUST display confidence score indicator (high/medium/low) for voice recognition results

#### Seamless Handoff
- **FR-016**: System MUST persist cart contents for 30 minutes after IVR call ends, allowing app completion
- **FR-017**: System MUST provide "Continue Order" prompt in app when reopening after IVR session
- **FR-018**: System MUST allow full checkout completion in app using cart from IVR session
- **FR-019**: System MUST clear expired carts (>2 hours inactive) with notification message on app reopen
- **FR-020**: System MUST sync order completion across channels (if completed in app, mark IVR session as completed)

#### Connection Resilience
- **FR-021**: System MUST display connection status indicator in app (connected, reconnecting, offline)
- **FR-022**: System MUST buffer app actions during connection loss and sync when reconnected
- **FR-023**: System MUST allow app to operate independently if connection cannot be reestablished (customer completes order in app only)
- **FR-024**: System MUST implement exponential backoff for reconnection attempts (5s, 10s, 20s intervals)
- **FR-025**: System MUST sync final state when connection restored, resolving conflicts with "most recent change wins" strategy

### Key Entities

- **SecondScreenSession**: IVR-app pairing with session_id, ivr_call_id, wallet_id, phone_number, websocket_connection_id, session_start_time, last_activity_time, status (active/ended/expired)
- **LiveCartState**: Real-time cart synchronized across IVR and app with session_id, items array, current_item_discussion (item being configured), subtotal, tax, total, last_updated_timestamp
- **VisualConfirmationPrompt**: Pending confirmation for voice-recognized item with prompt_id, session_id, recognized_item, confidence_score, prompt_time, timeout_time, confirmation_status (pending/confirmed/rejected/timeout)
- **SessionHandoff**: Cart persistence for IVR-to-app transition with handoff_id, session_id, cart_snapshot, handoff_time, expiration_time (30 min), completion_status

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 40% of IVR callers tap SMS link to launch second screen within first 30 seconds of call
- **SC-002**: 60% of second-screen users complete orders faster than IVR-only users (average time reduction: 2 minutes)
- **SC-003**: Order accuracy improves by 30% with visual confirmation (reduction in wrong item errors)
- **SC-004**: 80% customer satisfaction rating for second-screen experience in post-order surveys
- **SC-005**: Real-time sync latency averages <1 second for 95% of cart updates
- **SC-006**: WebSocket connection remains stable for 90% of session duration (minimal reconnections)
- **SC-007**: 25% of IVR orders are completed via app handoff (customer starts on phone, finishes in app)
- **SC-008**: Visual confirmation prompts receive response (confirm/reject) within 8 seconds on average
- **SC-009**: Connection loss recovery succeeds within 15 seconds for 95% of incidents
- **SC-010**: Second-screen adoption drives 20% increase in IVR channel usage within 6 months

## Assumptions *(mandatory)*

1. **SMS Delivery**: SMS delivery completes within 5 seconds for 95% of US mobile carriers. International SMS may have higher latency (out of scope for MVP).
2. **App Installation**: 60% of IVR callers have mobile app already installed. 40% require app store redirect and install (potential drop-off point).
3. **WebSocket Support**: Mobile app and backend support WebSocket connections (Socket.io or native WebSocket) for real-time bidirectional communication.
4. **Session Timeout**: 30-minute cart persistence balances server load with reasonable time for customer to complete handoff. Extended persistence is P2 feature.
5. **Caller ID Accuracy**: Caller ID provides accurate phone number for 90% of calls. Landlines and blocked numbers require manual entry fallback.
6. **Connection Reliability**: Average mobile connection supports stable WebSocket for IVR call duration (~5-10 minutes). Connection loss handling covers edge cases.
7. **Voice Recognition**: Olivia.io voice AI provides confidence scores for recognition results. Low-confidence items trigger visual confirmation prompts.
8. **Deep Link Support**: Universal links (iOS) and App Links (Android) work for seamless app launch from SMS. Fallback to web redirect for unsupported devices.
9. **Concurrent Interaction**: Customers can interact with both IVR (voice) and app (touch) simultaneously without conflicts. App takes precedence for conflicting actions.
10. **Data Retention**: Second-screen session logs retained for 30 days for customer support and analytics. WebSocket messages not logged (privacy).

## Constitution Alignment *(mandatory)*

### Principle I: AI-First Architecture
- Visual confirmation prompts leverage Olivia.io voice recognition confidence scores to reduce errors
- AI conversation state (current item discussion) synced to app for context-aware visual display

### Principle III: Privacy-First Customer Data
- WebSocket messages encrypted in transit, no session data logged permanently
- SMS link uses secure session token, no customer PII embedded in URL

### Principle IV: Omnichannel by Default
- Second-screen experience extends IVR channel without replacing it, enhancing with visual companion
- Cart state persists for handoff to mobile app channel, enabling seamless cross-channel completion

### Principle V: Progressive Enhancement & MVP Discipline
- **P1 Features**: SMS link, real-time sync, visual confirmation, basic handoff (FR-001 to FR-020)
- **P2 Features**: Advanced reconnection strategies, conflict resolution AI, session recording/playback

### Principle VII: Integration-Friendly Architecture
- WebSocket API exposed for potential future integrations (third-party apps showing order status)
- Deep link protocol follows industry standards (Universal Links, App Links)

## Dependencies *(mandatory)*

### Internal Dependencies
- **IVR Voice Ordering (spec 003)**: Generates second-screen sessions, sends cart updates, receives confirmation results
- **Mobile App (spec 005)**: Renders second-screen UI, establishes WebSocket connection, handles deep links
- **Notification Infrastructure (spec 010)**: Delivers SMS with deep link to customer phone number
- **Customer Identity (spec 008)**: Authenticates customer via caller ID, links session to wallet
- **Order Fulfillment (spec 006)**: Processes orders completed via app handoff identically to IVR-only orders

### External Dependencies
- **WebSocket Infrastructure**: Socket.io or native WebSocket server for real-time bidirectional communication
- **SMS Gateway**: Twilio (already used in spec 010) for deep link SMS delivery
- **Deep Link Service**: Branch.io, Firebase Dynamic Links, or native Universal Links/App Links configuration

## Future Considerations *(optional)*

### Post-MVP Enhancements (P2/P3)
- **Multi-Party Sessions**: Share second screen with family/friends during group ordering (collaborative cart editing)
- **Voice-to-Text Transcript**: Display real-time transcript of IVR conversation in app for hearing-impaired customers
- **Order History Replay**: Review previous IVR orders with second-screen recordings showing what was discussed
- **Proactive Suggestions**: App recommends items based on voice discussion ("You mentioned dessert - here are our top picks")
- **Visual Menu Browsing**: Customer can browse full menu in app while IVR waits, selecting items to add via touch
- **Payment in App**: Complete payment in app instead of providing card over phone (enhanced security)
- **Desktop Second Screen**: SMS link also works on desktop browser for customers using landline + computer
