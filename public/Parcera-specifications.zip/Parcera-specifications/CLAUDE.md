# Parcera-specs Development Guidelines

Auto-generated from all feature plans. Last updated: 2025-11-03

## Active Technologies
- Python 3.11+ + FastAPI, Celery, Twilio SDK, Firebase Admin SDK, SQLAlchemy, Pydantic (010-notification-infrastructure)
- PostgreSQL (queue, delivery logs, templates, metrics) (010-notification-infrastructure)
- Python 3.11+ (per constitution recommendation) + FastAPI, SQLAlchemy, Pydantic, Twilio SDK, payment gateway SDKs (008-customer-identity)
- PostgreSQL 14+ with row-level security for tenant isolation (008-customer-identity)

- Python 3.11+ (constitution recommendation) or Node.js 18+ (pending decision) + FastAPI (Python) or NestJS (Node.js), PostgreSQL 14+ with row-level security extensions, Redis for session/cache (001-restaurant-management)

## Project Structure

```text
src/
tests/
```

## Commands

cd src [ONLY COMMANDS FOR ACTIVE TECHNOLOGIES][ONLY COMMANDS FOR ACTIVE TECHNOLOGIES] pytest [ONLY COMMANDS FOR ACTIVE TECHNOLOGIES][ONLY COMMANDS FOR ACTIVE TECHNOLOGIES] ruff check .

## Code Style

Python 3.11+ (constitution recommendation) or Node.js 18+ (pending decision): Follow standard conventions

## Recent Changes
- 008-customer-identity: Added Python 3.11+ (per constitution recommendation) + FastAPI, SQLAlchemy, Pydantic, Twilio SDK, payment gateway SDKs
- 010-notification-infrastructure: Added Python 3.11+ + FastAPI, Celery, Twilio SDK, Firebase Admin SDK, SQLAlchemy, Pydantic

- 001-restaurant-management: Added Python 3.11+ (constitution recommendation) or Node.js 18+ (pending decision) + FastAPI (Python) or NestJS (Node.js), PostgreSQL 14+ with row-level security extensions, Redis for session/cache

<!-- MANUAL ADDITIONS START -->
<!-- MANUAL ADDITIONS END -->
